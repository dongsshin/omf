package com.rap.sample.service.impl;

import com.constants.GlobalCommonConstants;
import com.rap.api.object.foundation.model.CPamSearchBaseModel;
import com.rap.api.object.sample.dom.SampleRequest;
import com.rap.api.object.sample.model.SampleRequestVO;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.omc.controller.model.CParmHeaderVO;
import com.rap.omc.controller.service.FoundationRestService;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.util.foundation.CommonApiServiceUtil;
import com.rap.omc.util.foundation.CommonWorkflowHeaderUtil;
import com.rap.sample.service.SampleService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

@Service("sampleService")
@Slf4j
public class SampleServiceImpl implements SampleService {
    @Autowired
    private UserSession userSession;

    @Autowired
    private FoundationRestService foundationRestService;

    /****************************************Code Master*****************************************/
    @Override
    public SampleRequestVO txnCreateSampleRequest(SampleRequestVO sampleRequestVO) {
        SampleRequest inputDom = DomUtil.toDom(sampleRequestVO);
        CParmHeaderVO cParmHeaderVO = CommonWorkflowHeaderUtil.makeHeaderInfo("url","plant","Comments");
        Map<String,Object> parmMap = new HashMap<String,Object>();
        parmMap.put(GlobalCommonConstants.MAP_KEY_WORKFLOW_HEADER_IN,cParmHeaderVO);
        inputDom.createObject(parmMap);
        //if(1==1) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"ddddddddddddddddddd");
        return inputDom.getVo();
    }
    @Override
    public SampleRequestVO txnDeleteSampleRequest(SampleRequestVO sampleRequestVO) {
        SampleRequest objDom = new SampleRequest( sampleRequestVO.getObid() );
        objDom.deleteObject();
        return objDom.getVo();
    }
    @Override
    public SampleRequestVO txnModifySampleRequest(SampleRequestVO sampleRequestVO) {
        SampleRequest objDom = new SampleRequest( sampleRequestVO.getObid());
        DomUtil.copyAttribute(sampleRequestVO,objDom.getVo(),getDefaultSampleRequestUpdateAttr(sampleRequestVO));
        objDom.modifyObject();
        objDom = new SampleRequest( sampleRequestVO.getObid(),true);
        return objDom.getVo();
    }
    @Override
    public SampleRequestVO getSampleRequest(String names) {
        return SampleRequest.findSampleRequest(names);
    }
    @Override
    public SampleRequestVO getSampleRequestWithObid(String sampleRequestObid) {
        SampleRequest obj = new SampleRequest(sampleRequestObid,true);
        return obj.getVo();
    }
    @Override
    public List<SampleRequestVO> getSampleRequestList(SampleRequestVO sampleRequestVO, PagingEntity pagingEntity) {
        return SampleRequest.getSampleRequestList(sampleRequestVO, pagingEntity);
    }
    @Override
    public List<SampleRequestVO> getSampleRequestList(CPamSearchBaseModel searchVOIn) {
        return SampleRequest.getSampleRequestList(searchVOIn);
    }
    private Set<String> getDefaultSampleRequestUpdateAttr(SampleRequestVO sampleRequestVO){
        Set<String> updateAttrSet = new HashSet<String>();
        updateAttrSet.add("partNo");updateAttrSet.add("partDescription");
        updateAttrSet.add("partSpecification");updateAttrSet.add("plantName");
        updateAttrSet.add("descriptions");updateAttrSet.add("titles");
        return updateAttrSet;
    }
}