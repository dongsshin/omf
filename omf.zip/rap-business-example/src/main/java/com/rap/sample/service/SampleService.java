package com.rap.sample.service;


import com.rap.api.object.foundation.model.CPamSearchBaseModel;
import com.rap.api.object.sample.model.SampleRequestVO;
import com.rap.omc.dataaccess.paging.model.PagingEntity;

import java.util.List;

public interface SampleService {
    public SampleRequestVO txnCreateSampleRequest(SampleRequestVO sampleRequestVO);
    public SampleRequestVO txnModifySampleRequest(SampleRequestVO sampleRequestVO);
    public SampleRequestVO txnDeleteSampleRequest(SampleRequestVO sampleRequestVO);

    public SampleRequestVO getSampleRequest(String names);
    public List<SampleRequestVO> getSampleRequestList(SampleRequestVO sampleRequestVO, PagingEntity pagingEntity);
    public List<SampleRequestVO> getSampleRequestList(CPamSearchBaseModel searchVOIn);
    public SampleRequestVO getSampleRequestWithObid(String codeMasterObid);
}