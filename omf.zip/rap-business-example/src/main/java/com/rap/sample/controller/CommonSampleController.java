package com.rap.sample.controller;

import com.constants.GlobalCommonConstants;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.sample.dom.SampleRequest;
import com.rap.api.object.sample.model.SampleRequestVO;
import com.rap.example.constants.AppSchemaExampleConstants;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.PagingUtil;
import com.rap.sample.model.CParmSearchSamplePagingVO;
import com.rap.sample.model.CParmSearchSampleVO;
import com.rap.sample.service.SampleService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@Slf4j
public class CommonSampleController extends RestBaseController {

    @Autowired
    private SampleService sampleService;
    @Autowired
    private UserSession userSession;
    @Autowired
    ApplicationEventPublisher eventPublisher;
    /**************************************★★★ Sample Request Create ★★★ **********************************************/
    @Operation(summary  = "Sample를 Creation하는 API",
            description  = "Sample 제작을 위한 Request를 생성 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"className\":\"SampleRequest\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/example/sample",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createSampleRequest(@RequestBody SampleRequestVO sampleRequestVO) {
        try{
            //TransactionLinkUtil.setNoTransactionLog();
            System.out.println(Thread.currentThread().toString());
            SampleRequestVO sampleVO = sampleService.txnCreateSampleRequest(sampleRequestVO);
            SampleRequest sample = new SampleRequest(sampleVO);
            sample.modifyObject();
/*
            sampleVO = sampleService.txnCreateSampleRequest(sampleRequestVO);
            sampleVO = sampleService.txnCreateSampleRequest(sampleRequestVO);
            sampleVO = sampleService.txnCreateSampleRequest(sampleRequestVO);
            sampleVO = sampleService.txnCreateSampleRequest(sampleRequestVO);
*/
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,sampleVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @Operation(summary  = "Sample를 수정하는 API",
            description  = "Sample Request를 수정 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"obid\":\"$obid\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/example/sample",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifySampleRequest(@RequestBody SampleRequestVO sampleRequestVO) {
        try{
            SampleRequestVO sampleVO = sampleService.txnModifySampleRequest(sampleRequestVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,sampleVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @RequestMapping(value = "/example/sample",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> deleteSampleRequest(@RequestBody SampleRequestVO sampleRequestVO) {
        try{
            SampleRequestVO sampleVO = sampleService.txnDeleteSampleRequest(sampleRequestVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,sampleVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @RequestMapping(value = "/example/sample/{obid}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getSampleRequest(@PathVariable(name = "names") String names) {
        try{
            SampleRequestVO sampleVO = sampleService.getSampleRequest(names);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,sampleVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @Operation(summary  = "Sample를 Creation하는 API",
            description  = "Sample 제작을 위한 Request를 생성 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"className\":\"SampleRequest\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"names\":\"TEST-000001\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/example/samples",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getSampleRequestList(@RequestParam(name = "namePattern"        ,required = false) String namePattern,
                                                                @RequestParam(name = "partNoPattern"      ,required = false) String partNoPattern,
                                                                @RequestParam(name = "partDescription"    ,required = false) String partDescription,
                                                                @RequestParam(name = "partSpecification"  ,required = false) String partSpecification,
                                                                @RequestParam(name = "plantName"          ,required = false) String plantName,
                                                                @RequestParam(name = "states"             ,required = false) String states,
                                                                @RequestParam(name = "creationDateFrom"   ,required = false, defaultValue = "2020-01-01") String creationDateFrom,
                                                                @RequestParam(name = "creationDateTo"     ,required = false, defaultValue = "2022-12-21") String creationDateTo,
                                                                @RequestParam(name = "creator"            ,required = false, defaultValue = "me") String creator,
                                                                @RequestParam(name = "modifier"           ,required = false, defaultValue = "me") String modifier,
                                                                @RequestParam(name ="zz1_targetRow"       ,required = true ,defaultValue = "1") int targetRow,
                                                                @RequestParam(name ="zz2_rowSize"         ,required = true ,defaultValue = "30") int rowSize,
                                                                @RequestParam(name ="zz3_currentPage"     ,required = true ,defaultValue = "1") int currentPage,
                                                                @RequestParam(name ="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{
            PagingEntity pagingEntity = new PagingEntity(targetRow,rowSize,currentPage,sortByPattern);
            SampleRequestVO searchVO = new SampleRequestVO();

            if(!StrUtil.isEmpty(modifier) && modifier.equals("me")) modifier = userSession.getUserId();
            if(!StrUtil.isEmpty(creator) && creator.equals("me"))   creator = userSession.getUserId();

            searchVO.setNames(namePattern);
            searchVO.setPartNo(partNoPattern);
            searchVO.setPartDescription(partDescription);
            searchVO.setPartSpecification(partSpecification);
            searchVO.setPlantName(plantName);
            searchVO.setStates(states);
            searchVO.setModifier(modifier);
            searchVO.setCreator(creator);
            searchVO.setOutDataAttributeValue("creationDateFrom",creationDateFrom);
            searchVO.setOutDataAttributeValue("creationDateTo",creationDateTo);

            List<SampleRequestVO> sampleRequestVOList = sampleService.getSampleRequestList(searchVO,pagingEntity);
            OmfPagingList<SampleRequestVO> pagingList = (OmfPagingList<SampleRequestVO>)sampleRequestVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingList.getPagingEntity());
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,pagingList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @RequestMapping(value = "/example/samples",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getSampleRequestList(@RequestBody CParmSearchSampleVO cParmSearchSampleVO) {
        try{
            List<SampleRequestVO> sampleRequestVOList = sampleService.getSampleRequestList(cParmSearchSampleVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"map"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @RequestMapping(value = "/example/samples/paging",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getSampleRequestListPaging(@RequestBody CParmSearchSamplePagingVO cParmSearchSamplePagingVO) {
        try{
            //Paging에 대한 Validation을 수행한다.
            PagingUtil.validatePagingEntity(cParmSearchSamplePagingVO);
            //조회 조건에 맞는 Paging되어진 List를 조회한다.
            List<SampleRequestVO> sampleRequestVOList = sampleService.getSampleRequestList(cParmSearchSamplePagingVO);

            //결과를 가지고 리스트와 Paging Entity를 분리하여 Return한다.
            OmfPagingList<SampleRequestVO> pagingList = (OmfPagingList<SampleRequestVO>)sampleRequestVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingList.getPagingEntity());
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,pagingList);

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @RequestMapping(value = "/example/samples/test",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> multiTest(@RequestBody SampleRequestVO sampleRequestVO) {
        try{
            List<SampleRequestVO> list = BusinessObject.findObjects(AppSchemaExampleConstants.BIZCLASS_SAMPLEREQUEST,"SP*");
            Set<String> attributeSet = new HashSet<String>();
            attributeSet.add("partSpecification");attributeSet.add("partDescription");
            ObjectRoot.modifyObjectSetBatch(list,attributeSet);
            ObjectRoot.deleteObjectSet(list);

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"sampleVO"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
}