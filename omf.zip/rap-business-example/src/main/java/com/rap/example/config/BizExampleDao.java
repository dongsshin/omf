package com.rap.example.config;

import com.rap.config.datasource.dao.GenericDao;
import com.rap.omc.dataaccess.paging.executer.MyBatisPagingExecutor;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository
public class BizExampleDao extends GenericDao implements InitializingBean{
	@Autowired
	SqlSession bizexampleSqlSession;
	@Autowired
	MyBatisPagingExecutor myBatisPagingExecutor;
	
	@Override
	public void afterPropertiesSet() throws Exception{
		if (super.genricSqlSession == null) super.genricSqlSession = bizexampleSqlSession;
		if (super.pagingExecutor == null) super.pagingExecutor = myBatisPagingExecutor;
	}
}