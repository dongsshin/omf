package com.rap.example.config;


import com.rap.config.datasource.DatabaseProviderUtil;
import com.rap.config.datasource.OmfAtomikosDataSourceBean;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.dataaccess.mybatis.interceptor.LimitCountInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.MyBatisConvertMapInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.MyBatisPagingInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.QueryLoggingInterceptor;
import com.rap.omc.util.PropertiesUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.mapping.VendorDatabaseIdProvider;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;


@Configuration
@Slf4j
public class BizExampleSqlSessionConfig {

	@Bean(name = "bizexampleDataSource")
    public DataSource bizexampleDataSource() {
    	return new OmfAtomikosDataSourceBean("bizexample");
    }
    
	@Bean(name = "bizexampleSqlSessionFactory")
    public SqlSessionFactory exampleSqlSessionFactory(DataSource bizexampleDataSource) throws Exception {
        
    	SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
       
        factoryBean.setDataSource(bizexampleDataSource);

        factoryBean.setMapperLocations(getResources());

        //Multi Database를 위한 환경 설정
        factoryBean.setDatabaseIdProvider(exampleDatabaseIdProvider());

        int sqlMaxCount = PropertiesUtil.getInt("bizexample.maxSqlCount");
        log.info("bizexample.maxSqlCount:" + sqlMaxCount);
        
        factoryBean.setPlugins(new Interceptor[]{
                new QueryLoggingInterceptor(),
                new LimitCountInterceptor(sqlMaxCount,false),
                new MyBatisPagingInterceptor(),
                new MyBatisConvertMapInterceptor()
        });
        factoryBean.getObject().getConfiguration().setMapUnderscoreToCamelCase(true);
        return factoryBean.getObject();
    }
    
	@Bean(name = "bizexampleSqlSession", destroyMethod = "clearCache")
    public SqlSession exampleSqlSession(SqlSessionFactory bizexampleSqlSessionFactory) {
        return new SqlSessionTemplate(bizexampleSqlSessionFactory);
    }
    @Bean
    VendorDatabaseIdProvider exampleDatabaseIdProvider() {
        return DatabaseProviderUtil.databaseIdProvider();
    }
    private Resource[] getResources() throws Exception{
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        //factoryBean.setMapperLocations(resolver.getResources("classpath:mybatis/mapper/foundation/*.xml"));
        Resource[] foundationResources = resolver.getResources(GlobalConstants.FOUNDATION_RESOURCE_LOCATION);
        Resource[] moduleResources = resolver.getResources(GlobalConstants.MODULE_RESOURCE_LOCATION);
        Resource[] resources = new Resource[foundationResources.length+moduleResources.length];

        int i = 0;
        for(int j = 0; j < foundationResources.length; j ++){
            resources[i++] = foundationResources[j];
        }
        for(int j = 0; j < moduleResources.length; j ++){
            resources[i++] = moduleResources[j];
        }
        return resources;
    }
}