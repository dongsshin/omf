package com.rap.example.test.webclienttest;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;


//https://howtodoinjava.com/spring-boot2/resttemplate/spring-restful-client-resttemplate-example/ 참조해서
@Slf4j
public class Sample_Delete {
    public final static void main(String[] args) throws Exception {
        final String uri = "http://localhost:8081//foundation/class/{className}";
        RestTemplate restTemplate = new RestTemplate();


        //Parameter를 가지는 경우
        Map<String, String> params = new HashMap<String, String>();
        params.put("className", "Users");


        HttpHeaders headers = new HttpHeaders();
        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        headers.set("Authorization", "Bearer eyJyZWdEYXRlIjoxNTk5NDQyODk5Njc1LCJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJyb2xlIjpbeyJhdXRob3JpdHkiOiJST0xFXzNEIExpYnJhcmlhbiBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX0FjY2VzcyBHcmFudG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfQ29tcG9uZW50IERldmVsb3BtZW50IEVuZ2luZWVyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfR2VuZXJhbCBNYW5hZ2VyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfR2VuZXJhbCBVc2VyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfSGFyZHdhcmUgQWRtaW5pc3RyYXRvciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX0hhcmR3YXJlIEVuZ2luZWVyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfSGFyZHdhcmUgTGlicmFyaWFuIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfTWVjaGFuaWNhbCBFbmdpbmVlciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX01lY2huaWNhbCBBZG1pbmlzdHJhdG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfUENCIEVuZ2luZWVyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfUHJvY2VzcyBBZG1pbmlzdHJhdG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfUHVyY2hhc2UgRW5naW5lZXIgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9RdWFsaXR5IEFkbWluaXN0cmF0b3IgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9SZXF1aXJlbWVudCBFbmdpbmVlciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX1JlcXVpcmVtZW50IE1hbmFnZXIgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9Tb2Z0d2FyZSBBZG1pbmlzdHJhdG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfU29mdHdhcmUgRW5naW5lZXIgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9TdXBwbGllciBFbmdpbmVlciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX1N5c3RlbSBBZG1pbmlzdHJhdGlvbiBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX1VTRVIifV0sImlkIjoiWFAzODY2IiwiZXhwIjoxNjAyMDM0ODk5fQ._2kkTpqulWoKfyuGD9wiGSwMxjdKUOJ-RcH0DzXn8AE");
        HttpEntity<String> entity = new HttpEntity<String>(headers);



        //ResponseEntity<Object> response = restTemplate.exchange(uri, HttpMethod.GET, entity, Object.class);
        ResponseEntity<Object> response = restTemplate.postForEntity(uri, entity, Object.class,params);

        System.out.println(response);
        if(response.getStatusCode() == HttpStatus.OK){
            LinkedHashMap<String,Object> map = (LinkedHashMap<String,Object>)response.getBody();
            Object data = map.get("data");
            log.debug(data.toString());
            log.debug("Success-debug-success");
            log.info("Success-debug-success");
            log.trace("Success-debug-success");
        }else{
            log.debug("Success-debug-fali");
            log.info("Success-debug-fali");
            log.trace("Success-debug-fali");
        }

    }
}