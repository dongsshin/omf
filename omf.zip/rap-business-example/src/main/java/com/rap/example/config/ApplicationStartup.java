package com.rap.example.config;

import com.rap.config.OmfApplicationStartupBase;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.util.CommonCodeSyncUtil;
import com.rap.omc.util.PropertiesUtil;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class ApplicationStartup extends OmfApplicationStartupBase implements InitializingBean, ApplicationListener<ApplicationReadyEvent> {
    @Override
    public void onApplicationEvent(final ApplicationReadyEvent event) {
        super.onApplicationEvent(event);
        //Code Below
        //CommonCodeSyncUtil.synchronizeCodes();
    }
    @Override
    public void afterPropertiesSet() throws Exception {
        this.setDatasourceName(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_DATASOURCE_NAME));
    }
}