package com.rap.example.constants;

import com.rap.omc.core.util.PropertyUtil;

public class AppSchemaExampleConstants{
    public static final String LIFECYCLE_ECO = PropertyUtil.getProperty("LIFECYCLE_ECO");
    public static final String LIFECYCLE_SAMPLE = PropertyUtil.getProperty("LIFECYCLE_SAMPLE");
    public static final String LIFECYCLE_ADMINISTRATIVE_OBJECT = PropertyUtil.getProperty("LIFECYCLE_ADMINISTRATIVE_OBJECT");
    public static final String LIFECYCLE_WITHOUT_STATE = PropertyUtil.getProperty("LIFECYCLE_WITHOUT_STATE");
    public static final String LIFECYCLE_ACTIVE_INACTIVE = PropertyUtil.getProperty("LIFECYCLE_ACTIVE_INACTIVE");
    public static final String LIFECYCLE_SAMPLE_REQUEST = PropertyUtil.getProperty("LIFECYCLE_SAMPLE_REQUEST");
    public static final String STATE_ECO_1STPROCESSING = PropertyUtil.getProperty("STATE_ECO_1stProcessing");
    public static final String STATE_ECO_2NDPROCESSING = PropertyUtil.getProperty("STATE_ECO_2ndProcessing");
    public static final String STATE_ECO_CANCELLED = PropertyUtil.getProperty("STATE_ECO_Cancelled");
    public static final String STATE_ECO_IMPLEMENTED = PropertyUtil.getProperty("STATE_ECO_Implemented");
    public static final String STATE_ECO_INCOLLABORATION = PropertyUtil.getProperty("STATE_ECO_InCollaboration");
    public static final String STATE_ECO_RELEASE = PropertyUtil.getProperty("STATE_ECO_Release");
    public static final String STATE_ECO_WORKING = PropertyUtil.getProperty("STATE_ECO_Working");
    public static final String STATE_SAMPLE_WORKING = PropertyUtil.getProperty("STATE_SAMPLE_Working");
    public static final String STATE_ADMINISTRATIVE_OBJECT_EXISTS = PropertyUtil.getProperty("STATE_ADMINISTRATIVE_OBJECT_Exists");
    public static final String STATE_WITHOUT_STATE_EXISTS = PropertyUtil.getProperty("STATE_WITHOUT_STATE_Exists");
    public static final String STATE_ACTIVE_INACTIVE_ACTIVE = PropertyUtil.getProperty("STATE_ACTIVE_INACTIVE_Active");
    public static final String STATE_ACTIVE_INACTIVE_INACTIVE = PropertyUtil.getProperty("STATE_ACTIVE_INACTIVE_Inactive");
    public static final String STATE_SAMPLE_REQUEST_1STPROCESSING = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_1stProcessing");
    public static final String STATE_SAMPLE_REQUEST_2NDPROCESSING = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_2ndProcessing");
    public static final String STATE_SAMPLE_REQUEST_CANCELLED = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_Cancelled");
    public static final String STATE_SAMPLE_REQUEST_COMPLETED = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_Completed");
    public static final String STATE_SAMPLE_REQUEST_IFREQUESTED = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_IFRequested");
    public static final String STATE_SAMPLE_REQUEST_WORKING = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_Working");
    public static final String BIZCLASS_DEMOSAMPLETO = PropertyUtil.getProperty("BIZCLASS_DEMOSAMPLETO");
    public static final String BIZCLASS_BUSINESSOBJECTSAMPLE = PropertyUtil.getProperty("BIZCLASS_BUSINESSOBJECTSAMPLE");
    public static final String BIZCLASS_DEMOSAMPLEOBJECT = PropertyUtil.getProperty("BIZCLASS_DEMOSAMPLEOBJECT");
    public static final String BIZCLASS_DEMOSAMPLEFROM = PropertyUtil.getProperty("BIZCLASS_DEMOSAMPLEFROM");
    public static final String BIZCLASS_SAMPLEREQUEST = PropertyUtil.getProperty("BIZCLASS_SAMPLEREQUEST");
    public static final String BIZCLASS_BUSINESSOBJECTSAMPLE1 = PropertyUtil.getProperty("BIZCLASS_BUSINESSOBJECTSAMPLE1");
    public static final String BIZCLASS_BUSINESSOBJECTSAMPLE2 = PropertyUtil.getProperty("BIZCLASS_BUSINESSOBJECTSAMPLE2");
    public static final String RELCLASS_WORKFLOWRELATIONSAMPLE3 = PropertyUtil.getProperty("RELCLASS_WORKFLOWRELATIONSAMPLE3");
    public static final String RELCLASS_WORKFLOWRELATIONSAMPLE2 = PropertyUtil.getProperty("RELCLASS_WORKFLOWRELATIONSAMPLE2");
    public static final String RELCLASS_WORKFLOWRELATIONSAMPLE1 = PropertyUtil.getProperty("RELCLASS_WORKFLOWRELATIONSAMPLE1");
    public static final String RELCLASS_DEMORELATION = PropertyUtil.getProperty("RELCLASS_DEMORELATION");
    public static final String RELCLASS_WORKFLOWRELATIONSAMPLE4 = PropertyUtil.getProperty("RELCLASS_WORKFLOWRELATIONSAMPLE4");
}
