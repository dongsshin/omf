package com.rap.batch.config;


import com.rap.omc.util.PropertiesUtil;
import com.rap.config.datasource.OmfAtomikosDataSourceBean;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.dataaccess.mybatis.interceptor.LimitCountInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.MyBatisConvertMapInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.MyBatisPagingInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.QueryLoggingInterceptor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;


@Configuration
@Slf4j
public class BatchSqlSessionConfig {

	@Bean(name = "batchDataSource")
    public DataSource batchDataSource() {
    	return new OmfAtomikosDataSourceBean("batch");
    }
    
	@Bean(name = "batchSqlSessionFactory")
    public SqlSessionFactory batchSqlSessionFactory(DataSource batchDataSource) throws Exception {
        
    	SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
       
        factoryBean.setDataSource(batchDataSource);
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        //factoryBean.setMapperLocations(resolver.getResources("classpath:mybatis/mapper/foundation/*.xml"));
        factoryBean.setMapperLocations(resolver.getResources(GlobalConstants.FOUNDATION_RESOURCE_LOCATION));

        int sqlMaxCount = PropertiesUtil.getInt("batch.maxSqlCount");
        log.info("batch.maxSqlCount:" + sqlMaxCount);
        
        factoryBean.setPlugins(new Interceptor[]{
                new QueryLoggingInterceptor(),
                new LimitCountInterceptor(sqlMaxCount,false),
                new MyBatisPagingInterceptor(),
                new MyBatisConvertMapInterceptor()
        });
        factoryBean.getObject().getConfiguration().setMapUnderscoreToCamelCase(true);
        return factoryBean.getObject();
    }
    
	@Bean(name = "batchSqlSession", destroyMethod = "clearCache")
    public SqlSession batchSqlSession(SqlSessionFactory batchSqlSessionFactory) {
        return new SqlSessionTemplate(batchSqlSessionFactory);
    }
}