# Getting Started

## Batch Job 및 I/F를 위해서 정의되어진 모듈
아직 구체적인 설계 및 방향성이 정의되어져 있지 않다.