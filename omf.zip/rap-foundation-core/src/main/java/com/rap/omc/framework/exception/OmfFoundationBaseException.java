package com.rap.omc.framework.exception;

import com.rap.omc.core.util.MessageUtil;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

public class OmfFoundationBaseException extends OmfBaseException
{
    private static final long serialVersionUID = 1L;
    public OmfFoundationBaseException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfFoundationBaseException(HttpStatus httpStatus, String code, String message, Throwable cause)
    {
        super(httpStatus,code, message, cause);
    }
    public OmfFoundationBaseException(HttpStatus httpStatus, Throwable cause) {
        super(httpStatus,cause);
    }
    public OmfFoundationBaseException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, MessageUtil.getMessage(code), cause);
    }
    public OmfFoundationBaseException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfFoundationBaseException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfFoundationBaseException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
    public String toString()
    {
        String str = super.getClass().getName();
        String message = super.getMessage();
        return ((message != null) ? str + ": " + message : str);
    }
}