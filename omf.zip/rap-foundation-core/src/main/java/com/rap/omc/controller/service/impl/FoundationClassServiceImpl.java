package com.rap.omc.controller.service.impl;

import com.rap.omc.controller.service.FoundationClassService;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.util.foundation.ClassInfoUtil;
import org.springframework.stereotype.Service;

import java.util.HashMap;

@Service("foundationClassService")
public class FoundationClassServiceImpl implements FoundationClassService {
    @Override
    public HashMap<String, Object> getClassSchemaInfo() {
        return null;
    }

    @Override
    public HashMap<String, Object> getClassSchemaForJson() {
        return null;
    }

    @Override
    public ClassInfo getClassSchemaDetail(String className) {
        return ClassInfoUtil.getClassInfo(className);
    }
}
