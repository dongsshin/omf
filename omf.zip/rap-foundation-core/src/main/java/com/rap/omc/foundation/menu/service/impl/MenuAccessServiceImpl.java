/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : MemuInfoServiceImpl.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2017. 4. 24.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.omc.foundation.menu.service.impl;

import com.rap.omc.util.StrUtil;
import com.rap.omc.foundation.menu.service.MenuAccessService;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.object.dom.OmcSchemaUserCommon;
import com.rap.omc.schema.object.dom.OmcSchemaUserGroup;
import com.rap.omc.schema.object.dom.OmcSchemaUserRole;
import com.rap.omc.schema.object.dom.OmcSchemaUserUser;
import com.rap.omc.schema.object.model.OmcSchemaMenuVO;
import com.rap.omc.schema.object.model.OmcSchemaUserVO;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSchemaServiceUtils;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * Class : MemuInfoServiceImpl
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
@Service("menuAccessService")
public class MenuAccessServiceImpl implements MenuAccessService {
    @Override
    public void txnAddMenuForRole(String role, String menu, Map<String, String> map){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(role);
        if(NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Role(" + role + ") Not Found");

        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]" + role + " is not Role");
        OmcSchemaUserRole roleDom = new OmcSchemaUserRole(schemaUserVO);
        roleDom.addMenu(menu, OmcSystemConstants.SYSREL_KIND_RoleMenu,map);
    }
    @Override
    public void txnAddMenuForRole(String role, List<String> menuList, Map<String, String> map){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(role);
        if(NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Role(" + role + ") Not Found");

        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]" + role + " is not Role");
        OmcSchemaUserRole roleDom = new OmcSchemaUserRole(schemaUserVO);
        for(String menu : menuList){
            roleDom.addMenu(menu, OmcSystemConstants.SYSREL_KIND_RoleMenu,map);
        }
    }
    @Override
    public void txnAddMenuForGroup(String group, String menu, Map<String, String> map){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        if(NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Group(" + group + ") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]" + group + " is not Group");
        OmcSchemaUserGroup groupDom = new OmcSchemaUserGroup(schemaUserVO);
        groupDom.addMenu(menu, OmcSystemConstants.SYSREL_KIND_GroupMenu,map);
    }
    @Override
    public void txnAddMenuForGroup(String group, List<String> menuList, Map<String, String> map){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        if(NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Group(" + group + ") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]" + group + " is not Group");
        OmcSchemaUserGroup groupDom = new OmcSchemaUserGroup(schemaUserVO);
        for(String menu : menuList){
            groupDom.addMenu(menu, OmcSystemConstants.SYSREL_KIND_GroupMenu,map);
        }
    }
    @Override
    public void txnAddMenuForUser(String user, String menu, Map<String, String> map){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(user);
        if(NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]User(" + user + ") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_User)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]" + user + " is not User");
        OmcSchemaUserUser userDom = new OmcSchemaUserUser(schemaUserVO);
        userDom.addMenu(menu, OmcSystemConstants.SYSREL_KIND_UserMenu,map);
    }
    @Override
    public void txnAddMenuForUser(String user, List<String> menuList, Map<String, String> map){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(user);
        if(NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]User(" + user + ") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_User)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]" + user + " is not User");
        OmcSchemaUserUser userDom = new OmcSchemaUserUser(schemaUserVO);
        for(String menu : menuList){
            userDom.addMenu(menu, OmcSystemConstants.SYSREL_KIND_UserMenu,map);
        }
    }
    @Override
    public void txnAddMenuForRole(List<String> roleList, String menu, Map<String,String> map){
        for(String role : roleList){
            txnAddMenuForRole(role, menu, map);
        }
    }
    @Override
    public void txnAddMenuForRole(List<String> roleList, List<String> menuList, Map<String,String> map){

        for(String role : roleList){
            txnAddMenuForRole(role, menuList, map);
        }
    }
    @Override
    public void txnAddMenuForGroup(List<String> groupList, String menu, Map<String,String> map){

        for(String group : groupList){
            txnAddMenuForGroup(group, menu, map);
        }
    }
    @Override
    public void txnAddMenuForGroup(List<String> groupList, List<String> menuList, Map<String,String> map){

        for(String group : groupList){
            txnAddMenuForGroup(group, menuList, map);
        }
    }
    @Override
    public void txnAddMenuForUser(List<String> userIdList, String menu, Map<String,String> map){

        for(String userId : userIdList){
            txnAddMenuForUser(userId, menu, map);
        }
    }
    @Override
    public void txnAddMenuForUser(List<String> userIdList, List<String> menuList, Map<String,String> map){
        for(String userId : userIdList){
            txnAddMenuForUser(userId, menuList, map);
        }
    }
    @Override
    public void txnRemoveMenuForRole(String role, String menu){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(role);
        OmcSchemaUserRole roleDom = new OmcSchemaUserRole(schemaUserVO);
        roleDom.removeMenu(menu, OmcSystemConstants.SYSREL_KIND_RoleMenu);
    }
    @Override
    public void txnRemoveMenuForRole(String role, List<String> menuList){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(role);
        OmcSchemaUserRole roleDom = new OmcSchemaUserRole(schemaUserVO);
        for(String menu : menuList){
            roleDom.removeMenu(menu, OmcSystemConstants.SYSREL_KIND_RoleMenu);
        }
    }
    @Override
    public void txnRemoveMenuForGroup(String group, String menu){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        OmcSchemaUserGroup roleDom = new OmcSchemaUserGroup(schemaUserVO);
        roleDom.removeMenu(menu, OmcSystemConstants.SYSREL_KIND_GroupMenu);
    }
    @Override
    public void txnRemoveMenuForGroup(String group, List<String> menuList){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        OmcSchemaUserGroup roleDom = new OmcSchemaUserGroup(schemaUserVO);
        for(String menu : menuList){
            roleDom.removeMenu(menu, OmcSystemConstants.SYSREL_KIND_GroupMenu);
        }
    }
    @Override
    public void txnRemoveMenuForUser(String userId, String menu){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        OmcSchemaUserUser roleDom = new OmcSchemaUserUser(schemaUserVO);
        roleDom.removeMenu(menu, OmcSystemConstants.SYSREL_KIND_UserMenu);
    }
    @Override
    public void txnRemoveMenuForUser(String userId, List<String> menuList){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        OmcSchemaUserUser roleDom = new OmcSchemaUserUser(schemaUserVO);
        for(String menu : menuList){
            roleDom.removeMenu(menu, OmcSystemConstants.SYSREL_KIND_UserMenu);
        }
    }
    @Override
    public void txnRemoveMenuForRole(List<String> roleList, String menu){

        for(String role : roleList){
            txnRemoveMenuForRole(role,menu);
        }
    }
    @Override
    public void txnRemoveMenuForRole(List<String> roleList, List<String> menuList){

        for(String menu : menuList){
            txnRemoveMenuForRole(roleList,menu);
        }
    }
    @Override
    public void txnRemoveMenuForGroup(List<String> groupList, String menu){

        for(String group : groupList){
            txnRemoveMenuForGroup(group,menu);
        }
    }
    @Override
    public void txnRemoveMenuForGroup(List<String> groupList, List<String> menuList){

        for(String menu : menuList){
            txnRemoveMenuForGroup(groupList,menu);
        }
    }
    @Override
    public void txnRemoveMenuForUser(List<String> userIdList, String menu){

        for(String userId : userIdList){
            txnRemoveMenuForUser(userId,menu);
        }
    }
    @Override
    public void txnRemoveMenuForUser(List<String> userIdList, List<String> menuList){

        for(String menu : menuList){
            txnRemoveMenuForUser(userIdList,menu);
        }
    }
    @Override
    public List<OmcSchemaMenuVO> getMenuListForRole(String role){

        return(getMenuListForRole(role,false));
    }
    @Override
    public List<OmcSchemaMenuVO> getMenuListForRole(String role, boolean expand){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(role);
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + role + "' is not Role.");
        OmcSchemaUserGroup roleDom = new OmcSchemaUserGroup(schemaUserVO);
        List<OmcSchemaMenuVO> rsult = roleDom.getMenuList();
        return rsult;
    }
    @Override
    public List<OmcSchemaMenuVO> getMenuListForGroup(String group){

        return(getMenuListForGroup(group,false));
    }
    @Override
    public List<OmcSchemaMenuVO> getMenuListForGroup(String group, boolean expand){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + group + "' is not Group.");
        OmcSchemaUserGroup roleDom = new OmcSchemaUserGroup(schemaUserVO);
        List<OmcSchemaMenuVO> rsult = roleDom.getMenuList();
        return rsult;
    }
    @Override
    public List<OmcSchemaMenuVO> getMenuListForUser(String userId){

        return(getMenuListForUser(userId,false));
    }
    @Override
    public List<OmcSchemaMenuVO> getMenuListForUser(String userId, boolean expand){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_User)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + userId + "' is not User.");
        OmcSchemaUserGroup roleDom = new OmcSchemaUserGroup(schemaUserVO);
        List<OmcSchemaMenuVO> rsult = roleDom.getMenuList();
        return rsult;
    }
    @Override
    public List<OmcSchemaMenuVO> getMenuListForCommonUserWithNames(List<String> nameList,boolean expand){
        return OmcSchemaUserCommon.getMenuListForSetWithNames(nameList,expand);
    }
    @Override
    public Set<String> getMenuSetForCommonUserWithNames(List<String> nameList, boolean expand){
        List<String> result = OmcSchemaUserCommon.getMenuSetForSetWithNames(nameList);
        return StrUtil.convertListToSet(result);
    }
}
