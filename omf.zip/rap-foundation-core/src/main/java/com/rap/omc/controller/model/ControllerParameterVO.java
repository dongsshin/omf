package com.rap.omc.controller.model;

import com.rap.api.object.foundation.model.BaseModel;
import com.rap.omc.schema.util.OmcSchemaConstants;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
public class ControllerParameterVO extends BaseModel {

    private String parameterName;
    private String parameterDescription;
    private String parameterExample;
    private String parameterDefinedType;
    private String parameterMethodFullType;
    private String parameterMethodType;
    private String parameterAnnotation;
    private Integer parameterIndex;
    private String obid;
    private String creator  = OmcSchemaConstants.C_SCHEMA_DEFAULT_USER;
    private Date created;
    private String modifier = OmcSchemaConstants.C_SCHEMA_DEFAULT_USER;
    private Date   modified;

}
