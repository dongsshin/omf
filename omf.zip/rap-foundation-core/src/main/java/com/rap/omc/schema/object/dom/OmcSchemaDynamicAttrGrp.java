/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : OmcSchemaDynamicAttrGrp.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2017. 3. 23.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.omc.schema.object.dom;

import java.util.List;
import java.util.Map;

import com.rap.omc.schema.object.model.OmcSchemaDynamicAttrGrpVO;
import com.rap.omc.schema.object.model.OmcSchemaSysRootVO;


/**
 * <pre>
 * Class : OmcSchemaDynamicAttrGrp
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public class OmcSchemaDynamicAttrGrp extends OmcSchemaSysRoot{

    /**
     * 
     * @param map
     * @see com.rap.omc.schema.object.dom.OmcSchemaSysRoot#create(java.util.Map)
     */
    @Override
    protected void create(Map map){
        // TODO Auto-generated method stub
        
    }

    /**
     * 
     * @param map
     * @see com.rap.omc.schema.object.dom.OmcSchemaSysRoot#inActivate(java.util.Map)
     */
    @Override
    protected void inActivate(Map map){
        // TODO Auto-generated method stub
        
    }

    /**
     * 
     * @param map
     * @see com.rap.omc.schema.object.dom.OmcSchemaSysRoot#delete(java.util.Map)
     */
    @Override
    protected void delete(Map map){
        // TODO Auto-generated method stub
        
    }

    /**
     * 
     * @param map
     * @see com.rap.omc.schema.object.dom.OmcSchemaSysRoot#modify(java.util.Map)
     */
    @Override
    protected void modify(Map map){
        // TODO Auto-generated method stub
        
    }

    /**
     * 
     * @param Names
     * @return
     * @see com.rap.omc.schema.object.dom.OmcSchemaSysRoot#getObjectInfoByName(java.lang.String)
     */
    @Override
    protected OmcSchemaSysRootVO getObjectInfoByName(String Names){
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * 
     * @see com.rap.omc.schema.object.dom.OmcSchemaSysRoot#setFlags()
     */
    @Override
    protected void setFlags(){
        // TODO Auto-generated method stub
        
    }

    /**
     * 
     * @see com.rap.omc.schema.object.dom.OmcSchemaSysRoot#setClassKind()
     */
    @Override
    protected void setClassKind(){
        // TODO Auto-generated method stub
        
    }
    public static void uploadTemporaryList(List<OmcSchemaDynamicAttrGrpVO> list){
        ;
    }
}
