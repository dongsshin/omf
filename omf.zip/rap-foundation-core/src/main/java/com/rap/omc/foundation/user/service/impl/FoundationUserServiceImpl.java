/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : UserPropertyServiceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 3. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.user.service.impl;

import com.event.publish.vo.EventUserVO;
import com.rap.config.datasource.dao.GenericDao;
import com.rap.config.datasource.dao.SchemaDao;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.UserPropertyConstants;
import com.rap.omc.controller.model.CUserPropertyVO;
import com.rap.omc.core.oql.model.OmcSQLVariableParameter;
import com.rap.omc.core.oql.utility.OmcFoundationConstant;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.foundation.user.model.*;
import com.rap.omc.foundation.user.service.FoundationUserService;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.object.dom.*;
import com.rap.omc.schema.object.model.OmcSchemaPropertyVO;
import com.rap.omc.schema.object.model.OmcSchemaUserVO;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSchemaServiceUtils;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;

/**
 * <pre>
 * Class : UserServiceImpl
 * Description : TODO
 * </pre>
 * 
 * @author hyeyoung.park
 */
@Service("foundationUserService")
public class FoundationUserServiceImpl implements FoundationUserService {
    @Resource(name = "schemaDao")
    private SchemaDao schemaDao;
    /**
     * 
     * 
     * @param searchVO
     * @return
     * @see FoundationUserService#getCommonUserList(com.rap.omc.foundation.user.model.CommonUserSearchVO)
     */
    @Override
    public List<OmcSchemaUserVO> getCommonUserList(CommonUserSearchVO searchVO){
        return(OmcSchemaServiceUtils.getCommonUserList(searchVO));
    }
    /**
     * 
     * 
     * @param input
     * @see FoundationUserService#txnCreateUser(com.rap.omc.foundation.user.model.SysUserVO)
     */
    @Override
    public void txnCreateUser(SysUserVO input){
        String creator = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO omcUserVO = new OmcSchemaUserVO();
        omcUserVO.setKindsStr("User");
        omcUserVO.setNames(input.getUserId());
        omcUserVO.setParent("1");
        omcUserVO.setDescriptions(input.getDescriptions());
        omcUserVO.setPassword(input.getPassword());
        omcUserVO.setCreator(creator);
        omcUserVO.setModifier(creator);
        omcUserVO.setSite(input.getSite());
        OmcSchemaUserUser dom  = new OmcSchemaUserUser(omcUserVO);
        dom.createObject(new HashMap<String,Object>());
        txnSetPropertyValueList(input.getUserId(),input.getPropertyList());
        txnAddRoleToUser(input.getUserId(),input.getRoleSet());
    }
    /**
     * 
     * 
     * @param userId
     * @param userName
     * @param site
     * @param departmentCode
     * @param departmentDesc
     * @param departmentDescKor
     * @param mailId
     * @see FoundationUserService#txnCreateUser(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void txnCreateUser(String userId, String userName, String site, String departmentCode, String departmentDesc, String departmentDescKor, String mailId){
        String creator = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO omcUserVO = new OmcSchemaUserVO();
        omcUserVO.setNames(userId);
        omcUserVO.setParent("1");
        omcUserVO.setDescriptions(userName);
        omcUserVO.setPassword(userName);
        omcUserVO.setCreator(creator);
        omcUserVO.setModifier(creator);
        omcUserVO.setSite(site);
        OmcSchemaUserUser dom  = new OmcSchemaUserUser(omcUserVO);
        dom.createObject(new HashMap<String,Object>());
    }
    /**
     * 
     * 
     * @param userId
     * @param userName
     * @param site
     * @param mailId
     * @see FoundationUserService#txnCreateUser(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void txnCreateUser(String userId, String userName, String site, String mailId){
        txnCreateUser(userId,userName,site,"-","-","-",mailId);
    }
    /**
     * 
     * 
     * @param userId
     * @param userName
     * @see FoundationUserService#txnCreateUser(java.lang.String, java.lang.String)
     */
    @Override
    public void txnCreateUser(String userId, String userName){
        txnCreateUser(userId,userName,"LG","-","-","-","-");
    }
    /**
     * 
     * 
     * @param role
     * @param roleName
     * @see FoundationUserService#txnCreateRole(java.lang.String, java.lang.String)
     */
    @Override
    public OmcSchemaUserVO txnCreateRole(String role, String roleName){
        String creator = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO omcUserVO = new OmcSchemaUserVO();
        omcUserVO.setNames(role);
        omcUserVO.setParent("1");
        omcUserVO.setDescriptions(roleName);
        omcUserVO.setPassword("-");
        omcUserVO.setCreator(creator);
        omcUserVO.setModifier(creator);
        omcUserVO.setSite("-");
        OmcSchemaUserRole dom  = new OmcSchemaUserRole(omcUserVO);
        dom.createObject(new HashMap<String,Object>());
        return dom.getVo();
    }
    /**
     * 
     * 
     * @param group
     * @param groupName
     * @see FoundationUserService#txnCreateGroup(java.lang.String, java.lang.String)
     */
    @Override
    public OmcSchemaUserVO txnCreateGroup(String group, String groupName){
        String creator = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO omcUserVO = new OmcSchemaUserVO();
        omcUserVO.setNames(group);
        omcUserVO.setParent("1");
        omcUserVO.setDescriptions(groupName);
        omcUserVO.setPassword("-");
        omcUserVO.setCreator(creator);
        omcUserVO.setModifier(creator);
        omcUserVO.setSite("-");
        OmcSchemaUserGroup dom  = new OmcSchemaUserGroup(omcUserVO);
        dom.createObject(new HashMap<String,Object>());
        return dom.getVo();
    }  
    /**
     * 
     * 
     * @param roleGroup
     * @param roleGroupName
     * @see FoundationUserService#txnCreateRoleGroup(java.lang.String, java.lang.String)
     */
    @Override
    public void txnCreateRoleGroup(String roleGroup, String roleGroupName){
        String creator = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO omcUserVO = new OmcSchemaUserVO();
        omcUserVO.setNames(roleGroup);
        omcUserVO.setParent("1");
        omcUserVO.setDescriptions(roleGroupName);
        omcUserVO.setPassword("-");
        omcUserVO.setCreator(creator);
        omcUserVO.setModifier(creator);
        omcUserVO.setSite("-");
        OmcSchemaUserRoleGroup dom  = new OmcSchemaUserRoleGroup(omcUserVO);
        dom.createObject(new HashMap<String,Object>());
    }  
    /**
     * 
     * 
     * @param userId
     * @see FoundationUserService#txnActivate(java.lang.String)
     */
    //------------------------------ Activiate User------------------------------------
    @Override
    public void txnActivate(String userId){
        String modifier = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        schemaUserVO.setModifier(modifier);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.modifyObject(new HashMap<String,Object>());
    }
    /**
     * 
     * 
     * @param userId
     * @see FoundationUserService#txnInActivate(java.lang.String)
     */
    @Override
    public void txnInActivate(String userId){
        String modifier = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        schemaUserVO.setModifier(modifier);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.inActiviateObject(new HashMap<String,Object>());
    }

    @Override
    public void txnChangePassword(String userId, String newPassword) {
        String modifier = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        schemaUserVO.setModifier(modifier);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.changePassword(newPassword);
    }

    /**
     * 
     * 
     * @param userId
     * @return
     * @see FoundationUserService#getUserInfo(java.lang.String)
     */

    @Cacheable(value = "sysUserInfoCache", key = "#userId")
    @Override
    public SysUserVO getUserInfo(String userId){
        return getUserInfo(userId,false);
    }
    @Cacheable(value = "sysUserInfoCache", key = "#userId")
    @Override
    public SysUserVO getUserInfo(String userId, boolean includePwd){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId,includePwd);
        if(NullUtil.isNull(schemaUserVO)) return null;
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_User)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"{} is not user.",userId);
        SysUserVO susUserVO = new SysUserVO(schemaUserVO);
        susUserVO.setPropertyList(getPropertyList(userId));
        susUserVO.setRoleSet(getRoleList(userId));
        susUserVO.setGroupSet(getGroupList(userId));
        return susUserVO;
    }
    @Override
    public String getTimeStamp(String userId){
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("userId",userId);
        return schemaDao.select("OmcUser.getUserTimestamp", map);
    }
    @Override
    public List<EventUserVO> getMustBeSynchronizedList(String databaseBeanName){
        Map<String,String> map = new HashMap<String,String>();
        map.put("databaseBeanName","@" + databaseBeanName + "@");
        return schemaDao.selectList("OmcUser.getMustBeSynchronizedList",map);
    }
    @Override
    public void txnSynchronize(GenericDao genericDao, EventUserVO eventUserVO){
        synchronizeSub(genericDao,eventUserVO);
    }

    @Override
    public void synchronizeUser(GenericDao genericDao, EventUserVO eventUserVO){
        synchronizeSub(genericDao,eventUserVO);
    }
    private void synchronizeSub(GenericDao genericDao, EventUserVO asynchUserVO){
        if(genericDao instanceof SchemaDao) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Schema Database cannot be synchronized!");
        StringBuffer sqlStrBuff = new StringBuffer();
        OmcSQLVariableParameter variableParameter = new OmcSQLVariableParameter();
        sqlStrBuff.append(                                      "update psysuser a");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("set a.pdescriptions = #{funVariable_00002},");
        variableParameter.setFunVariable_00002(asynchUserVO.getDescriptions());
        sqlStrBuff.append(OmcFoundationConstant.newline).append("    a.pnames         = #{funVariable_00003}");
        variableParameter.setFunVariable_00003(asynchUserVO.getNames());
        sqlStrBuff.append(OmcFoundationConstant.newline).append("where  a.obid       = #{funVariable_00001}");
        variableParameter.setFunVariable_00001(asynchUserVO.getObid());
        variableParameter.setSql(sqlStrBuff.toString());
        int count = genericDao.update("SchemaNew.dynamicModify", variableParameter);
        if(count == 0){
            variableParameter = new OmcSQLVariableParameter();
            sqlStrBuff.setLength(0);
            sqlStrBuff.append(                                      "insert into psysuser(obid,pnames,pdescriptions) values(");
            sqlStrBuff.append(OmcFoundationConstant.newline).append(" #{funVariable_00001}");
            variableParameter.setFunVariable_00001(asynchUserVO.getObid());
            sqlStrBuff.append(OmcFoundationConstant.newline).append(",#{funVariable_00002}");
            variableParameter.setFunVariable_00002(asynchUserVO.getNames());
            sqlStrBuff.append(OmcFoundationConstant.newline).append(",#{funVariable_00003}");
            variableParameter.setFunVariable_00003(asynchUserVO.getDescriptions());
            sqlStrBuff.append(OmcFoundationConstant.newline).append(")");
            variableParameter.setSql(sqlStrBuff.toString());
            genericDao.insert("SchemaNew.dynamicCreate",variableParameter);
        }
    }
    /**
     * 
     * 
     * @param roleId
     * @return
     * @see FoundationUserService#getRoleInfo(java.lang.String)
     */
    @Override
    public SysUserVO getRoleInfo(String roleId){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(roleId);
        if(NullUtil.isNull(schemaUserVO)) return null;
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"'" + roleId + "' is not role.");
        SysUserVO susUserVO = new SysUserVO(schemaUserVO);
        return susUserVO;
    }
    /**
     * 
     * 
     * @param groupId
     * @return
     * @see FoundationUserService#getGroupInfo(java.lang.String)
     */
    public SysUserVO getGroupInfo(String groupId){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(groupId);
        if(NullUtil.isNull(schemaUserVO)) return null;
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"'" + groupId + "' is not Group.");
        SysUserVO susUserVO = new SysUserVO(schemaUserVO);
        return susUserVO;
    }
    
    /**
     * 
     * 
     * @param userId
     * @return
     * @see FoundationUserService#getCommonUserInfo(java.lang.String)
     */
    @Override
    public SysUserVO getCommonUserInfo(String userId){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        if(NullUtil.isNull(schemaUserVO)) return null;
        SysUserVO susUserVO = new SysUserVO(schemaUserVO);
        susUserVO.setPropertyList(getPropertyList(userId));
        susUserVO.setRoleSet(getRoleList(userId));
        susUserVO.setGroupSet(getGroupList(userId));
        return susUserVO;
    }
    /**
     * 
     *
     * @param groupName
     * @return
     */
    private Set<String> getGroupListForGroup(String groupName){
        Set<String> groupSet = new HashSet<String>();
        List<User2UserResultVO> groupList = getCommonToUserListForCommonUser(groupName,
                                                                             OmcSystemConstants.SYSUSER_KIND_Group,
                                                                             OmcSystemConstants.SYSREL_KIND_GroupGroup,
                                                                             OmcSystemConstants.SYSUSER_KIND_Group,
                                                                             5,
                                                                             1,
                                                                             "00000");
        for(User2UserResultVO vo : groupList){
            groupSet.add(vo.getNames());
        }
        return(groupSet);
    }
    /**
     * 
     *
     * @param groupName
     * @return
     */
    private Set<String> getRoleListForRole(String groupName){
        Set<String> groupSet = new HashSet<String>();
        List<User2UserResultVO> groupList = getCommonToUserListForCommonUser(groupName,
                                                                             OmcSystemConstants.SYSUSER_KIND_Role,
                                                                             OmcSystemConstants.SYSREL_KIND_RoleRole,
                                                                             OmcSystemConstants.SYSUSER_KIND_Role,
                                                                             5,
                                                                             1,
                                                                             "00000");
        for(User2UserResultVO vo : groupList){
            groupSet.add(vo.getNames());
        }
        return(groupSet);
    }
    /**
     * 
     *
     * @param userId
     * @return
     */
    private Set<String> getRoleListAll(String userId){
        Set<String> roleSet = getRoleListForUser(userId);
        Set<String> rtnRoleSet = new HashSet<String>();
        for(String role : roleSet){
            Set<String> subRoleSet = getRoleListForRole(role);
            for(String subRole : subRoleSet){
                rtnRoleSet.add(subRole);
            }
            rtnRoleSet.add(role);
        }
        return rtnRoleSet;
    }
    /**
     * 
     *
     * @param userId
     * @return
     */
    private Set<String> getGroupListAll(String userId){
        Set<String> groupSet = getGroupListForUser(userId);
        Set<String> rtnGroupSet = new HashSet<String>();
        for(String group : groupSet){
            Set<String> subGroupSet = getGroupListForGroup(group);
            for(String subGroup : subGroupSet){
                rtnGroupSet.add(subGroup);
            }
            rtnGroupSet.add(group);
        }
        return rtnGroupSet;
    }
    
    /**
     * 
     * 
     * @param userId
     * @return
     * @see FoundationUserService#getPropertyList(java.lang.String)
     */
    @Override
    public Map<String,String> getPropertyList(String userId){
        Map<String,String> map = new HashMap<String,String>();
        List<OmcSchemaPropertyVO> voList = getUserPropertyList(userId);
        if(NullUtil.isNone(voList)) return map;
        for(OmcSchemaPropertyVO vo : voList){
            map.put(vo.getPropertyName(), vo.getPropertyValue());
        }
        return map;
    }
    /**
     * 
     * 
     * @param userId
     * @param propertyName
     * @return
     * @see FoundationUserService#getPropertyValue(java.lang.String, java.lang.String)
     */
    @Override
    public String getPropertyValue(String userId, String propertyName){
        OmcSchemaPropertyVO vo = getUserProperty(userId,propertyName);
        if(vo == null) return null;
        return(vo.getPropertyValue());
    }
    /**
     * 
     * 
     * @param userId
     * @param propertyName
     * @param propertyValue
     * @see FoundationUserService#txnSetPropertyValue(java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void txnSetPropertyValue(String userId, String propertyName, String propertyValue){
        createModifyDeleteUserProperty(userId,propertyName,propertyValue);
    }
    /**
     * 
     * 
     * @param userId
     * @param propertyList
     * @see FoundationUserService#txnSetPropertyValueList(java.lang.String, java.util.Map)
     */
    @Override
    public void txnSetPropertyValueList(String userId, Map<String,String> propertyList){
        createModifyDeleteUserPropertyList(userId,propertyList);
    }

    @Override
    public void txnSetPropertyValueList(String userId, CUserPropertyVO cUserPropertyVO) {
        Map<String,String> propertyList = new HashMap<String,String>();
        if(!StrUtil.isEmpty(cUserPropertyVO.getCompany()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_COMPANY,cUserPropertyVO.getCompany());
        if(!StrUtil.isEmpty(cUserPropertyVO.getBusinessUnit()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_BUSINESS_UNIT,cUserPropertyVO.getBusinessUnit());
        if(!StrUtil.isEmpty(cUserPropertyVO.getDivisionUnit()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_DR,cUserPropertyVO.getDivisionUnit());
        if(!StrUtil.isEmpty(cUserPropertyVO.getPlantUnit()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_MR,cUserPropertyVO.getPlantUnit());
        if(!StrUtil.isEmpty(cUserPropertyVO.getDefaultPrivateFolder()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_DEFAULT_PRIVATE_FOLDER,cUserPropertyVO.getDefaultPrivateFolder());
        if(!StrUtil.isEmpty(cUserPropertyVO.getDefaultProject()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_DEFAULT_PROJECT,cUserPropertyVO.getDefaultProject());
        if(!StrUtil.isEmpty(cUserPropertyVO.getPrivateFolder()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_PRIVATE_FOLDER,cUserPropertyVO.getPrivateFolder());
        if(!StrUtil.isEmpty(cUserPropertyVO.getLocale()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_LOCALE,cUserPropertyVO.getLocale());
        if(!StrUtil.isEmpty(cUserPropertyVO.getTimeZone()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_TIME_ZONE,cUserPropertyVO.getTimeZone());
        if(!StrUtil.isEmpty(cUserPropertyVO.getUserObid()))  propertyList.put(UserPropertyConstants.USER_PROPERTY_USER_OBID,cUserPropertyVO.getUserObid());
        txnSetPropertyValueList(userId,propertyList);
    }
    /********************************************************************************************/
    /*******************************   Role           ******************************************/
    /********************************************************************************************/
    
    /**
     * 
     * 
     * @param userId
     * @param role
     * @see FoundationUserService#txnAddRoleToUser(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddRoleToUser(String userId, String role){
        OmcSchemaUserVO schemaUserVO = getSysUserInfo(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.addRoleToUser(role);
    }
    /**
     * 
     * 
     * @param userId
     * @param roleList
     * @see FoundationUserService#txnAddRoleToUser(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddRoleToUser(String userId, Set<String> roleList){
        OmcSchemaUserVO schemaUserVO = getSysUserInfo(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.addRoleToUser(roleList);
    }
    /**
     * 
     * 
     * @param userId
     * @param role
     * @see FoundationUserService#txnRemoveRoleToUser(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveRoleToUser(String userId, String role){
        OmcSchemaUserVO schemaUserVO = getSysUserInfo(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.removeRoleToUser(role);
    }
    /**
     * 
     * 
     * @param userId
     * @param roleList
     * @see FoundationUserService#txnRemoveRoleToUser(java.lang.String, java.util.Set)
     */
    @Override
    public void txnRemoveRoleToUser(String userId, Set<String> roleList){
        OmcSchemaUserVO schemaUserVO = getSysUserInfo(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.removeRoleToUser(roleList);
    } 
    /**
     * 
     * 
     * @param userId
     * @return
     * @see FoundationUserService#getRoleList(java.lang.String)
     */
    @Override
    public Set<String> getRoleList(String userId){
        Set<String> groupSet = getGroupList(userId);
        Set<String> roleSet  = getRoleListAll(userId);
        for(String group : groupSet){
            Set<String> subRoleSet = getRoleListForGroup(group);
            for(String role : subRoleSet){
                roleSet.add(role);
            }
        }
        return roleSet;
    }
    /********************************************************************************************/
    /*******************************   Group           ******************************************/
    /********************************************************************************************/
    
    /**
     * 
     * 
     * @param userId
     * @param group
     * @see FoundationUserService#txnAddGroupToUser(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddGroupToUser(String userId, String group){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.addGroupToUser(group);
    }
    /**
     * 
     * 
     * @param userId
     * @param groupList
     * @see FoundationUserService#txnAddGroupToUser(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddGroupToUser(String userId, Set<String> groupList){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.addGroupToUser(groupList);
    }
    /**
     * 
     * 
     * @param userId
     * @param groupList
     * @see FoundationUserService#txnRemoveGroupToUser(java.lang.String, java.util.Set)
     */
    @Override
    public void txnRemoveGroupToUser(String userId, Set<String> groupList){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.removeGroupToUser(groupList);
    }
    /**
     * 
     * 
     * @param userId
     * @param group
     * @see FoundationUserService#txnRemoveGroupToUser(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveGroupToUser(String userId, String group){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.removeGroupToUser(group);
    }
    /**
     * 
     * 
     * @param userId
     * @return
     * @see FoundationUserService#getGroupList(java.lang.String)
     */
    @Override
    public Set<String> getGroupList(String userId){
        return(getGroupListAll(userId));
    }
    /********************************************************************************************/
    /*******************************   Change          ******************************************/
    /********************************************************************************************/
    /**
     * 
     * 
     * @param userId
     * @param site
     * @see FoundationUserService#txnChangeSite(java.lang.String, java.lang.String)
     */
    @Override
    public void txnChangeSite(String userId, String site){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        schemaUserVO.setSite(site);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.modifyObject(new HashMap<String,Object>());
    }
    /**
     * 
     * 
     * @param userId
     * @param descriptions
     * @see FoundationUserService#txnSetUserDescription(java.lang.String, java.lang.String)
     */
    @Override
    public void txnSetUserDescription(String userId, String descriptions){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        schemaUserVO.setDescriptions(descriptions);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.modifyObject(new HashMap<String,Object>());
    }
    /**
     * 
     * 
     * @param userId
     * @param departmentCode
     * @param departmentDesc
     * @param departmentDescKr
     * @see FoundationUserService#txnChangeDepartment(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
     */
    @Override
    public void txnChangeDepartment(String userId, String departmentCode, String departmentDesc, String departmentDescKr){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        schemaUserVO.setDepartmentCode(departmentCode);
        schemaUserVO.setDepartmentDesc(departmentDesc);
        schemaUserVO.setDepartmentDescKor(departmentDescKr);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.modifyObject(new HashMap<String,Object>());
    }
    /**
     * 
     * 
     * @param userId
     * @param emailId
     * @see FoundationUserService#txnChangeMailId(java.lang.String, java.lang.String)
     */
    @Override
    public void txnChangeMailId(String userId, String emailId){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        schemaUserVO.setEmailId(emailId);
        OmcSchemaUserUser dom =  new OmcSchemaUserUser(schemaUserVO);
        dom.modifyObject(new HashMap<String,Object>());
    }
    /**
     * 
     * 
     * @param searchInfo
     * @return
     * @see FoundationUserService#getSessionUserLocalTimeForUser(com.rap.omc.foundation.user.model.UserPropertyVO)
     */
    @Override
    public Date getSessionUserLocalTimeForUser(UserPropertyVO searchInfo) {
        Date result = schemaDao.select("Schema.getSessionUserLocalTimeForUser", searchInfo);
        return result;
    }
    /********************************************************************************************/
    /*******************************   Private         ******************************************/
    /********************************************************************************************/
    /**
     * 
     *
     * @param userId
     * @param propertyName
     * @return
     */
    private OmcSchemaPropertyVO getUserProperty(String userId, String propertyName){
        UserPropertyVO searchInfo = new UserPropertyVO();
        searchInfo.setPropertyName(propertyName);
        searchInfo.setUserNames(userId);
        OmcSchemaPropertyVO result = schemaDao.select("OmcUser.getUserProperty", searchInfo);
        return result;
    }
    /**
     * 
     *
     * @param userId
     * @return
     */
    private List<OmcSchemaPropertyVO> getUserPropertyList(String userId){
        UserPropertyVO searchInfo = new UserPropertyVO();
        searchInfo.setUserNames(userId);
        List<OmcSchemaPropertyVO> result = schemaDao.selectList("OmcUser.getUserProperty", searchInfo);
        return result;
    }
    /**
     * 
     *
     * @param userId
     * @param fromKinds
     * @param scemaKinds
     * @param toKinds
     * @return
     */
    private List<User2UserResultVO> getListToUserForUser(String userId, long fromKinds, long scemaKinds, long toKinds){
        User2UserSearchVO searchInfo = new User2UserSearchVO();
        searchInfo.setUserNames(userId);
        searchInfo.setSearchUserFromKind(fromKinds);
        searchInfo.setSearchUserRelSchemaKind(scemaKinds);
        searchInfo.setSearchUserToKind(toKinds);
        List<User2UserResultVO> result = schemaDao.selectList("OmcUser.getUserToUser", searchInfo);
        return result;
    }
    /**
     * 
     *
     * @param userId
     * @param fromKinds
     * @param scemaKinds
     * @param toKinds
     * @return
     */
    private List<User2UserResultVO> getListFromUserForUser(String userId, long fromKinds, long scemaKinds, long toKinds){
        User2UserSearchVO searchInfo = new User2UserSearchVO();
        searchInfo.setUserNames(userId);
        searchInfo.setSearchUserFromKind(fromKinds);
        searchInfo.setSearchUserRelSchemaKind(scemaKinds);
        searchInfo.setSearchUserToKind(toKinds);
        List<User2UserResultVO> result = schemaDao.selectList("OmcUser.getUserFromUser", searchInfo);
        return result;
    }
    /**
     * 
     *
     * @param commonUserId
     * @return
     */
    @Override
    public List<User2UserResultVO> getCommonUserAllListForUser(String commonUserId){
        User2UserSearchVO searchInfo = new User2UserSearchVO();
        searchInfo.setUserNames(commonUserId);
        List<User2UserResultVO> result = schemaDao.selectList("OmcUser.getUserRelatedAllUser", searchInfo);
        return result;
    }
    /**
     * 
     *
     * @param userId
     * @param propertyList
     */
    private void createModifyDeleteUserPropertyList(String userId, Map<String,String> propertyList){
        if(NullUtil.isNone(propertyList)) return;
        for(String propertyName : propertyList.keySet()){
            createModifyDeleteUserProperty(userId,propertyName,propertyList.get(propertyName));
        }
    }
    /**
     * 
     *
     * @param userId
     * @param propertyName
     * @param propertyValue
     */
    private void createModifyDeleteUserProperty(String userId, String propertyName,  String propertyValue){
        UserPropertyVO input = new UserPropertyVO();
        input.setUserNames(userId);
        input.setPropertyName(propertyName);
        input.setPropertyValue(propertyValue);
        createModifyDeleteUserProperty(input);
    }
    /**
     * 
     *
     * @param input
     */
    private void createModifyDeleteUserProperty(UserPropertyVO input){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(input.getUserNames());
        OmcSchemaServiceUtils.setUserProperty(schemaUserVO, input.getPropertyName(), input.getPropertyValue());
    }
    /**
     * 
     *
     * @param userId
     * @return
     */
    private OmcSchemaUserVO getSysUserInfo(String userId){
        return(getSysUserInfo(userId,true,true));
    }
    /**
     * 
     *
     * @param userId
     * @param isNotFoundCheck
     * @param isInActiveCheck
     * @return
     */
    private OmcSchemaUserVO getSysUserInfo(String userId, boolean isNotFoundCheck, boolean isInActiveCheck){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        if(isNotFoundCheck && NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Sysuser Object(" + userId +") Not Found");
        if(isInActiveCheck && !NullUtil.isNull(schemaUserVO) && !Bit.isInclude(schemaUserVO.getFlags(), OmcSystemConstants.SYSUSER_FLAG_Active)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Sysuser Object(" + userId +") is inactive");
        return schemaUserVO;
    }
    /**
     * 
     * 
     * @param group
     * @param userId
     * @see FoundationUserService#txnAddUserForGroup(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddUserForGroup(String group, String userId){

        txnAddGroupToUser(userId,group);
    }
    /**
     * 
     * 
     * @param group
     * @param userList
     * @see FoundationUserService#txnAddUserForGroup(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddUserForGroup(String group, Set<String> userList){

        for(String userId : userList){
            txnAddGroupToUser(userId,group);
        }
    }
    /**
     * 
     * 
     * @param group
     * @param userId
     * @see FoundationUserService#txnRemoveUserForGroup(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveUserForGroup(String group, String userId){

        txnRemoveGroupToUser(userId,group);
    }
    /**
     * 
     * 
     * @param group
     * @param userList
     * @see FoundationUserService#txnRemoveUserForGroup(java.lang.String, java.util.Set)
     */
    @Override
    public void txnRemoveUserForGroup(String group, Set<String> userList){

        for(String userId : userList){
            txnRemoveGroupToUser(userId,group);
        }
    }
    /**
     * 
     * 
     * @param group
     * @return
     * @see FoundationUserService#getUserListForGroup(java.lang.String)
     */
    @Override
    public Set<String> getUserListForGroup(String group){
        return null;
               
    }
    /**
     * 
     * 
     * @param group
     * @param addedGroup
     * @see FoundationUserService#txnAddGroupForGroup(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddGroupForGroup(String group, String addedGroup){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        if(NullUtil.isNull(schemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Group Object(" + group +") Not Found");

        OmcSchemaUserVO addedSchemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(addedGroup);
        if(NullUtil.isNull(addedSchemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Group Object(" + addedGroup +") Not Found");

        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + group +") is not Group");
        if(!Bit.isInclude(addedSchemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + addedGroup +") is not Group");

        OmcSchemaUserGroup groupDom = new OmcSchemaUserGroup(schemaUserVO);
        groupDom.addGroup(addedGroup);
    }
    /**
     * 
     * 
     * @param group
     * @param addedGroupList
     * @see FoundationUserService#txnAddGroupForGroup(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddGroupForGroup(String group, Set<String> addedGroupList){

        for(String addedGroup : addedGroupList){
            txnAddGroupForGroup(group,addedGroup);
        }
    }
    /**
     * 
     * 
     * @param group
     * @param role
     * @see FoundationUserService#txnAddRoleForGroup(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddRoleForGroup(String group, String role){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        if(NullUtil.isNull(schemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Group Object(" + group +") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + group +") is not Group");
        
        OmcSchemaUserVO addedRoleVo = OmcSchemaServiceUtils.getUserCommonWithName(role);
        if(NullUtil.isNull(addedRoleVo))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Role Object(" + addedRoleVo +") Not Found");
        if(!Bit.isInclude(addedRoleVo.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + role +") is not Role");
        OmcSchemaUserGroup groupDom = new OmcSchemaUserGroup(schemaUserVO);
        groupDom.addRole(role);
    }
    /**
     * 
     * 
     * @param group
     * @param roleList
     * @see FoundationUserService#txnAddRoleForGroup(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddRoleForGroup(String group, Set<String> roleList){

        for(String role : roleList){
            txnAddRoleForGroup(group,role);
        }
    }
    /**
     * 
     * 
     * @param group
     * @param addedGroup
     * @see FoundationUserService#txnRemoveGroupForGroup(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveGroupForGroup(String group, String addedGroup){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        if(NullUtil.isNull(schemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Group Object(" + group +") Not Found");
        OmcSchemaUserVO addedSchemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(addedGroup);
        if(NullUtil.isNull(addedSchemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Group Object(" + addedGroup +") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + group +") is not Group");
        if(!Bit.isInclude(addedSchemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + addedGroup +") is not Group");
        OmcSchemaUserGroup groupDom = new OmcSchemaUserGroup(schemaUserVO);
        groupDom.removeGroup(addedGroup);
    }
    /**
     * 
     * 
     * @param group
     * @param addedGroupList
     * @see FoundationUserService#txnRemoveGroupForGroup(java.lang.String, java.util.Set)
     */
    @Override
    public void txnRemoveGroupForGroup(String group, Set<String> addedGroupList){

        for(String addedGroup : addedGroupList){
            txnRemoveGroupForGroup(group,addedGroup);
        }
    }
    /**
     * 
     * 
     * @param group
     * @param role
     * @see FoundationUserService#txnRemoveRoleForGroup(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveRoleForGroup(String group, String role){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(group);
        if(NullUtil.isNull(schemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Group Object(" + group +") Not Found");
        OmcSchemaUserVO addedRoleVo = OmcSchemaServiceUtils.getUserCommonWithName(role);
        if(NullUtil.isNull(addedRoleVo))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Role Object(" + addedRoleVo +") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + group +") is not Group");
        if(!Bit.isInclude(addedRoleVo.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + role +") is not Group");
        OmcSchemaUserGroup groupDom = new OmcSchemaUserGroup(schemaUserVO);
        groupDom.removeRole(role);
    }
    /**
     * 
     * 
     * @param group
     * @param roleList
     * @see FoundationUserService#txnRemoveRoleForGroup(java.lang.String, java.util.Set)
     */
    @Override
    public void txnRemoveRoleForGroup(String group, Set<String> roleList){

        for(String role : roleList){
            txnRemoveRoleForGroup(group,role);
        }
    }
    /**
     * 
     * 
     * @param role
     * @param user
     * @see FoundationUserService#txnAddUserForRole(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddUserForRole(String role, String user){

        txnAddRoleToUser(user,role);
    }
    /**
     * 
     * 
     * @param role
     * @param userList
     * @see FoundationUserService#txnAddUserForRole(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddUserForRole(String role, Set<String> userList){

        for(String user : userList){
            txnAddRoleToUser(user,role);
        }
    }
    /**
     * 
     * 
     * @param role
     * @param user
     * @see FoundationUserService#txnRemoveUserForRole(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveUserForRole(String role, String user){

        txnRemoveRoleToUser(user,role);
    }
    /**
     * 
     * 
     * @param role
     * @param userList
     * @see FoundationUserService#txnRemoveUserForRole(java.lang.String, java.util.Set)
     */
    @Override
    public void txnRemoveUserForRole(String role, Set<String> userList){

        for(String user : userList){
            txnRemoveRoleToUser(user,role);
        }
    }
    /**
     * 
     * 
     * @param role
     * @return
     * @see FoundationUserService#getUserListForRole(java.lang.String)
     */
    @Override
    public Set<String> getUserListForRole(String role){

        return null;
    }
    /**
     * 
     * 
     * @param role
     * @param addedRole
     * @see FoundationUserService#txnAddRoleForRole(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddRoleForRole(String role, String addedRole){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(role);
        if(NullUtil.isNull(schemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Role Object(" + role +") Not Found");
        OmcSchemaUserVO addedRoleVo = OmcSchemaServiceUtils.getUserCommonWithName(addedRole);
        if(NullUtil.isNull(addedRoleVo))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Role Object(" + addedRole +") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + role +") is not Role");
        if(!Bit.isInclude(addedRoleVo.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + addedRole +") is not Role");
        OmcSchemaUserRole dom = new OmcSchemaUserRole(schemaUserVO);
        dom.addRole(addedRole);
    }
    /**
     * 
     * 
     * @param role
     * @param addedRoleList
     * @see FoundationUserService#txnAddRoleForRole(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddRoleForRole(String role, Set<String> addedRoleList){

        for(String addedRole : addedRoleList){
            txnAddRoleForRole(role,addedRole);
        }
    }
    /**
     * 
     * 
     * @param role
     * @param group
     * @see FoundationUserService#txnAddGroupForRole(java.lang.String, java.lang.String)
     */
    @Override
    public void txnAddGroupForRole(String role, String group){

        txnAddRoleForGroup(group, role);
    }
    /**
     * 
     * 
     * @param role
     * @param groupList
     * @see FoundationUserService#txnAddGroupForRole(java.lang.String, java.util.Set)
     */
    @Override
    public void txnAddGroupForRole(String role, Set<String> groupList){

        for(String group : groupList){
            txnAddRoleForGroup(group, role);
        }
    }
    /**
     * 
     * 
     * @param role
     * @param removeRole
     * @see FoundationUserService#txnRemoveRoleForRole(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveRoleForRole(String role, String removeRole){

        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(role);
        if(NullUtil.isNull(schemaUserVO))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Role Object(" + role +") Not Found");
        OmcSchemaUserVO addedRoleVo = OmcSchemaServiceUtils.getUserCommonWithName(removeRole);
        if(NullUtil.isNull(addedRoleVo))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Role Object(" + removeRole +") Not Found");
        if(!Bit.isInclude(schemaUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + role +") is not Role");
        if(!Bit.isInclude(addedRoleVo.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object(" + removeRole +") is not Role");
        OmcSchemaUserRole dom = new OmcSchemaUserRole(schemaUserVO);
        dom.removeRole(removeRole);
    }
    /**
     * 
     * 
     * @param role
     * @param removedRoleList
     * @see FoundationUserService#txnRemoveRoleForRole(java.lang.String, java.util.Set)
     */
    @Override
    public void txnRemoveRoleForRole(String role, Set<String> removedRoleList){

        for(String removeRole : removedRoleList){
            txnRemoveRoleForRole(role,removeRole);
        }
    }
    /**
     * 
     * 
     * @param role
     * @param group
     * @see FoundationUserService#txnRemoveGroupForRole(java.lang.String, java.lang.String)
     */
    @Override
    public void txnRemoveGroupForRole(String role, String group){

        txnRemoveRoleForGroup(group, role);
    }
    @Override
    public void txnRemoveGroupForRole(String role, Set<String> groupList){

        for(String group : groupList){
            txnRemoveGroupForRole(role,group);
        }
    }
    private Set<String> getGroupListForUser(String userId){
        Set<String> strSet = new HashSet<String>();
        List<User2UserResultVO> relList = getGroupVOListForUser(userId,1,1,"00000");
        for(User2UserResultVO vo : relList){
            strSet.add(vo.getNames());
        }
        return(strSet);
    }
    @Override
    public List<User2UserResultVO> getGroupVOListForUser(String userId,int wantedLevel, int currentLevel,String uniqueStr){
        OmcSchemaUserVO schemaUserVO = getCommonUser(userId);
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_User)){
            return new ArrayList<User2UserResultVO>();
            //throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + userId + "' is not User.");
        }
        return getCommonFromUserListForCommonUser(userId,
                                                  OmcSystemConstants.SYSUSER_KIND_Group,
                                                  OmcSystemConstants.SYSREL_KIND_GroupUser,
                                                  OmcSystemConstants.SYSUSER_KIND_User,
                                                  1,
                                                  1,
                                                  uniqueStr);
    }
    private Set<String> getRoleListForUser(String userId){
        Set<String> strSet = new HashSet<String>();
        List<User2UserResultVO> relList = getRoleVOListForUser(userId,1,1,"00000");
        for(User2UserResultVO vo : relList){
            strSet.add(vo.getNames());
        }
        return(strSet);
    }
    @Override
    public List<User2UserResultVO> getRoleVOListForUser(String userId,int wantedLevel, int currentLevel,String uniqueStr){
        OmcSchemaUserVO schemaUserVO = getCommonUser(userId);
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_User)) {
            return new ArrayList<User2UserResultVO>();
            //throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + userId + "' is not User.");
        }
        return getCommonFromUserListForCommonUser(userId,
                                                  OmcSystemConstants.SYSUSER_KIND_Role,
                                                  OmcSystemConstants.SYSREL_KIND_RoleUser,
                                                  OmcSystemConstants.SYSUSER_KIND_User,
                                                  wantedLevel,
                                                  currentLevel,
                                                  uniqueStr);
    }
    
    @Override
    public List<User2UserResultVO> getUserVOListForRole(String userId,int wantedLevel, int currentLevel,String uniqueStr){
        OmcSchemaUserVO schemaUserVO = getCommonUser(userId);
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_User)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + userId + "' is not User.");
        return getCommonToUserListForCommonUser(userId,
                                                OmcSystemConstants.SYSUSER_KIND_Role,
                                                OmcSystemConstants.SYSREL_KIND_RoleUser,
                                                OmcSystemConstants.SYSUSER_KIND_User,
                                                wantedLevel,
                                                currentLevel,
                                                uniqueStr);
    }
    @Override
    public List<User2UserResultVO> getUserVOListForGroup(String groupId,int wantedLevel, int currentLevel,String uniqueStr){
        OmcSchemaUserVO schemaUserVO = getCommonUser(groupId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_RoleGroup)) return (new ArrayList<User2UserResultVO>());
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + groupId + "' is not Group.");
        return getCommonToUserListForCommonUser(groupId,
                                                OmcSystemConstants.SYSUSER_KIND_Group,
                                                OmcSystemConstants.SYSREL_KIND_GroupUser,
                                                OmcSystemConstants.SYSUSER_KIND_User,
                                                wantedLevel,
                                                currentLevel,
                                                uniqueStr);
    }
    
    private Set<String> getRoleListForGroup(String groupId){
        Set<String> roleSet = new HashSet<String>();
        List<User2UserResultVO> roleList = getRoleVOListForGroup(groupId,1,1,"00000");
        for(User2UserResultVO vo : roleList){
            roleSet.add(vo.getNames());
        }
        return(roleSet);
    }
    @Override
    public List<User2UserResultVO> getRoleVOListForGroup(String groupId,int wantedLevel, int currentLevel,String uniqueStr){
        OmcSchemaUserVO schemaUserVO = getCommonUser(groupId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_RoleGroup)) return (new ArrayList<User2UserResultVO>());
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + groupId + "' is not Group.");
        return this.getCommonToUserListForCommonUser(groupId,
                                                     OmcSystemConstants.SYSUSER_KIND_Group,
                                                     OmcSystemConstants.SYSREL_KIND_GroupRole,
                                                     OmcSystemConstants.SYSUSER_KIND_Role,
                                                     wantedLevel,
                                                     currentLevel,
                                                     uniqueStr);
    }
    @Override
    public List<User2UserResultVO> getRoleVOListForRole(String roleId, int wantedLevel, int currentLevel,String uniqueStr){
        OmcSchemaUserVO schemaUserVO = getCommonUser(roleId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_RoleGroup)) return (new ArrayList<User2UserResultVO>());
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + roleId + "' is not Role.");
        return this.getCommonToUserListForCommonUser(roleId,
                                                     OmcSystemConstants.SYSUSER_KIND_Role,
                                                     OmcSystemConstants.SYSREL_KIND_RoleRole,
                                                     OmcSystemConstants.SYSUSER_KIND_Role,
                                                     wantedLevel,
                                                     currentLevel,
                                                     uniqueStr);
    }
    @Override
    public List<User2UserResultVO> getGroupVOListForGroup(String groupId, int wantedLevel, int currentLevel,String uniqueStr){
        OmcSchemaUserVO schemaUserVO = getCommonUser(groupId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_RoleGroup)) return (new ArrayList<User2UserResultVO>());
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Group)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + groupId + "' is not Group.");
        return this.getCommonToUserListForCommonUser(groupId,
                                                     OmcSystemConstants.SYSUSER_KIND_Group,
                                                     OmcSystemConstants.SYSREL_KIND_GroupGroup,
                                                     OmcSystemConstants.SYSUSER_KIND_Group,
                                                     wantedLevel,
                                                     currentLevel,
                                                     uniqueStr);
    }
    @Override
    public List<User2UserResultVO> getGroupVOListForRole(String roleId, int wantedLevel, int currentLevel,String uniqueStr){
        
        OmcSchemaUserVO schemaUserVO = getCommonUser(roleId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_RoleGroup)) return (new ArrayList<User2UserResultVO>());
        if(!Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Role)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]'" + roleId + "' is not Role.");
        
        return this.getCommonFromUserListForCommonUser(roleId,
                                                      OmcSystemConstants.SYSUSER_KIND_Group,
                                                      OmcSystemConstants.SYSREL_KIND_GroupRole,
                                                      OmcSystemConstants.SYSUSER_KIND_Role,
                                                      wantedLevel,
                                                      currentLevel,
                                                      uniqueStr);
    }
    @Override
    public List<User2UserResultVO> getCommonUserListForCommon(String commonId){
        // TODO Auto-generated method stub
        OmcSchemaUserVO schemaUserVO = getCommonUser(commonId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_RoleGroup)) return (new ArrayList<User2UserResultVO>());
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_User)) return getCommonUserListForUser(commonId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Role)) return getCommonUserListForRole(commonId);
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Group)) return getCommonUserListForGroup(commonId);
        return (new ArrayList<User2UserResultVO>());
    }
    @Override
    public List<User2UserResultVO> getCommonUserListForUser(String userId){
        List<User2UserResultVO> result = new ArrayList<User2UserResultVO>();
        
        List<User2UserResultVO> directList1 = this.getGroupVOListForUser(userId, 1, 1, "A");
        for(User2UserResultVO groupVO : directList1){
            result.add(groupVO);
            List<User2UserResultVO> tempList = this.getGroupVOListForGroup(groupVO.getNames(), 5, 2, groupVO.getUniqueStr());
            result.addAll(tempList);
        }
        List<User2UserResultVO> directList2 = this.getRoleVOListForUser(userId, 1, 0, "B");
        for(User2UserResultVO roleVO : directList2){
            List<User2UserResultVO> tempList = this.getRoleVOListForRole(roleVO.getNames(), 5, 2, roleVO.getUniqueStr());
            result.addAll(tempList);
        }
        return result;
    }
    @Override
    public List<User2UserResultVO> getCommonUserListForRole(String roleId){
        List<User2UserResultVO> result = new ArrayList<User2UserResultVO>();
        List<User2UserResultVO> directList1 = this.getRoleVOListForRole(roleId, 5, 0, "A");
        result.addAll(directList1);
        List<User2UserResultVO> directList2 = this.getGroupVOListForRole(roleId, 1, 0, "B");
        for(User2UserResultVO vo : directList2){
            List<User2UserResultVO> tempGroupList = this.getGroupVOListForGroup(vo.getNames(), 5, 0, vo.getUniqueStr());
            result.addAll(tempGroupList);
        }
        return result;
    }
    @Override
    public List<User2UserResultVO> getCommonUserListForGroup(String groupId){
        List<User2UserResultVO> result = new ArrayList<User2UserResultVO>();
        List<User2UserResultVO> directList1 = this.getGroupVOListForGroup(groupId, 5, 0, "A");
        result.addAll(directList1);
        List<User2UserResultVO> directList2 = this.getRoleVOListForGroup(groupId, 1, 0, "B");
        for(User2UserResultVO vo : directList2){
            List<User2UserResultVO> tempGroupList = this.getRoleVOListForRole(vo.getNames(), 5, 0, vo.getUniqueStr());
            result.addAll(tempGroupList);
        }
        return result;
    }
    private void getCommonFromUserListForCommonUserSub(String groupName,List<User2UserResultVO> groupList, long fromKinds, long scemaKinds, long toKinds,int wantedLevel, int currentLevel,String uniqueStrParent){
        if(currentLevel > wantedLevel) return;
        List<User2UserResultVO> subGroupList = getListFromUserForUser(groupName, fromKinds, scemaKinds, toKinds);
        int seq = 1;String uniqueStr = "";
        for(User2UserResultVO subGroup : subGroupList){
            uniqueStr =  uniqueStrParent + StrUtil.LPAD(seq, 5, "0");
            subGroup.setUniqueStr(uniqueStr);
            subGroup.setUniqueStrParent(uniqueStrParent);
            subGroup.setLevel(currentLevel);
            getCommonFromUserListForCommonUserSub(subGroup.getNames(),groupList,fromKinds, scemaKinds, toKinds,wantedLevel,currentLevel+1,uniqueStr);
            groupList.add(subGroup);
            seq++;
        }
    }
    private void getCommonToUserListForCommonUserSub(String groupName,List<User2UserResultVO> groupList, long fromKinds, long scemaKinds, long toKinds, int wantedLevel, int currentLevel, String uniqueStrParent){
        if(currentLevel > wantedLevel) return;
        List<User2UserResultVO> subGroupList = getListToUserForUser(groupName, fromKinds, scemaKinds, toKinds);
        int seq = 1;String uniqueStr = "";
        for(User2UserResultVO subGroup : subGroupList){
            uniqueStr =  uniqueStrParent + StrUtil.LPAD(seq, 5, "0");
            subGroup.setUniqueStr(uniqueStr);
            subGroup.setUniqueStrParent(uniqueStrParent);
            subGroup.setLevel(currentLevel);
            getCommonToUserListForCommonUserSub(subGroup.getNames(),groupList,fromKinds, scemaKinds, toKinds,wantedLevel,currentLevel+1,uniqueStr);
            groupList.add(subGroup);
            seq++;
        }
    }
    @Override
    public List<User2UserResultVO> getCommonToUserListForCommonUser(String commonUserName,long fromKinds, long scemaKinds, long toKinds, int wantedLevel){
            return this.getCommonToUserListForCommonUser(commonUserName,fromKinds, scemaKinds, toKinds,wantedLevel,1,"00000");
    }
    @Override
    public List<User2UserResultVO> getCommonToUserListForCommonUser(String commonUserName,long fromKinds, long scemaKinds, long toKinds, int wantedLevel, int currentLevel, String uniqueStr){
            List<User2UserResultVO> userList = new ArrayList<User2UserResultVO>();
            this.getCommonToUserListForCommonUserSub(commonUserName,userList,fromKinds, scemaKinds, toKinds,wantedLevel,currentLevel,uniqueStr);
            return userList;
    }
    @Override
    public List<User2UserResultVO> getCommonFromUserListForCommonUser( String commonUserName,long fromKinds, long scemaKinds, long toKinds,int wantedLevel){
            return this.getCommonFromUserListForCommonUser(commonUserName,fromKinds, scemaKinds, toKinds,wantedLevel,1,"00000");
    }
    @Override
    public List<User2UserResultVO> getCommonFromUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds,int wantedLevel,int currentLevel,String uniqueStr){
        List<User2UserResultVO> userList = new ArrayList<User2UserResultVO>();
        this.getCommonFromUserListForCommonUserSub(commonUserName,userList,fromKinds, scemaKinds, toKinds,wantedLevel,currentLevel,uniqueStr);
        return userList;
    }

    private OmcSchemaUserVO getCommonUser(String userId){
        return(OmcSchemaServiceUtils.getUserCommonWithName(userId));
    }
	@Override
	public void txnSetTimeStampSystemUser(String userId, String timeStamp) {
		OmcSchemaUserVO parmVO = new OmcSchemaUserVO();
		parmVO.setNames(userId);
		parmVO.setTimeStamp(timeStamp);
	    OmcSchemaServiceUtils.setTimeStampSystemUser(parmVO);
	}
    @Override
    public void txnSetSynchronizedSystemUser(String userId, String datasourceName) {
        OmcSchemaUserVO parmVO = new OmcSchemaUserVO();
        parmVO.setNames(userId);
        parmVO.setSynchronizedList("@" + datasourceName + "@");
        OmcSchemaServiceUtils.setSynchronizedSystemUser(parmVO);
    }
    @Override
    public void txnAddCheckItem(String userId, String checkItem){
        OmcSchemaUserVO schemaUserVO = OmcSchemaServiceUtils.getUserCommonWithName(userId);
        if(NullUtil.isNull(schemaUserVO)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"'" + userId + "' is not found.");
        OmcSchemaUserCommon dom = null;
        if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_User)){
            dom =  new OmcSchemaUserUser(schemaUserVO);
        }else if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Group)) {
            dom =  new OmcSchemaUserGroup(schemaUserVO);
        }else if(Bit.isInclude(schemaUserVO.getKinds(),OmcSystemConstants.SYSUSER_KIND_Role)){
            dom =  new OmcSchemaUserRole(schemaUserVO);
        }else{
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"'" + userId + "' is invalid.");
        }
        dom.addCheckItem(checkItem);
    }
}