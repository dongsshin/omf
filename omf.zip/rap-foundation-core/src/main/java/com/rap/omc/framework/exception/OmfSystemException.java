package com.rap.omc.framework.exception;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

import java.util.Locale;

public class OmfSystemException extends OmfBaseException {
     private static final long serialVersionUID = 1L;
     public OmfSystemException(HttpStatus httpStatus, String message)
     {
        super(httpStatus,message);
     }
     public OmfSystemException(HttpStatus httpStatus, String code, String message)
     {
        super(httpStatus,message);
        super.setCode(code);
     }
     public OmfSystemException(HttpStatus httpStatus, Throwable cause)
     {
        super(httpStatus,cause);
     }
     public OmfSystemException(HttpStatus httpStatus, String message, Throwable cause)
     {
        super(httpStatus,message, cause);
     }
     public OmfSystemException(HttpStatus httpStatus, String code, String message, Throwable cause)
     {
        super(httpStatus,code, message, cause);
     }
     public OmfSystemException(HttpStatus httpStatus, String code, MessageSource messageSource)
     {
        super(httpStatus,code, messageSource);
     }
     public OmfSystemException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters)
     {
        super(httpStatus,code, messageSource, messageParameters);
     }
     public OmfSystemException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters, Locale locale)
     {
        super(httpStatus,code, messageSource, messageParameters, locale);
     }
     public String toString()
     {
        String str = super.getClass().getName();
        String message = super.getMessage();
        String code = super.getCode();
        
        StringBuilder strBuilder = new StringBuilder(str);
        strBuilder.append((message != null) ? ": " + message : "");
        strBuilder.append(((code != null) && (!("".equals(code)))) ? "(" + code + ")" : " ");
        return strBuilder.toString();
     }
}