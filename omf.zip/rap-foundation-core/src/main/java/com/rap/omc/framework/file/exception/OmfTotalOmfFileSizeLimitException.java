package com.rap.omc.framework.file.exception;

import org.springframework.http.HttpStatus;

public class OmfTotalOmfFileSizeLimitException extends OmfFileUploadException {
	private static final long serialVersionUID = 1L;
	public OmfTotalOmfFileSizeLimitException(HttpStatus httpStatus, String message)
	{
		super(httpStatus,message);
	}
	public OmfTotalOmfFileSizeLimitException(HttpStatus httpStatus, String code, String message)
	{
		super(httpStatus,code, message);
	}
	public OmfTotalOmfFileSizeLimitException(HttpStatus httpStatus, Throwable cause)
	{
		super(httpStatus,cause);
	}
	public OmfTotalOmfFileSizeLimitException(HttpStatus httpStatus, String code, String message, Throwable cause)
	{
		super(httpStatus,code, message, cause);
	}
	public OmfTotalOmfFileSizeLimitException(HttpStatus httpStatus, String message, Throwable cause)
	{
		super(httpStatus,message, cause);
	}
}