/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : OmcSchemaSite.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2017. 4. 5.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.omc.schema.object.dom;

import com.rap.omc.core.oql.model.OmcSQLVariableParameter;
import com.rap.omc.core.oql.utility.OmcFoundationConstant;
import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.schema.object.model.OmcSchemaCheckItemVO;
import com.rap.omc.schema.object.model.OmcSchemaRelationVO;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSchemaServiceUtils;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * Class : OmcSchemaCheckItem
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
@SuppressWarnings("rawtypes")
@Slf4j
public class OmcSchemaCheckItem extends OmcSchemaSysRoot {
    public OmcSchemaCheckItem(String obid) {
        super(OmcSchemaServiceUtils.getCheckItemWithObid(obid));
    }
    public OmcSchemaCheckItem(String names, boolean isName) {
        super(OmcSchemaServiceUtils.getCheckItemWithNames(names));
    }

    @Override
    public OmcSchemaCheckItemVO getVo() {
        return (OmcSchemaCheckItemVO) vo;
    }

    /**
     * @param vo
     */

    public OmcSchemaCheckItem(OmcSchemaCheckItemVO vo) {
        super(vo);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param map
     * @see OmcSchemaSysRoot#create(Map)
     */
    @Override
    protected void create(Map map) {
        // TODO Auto-generated method stub
        OmcSchemaServiceUtils.createCheckItem(this.getVo());
    }

    /**
     * @param map
     * @see OmcSchemaSysRoot#inActivate(Map)
     */
    @Override
    protected void inActivate(Map map) {
        // TODO Auto-generated method stub
        OmcSchemaServiceUtils.inactivateCheckItem(this.getVo());
    }

    /**
     * @param map
     * @see OmcSchemaSysRoot#delete(Map)
     */
    @Override
    protected void delete(Map map) {
        // TODO Auto-generated method stub
        OmcSchemaServiceUtils.deleteCheckItem(this.getVo());
    }

    /**
     * @param map
     * @see OmcSchemaSysRoot#modify(Map)
     */
    @Override
    protected void modify(Map map) {
        // TODO Auto-generated method stub
        OmcSchemaServiceUtils.modifyCheckItem(this.getVo());
    }

    /**
     * @param Names
     * @return
     * @see OmcSchemaSysRoot#getObjectInfoByName(String)
     */
    @Override
    protected OmcSchemaCheckItemVO getObjectInfoByName(String Names) {
        // TODO Auto-generated method stub
        return null;
    }

    /**
     * @see OmcSchemaSysRoot#setFlags()
     */
    @Override
    protected void setFlags() {
        // TODO Auto-generated method stub
        OmcSchemaCheckItemVO thisVo = this.getVo();
        long flags = Bit.or(OmcSystemConstants.CHECKITEM_FLAG_Default, OmcSystemConstants.CHECKITEM_FLAG_Active);
        if(!StrUtil.isEmpty(this.getVo().getAllUserGranted()) && this.getVo().getAllUserGranted().equals("Y")){
            flags = Bit.or(flags,OmcSystemConstants.CHECKITEM_FLAG_AllUser);
        }
        thisVo.setFlags(flags);
        this.setVo(thisVo);
    }

    /**
     * @see OmcSchemaSysRoot#setClassKind()
     */
    @Override
    protected void setClassKind() {
        // TODO Auto-generated method stub
        OmcSchemaCheckItemVO thisVo = this.getVo();
        thisVo.setClassKinds(OmcSystemConstants.SYSKEY_KIND_CheckItem);
        this.setVo(thisVo);
    }

    @Override
    protected void validateForCreate(Map map) {
        log.debug("OmcSchemaCheckItem.validateForCreate Start");
        super.validateForCreate(map);
    }

    @Override
    protected void preProcessForCreate(Map map) {
        super.preProcessForCreate(map);
    }

    @Override
    protected void postProcessForCreate(Map map) {
        super.postProcessForCreate(map);
        grantTo((Set<String>)map.get("commonUserSet"));
    }

    @Override
    protected void validateForInActivate(Map map) {
        super.validateForInActivate(map);
    }

    @Override
    protected void preProcessForInActivate(Map map) {
        super.preProcessForInActivate(map);
    }

    @Override
    protected void postProcessForInActivate(Map map) {
        super.postProcessForInActivate(map);
    }

    @Override
    protected void validateForDelete(Map map) {
        super.validateForDelete(map);
    }

    @Override
    protected void preProcessForDelete(Map map) {
        super.preProcessForDelete(map);
    }

    @Override
    protected void postProcessForDelete(Map map) {
        super.postProcessForDelete(map);
    }

    @Override
    protected void validateForModify(Map map) {
        super.validateForModify(map);
    }

    @Override
    protected void preProcessForModify(Map map) {
        super.preProcessForModify(map);
    }

    @Override
    protected void postProcessForModify(Map map) {
        super.postProcessForModify(map);
        grantTo((Set<String>)map.get("commonUserSet"));
    }
    public static void getCommonSelectSql(StringBuffer sqlStrBuff, OmcSQLVariableParameter variableParameter) {
        sqlStrBuff.append("select a.obid                       as obid                ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pflags                     as flags               ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pnames                     as names               ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pdisplay_name              as display_name        ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pdisplay_name_kr           as display_name_kr     ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.premarks                   as remarks             ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pcreator                   as creator             ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pcreated                   as created             ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pmodifier                  as modifier            ,");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("       a.pmodified                  as modified            ");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("from psysauthcheckitem a ");
    }
    public void activateObject(Map map) {
        // TODO Auto-generated method stub
        OmcSchemaServiceUtils.activateCheckItem(this.getVo());
    }
    private void grantTo(Set<String> commonUserSet){
        if(!NullUtil.isNone(commonUserSet)){
            for(String userId : commonUserSet) {
                if(!StrUtil.isEmpty(userId)){
                    boolean isValid = true;
                    SysUserVO sysUserVO = FoundationUserUtil.getCommonUserInfo(userId);
                    if(!NullUtil.isNull(sysUserVO)){
                        List<OmcSchemaRelationVO> relList = null;
                        if(Bit.isInclude(sysUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_User)){
                            relList = OmcSchemaServiceUtils.getRelationList(OmcSystemConstants.SYSREL_KIND_UserCheckItem, sysUserVO.getObid(), this.getVo().getObid());
                        }else if(Bit.isInclude(sysUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Role)){
                            relList = OmcSchemaServiceUtils.getRelationList(OmcSystemConstants.SYSREL_KIND_RoleCheckItem, sysUserVO.getObid(), this.getVo().getObid());
                        }else if(Bit.isInclude(sysUserVO.getKinds(), OmcSystemConstants.SYSUSER_KIND_Group)){
                            relList = OmcSchemaServiceUtils.getRelationList(OmcSystemConstants.SYSREL_KIND_GroupCheckItem, sysUserVO.getObid(), this.getVo().getObid());
                        }else{
                            isValid = false;
                            log.warn("Skipped(User Type invalid");
                        }
                        if(!NullUtil.isNone(relList)){
                            isValid = false;
                            log.warn("Skipped(Already exists)");
                        }
                        if(isValid) FoundationUserUtil.addCheckItem(userId,this.getVo().getNames());
                    }else{
                        log.warn("(Skipped)User Id is not found.");
                    }
                 }else{
                    log.warn("(Skipped)User Id is empty.");
                }
            }
        }
    }
    public void grantAllUser() {
        if(!Bit.isInclude(this.getVo().getFlags(),OmcSystemConstants.CHECKITEM_FLAG_AllUser)){
            this.getVo().setFlags(Bit.or(this.getVo().getFlags(),OmcSystemConstants.CHECKITEM_FLAG_AllUser));
        }
        OmcSchemaServiceUtils.modifyCheckItemFlags(this.getVo());
    }
    public Set<String> getGrantedCommonUserSet() {
        return OmcSchemaServiceUtils.getGrantedCommonUserSet(this.getVo());
    }
}