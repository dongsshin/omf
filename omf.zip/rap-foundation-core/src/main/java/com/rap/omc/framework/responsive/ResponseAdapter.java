package com.rap.omc.framework.responsive;

import org.springframework.http.HttpStatus;

import java.util.HashMap;

public class ResponseAdapter {
    //단순히 성공 Message를 보내고 싶을때
    public static ResponseMapper responseMapper(String key){
        return ResponseMapper.builder().statusCode(HttpStatus.OK.value()).message("Empty").key(key).data("Empty").build();
    }
    public static ResponseMapper responseMapper(String key, String message){
        return ResponseMapper.builder().statusCode(HttpStatus.OK.value()).message(message).key(key).data("Empty").build();
    }
    //시스템 에러메세지를 전달하고 싶을때 사용(여러 Object를 Return하는 경우, data 에 여러개를 담으면 됨)
    public static ResponseMapper responseMapper(String message, String key, Object data){
        return ResponseMapper.builder().statusCode(HttpStatus.OK.value()).message(message).key(key).data(data).build();
    }
    //단순히 에러메시지를 보내고 싶을때
    public static ResponseMapper responseMapper(int statusCode, String key, String message){
        return ResponseMapper.builder().statusCode(statusCode).message(message).key(key).data("Empty").build();
    }
    //시스템 에러메세지를 전달하고 싶을때 사용(여러 Object를 Return하는 경우, data 에 여러개를 담으면 됨)
    public static ResponseMapper responseMapper(int statusCode, String message, HashMap<String, Object> data){
        return ResponseMapper.builder().statusCode(statusCode).message(message).data(data).build();
    }
    //시스템 에러메세지를 전달하고 싶을때 사용(단일 Object를 Return하는 경우)
    public static ResponseMapper responseMapper(int statusCode, String message, String key, Object data){
        HashMap<String,Object> tempMap = new HashMap<String,Object>();
        tempMap.put(key,data);
        return ResponseMapper.builder().statusCode(statusCode).message(message).data(tempMap).build();
    }
    //Message 필요 없고 성공한 데이터를 보내고 싶을 때
    public static ResponseMapper responseMapper(String key, Object data){
        return ResponseMapper.builder().statusCode(HttpStatus.OK.value()).message("").key(key).data(data).build();
    }
    //Message 필요 없고 성공한 데이터(Key값은 개발자고 정의)를 보내고 싶을 때
    public static ResponseMapper responseMapper(HashMap<String, Object> data){
        return ResponseMapper.builder().data(data).build();
    }
}