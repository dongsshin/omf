/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : BranchException.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 4. 23. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.framework.exception;


import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

@SuppressWarnings("serial")
public class OmfBranchException extends OmfFoundationBaseException {

    public OmfBranchException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfBranchException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfBranchException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfBranchException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfBranchException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfBranchException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfBranchException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
}
