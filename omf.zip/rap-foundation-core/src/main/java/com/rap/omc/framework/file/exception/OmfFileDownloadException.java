package com.rap.omc.framework.file.exception;

import org.springframework.http.HttpStatus;

public class OmfFileDownloadException extends OmfFileBaseException {
	private static final long serialVersionUID = 1L;
	public OmfFileDownloadException(HttpStatus httpStatus, String message)
	{
	    super(httpStatus,message);
	}
	public OmfFileDownloadException(HttpStatus httpStatus, String code, String message)
	{
	    super(httpStatus,code, message);
	}
	public OmfFileDownloadException(HttpStatus httpStatus, Throwable cause)
	{
	    super(httpStatus,cause);
	}
	public OmfFileDownloadException(HttpStatus httpStatus, String code, String message, Throwable cause)
	{
	    super(httpStatus,code, message, cause);
	}
	public OmfFileDownloadException(HttpStatus httpStatus, String message, Throwable cause)
	{
	    super(httpStatus,message, cause);
	}
}