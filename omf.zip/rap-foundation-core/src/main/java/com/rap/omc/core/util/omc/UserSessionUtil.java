package com.rap.omc.core.util.omc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.config.redis.JsonRedisTemplate;
import com.rap.config.web.security.UserSessionMappingKey;
import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.RedisConstants;
import com.rap.omc.foundation.user.ThreadLocalSessionUtil;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.foundation.user.model.UserSessionVO;
import com.rap.omc.util.RedisUtil;
import org.springframework.beans.BeanUtils;
import org.springframework.data.redis.core.ValueOperations;

import java.util.Map;
import java.util.Set;

public class UserSessionUtil {
	private UserSession userSession;
	private static UserSessionUtil fInstance;
    private JsonRedisTemplate<Object> jsonRedisTemplate;

    @SuppressWarnings("unchecked")
	private synchronized static UserSessionUtil getInstance(){
        if (fInstance == null) {
            fInstance = new UserSessionUtil();
            fInstance.userSession = (UserSession)SpringFactoryUtil.getBean(GlobalConstants.SESSION_USER_INFO);
            fInstance.jsonRedisTemplate = (JsonRedisTemplate<Object>)SpringFactoryUtil.getBean("jsonRedisTemplate");
        }
        return fInstance;
    }
	public static UserSessionVO refreshUserSession(String userId) {
		SysUserVO sysUserVO = FoundationUserUtil.getUserInfo(userId);
		return refreshUserSession(sysUserVO);
	}
	@SuppressWarnings("unchecked")
	public static UserSessionVO refreshUserSession(SysUserVO sysUserVO) {
        getInstance().userSession.setUserSysObid(sysUserVO.getObid());
        getInstance().userSession.setUserId(sysUserVO.getUserId());
		getInstance().userSession.setUserNameEng(sysUserVO.getDescriptions());
		getInstance().userSession.setGroupSet(sysUserVO.getGroupSet());
		getInstance().userSession.setRoleSet(sysUserVO.getRoleSet());
		getInstance().userSession.getRoleSet().add("General User Role");
		getInstance().userSession.setUserSite(sysUserVO.getSite());
		getInstance().userSession.setPropertyMap(sysUserVO.getPropertyList());
		
		Map<String,Object> map = FoundationUserUtil.getUserSessionInfo(sysUserVO.getUserId());
		        
        Set<String> managementRoleSet  = (Set<String>)map.get(UserSessionMappingKey.managementRoleSet);
        
        getInstance().userSession.setManagementRoleSet(managementRoleSet);

        getInstance().userSession.setCompanyCode((String)map.get(UserSessionMappingKey.companyCode));
        getInstance().userSession.setCompanyCodeDesc((String)map.get(UserSessionMappingKey.companyCodeDesc));
        
        getInstance().userSession.setDivisionUnitCode((String)map.get(UserSessionMappingKey.divisionUnitCode));
        getInstance().userSession.setDivisionUnitCodeDesc((String)map.get(UserSessionMappingKey.divisionUnitCodeDesc));
        
        getInstance().userSession.setBusinessUnitCode((String)map.get(UserSessionMappingKey.businessUnitCode));
        getInstance().userSession.setBusinessUnitCodeDesc((String)map.get(UserSessionMappingKey.businessUnitCodeDesc));
        
        getInstance().userSession.setBusinessUnitCode((String)map.get(UserSessionMappingKey.businessUnitCode));
        getInstance().userSession.setBusinessUnitCodeDesc((String)map.get(UserSessionMappingKey.businessUnitCodeDesc));
        
        getInstance().userSession.setUserLocale((String)map.get(UserSessionMappingKey.userLocale));
        getInstance().userSession.setUserTimeZone((String)map.get(UserSessionMappingKey.userTimeZone));

        getInstance().userSession.setDefaultProject((String)map.get(UserSessionMappingKey.defaultProject));
        getInstance().userSession.setPrivateFolder((String)map.get(UserSessionMappingKey.privateFolder));
        getInstance().userSession.setDefaultPrivateFolder((String)map.get(UserSessionMappingKey.defaultPrivateFolder));

        getInstance().userSession.setEmail((String)map.get(UserSessionMappingKey.email));
        getInstance().userSession.setTelephone((String)map.get(UserSessionMappingKey.telephone));
        getInstance().userSession.setUserNameKor((String)map.get(UserSessionMappingKey.userNameKor));
        getInstance().userSession.setUserNameEng((String)map.get(UserSessionMappingKey.userNameEng));
        
        getInstance().userSession.setDepartmentCode((String)map.get(UserSessionMappingKey.departmentCode));
        getInstance().userSession.setDepartmentDesc((String)map.get(UserSessionMappingKey.departmentDesc));

        getInstance().userSession.setLeaderUserId((String)map.get(UserSessionMappingKey.leaderUserId));
        getInstance().userSession.setMainModule((String)map.get(UserSessionMappingKey.mainModule));
        getInstance().userSession.setTimeStamp((String)map.get(UserSessionMappingKey.timeStamp));
        getInstance().userSession.setUserBizObid((String)map.get(UserSessionMappingKey.userBizObid));
        getInstance().userSession.setExcutorId((String)map.get(sysUserVO.getUserId()));
        
        UserSessionVO userSessionVO = new UserSessionVO();
        BeanUtils.copyProperties(getInstance().userSession, userSessionVO);
        registerUserSessionToRedis(sysUserVO.getUserId(),userSessionVO);
        ThreadLocalSessionUtil.refreshThreadLocalFromSession(userSessionVO);
        return userSessionVO;
	}
    public static void refreshUserSession(UserSessionVO userSessionVO) {
        BeanUtils.copyProperties(userSessionVO, getInstance().userSession);
        ThreadLocalSessionUtil.refreshThreadLocalFromSession(userSessionVO);
    }
	private static void registerUserSessionToRedis(String userId,  UserSessionVO userSessionVO) {
        ValueOperations<String, Object> vop = getInstance().jsonRedisTemplate.opsForValue();
        RedisUtil.set(getUserSessionVOKey(userId),userSessionVO);
	}
	public static UserSessionVO getUserSessionVOFromRedis(String userId) {
		ValueOperations<String, Object> vop = getInstance().jsonRedisTemplate.opsForValue();
		Object obj = vop.get(getUserSessionVOKey(userId));
		ObjectMapper mapper = new ObjectMapper();
		UserSessionVO userSessionVO = null;
		try {
			userSessionVO = mapper.convertValue(obj, UserSessionVO.class);
		}catch(Exception e) {
			e.printStackTrace();
		}
		
		return userSessionVO;
	}
	private static String getUserSessionVOKey(String userId) {
		return RedisConstants.REDIS_USER_SESSION_KEY_FROMAT.replace(RedisConstants.REDIS_USER_ID_PARAMETER, userId);
	}
}