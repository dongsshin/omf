package com.rap.omc.controller.model;

import lombok.Getter;
import lombok.Setter;

import java.util.List;
@Setter
@Getter
public class ControllerRequestOutputVO {
    private String serviceName;
    private String requestPath;
    private String controllerMethod;
    private String controllerClass;
    private String httpMethod;
    private String summary = "Not Described";
    private String description = "Not Described";
    private List<ControllerParameterVO> parameters;
    private String parametersJson = "{}";
    private Boolean authorityTarget = false;
    private String authorityCheckItem = "";
    private String returnType = "";
    private String produces = "Not Described";
}
