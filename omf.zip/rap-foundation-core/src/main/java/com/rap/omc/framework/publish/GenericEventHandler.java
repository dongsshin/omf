package com.rap.omc.framework.publish;


import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.schema.object.model.OmcSchemaServiceVO;
import com.rap.omc.util.BaseFoundationUtil;
import com.rap.omc.util.foundation.CommonApiServiceUtil;

public abstract class GenericEventHandler {

    private String serviceName;
    private String serviceUri;

    public GenericEventHandler(String serviceName, String serviceUri) {
        this.serviceName = serviceName;
        this.serviceUri = serviceUri;
    }

    public String getServiceUri() {
        return serviceUri;
    }

    public void setServiceUri(String serviceUri) {
        this.serviceUri = serviceUri;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }
    public void execute(GenericEvent event) throws Exception{
        RestParameterMap restParameterMap = new RestParameterMap(event.getSyncHttpMethod(),this.getServiceUri(),event.getToken());
        restParameterMap.setBody(event.getEventVO());
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithServiceName(this.serviceName);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        CommonApiServiceUtil.callRestService(restParameterMap);
    }
}
