package com.rap.omc.framework.publish.classes.handler;


import com.rap.omc.framework.publish.GenericEventHandler;

public class ClassEventGenericHandler extends GenericEventHandler {
    public ClassEventGenericHandler(String serviceName) {
        super(serviceName,"/foundation/class/eventsynch");
    }
}