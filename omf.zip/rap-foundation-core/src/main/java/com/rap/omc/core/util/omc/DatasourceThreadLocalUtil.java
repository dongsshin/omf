package com.rap.omc.core.util.omc;

import java.util.concurrent.ConcurrentHashMap;

import com.rap.config.datasource.dao.GenericDao;
public class DatasourceThreadLocalUtil {

    private static ThreadLocal<ConcurrentHashMap<String, GenericDao>> threadLocal = new ThreadLocal<ConcurrentHashMap<String, GenericDao>>();
    public static enum KEY {fileDataSource,schemaDataSource}
    public static void init(){
        ConcurrentHashMap<String, GenericDao> map = new ConcurrentHashMap<String, GenericDao>();
        threadLocal.set(map);
    }
    public static void destroy(){
        threadLocal.remove();
    }
    public static boolean isInitialized(){
        return (threadLocal.get() != null);
    }
    public static void setDatasource(KEY key, GenericDao value){
        if (!DatasourceThreadLocalUtil.isInitialized()) {
            DatasourceThreadLocalUtil.init();
        }
        ConcurrentHashMap<String, GenericDao> map = threadLocal.get();
        map.put(key.name(), value);
    }
    public static GenericDao getDatasource(KEY key){
        ConcurrentHashMap<String, GenericDao> map = threadLocal.get();
        if (map == null) {
            return null;
        }
        return map.get(key.name());
    }
}
