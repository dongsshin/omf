package com.rap.omc.constants;

public class TransactionTypeConstants {
    public static enum TYPE {Modify, ModifyBatch, ModifyChange, Create, CreateSet, Delete,DeleteSet, ModifyChangeRel, ModifyChangeRelAll}
}
