/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : AjaxExceptionResolver.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 10. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.framework.resolver.exception;

import com.rap.omc.framework.exception.OmfBaseException;
import com.rap.omc.framework.exception.OmfBusinessException;
import com.rap.omc.framework.exception.OmfDaoException;
import com.rap.omc.framework.resolver.handler.SimpleHeaderMappingExceptionResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.NoSuchMessageException;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.web.servlet.ModelAndView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <pre>
 * Class : AjaxExceptionResolver
 * Description : Ajax Request에 대한 Exception Resolver (RUI에서의 호출은 ajax 호출임)
 * <p> Exception 발생 시, 에러 메시지를 alert창으로 표출함
 * </pre>
 * 
 * @author hyeyoung.park
 */
@Slf4j
public class AjaxExceptionResolver extends SimpleHeaderMappingExceptionResolver {

    @Resource(name = "messageSourceAccessor")
    private MessageSourceAccessor messageSourceAccessor;

    @Override
    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler,
            Exception ex){
        if (supportsHeader(request)) {
            logException(ex, request);
            return doResolveException(request, response, handler, ex);
        }
        return null;
    }

    /**
     * Exception 유형 별로 에러 로그 출력 유형 변경
     * 
     * @param ex
     * @param request
     * @see devonframe.exception.handler.AbstractHeaderMappingExceptionResolver#logException(java.lang.Exception, javax.servlet.http.HttpServletRequest)
     */
    @Override
    protected void logException(Exception ex, HttpServletRequest request){
        String logMessage = buildLogMessage(ex, request);
        if (ex instanceof OmfDaoException || ex instanceof OmfBusinessException) {
            log.warn(logMessage);
        } else if (ex instanceof OmfBaseException) {
            log.warn(logMessage, ex);
        } else {
            log.warn(logMessage, ex);
        }
    }

    /**
     * 에러 메시지 구성 (에러 로그 남길 때, 로그가 남겨지는 형식을 통일하기 위함)
     * 
     * @param ex
     * @param request
     * @return
     * @see devonframe.exception.handler.AbstractHeaderMappingExceptionResolver#buildLogMessage(java.lang.Exception, javax.servlet.http.HttpServletRequest)
     */
    @Override
    protected String buildLogMessage(Exception ex, HttpServletRequest request){
        StringBuilder sb = new StringBuilder("");
        sb.append("\n================================== Exception occurred!(ajax) ===================================\n");
        sb.append("# Exception Information\n");
        sb.append(" - Exception Type   : " + ex.getClass().getName() + "\n");
        sb.append("\n# Exception StackTrace");
        if (ex instanceof OmfBaseException) {
            sb.append("\n Description=" + this.getCompleteExceptionMessage((OmfBaseException)ex) + "\n");
        } else {
            sb.append("\n Description=\n");
        }
        return sb.toString();
    }

    /**
     * 예외 클래스의 메시지 코드, 메시지 파라미터를 가지고 완성된 메시지 문자열을 생성한다.
     *
     * @param be
     * @return
     */
    private String getCompleteExceptionMessage(OmfBaseException be){
        String message = null;
        try {
            message = messageSourceAccessor.getMessage(be.getCode(), be.getMessage());
        } catch (NoSuchMessageException e) {
            message = be.getCode();
            log.debug(message);
        }
        return message;
    }

}
