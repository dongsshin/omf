package com.rap.omc.framework.file.exception;

import org.springframework.http.HttpStatus;

public class OmfAllowOrDenyOmfFileUploadException extends OmfFileUploadException {
	private static final long serialVersionUID = 1L;
	public OmfAllowOrDenyOmfFileUploadException(HttpStatus httpStatus, String message)
	{
	    super(httpStatus,message);
	}
	public OmfAllowOrDenyOmfFileUploadException(HttpStatus httpStatus, String code, String message)
	{
	    super(httpStatus,code, message);
	}
	public OmfAllowOrDenyOmfFileUploadException(HttpStatus httpStatus, Throwable cause)
	{
	    super(httpStatus,cause);
	}
	public OmfAllowOrDenyOmfFileUploadException(HttpStatus httpStatus, String code, String message, Throwable cause)
	{
	    super(httpStatus,code, message, cause);
	}
	public OmfAllowOrDenyOmfFileUploadException(HttpStatus httpStatus, String message, Throwable cause)
	{
	    super(httpStatus,message, cause);
	}
}