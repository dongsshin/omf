package com.rap.omc.framework.publish;

import com.rap.omc.core.util.spring.SpringFactoryLoader;

public class EventPublishUtil {
    public static void publishEvent(GenericEvent event){
        SpringFactoryLoader.getContext().publishEvent(event);
    }
}
