package com.rap.omc.framework.exception;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;


/**
 * <pre>
 * Class : FoundationException
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public class OmfFoundationException extends OmfFoundationBaseException {
	private static final long serialVersionUID = 2217430042345028027L;
    public OmfFoundationException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfFoundationException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfFoundationException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfFoundationException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfFoundationException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
     public OmfFoundationException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfFoundationException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
    public OmfFoundationException(HttpStatus httpStatus, String code, String message, Throwable cause)
    {
        super(httpStatus,code, message, cause);
    }
}
