package com.rap.omc.framework.file.exception;

import org.springframework.http.HttpStatus;

public class OmfFileSizeLimitException extends OmfFileUploadException {
	private static final long serialVersionUID = 1L;
	public OmfFileSizeLimitException(HttpStatus httpStatus, String message)
	{
		super(httpStatus,message);
	}
	public OmfFileSizeLimitException(HttpStatus httpStatus, String code, String message)
	{
		super(httpStatus,code, message);
	}
	public OmfFileSizeLimitException(HttpStatus httpStatus, Throwable cause)
	{
		super(httpStatus,cause);
	}
	public OmfFileSizeLimitException(HttpStatus httpStatus, String code, String message, Throwable cause)
	{
		super(httpStatus,code, message, cause);
	}
	public OmfFileSizeLimitException(HttpStatus httpStatus, String message, Throwable cause)
	{
		super(httpStatus,message, cause);
	}
}