
package com.rap.omc.intf;

public interface TriggerUtilService {

    public void createDataByTrigger(IfPlmDataByTriggerVO triggerVO);
    public void createDataByTriggerPjtCommonAll(IfPlmDataByTriggerVO triggerVO);
    public void createDataByTriggerPjtModel(IfPlmDataByTriggerVO triggerVO);
}