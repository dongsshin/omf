package com.rap.omc.controller.model;

import java.util.HashMap;

public class CSysUserVO {
    private String userId;
    private String descriptions;
    private String password;
    private String site;
    private String emailId;
    private String[] roleSet;
    private String[] groupSet;
    private HashMap<String,String> property = new HashMap<String,String>();

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getDescriptions() {
        return descriptions;
    }

    public void setDescriptions(String descriptions) {
        this.descriptions = descriptions;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSite() {
        return site;
    }

    public void setSite(String site) {
        this.site = site;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public String[] getRoleSet() {
        return roleSet;
    }

    public void setRoleSet(String[] roleSet) {
        this.roleSet = roleSet;
    }

    public String[] getGroupSet() {
        return groupSet;
    }

    public void setGroupSet(String[] groupSet) {
        this.groupSet = groupSet;
    }

    public HashMap<String, String> getProperty() {
        return property;
    }

    public void setProperty(HashMap<String, String> property) {
        this.property = property;
    }
}
