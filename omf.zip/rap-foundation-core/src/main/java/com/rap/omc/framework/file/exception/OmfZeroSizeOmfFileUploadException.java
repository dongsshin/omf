package com.rap.omc.framework.file.exception;

import org.springframework.http.HttpStatus;

public class OmfZeroSizeOmfFileUploadException extends OmfFileUploadException {
	private static final long serialVersionUID = 1L;
	public OmfZeroSizeOmfFileUploadException(HttpStatus httpStatus, String message)
	{
		super(httpStatus,message);
	}
	public OmfZeroSizeOmfFileUploadException(HttpStatus httpStatus, String code, String message)
	{
		super(httpStatus,code, message);
	}
	public OmfZeroSizeOmfFileUploadException(HttpStatus httpStatus, Throwable cause)
	{
		super(httpStatus,cause);
	}
	public OmfZeroSizeOmfFileUploadException(HttpStatus httpStatus, String code, String message, Throwable cause)
	{
		super(httpStatus,code, message, cause);
	}
	public OmfZeroSizeOmfFileUploadException(HttpStatus httpStatus, String message, Throwable cause)
	{
		super(httpStatus,message, cause);
	}
}