package com.rap.omc.framework.view;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.ResponseConstants;
import com.rap.omc.framework.exception.OmfDaoException;
import com.rap.omc.framework.exception.*;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.http.MediaType;
import org.springframework.web.servlet.view.AbstractView;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;
public class AjaxExceptionView extends AbstractView {

    public static final String DEFAULT_EXCEPTION_ATTRIBUTE = "exception";

    public static final String DEFAULT_EXCEPTION_CODE_ATTRIBUTE = "exceptionCode";
	
    private String exceptionAttribute = DEFAULT_EXCEPTION_ATTRIBUTE;

    @Resource(name = "messageSourceAccessor")
    private MessageSourceAccessor messageSourceAccessor;

    public void setExceptionAttribute(String exceptionAttribute){
        this.exceptionAttribute = exceptionAttribute;
    }

    protected void renderMergedOutputModel(Map<String, Object> model, HttpServletRequest request,
            HttpServletResponse response) throws Exception{

        Exception ex = (Exception)model.get(this.exceptionAttribute);
        Map<String, Object> exceptionModel = new HashMap<String, Object>();
       
        if (ex != null) {
            
            if (ex instanceof OmfFoundationException){
                exceptionModel.put(GlobalConstants.M_STATUS_CODE, ResponseConstants.STATUS_SYSTEM_DEFAULT_ERROR );
                exceptionModel.put(GlobalConstants.M_MESSAGE, ex.getMessage());
                
            }else if (ex instanceof OmfApplicationException){
                exceptionModel.put(GlobalConstants.M_STATUS_CODE,  ((OmfApplicationException) ex).getHttpStatus());
                exceptionModel.put(GlobalConstants.M_MESSAGE, ex.getMessage());
                
            }else if (ex instanceof OmfNoAuthorityException) {
                OmfNoAuthorityException be = (OmfNoAuthorityException)ex;
                exceptionModel.put(GlobalConstants.M_STATUS_CODE, ResponseConstants.STATUS_AUTHORIZATION_FAIL);
                exceptionModel.put(GlobalConstants.M_MESSAGE, be.getMessage());
                
            }else if (ex instanceof OmfNoAuthorityTokenException) {
                OmfNoAuthorityTokenException be = (OmfNoAuthorityTokenException)ex;
                exceptionModel.put(GlobalConstants.M_STATUS_CODE, ResponseConstants.STATUS_AUTHORIZATION_FAIL);
                exceptionModel.put(GlobalConstants.M_MESSAGE, be.getMessage());
                
            }else if (ex instanceof OmfNoSessionException) {
                OmfNoSessionException be = (OmfNoSessionException)ex;
                exceptionModel.put(GlobalConstants.M_STATUS_CODE,  ResponseConstants.STATUS_LOGIN_REQUIRED);
                exceptionModel.put(GlobalConstants.M_MESSAGE, be.getMessage());
                
            }else {
                if (ex instanceof OmfDaoException) {
                    exceptionModel.put(GlobalConstants.M_STATUS_CODE, ResponseConstants.STATUS_TRANSACTION_FAILED);                            
                    exceptionModel.put(GlobalConstants.M_MESSAGE,messageSourceAccessor.getMessage("com.fail.database"));
                    
                } else {
                    exceptionModel.put(GlobalConstants.M_STATUS_CODE, ResponseConstants.STATUS_UNKNOWN_HOST_ERROR);
                    exceptionModel.put(GlobalConstants.M_MESSAGE, ex.getMessage());
                    
                }
            }
            writeExceptionContent(response, HttpServletResponse.SC_OK, exceptionModel);
        }
    }

    protected void writeExceptionContent(HttpServletResponse response, int httpStatus, Map<String, Object> model) throws Exception{
        ObjectMapper mapper = new ObjectMapper();
        String jsonStr = mapper.writeValueAsString(model);
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        response.setStatus(httpStatus);
        response.getWriter().write(jsonStr);
    }
}
