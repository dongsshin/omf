/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : OQLException1.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2016. 7. 27.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.omc.framework.exception;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;


/**
 * <pre>
 * Class : OQLException
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
@SuppressWarnings("serial")
public class OmfOQLException extends OmfFoundationBaseException {
    public OmfOQLException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfOQLException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfOQLException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfOQLException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfOQLException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfOQLException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfOQLException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
}