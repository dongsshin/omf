package com.rap.omc.framework.exception;

import org.springframework.http.HttpStatus;

public class StatusConstants {

    public static final String MAP_ERROR_KEY_errorStatusCode = "_omfErrorStatusCode_";
    public static final String MAP_ERROR_KEY_errorRequestUri = "_omfErrorRequestUri_";
    public static final String MAP_ERROR_KEY_errorMessage = "_omfErrorMessage_";
    public static final String MAP_ERROR_KEY_exception = "_omfException_";
    public static final String MAP_ERROR_SESSION_ATTR = "_omfError_";



    public static final HttpStatus INTERNAL_SERVER_ERROR = HttpStatus.INTERNAL_SERVER_ERROR;
    public static final HttpStatus FOUND = HttpStatus.FOUND;
    public static final HttpStatus BAD_REQUEST = HttpStatus.BAD_REQUEST;
    public static final HttpStatus NOT_ACCEPTABLE = HttpStatus.NOT_ACCEPTABLE;
    public static final HttpStatus OK = HttpStatus.OK;
    public static final HttpStatus HTTP_VERSION_NOT_SUPPORTED = HttpStatus.HTTP_VERSION_NOT_SUPPORTED;
    public static final HttpStatus PAYLOAD_TOO_LARGE = HttpStatus.PAYLOAD_TOO_LARGE;
    public static final HttpStatus UNAUTHORIZED = HttpStatus.UNAUTHORIZED;
    public static final HttpStatus[] validArray = {
            INTERNAL_SERVER_ERROR,
            FOUND,
            BAD_REQUEST,
            NOT_ACCEPTABLE,
            OK,
            HTTP_VERSION_NOT_SUPPORTED,
            PAYLOAD_TOO_LARGE,
            UNAUTHORIZED};
}
