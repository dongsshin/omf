/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CacheInterfaceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 18. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service.impl;

import com.rap.config.datasource.dao.SchemaDao;
import com.rap.omc.core.oql.model.OmcSQLVariableParameter;
import com.rap.omc.core.oql.utility.OmcFoundationConstant;
import com.rap.omc.foundation.classes.model.ClassDbmsTableVO;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.foundation.classes.model.ClassNameForDisplayVO;
import com.rap.omc.foundation.classes.model.ColumnInfo;
import com.rap.omc.foundation.classes.service.ClassInfoService;
import com.rap.omc.foundation.classes.service.SchemaConstantsService;
import com.rap.omc.foundation.lifecycle.model.LifeCycleInfo;
import com.rap.omc.schema.object.dom.OmcSchemaProperty;
import com.rap.omc.schema.object.model.OmcSchemaPropertyVO;
import com.rap.omc.schema.util.OmcSchemaUtil;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.foundation.ClassInfoUtil;
import com.rap.omc.util.foundation.LifeCycleUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

/**
 * <pre>
 * Class : SchemaConstantsServiceImpl
 * Description : TODO
 * </pre>
 *
 */ 
@Service("schemaConstantsService")
public class SchemaConstantsServiceImpl implements SchemaConstantsService {
    @Autowired
    private SchemaDao schemaDao;
    @Override
    public List<OmcSchemaPropertyVO> getSystemConstantsList(){
        StringBuffer sqlStrBuff = new StringBuffer();
        OmcSQLVariableParameter variableParameter = new OmcSQLVariableParameter();
        OmcSchemaProperty.getCommonSelectSql(sqlStrBuff, variableParameter);
        sqlStrBuff.append(OmcFoundationConstant.newline).append("inner join psysconstants b");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("on a.psys_object = b.obid");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("where 1=1");
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{funVariable_00001}", "#{funVariable_00001}"));
        variableParameter.setFunVariable_00001(String.valueOf(OmcSystemConstants.SYSPTY_KIND_Constants));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pflags", "#{funVariable_00002}", "#{funVariable_00002}"));
        variableParameter.setFunVariable_00002(String.valueOf(OmcSystemConstants.SYSPTY_FLAG_Active));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("b.pflags", "#{funVariable_00003}", "#{funVariable_00003}"));
        variableParameter.setFunVariable_00003(String.valueOf(OmcSystemConstants.SYSCONSTANTS_FLAG_Active));
        //System.out.println(sqlStrBuff.toString());
        variableParameter.setSql(sqlStrBuff.toString());
        List<OmcSchemaPropertyVO> propertyList = schemaDao.selectList("SchemaNew.dynamicRetrieveProperty", variableParameter);
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getLifeCycleConstantsList(String moduleName){
        StringBuffer sqlStrBuff = new StringBuffer();
        OmcSQLVariableParameter variableParameter = new OmcSQLVariableParameter();
        OmcSchemaProperty.getCommonSelectSql(sqlStrBuff, variableParameter);
        sqlStrBuff.append(OmcFoundationConstant.newline).append("inner join psyslifecycle b");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("on a.psys_object = b.obid");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("where 1=1");
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{funVariable_00001}", "#{funVariable_00001}"));
        variableParameter.setFunVariable_00001(String.valueOf(OmcSystemConstants.SYSPTY_KIND_LifeCycle));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pflags", "#{funVariable_00002}", "#{funVariable_00002}"));
        variableParameter.setFunVariable_00002(String.valueOf(OmcSystemConstants.SYSPTY_FLAG_Active));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("b.pflags", "#{funVariable_00003}", "#{funVariable_00003}"));
        variableParameter.setFunVariable_00003(String.valueOf(OmcSystemConstants.SYSLCYCLE_FLAG_Active));
        if(!moduleName.equals("All")) {
            sqlStrBuff.append(OmcFoundationConstant.newline).append("and (b.pmodule_list like #{funVariable_00004} or b.pmodule_list like  #{funVariable_00005})");
            variableParameter.setFunVariable_00004("%#" + moduleName + "#%");
            variableParameter.setFunVariable_00005("%#" + "All" + "#%");
        }
        variableParameter.setSql(sqlStrBuff.toString());
        List<OmcSchemaPropertyVO> propertyList = schemaDao.selectList("SchemaNew.dynamicRetrieveProperty", variableParameter);
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getStateConstantsList(String moduleName){
        StringBuffer sqlStrBuff = new StringBuffer();
        OmcSQLVariableParameter variableParameter = new OmcSQLVariableParameter();
        OmcSchemaProperty.getCommonSelectSql(sqlStrBuff, variableParameter);
        sqlStrBuff.append(OmcFoundationConstant.newline).append("inner join psysstate b");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("inner join psyslifecycle c");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("on  a.psys_object = b.obid");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("and b.plife_cycle = c.obid");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("where 1=1");
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{funVariable_00001}", "#{funVariable_00001}"));
        variableParameter.setFunVariable_00001(String.valueOf(OmcSystemConstants.SYSPTY_KIND_State));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pflags", "#{funVariable_00002}", "#{funVariable_00002}"));
        variableParameter.setFunVariable_00002(String.valueOf(OmcSystemConstants.SYSPTY_FLAG_Active));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("b.pflags", "#{funVariable_00003}", "#{funVariable_00003}"));
        variableParameter.setFunVariable_00003(String.valueOf(OmcSystemConstants.SYSSTATE_FLAG_Active));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("c.pflags", "#{funVariable_00004}", "#{funVariable_00004}"));
        variableParameter.setFunVariable_00004(String.valueOf(OmcSystemConstants.SYSLCYCLE_FLAG_Active));
        if(!moduleName.equals("All")) {
            sqlStrBuff.append(OmcFoundationConstant.newline).append("and (c.pmodule_list like #{funVariable_00005} or c.pmodule_list like  #{funVariable_00006})");
            variableParameter.setFunVariable_00005("%#" + moduleName + "#%");
            variableParameter.setFunVariable_00006("%#" + "All" + "#%");
        }

        variableParameter.setSql(sqlStrBuff.toString());
        List<OmcSchemaPropertyVO> propertyList = schemaDao.selectList("SchemaNew.dynamicRetrieveProperty", variableParameter);
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getClassBizConstantsList(String moduleName){
        StringBuffer sqlStrBuff = new StringBuffer();
        OmcSQLVariableParameter variableParameter = new OmcSQLVariableParameter();
        OmcSchemaProperty.getCommonSelectSql(sqlStrBuff, variableParameter);
        sqlStrBuff.append(OmcFoundationConstant.newline).append("inner join psysbizobjectclassinfo b");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("on a.psys_object = b.obid");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("where 1=1");
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{funVariable_00001}", "#{funVariable_00001}"));
        variableParameter.setFunVariable_00001(String.valueOf(OmcSystemConstants.SYSPTY_KIND_Class));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pflags", "#{funVariable_00002}", "#{funVariable_00002}"));
        variableParameter.setFunVariable_00002(String.valueOf(OmcSystemConstants.SYSPTY_FLAG_Active));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("b.pflags", "#{funVariable_00003}", "#{funVariable_00003}"));
        variableParameter.setFunVariable_00003(String.valueOf(OmcSystemConstants.BUSINESS_FLAG_Active));
        if(!moduleName.equals("All")) {
            sqlStrBuff.append(OmcFoundationConstant.newline).append("and b.pmodule_name = #{funVariable_00004}");
            variableParameter.setFunVariable_00004(moduleName);
        }
        variableParameter.setSql(sqlStrBuff.toString());
        List<OmcSchemaPropertyVO> propertyList = schemaDao.selectList("SchemaNew.dynamicRetrieveProperty", variableParameter);
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getClassRelConstantsList(String moduleName){
        StringBuffer sqlStrBuff = new StringBuffer();
        OmcSQLVariableParameter variableParameter = new OmcSQLVariableParameter();
        OmcSchemaProperty.getCommonSelectSql(sqlStrBuff, variableParameter);
        sqlStrBuff.append(OmcFoundationConstant.newline).append("inner join psysrelobjectclassinfo b");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("on a.psys_object = b.obid");
        sqlStrBuff.append(OmcFoundationConstant.newline).append("where 1=1");
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{funVariable_00001}", "#{funVariable_00001}"));
        variableParameter.setFunVariable_00001(String.valueOf(OmcSystemConstants.SYSPTY_KIND_Class));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pflags", "#{funVariable_00002}", "#{funVariable_00002}"));
        variableParameter.setFunVariable_00002(String.valueOf(OmcSystemConstants.SYSPTY_FLAG_Active));
        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("b.pflags", "#{funVariable_00003}", "#{funVariable_00003}"));
        variableParameter.setFunVariable_00003(String.valueOf(OmcSystemConstants.RELATION_FLAG_Active));
        if(!moduleName.equals("All")) {
            sqlStrBuff.append(OmcFoundationConstant.newline).append("and b.pmodule_name = #{funVariable_00004}");
            variableParameter.setFunVariable_00004(moduleName);
        }
        variableParameter.setSql(sqlStrBuff.toString());
        List<OmcSchemaPropertyVO> propertyList = schemaDao.selectList("SchemaNew.dynamicRetrieveProperty", variableParameter);
        return(propertyList);
    }

}
