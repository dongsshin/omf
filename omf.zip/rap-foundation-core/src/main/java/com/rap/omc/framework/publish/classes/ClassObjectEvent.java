package com.rap.omc.framework.publish.classes;

import com.event.publish.vo.EventClassVO;
import com.rap.omc.framework.publish.GenericEvent;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpMethod;

@Setter
@Getter
public class ClassObjectEvent extends GenericEvent {
    public ClassObjectEvent(Object source, EventClassVO eventCodeVO) {
        super(source,eventCodeVO, HttpMethod.POST);
    }
}