package com.rap.omc.controller;

import com.rap.omc.framework.controller.RestBaseController;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FoundationUiController extends RestBaseController {

}
