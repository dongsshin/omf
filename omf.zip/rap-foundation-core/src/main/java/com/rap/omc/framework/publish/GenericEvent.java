package com.rap.omc.framework.publish;

import com.event.publish.generic.GenericEventVO;
import com.rap.config.web.security.TokenUtils;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@Setter
@Getter
public class GenericEvent {
    private GenericEventVO eventVO;
    private Object source;
    private HttpMethod syncHttpMethod;
    private String token;
    public GenericEvent(Object source, GenericEventVO eventVO, HttpMethod syncHttpMethod) {
        this.source = source;
        this.eventVO = eventVO;
        this.syncHttpMethod = syncHttpMethod;
        this.token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getHeader(TokenUtils.HEADER_STRING);
    }
}
