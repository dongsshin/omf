package com.rap.omc.controller.service.impl;

import com.rap.config.web.security.TokenUtils;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.controller.service.FoundationRestService;
import com.rap.omc.core.util.general.FoundationDbProxy;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.util.OmcUniqueIDGenerator;
import com.rap.omc.util.NullUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

@Service("foundationRestService")
public class FoundationRestServiceImpl implements FoundationRestService {
    @Autowired
    private RestTemplate restTemplate;
    @Override
    public <T> T callRestService(RestParameterMap restParameterMap,Class<T> valueType) {

        //아래부분은 restTemplate Bean에 반영되어져 있음.
        //DefaultUriBuilderFactory builderFactory = new DefaultUriBuilderFactory();
        //builderFactory.setEncodingMode(DefaultUriBuilderFactory.EncodingMode.VALUES_ONLY); //+
        //RestTemplate restTemplate = new RestTemplate();
        //restTemplate.setUriTemplateHandler(builderFactory);

        HttpHeaders headers = new HttpHeaders();

        headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
        String token = restParameterMap.getToken();
        headers.set(TokenUtils.HEADER_STRING, restParameterMap.getToken());
        String globalTransactionFlag = "Y";
        if(!FoundationDbProxy.getTransactionLogFlag()) globalTransactionFlag = "N";
        headers.set(TokenUtils.HEADER_GLOBAL_TRANSACTION_ID, ThreadLocalUtil.getString(ThreadLocalUtil.KEY.globalTransactionId, OmcUniqueIDGenerator.getObid()));
        headers.set(TokenUtils.HEADER_GLOBAL_TRANSACTION_FLAG, globalTransactionFlag);

        if(restParameterMap.hasBody() && restParameterMap.getRequestMethod().name().equals(HttpMethod.GET.name())){
            throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Get cannot Body!!");
        }
        HttpEntity entity = null;
        if(restParameterMap.hasBody()){
            entity = new HttpEntity(restParameterMap.getBody(),headers);
        }else{
            entity = new HttpEntity(headers);
        }
        ResponseEntity<LinkedHashMap> response = null;
        String str = restParameterMap.getURL();

        UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(restParameterMap.getURL());

        for (Map.Entry<String, Object> entry : restParameterMap.getQueryMap().entrySet()) {
            builder.queryParam(entry.getKey(), entry.getValue());
        }
        if(!NullUtil.isNone(restParameterMap.getPathMap())) builder.uriVariables(restParameterMap.getPathMap());
        builder.build(false);
        String ddd = builder.toUriString();
        response = restTemplate.exchange(builder.toUriString(),restParameterMap.getRequestMethod(),entity,LinkedHashMap.class);
        if(response.getStatusCode() == HttpStatus.OK) {
            LinkedHashMap<String,Object> map = response.getBody();
            map = (LinkedHashMap<String,Object>)map.get(GlobalConstants.M_DATA);
            return (T)map.get(GlobalConstants.M_RESULT);
        }else{
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Call Error");
        }
    }
}