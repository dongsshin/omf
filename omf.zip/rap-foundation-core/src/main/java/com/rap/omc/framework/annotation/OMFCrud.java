package com.rap.omc.framework.annotation;

public class OMFCrud {
    public static enum KEY {Create, Modify,Delete,Read}
}
