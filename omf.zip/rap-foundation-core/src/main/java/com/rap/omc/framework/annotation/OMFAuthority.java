package com.rap.omc.framework.annotation;

import java.lang.annotation.*;

@Target({ElementType.TYPE, ElementType.METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface OMFAuthority {
    public abstract boolean target() default false;
    public abstract String checkItem() default "N/A";
    public abstract OMFCrud.KEY[] crudTypes() default {};
    public abstract String[] roles() default {};
    public abstract String[] groups() default {};
    public abstract String[] users() default {};
}