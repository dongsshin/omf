package com.rap.omc.foundation.workflow;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class WorkflowMethodCallParameter {
    private String serviceName;
    private String program;
    private String method;
    private String obid;
}