package com.rap.omc.foundation.user.model;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;

public class OmfSecurityMember extends User{
	private static final String ROLE_PREFIX = "ROLE_";
    private static final long serialVersionUID = 1L;
    
    private String ip;

    private SysUserVO sysUserVO;

    public SysUserVO getSysUserVO() {
        return sysUserVO;
    }

    public OmfSecurityMember(SysUserVO sysUserVO) {
    	super(sysUserVO.getUserId(), sysUserVO.getPassword(), (Collection<? extends GrantedAuthority>) makeGrantedAuthority(sysUserVO.getRoleSet()));
        sysUserVO.setPassword("...");
    	this.sysUserVO = sysUserVO;
    }
    public String getIp() {
        return ip;
    }
    public void setIp(String ip) {
        this.ip = ip;
    }
    private static List<? extends GrantedAuthority> makeGrantedAuthority(Set<String> roles){
        List<GrantedAuthority> list = new ArrayList<>();
        if(!roles.contains("USER")) roles.add("USER");
        roles.forEach(role -> list.add(new SimpleGrantedAuthority(ROLE_PREFIX + role)));
        return list;
    }
}
