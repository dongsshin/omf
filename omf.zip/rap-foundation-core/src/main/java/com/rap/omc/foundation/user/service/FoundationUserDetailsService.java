package com.rap.omc.foundation.user.service;

import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.core.util.omc.UserSessionUtil;
import com.rap.omc.foundation.user.model.OmfSecurityMember;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.foundation.user.model.UserSessionVO;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.PropertiesUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpSession;

@Service("foundationUserDetailsService")
@Slf4j
public class FoundationUserDetailsService implements UserDetailsService{
	@Autowired
	UserSession userSession;
	@Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		boolean isSetUp = PropertiesUtil.getBoolean("setup.isSetUp");
    	SysUserVO sysUserVO = null;
    	try {
    		sysUserVO = FoundationUserUtil.getUserInfo(username,true);
    	}catch(Exception e) {
    		e.printStackTrace();
    		throw e;
    	}
    	if(NullUtil.isNull(sysUserVO)) throw new UsernameNotFoundException(username);
        ServletRequestAttributes attr = (ServletRequestAttributes) RequestContextHolder.currentRequestAttributes();
        HttpSession session = attr.getRequest().getSession(true);
//        if(!isSetUp) {
        	UserSessionVO userSessionVO = UserSessionUtil.refreshUserSession(sysUserVO);
            session.setAttribute(GlobalConstants.SESSION_USER_INFO, userSessionVO);
            if(log.isInfoEnabled()){
				log.info(userSessionVO.toString());
				log.info(userSession.toString());
			}
//        }
		return new OmfSecurityMember(sysUserVO);
    }
}