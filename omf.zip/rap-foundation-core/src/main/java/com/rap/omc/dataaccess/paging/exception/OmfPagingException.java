package com.rap.omc.dataaccess.paging.exception;

import com.rap.omc.framework.exception.OmfFoundationBaseException;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

public class OmfPagingException extends OmfFoundationBaseException {
    public OmfPagingException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfPagingException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfPagingException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfPagingException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfPagingException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfPagingException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfPagingException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
}