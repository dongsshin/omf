package com.rap.omc.framework.message.exception;

import com.rap.omc.framework.exception.OmfFoundationBaseException;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

public class OmfMessageException extends OmfFoundationBaseException {
    private static final long serialVersionUID = -6870044584432409361L;


    public OmfMessageException(HttpStatus httpStatus, String code) {
        super(httpStatus, code);
    }

    public OmfMessageException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus, code, message);
    }

    public OmfMessageException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus, cause);
    }

    public OmfMessageException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus, code, cause);
    }

    public OmfMessageException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus, code, messageSource);
    }

    public OmfMessageException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus, code, messageParameters);
    }

    public OmfMessageException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus, code, messageParameters, cause);
    }
}