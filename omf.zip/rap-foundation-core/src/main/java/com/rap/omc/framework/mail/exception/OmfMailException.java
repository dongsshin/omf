package com.rap.omc.framework.mail.exception;

import com.rap.omc.framework.exception.OmfFoundationBaseException;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

public class OmfMailException extends OmfFoundationBaseException {

    public OmfMailException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfMailException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfMailException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfMailException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfMailException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfMailException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfMailException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
}
