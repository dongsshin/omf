/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : MemuInfoService.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2017. 4. 24.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.omc.foundation.menu.service;

import com.rap.omc.schema.object.model.OmcSchemaMenuVO;

import java.util.List;
import java.util.Map;
import java.util.Set;


/**
 * <pre>
 * Class : MemuInfoService
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public interface MenuAccessService {
    public void txnAddMenuForRole(String role, String menu, Map<String,String> map);
    public void txnAddMenuForRole(String role, List<String> menuList, Map<String,String> map);
    public void txnAddMenuForGroup(String group, String menu, Map<String,String> map);
    public void txnAddMenuForGroup(String group, List<String> menuList, Map<String,String> map);
    public void txnAddMenuForUser(String user, String menu, Map<String,String> map);
    public void txnAddMenuForUser(String user, List<String> menuList, Map<String,String> map);

    public void txnAddMenuForRole(List<String> roleList, String menu, Map<String,String> map);
    public void txnAddMenuForRole(List<String> roleList, List<String> menuList, Map<String,String> map);
    public void txnAddMenuForGroup(List<String> groupList, String menu, Map<String,String> map);
    public void txnAddMenuForGroup(List<String> groupList, List<String> menuList, Map<String,String> map);
    public void txnAddMenuForUser(List<String> userIdList, String menu, Map<String,String> map);
    public void txnAddMenuForUser(List<String> userIdList, List<String> menuList, Map<String,String> map);

    public void txnRemoveMenuForRole(String role, String menu);
    public void txnRemoveMenuForRole(String role, List<String> menuList);
    public void txnRemoveMenuForGroup(String group, String menu);
    public void txnRemoveMenuForGroup(String group, List<String> menuList);
    public void txnRemoveMenuForUser(String userId, String menu);
    public void txnRemoveMenuForUser(String userId, List<String> menuList);

    public void txnRemoveMenuForRole(List<String> roleList, String menu);
    public void txnRemoveMenuForRole(List<String> roleList, List<String> menuList);
    public void txnRemoveMenuForGroup(List<String> groupList, String menu);
    public void txnRemoveMenuForGroup(List<String> groupList, List<String> menuList);
    public void txnRemoveMenuForUser(List<String> userIdList, String menu);
    public void txnRemoveMenuForUser(List<String> userIdList, List<String> menuList);

    public List<OmcSchemaMenuVO> getMenuListForRole(String role);
    public List<OmcSchemaMenuVO> getMenuListForGroup(String group);
    public List<OmcSchemaMenuVO> getMenuListForUser(String userId);

    public List<OmcSchemaMenuVO> getMenuListForRole(String role, boolean expand);
    public List<OmcSchemaMenuVO> getMenuListForGroup(String group,boolean expand);
    public List<OmcSchemaMenuVO> getMenuListForUser(String userId,boolean expand);
    public List<OmcSchemaMenuVO> getMenuListForCommonUserWithNames(List<String> nameList,boolean expand);
    public Set<String> getMenuSetForCommonUserWithNames(List<String> nameList, boolean expand);
}
