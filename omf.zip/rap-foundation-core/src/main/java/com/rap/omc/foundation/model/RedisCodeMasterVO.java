package com.rap.omc.foundation.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RedisCodeMasterVO  extends RedisRootVO{
    private String  names;
    private String  titles;
    private Boolean useCache;
    public RedisCodeMasterVO() {}

    public RedisCodeMasterVO(String names, String titles, Boolean useCache) {
        this.names = names;
        this.titles = titles;
        this.useCache = useCache;
    }
}
