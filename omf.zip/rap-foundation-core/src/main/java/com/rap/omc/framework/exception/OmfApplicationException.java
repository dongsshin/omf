/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : ApplicationException.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 2. 3. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.framework.exception;


import org.springframework.context.MessageSource;

import com.rap.omc.core.util.MessageUtil;
import org.springframework.http.HttpStatus;


/**
 * <pre>
 * Class : ApplicationException
 * Description : 프로젝트에서 비즈니스 Rule 위반 시 발생시키는 Exception
 * </pre>
 * 
 * @author hyeyoung.park
 */
@SuppressWarnings("serial")
public class OmfApplicationException extends OmfBusinessException {
    public OmfApplicationException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfApplicationException(HttpStatus httpStatus, Throwable cause) {
        super(httpStatus,cause);
    }
    public OmfApplicationException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code, messageSource);
    }

    public OmfApplicationException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfApplicationException(HttpStatus httpStatus, String code, Object[] messageParameters) {
        super(httpStatus,code);
        super.setMessage(MessageUtil.getMessage(code, messageParameters));
    }

    public OmfApplicationException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code, null, cause);
        super.setMessage(MessageUtil.getMessage(code, messageParameters));
    }
    public OmfApplicationException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters) {
        super(httpStatus,code, messageSource, messageParameters);
    }
}
