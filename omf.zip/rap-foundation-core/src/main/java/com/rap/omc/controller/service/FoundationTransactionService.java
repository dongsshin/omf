package com.rap.omc.controller.service;

import com.rap.omc.controller.model.CParmTranVO;
import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;

import java.util.List;

public interface FoundationTransactionService {
    public List<TransactionLinkVO> getTransactionLinkListPaging(CParmTranVO cParmTranVO);
    public List<TransactionLinkVO> getTransactionLinkListForObject(String obid);
    public List<TransactionLinkVO> getTransactionLinkListForTransactionId(String globalTransactionId);
    public List<TransactionLinkVO> getRelatedTranLinkListForTranSeq(int transactionSeq);
    public List<String> getGlobalTransactionIdListForObject(String obid);
    public TransactionLinkVO getTransactionLink(int transactionSeq);
    public void txnRollbackForTransactionSeq(int transactionSeq, RestParameterMap RestParameterMap);
    public void txnRollbackForTransactionId(String globalTransactionId);
}
