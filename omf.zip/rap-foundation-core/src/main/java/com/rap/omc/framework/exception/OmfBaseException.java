package com.rap.omc.framework.exception;

import com.rap.omc.core.util.MessageUtil;
import com.rap.omc.util.StrUtil;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Locale;

	public class OmfBaseException extends RuntimeException
{
    private static final long serialVersionUID = 1L;
    private String message = "";
    private String code = "NA";
    private HttpStatus httpStatus = HttpStatus.INTERNAL_SERVER_ERROR;


    @Override
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }

    public void setHttpStatus(HttpStatus httpStatus) {
        this.httpStatus = httpStatus;
    }

    public OmfBaseException(HttpStatus httpStatus, String message)
    {
        super(message);
        this.message = message;
        this.httpStatus = httpStatus;
        setMessageAndCode(message);
    }
    public OmfBaseException(HttpStatus httpStatus, String code, String message)
    {
        super(message);
        this.httpStatus = httpStatus;
        this.code = code;
        this.message = message;
    }
    public OmfBaseException(HttpStatus httpStatus, Throwable cause)
    {
        super(cause);
        this.httpStatus = httpStatus;
    }
    public OmfBaseException(HttpStatus httpStatus, String message, Throwable cause)
    {
        super(message, cause);
        this.httpStatus = httpStatus;
        this.message = message;
        setMessageAndCode(message);
    }
    public OmfBaseException(HttpStatus httpStatus, String code, String message, Throwable cause)
    {
        super(message, cause);
        this.httpStatus = httpStatus;
        this.message = message;
        this.code = code;
    }
    public OmfBaseException(HttpStatus httpStatus, String code, MessageSource messageSource)
    {
    	this(httpStatus,code, messageSource, null);
    }
    public OmfBaseException(HttpStatus httpStatus, String code, Object[] messageParameters)
    {
        this(httpStatus,code, null, messageParameters);
    }
    public OmfBaseException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause)
    {
        this(httpStatus,code, null, messageParameters, cause);
    }

    public OmfBaseException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters)
    {
        this(httpStatus,code, messageSource, messageParameters, Locale.getDefault());
    }

    public OmfBaseException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters, Throwable cause)
    {
        this(httpStatus,code, messageSource, messageParameters, Locale.getDefault(), cause);
    }
    public OmfBaseException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters, Locale locale)
    {
        this(httpStatus,(messageSource != null) ? messageSource.getMessage(code, messageParameters, locale) : "");
        this.code = code;
    }
    public OmfBaseException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters, Locale locale, Throwable cause)
    {
        this(httpStatus,(messageSource != null) ? messageSource.getMessage(code, messageParameters, locale) : "", cause);
        this.code = code;
    }


    public Throwable getRootCause()
    {
        Throwable tempCause = getCause();
        while (tempCause != null) {
            if (tempCause.getCause() == null) {
                 break;
            }
            tempCause = tempCause.getCause();
        }
        return tempCause;
    }
    public String getStackTraceString()
    {
        StringWriter writer = new StringWriter();
        super.printStackTrace(new PrintWriter(writer));
        return writer.toString();
    }
    public void printStackTrace(PrintWriter log)
    {
        log.println(getStackTraceString());
    }
    protected void setMessageAndCode(String messageOrCode){
        String msg = MessageUtil.getMessage(messageOrCode);
        if(!StrUtil.isEmpty(msg)){
            this.message = msg;
            this.code = messageOrCode;
        }else{
            this.message = messageOrCode;
        }
    }
}
