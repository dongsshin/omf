package com.rap.omc.framework.exception;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

public class OmfSigninFailedExceptionOmf extends OmfFoundationException {
    private static final long serialVersionUID = 0L;
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
    public OmfSigninFailedExceptionOmf(HttpStatus httpStatus, String code, String message, Throwable cause)
    {
        super(httpStatus,code, message, cause);
    }
}
