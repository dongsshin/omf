/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : FoundationUtil.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 3. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.core.util.general;

import com.event.publish.vo.EventUserVO;
import com.rap.config.datasource.dao.GenericDao;
import com.rap.config.web.security.UserSessionMappingKey;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.UserPropertyConstants;
import com.rap.omc.core.util.omc.CacheUtil;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.foundation.menu.service.MenuAccessService;
import com.rap.omc.foundation.user.model.CommonUserSearchVO;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.foundation.user.model.User2UserResultVO;
import com.rap.omc.foundation.user.model.UserPropertyVO;
import com.rap.omc.foundation.user.service.FoundationUserService;
import com.rap.omc.schema.object.model.OmcSchemaMenuVO;
import com.rap.omc.schema.object.model.OmcSchemaUserVO;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.StrUtil;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 
 * <pre>
 * Class : UserManagementUtil
 * Description : 시스템 사용자 정보(psysuser, user property 등)와 관련한 CRUD 작업을 수행한다.
 * </pre>
 * 
 * @author s_dongsshin
 */
public class FoundationUserUtil {

    private FoundationUserService foundationUserService;
    private MenuAccessService     menuAccessService;

    private static FoundationUserUtil fInstance;

    /**
     * Singleton을 구성된 getInstance() method
     */
    private synchronized static FoundationUserUtil getInstance(){
        if (fInstance == null) {
            fInstance = new FoundationUserUtil();
            fInstance.foundationUserService = (FoundationUserService)SpringFactoryUtil.getBean("foundationUserService");
            fInstance.menuAccessService = (MenuAccessService)SpringFactoryUtil.getBean("menuAccessService");
        }
        return fInstance;
    }
    public static void evictCacheForUser(String userName){
        CacheUtil.evictCache("sysUserInfoCache",userName);
    }

    /**
     * 사용자 Property 정보를 조회한다.
     *
     * @param userName user 정보의 name attribute
     * @param propertyName
     * @return User Property Value
     */
    public static String getUserProperty(String userName, String propertyName){
        return getInstance().foundationUserService.getPropertyValue(userName, propertyName);
    }

    /**
     * 사용자 Property 정보를 설정한다.
     *
     * @param userName user 정보의 name attribute
     * @param propertyName
     * @param propertyValue
     */
    public static void setUserProperty(String userName, String propertyName, String propertyValue){
        getInstance().foundationUserService.txnSetPropertyValue(userName,propertyName,propertyValue);
    }

    /**
     * user의 Timezone을 적용하여, 전달인자로 넘어온 날짜를 LocalTime으로 변경하여 리턴함
     *
     * @param userName
     * @param searchDate
     * @return User Local Time
     */
    public static Date getSessionUserLocalTimeForUser(String userName, Date searchDate){
        Date localTime = null;
        UserPropertyVO searchInfo = new UserPropertyVO();
        searchInfo.setUserNames(userName);
        SimpleDateFormat dateFormat = new SimpleDateFormat(OmcSystemConstants.OMC_JAVA_DATE_FORMAT_DATE);
        searchInfo.setSearchDate(dateFormat.format(searchDate));
        localTime = getInstance().foundationUserService.getSessionUserLocalTimeForUser(searchInfo);
        return localTime;
    }
    /**
     * 사용자 정보(psysuser)를 생성한다.
     *
     * @param userId user ID/Name
     * @param kindsStr User / Role / Group / RoleGroup
     * @param password
     * @param description
     * @param site
     * @param roleList (","를 사용하여 여러 개 입력 가능)
     * @param propertyList
     */
    public static void createUser(String userId, String kindsStr, String password, String description, String site, String roleList, String propertyList){
        SysUserVO input = new SysUserVO();
        input.setUserId(userId);
        input.setKindsStr(kindsStr);
//임시로 막음
//      input.setPassword(DigestManager.digest(password, "SHA-512"));

        input.setPassword(password);
        input.setDescriptions(description);
        input.setSite(site);
        input.setRoleSet(roleList);
        input.setPropertyList(propertyList);
        getInstance().foundationUserService.txnCreateUser(input);
    }

    /**
     * 사용자 정보(psysuser)를 조회한다.
     *
     * @param userId
     * @return System User Info
     */
    public static SysUserVO getSysUserInfo(String userId){
        SysUserVO result = getInstance().foundationUserService.getUserInfo(userId);
        return result;
    }
    /**
     * Key값에 대한 User/Group/Role를 Return함. 일반적인 곳에서는 사용하면 절대 안됨.
     * Foundation내부적으로 사용하기 위해 만들어진 것임 
     *
     * @param userId User/Group/Role ID
     * @return System User Info
     */
    public static SysUserVO getCommonUserInfo(String userId){
        SysUserVO result = getInstance().foundationUserService.getCommonUserInfo(userId);
        return result;
    }
    /**
     * User정보를 Return(psysuser)
     *
     * @param userId User Id
     * @return System User Info
     */
    public static SysUserVO getUserInfo(String userId){
        return getUserInfo(userId,false);
    }
    public static SysUserVO getUserInfo(String userId, boolean includePwd){
        return getInstance().foundationUserService.getUserInfo(userId,includePwd);
    }
    public static String getTimeStamp(String userId){
        return getInstance().foundationUserService.getTimeStamp(userId);
    }
    /**
     * Role정보를 Return(psysuser)
     *
     * @param roleId Role Id
     * @return System User Info
     */
    public static SysUserVO getRoleInfo(String roleId){
        SysUserVO result = getInstance().foundationUserService.getRoleInfo(roleId);
        return result;
    }
    /**
     * Group정보를 Return(psysuser)
     *
     * @param groupId Group Id
     * @return User Info(psysuser)
     */
    public static SysUserVO getGroupInfo(String groupId){
        SysUserVO result = getInstance().foundationUserService.getGroupInfo(groupId);
        return result;
    }
    
    /**
     * 사용자 정보(psysuser) 목록을 조회한다.
     *
     * @param userId (","를 사용하여 여러 개 입력 가능)
     * @return System User Info List
     */
    public static List<SysUserVO> getSysUserInfoList(String userId){
        List<SysUserVO> userList = new ArrayList<SysUserVO>();
        String[] strList = userId.split(",");
        for(int i = 0; i < strList.length; i++){
            SysUserVO temVo = getInstance().foundationUserService.getUserInfo(strList[i]);
            if(temVo != null) userList.add(temVo);
        }
        return userList;
    }
    /**
     * Activiate User.
     *
     * @param userId User Id
     */
    public static void activiateUser(String userId){
        getInstance().foundationUserService.txnActivate(userId);
    }
    /**
     * inActivate User.
     *
     * @param userId User Id
     */
    public static void inActiviateUser(String userId){
        getInstance().foundationUserService.txnInActivate(userId);
    }
    /**
     * 사용자에 대한 Property정보를 Return함.
     *
     * @param userId User Id
     * @return 해당 User에 대한 Property정보(PropertyName:Value)의 Map
     */
    public static Map<String,String> getPropertyList(String userId){
        return(getInstance().foundationUserService.getPropertyList(userId));
    }
    /**
     * 사용자에 대한 Property를 Set함.
     *
     * @param userId User Id
     * @param propertyList 반영할 Property List
     */
    public static void setPropertyList(String userId,Map<String,String> propertyList){
        getInstance().foundationUserService.txnSetPropertyValueList(userId,propertyList);
    }
    /**
     * 
     *
     * @param userId
     * @param role
     */
    public static void addRoleToUser(String userId, String role){
        getInstance().foundationUserService.txnAddRoleToUser(userId,role);
    }
    /**
     * 
     *
     * @param userId
     * @param roleList
     */
    public static void addRoleToUser(String userId, Set<String> roleList){
        getInstance().foundationUserService.txnAddRoleToUser(userId,roleList);
    }
    /**
     * 
     *
     * @param userId
     * @param roleList
     */
    public static void removeRoleToUser(String userId, Set<String> roleList){
        getInstance().foundationUserService.txnRemoveRoleToUser(userId,roleList);
    }
    /**
     * 
     *
     * @param userId
     * @return Role Set
     */
    public static Set<String> getRoleList(String userId){
        return(getInstance().foundationUserService.getRoleList(userId));
    }
    /**
     * 
     *
     * @param userId
     * @param group
     */
    public static void addGroupToUser(String userId, String group){
        getInstance().foundationUserService.txnAddGroupToUser(userId,group);
    }
    /**
     * 
     *
     * @param userId
     * @param groupList
     */
    public static void addGroupToUser(String userId, Set<String> groupList){
        getInstance().foundationUserService.txnAddGroupToUser(userId,groupList);
    }
    /**
     * 
     *
     * @param userId
     * @param groupList
     */
    public static void removeGroupToUser(String userId, Set<String> groupList){
        getInstance().foundationUserService.txnRemoveGroupToUser(userId,groupList);
    }
    /**
     * 
     *
     * @param userId
     * @param group
     */
    public static void removeGroupToUser(String userId, String group){
        getInstance().foundationUserService.txnRemoveGroupToUser(userId,group);
    }
    /**
     * 
     *
     * @param userId
     * @return Group Set
     */
    public static Set<String> getGroupList(String userId){
        return(getInstance().foundationUserService.getGroupList(userId));
    }
    /**
     * 
     *
     * @param userId
     * @param site
     */
    public static void changeSite(String userId, String site){
        getInstance().foundationUserService.txnRemoveGroupToUser(userId,site);
    }
    /**
     * 
     *
     * @param userId
     * @param descriptions
     */
    public static void setUserDescription(String userId, String descriptions){
        getInstance().foundationUserService.txnSetUserDescription(userId,descriptions);
    }
    /**
     * 
     *
     * @param userId
     * @param departmentCode
     * @param departmentDesc
     * @param departmentDescKr
     */
    public static void changeDepartment(String userId, String departmentCode,String departmentDesc, String departmentDescKr){
        getInstance().foundationUserService.txnChangeDepartment(userId,departmentCode,departmentDesc,departmentDescKr);
    }
    /**
     * 
     *
     * @param userId
     * @param emailId
     */
    public static void changeMailId(String userId, String emailId){
        getInstance().foundationUserService.txnChangeMailId(userId,emailId);
    }
    /**
     * 
     *
     * @param userId
     * @param userName
     * @param site
     * @param departmentCode
     * @param departmentDesc
     * @param departmentDescKor
     * @param mailId
     */
    public static void createUserDefault(String userId,String userName, String site, String departmentCode, String departmentDesc, String departmentDescKor, String mailId){
        getInstance().foundationUserService.txnCreateUser(userId,userName, site, departmentCode, departmentDesc, departmentDescKor, mailId);
    }
    /**
     * 
     *
     * @param userId
     * @param userName
     * @param site
     * @param mailId
     */
    public static void createUser(String userId,String userName, String site, String mailId){
        getInstance().foundationUserService.txnCreateUser(userId,userName, site, mailId);
    }
    /**
     * 
     *
     * @param userId
     * @param userName
     */
    public static void createUser(String userId,String userName){
        getInstance().foundationUserService.txnCreateUser(userId,userName);
    }
    /**
     * 
     *
     * @param role
     * @param roleName
     */
    public static void createRole(String role,String roleName){
        getInstance().foundationUserService.txnCreateRole(role,roleName);
    }

    public static void addCheckItem(String userId, String checkItem){
        getInstance().foundationUserService.txnAddCheckItem(userId,checkItem);
    }
    
    /**
     * 
     *
     * @param group
     * @param groupName
     */
    public static void createGroup(String group,String groupName){
        getInstance().foundationUserService.txnCreateGroup(group,groupName);
    }
    public static void setTimeStampSystemUser(String userId, String timeStamp){
        getInstance().foundationUserService.txnSetTimeStampSystemUser(userId,timeStamp);
    }
    public static void setSynchronizedSystemUser(String userId, String datasourceName){
        getInstance().foundationUserService.txnSetSynchronizedSystemUser(userId,datasourceName);
    }

    public static List<EventUserVO> getMustBeSynchronizedList(String databaseBeanName){
        return getInstance().foundationUserService.getMustBeSynchronizedList(databaseBeanName);
    }
    public static void synchronizeUser(GenericDao genericDao, EventUserVO eventUserVO){
        getInstance().foundationUserService.txnSynchronize(genericDao,eventUserVO);
    }
    public static void synchronizeUser(String databaseBeanName){
        //Connection 반환이 되므로 Loop내로 이동
        GenericDao genericDao = (GenericDao)SpringFactoryUtil.getBean(databaseBeanName);
        List<EventUserVO> synchList = FoundationUserUtil.getMustBeSynchronizedList(databaseBeanName);
        for(EventUserVO vo : synchList){
            //GenericDao genericDao = (GenericDao)SpringFactoryUtil.getBean(databaseBeanName);
            FoundationUserUtil.synchronizeUser(genericDao,vo);
            FoundationUserUtil.setSynchronizedSystemUser(vo.getNames(),databaseBeanName);
        }
    }

    /**
     * 
     *
     * @param groupId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getUserVOListForRole(String groupId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getUserVOListForRole(groupId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param groupId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getUserVOListForGroup(String groupId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getUserVOListForGroup(groupId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param userId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getRoleVOListForUser(String userId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getRoleVOListForUser(userId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param roleId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getRoleVOListForRole(String roleId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getRoleVOListForRole(roleId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param groupId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getRoleVOListForGroup(String groupId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getRoleVOListForGroup(groupId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param userId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getGroupVOListForUser(String userId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getGroupVOListForUser(userId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param groupId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getGroupVOListForGroup(String  groupId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getGroupVOListForGroup(groupId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param roleId
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getGroupVOListForRole(String  roleId,int wantedLevel, int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getGroupVOListForRole(roleId,wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param commonUserName
     * @param fromKinds
     * @param scemaKinds
     * @param toKinds
     * @param wantedLevel
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonToUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds, int wantedLevel){
        return(getInstance().foundationUserService.getCommonToUserListForCommonUser(commonUserName,fromKinds,scemaKinds,toKinds, wantedLevel));
    }
    /**
     * 
     *
     * @param commonUserName
     * @param fromKinds
     * @param scemaKinds
     * @param toKinds
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonToUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds,int wantedLevel,int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getCommonToUserListForCommonUser(commonUserName,fromKinds,scemaKinds,toKinds, wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param commonUserName
     * @param fromKinds
     * @param scemaKinds
     * @param toKinds
     * @param wantedLevel
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonFromUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds,int wantedLevel){
        return(getInstance().foundationUserService.getCommonFromUserListForCommonUser(commonUserName,fromKinds,scemaKinds,toKinds, wantedLevel));
    }
    /**
     * 
     *
     * @param commonUserName
     * @param fromKinds
     * @param scemaKinds
     * @param toKinds
     * @param wantedLevel
     * @param currentLevel
     * @param uniqueStr
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonFromUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds,int wantedLevel,int currentLevel,String uniqueStr){
        return(getInstance().foundationUserService.getCommonFromUserListForCommonUser(commonUserName,fromKinds,scemaKinds,toKinds, wantedLevel,currentLevel,uniqueStr));
    }
    /**
     * 
     *
     * @param userId
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonUserListForUser(String  userId){
        return(getInstance().foundationUserService.getCommonUserListForUser(userId));
    }
    /**
     * 
     *
     * @param roleId
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonUserListForRole(String  roleId){
        return(getInstance().foundationUserService.getCommonUserListForRole(roleId));
    }
    /**
     * 
     *
     * @param groupId
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonUserListForGroup(String  groupId){
        return(getInstance().foundationUserService.getCommonUserListForGroup(groupId));
    }
    /**
     * 
     *
     * @param commonId
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonUserListForCommon(String  commonId){
        return(getInstance().foundationUserService.getCommonUserListForCommon(commonId));
    }
    /**
     * 
     *
     * @param searchVO
     * @return User Info
     */
    public static List<OmcSchemaUserVO> getCommonUserList(CommonUserSearchVO searchVO){
        return(getInstance().foundationUserService.getCommonUserList(searchVO));
    }
    /**
     * 
     *
     * @param commonUserId
     * @return Relation Info List
     */
    public static List<User2UserResultVO> getCommonUserAllListForUser(String commonUserId){
        return(getInstance().foundationUserService.getCommonUserAllListForUser(commonUserId));
    }
    /**
     * 
     *
     * @param input
     */
    public static void createUser(SysUserVO input){
        getInstance().foundationUserService.txnCreateUser(input);
    }
    /**
     * 
     *
     * @param roleGroup
     * @param roleGroupName
     */
    public static void createRoleGroup(String roleGroup,String roleGroupName){
        getInstance().foundationUserService.txnCreateRoleGroup(roleGroup,roleGroupName);
    }
    /**
     * 
     *
     * @param userId
     */
    public static void activate(String userId){
        getInstance().foundationUserService.txnActivate(userId);
    }
    /**
     * 
     *
     * @param userId
     */
    public static void inActivate(String userId){
        getInstance().foundationUserService.txnInActivate(userId);
    }
    /**
     * 
     *
     * @param userId 
     * @param propertyName Property Name
     * @return Property Value
     */
    public static String getPropertyValue(String userId,String propertyName){
        return(getInstance().foundationUserService.getPropertyValue(userId,propertyName));
    }
    /**
     * 
     *
     * @param userId
     * @param propertyName
     * @param propertyValue
     */
    public static void setPropertyValue(String userId, String propertyName, String propertyValue){
        getInstance().foundationUserService.txnSetPropertyValue(userId,propertyName,propertyValue);
    }
    /**
     * 
     *
     * @param userId
     * @param propertyList
     */
    public static void setPropertyValueList(String userId, Map<String,String> propertyList){
        getInstance().foundationUserService.txnSetPropertyValueList(userId,propertyList);
    }
    /**
     * 
     *
     * @param userId
     * @param role
     */
    public static void removeRoleToUser(String userId, String role){
        getInstance().foundationUserService.txnRemoveRoleToUser(userId,role);
    }
    /**
     * 
     *
     * @param group
     * @param userId
     */
    public static void addUserForGroup(String group, String userId){
        getInstance().foundationUserService.txnAddUserForGroup(group,userId);
    }
    /**
     * 
     *
     * @param group
     * @param userList
     */
    public static void addUserForGroup(String group, Set<String> userList){
        getInstance().foundationUserService.txnAddUserForGroup(group,userList);
    }
    /**
     * 
     *
     * @param group
     * @param userId
     */
    public static void removeUserForGroup(String group, String userId){
        getInstance().foundationUserService.txnRemoveUserForGroup(group,userId);
    }
    /**
     * 
     *
     * @param group
     * @param userList
     */
    public static void removeUserForGroup(String group, Set<String> userList){
        getInstance().foundationUserService.txnRemoveUserForGroup(group,userList);
    }
    /**
     * 
     *
     * @param group
     * @return Group에 대한 User Set
     */
    public static Set<String> getUserListForGroup(String group){
        return(getInstance().foundationUserService.getUserListForGroup(group));
    }
    /**
     * 
     *
     * @param group
     * @param addedGroup
     */
    public static void addGroupForGroup(String group, String addedGroup){
        getInstance().foundationUserService.txnAddGroupForGroup(group,addedGroup);
    }
    /**
     * 
     *
     * @param group
     * @param addedGroupList
     */
    public static void addGroupForGroup(String group, Set<String> addedGroupList){
        getInstance().foundationUserService.txnAddGroupForGroup(group,addedGroupList);
    }
    /**
     * 
     *
     * @param group
     * @param role
     */
    public static void addRoleForGroup(String group, String role){
        getInstance().foundationUserService.txnAddRoleForGroup(group,role);
    }
    /**
     * 
     *
     * @param group
     * @param roleList
     */
    public static void addRoleForGroup(String group, Set<String> roleList){
        getInstance().foundationUserService.txnAddRoleForGroup(group,roleList);
    }
    /**
     * 
     *
     * @param group
     * @param addedGroup
     */
    public static void removeGroupForGroup(String group, String addedGroup){
        getInstance().foundationUserService.txnAddRoleForGroup(group,addedGroup);
    }
    /**
     * 
     *
     * @param group
     * @param addedGroupList
     */
    public static void removeGroupForGroup(String group, Set<String> addedGroupList){
        getInstance().foundationUserService.txnRemoveGroupForGroup(group,addedGroupList);
    }
    /**
     * 
     *
     * @param group
     * @param role
     */
    public static void removeRoleForGroup(String group, String role){
        getInstance().foundationUserService.txnRemoveRoleForGroup(group,role);
    }
    /**
     * 
     *
     * @param group
     * @param roleList
     */
    public static void removeRoleForGroup(String group, Set<String> roleList){
        getInstance().foundationUserService.txnRemoveRoleForGroup(group,roleList);
    }
    /**
     * 
     *
     * @param role
     * @param user
     */
    public static void addUserForRole(String role, String user){
        getInstance().foundationUserService.txnAddUserForRole(role,user);
    }
    /**
     * 
     *
     * @param role
     * @param userList
     */
    public static void addUserForRole(String role, Set<String> userList){
        getInstance().foundationUserService.txnAddUserForRole(role,userList);
    }
    /**
     * 
     *
     * @param role
     * @param user
     */
    public static void removeUserForRole(String role, String user){
        getInstance().foundationUserService.txnRemoveUserForRole(role,user);
    }
    /**
     * 
     *
     * @param role
     * @param userList
     */
    public static void removeUserForRole(String role, Set<String> userList){
        getInstance().foundationUserService.txnRemoveUserForRole(role,userList);
    }
    /**
     * 
     *
     * @param role
     * @return 해당 Role를 가지고 있는 User List
     */
    public static Set<String> getUserListForRole(String role){
        return(getInstance().foundationUserService.getUserListForRole(role));
    }
    /**
     * 
     *
     * @param role
     * @param addedRole
     */
    public static void addRoleForRole(String role, String addedRole){
        getInstance().foundationUserService.txnAddRoleForRole(role,addedRole);
    }
    /**
     * 
     *
     * @param role
     * @param addedRoleList
     */
    public static void addRoleForRole(String role, Set<String> addedRoleList){
        getInstance().foundationUserService.txnAddRoleForRole(role,addedRoleList);
    }
    /**
     * 
     *
     * @param role
     * @param group
     */
    public static void addGroupForRole(String role, String group){
        getInstance().foundationUserService.txnAddRoleForRole(role,group);
    }
    /**
     * 
     *
     * @param role
     * @param groupList
     */
    public static void addGroupForRole(String role, Set<String> groupList){
        getInstance().foundationUserService.txnAddGroupForRole(role,groupList);
    }
    /**
     * 
     *
     * @param role
     * @param removeRole
     */
    public static void removeRoleForRole(String role, String removeRole){
        getInstance().foundationUserService.txnRemoveRoleForRole(role,removeRole);
    }
    /**
     * 
     *
     * @param role
     * @param removedRoleList
     */
    public static void removeRoleForRole(String role, Set<String> removedRoleList){
        getInstance().foundationUserService.txnRemoveRoleForRole(role,removedRoleList);
    }
    /**
     * 
     *
     * @param role
     * @param group
     */
    public static void removeGroupForRole(String role, String group){
        getInstance().foundationUserService.txnRemoveGroupForRole(role,group);
    }
    /**
     * 
     *
     * @param role
     * @param groupList
     */
    public static void removeGroupForRole(String role, Set<String> groupList){
        getInstance().foundationUserService.txnRemoveGroupForRole(role,groupList);
    }
    /**
     * 
     *
     * @param role
     * @param menu
     * @param map
     */
    public static void addMenuForRole(String role, String menu,Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForRole(role,menu,map);
    }
    /**
     * 
     *
     * @param role
     * @param menuList
     * @param map
     */
    public static void addMenuForRole(String role, List<String> menuList,Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForRole(role,menuList,map);
    }
    /**
     * 
     *
     * @param group
     * @param menu
     * @param map
     */
    public static void addMenuForGroup(String group, String menu,Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForGroup(group,menu,map);
    }
    /**
     * 
     *
     * @param group
     * @param menuList
     * @param map
     */
    public static void addMenuForGroup(String group, List<String> menuList,Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForGroup(group,menuList,map);
    }
    /**
     * 
     *
     * @param user
     * @param menu
     * @param map
     */
    public static void addMenuForUser(String user, String menu,Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForUser(user,menu,map);
    }
    /**
     * 
     *
     * @param user
     * @param menuList
     * @param map
     */
    public static void addMenuForUser(String user, List<String> menuList,Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForUser(user,menuList,map);
    }
    /**
     * 
     *
     * @param roleList
     * @param menu
     * @param map
     */
    public static void addMenuForRole(List<String> roleList, String menu, Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForRole(roleList,menu,map);
    }
    /**
     * 
     *
     * @param roleList
     * @param menuList
     * @param map
     */
    public static void addMenuForRole(List<String> roleList, List<String> menuList, Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForRole(roleList,menuList,map);
    }
    /**
     * 
     *
     * @param groupList
     * @param menu
     * @param map
     */
    public static void addMenuForGroup(List<String> groupList, String menu, Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForGroup(groupList,menu,map);
    }
    /**
     * 
     *
     * @param groupList
     * @param menuList
     * @param map
     */
    public static void addMenuForGroup(List<String> groupList, List<String> menuList, Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForGroup(groupList,menuList,map);
    }
    /**
     * 
     *
     * @param userIdList
     * @param menu
     * @param map
     */
    public static void addMenuForUser(List<String> userIdList, String menu, Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForUser(userIdList,menu,map);
    }
    /**
     * 
     *
     * @param userIdList
     * @param menuList
     * @param map
     */
    public static void addMenuForUser(List<String> userIdList, List<String> menuList, Map<String,String> map){
        getInstance().menuAccessService.txnAddMenuForUser(userIdList,menuList,map);
    }
    /**
     * 
     *
     * @param role
     * @param menu
     */
    public static void removeMenuForRole(String role, String menu){
        getInstance().menuAccessService.txnRemoveMenuForRole(role,menu);
    }
    /**
     * 
     *
     * @param role
     * @param menuList
     */
    public static void removeMenuForRole(String role, List<String> menuList){
        getInstance().menuAccessService.txnRemoveMenuForRole(role,menuList);
    }
    /**
     * 
     *
     * @param group
     * @param menu
     */
    public static void removeMenuForGroup(String group, String menu){
        getInstance().menuAccessService.txnRemoveMenuForGroup(group,menu);
    }
    /**
     * 
     *
     * @param group
     * @param menuList
     */
    public static void removeMenuForGroup(String group, List<String> menuList){
        getInstance().menuAccessService.txnRemoveMenuForGroup(group,menuList);
    }
    /**
     * 
     *
     * @param userId
     * @param menu
     */
    public static void removeMenuForUser(String userId, String menu){
        getInstance().menuAccessService.txnRemoveMenuForUser(userId,menu);
    }
    /**
     * 
     *
     * @param userId
     * @param menuList
     */
    public static void removeMenuForUser(String userId, List<String> menuList){
        getInstance().menuAccessService.txnRemoveMenuForUser(userId,menuList);
    }
    /**
     * 
     *
     * @param roleList
     * @param menu
     */
    public static void removeMenuForRole(List<String> roleList, String menu){
        getInstance().menuAccessService.txnRemoveMenuForRole(roleList,menu);
    }
    /**
     * 
     *
     * @param roleList
     * @param menuList
     */
    public static void removeMenuForRole(List<String> roleList, List<String> menuList){
        getInstance().menuAccessService.txnRemoveMenuForRole(roleList,menuList);
    }
    /**
     * 
     *
     * @param groupList
     * @param menu
     */
    public static void removeMenuForGroup(List<String> groupList, String menu){
        getInstance().menuAccessService.txnRemoveMenuForGroup(groupList,menu);
    }
    /**
     * 
     *
     * @param groupList
     * @param menuList
     */
    public static void removeMenuForGroup(List<String> groupList, List<String> menuList){
        getInstance().menuAccessService.txnRemoveMenuForGroup(groupList,menuList);
    }
    /**
     * 
     *
     * @param userIdList
     * @param menu
     */
    public static void removeMenuForUser(List<String> userIdList, String menu){
        getInstance().menuAccessService.txnRemoveMenuForUser(userIdList,menu);
    }
    /**
     * 
     *
     * @param userIdList
     * @param menuList
     */
    public static void removeMenuForUser(List<String> userIdList, List<String> menuList){
        getInstance().menuAccessService.txnRemoveMenuForUser(userIdList,menuList);
    }
    /**
     * 
     *
     * @param role Role
     * @return 해당 Role에 할당되어진 Menu List
     */
    public static List<OmcSchemaMenuVO> getMenuListForRole(String role){
        return getInstance().menuAccessService.getMenuListForRole(role);
    }
    /**
     * 
     *
     * @param group
     * @return 해당 Group에 할당되어진 Menu List
     */
    public static List<OmcSchemaMenuVO> getMenuListForGroup(String group){
        return getInstance().menuAccessService.getMenuListForGroup(group);
    }
    /**
     * 
     *
     * @param userId
     * @return 해당 User에 할당되어진 Menu List
     */
    public static List<OmcSchemaMenuVO> getMenuListForUser(String userId){
        return getInstance().menuAccessService.getMenuListForUser(userId);
    }
    /**
     * 
     *
     * @param role Role
     * @param expand 하위 전개 여부
     * @return 해당 Role에 할당되어진 Menu List
     */
    public static List<OmcSchemaMenuVO> getMenuListForRole(String role, boolean expand){
        return getInstance().menuAccessService.getMenuListForRole(role,expand);
    }
    /**
     * 
     *
     * @param group Group
     * @param expand 하위 전개여부
     * @return 해당 Group에 할당되어진 Menu List
     */
    public static List<OmcSchemaMenuVO> getMenuListForGroup(String group,boolean expand){
        return getInstance().menuAccessService.getMenuListForGroup(group,expand);
    }
    /**
     * 
     *
     * @param userId User Id
     * @param expand 하위 전개 여부
     * @return 해당 사용자에 할당되어진 Menu List
     */
    public static List<OmcSchemaMenuVO> getMenuListForUser(String userId,boolean expand){
        return getInstance().menuAccessService.getMenuListForUser(userId,expand);
    }
    /**
     * 
     *
     * @param comUserNameList User/Role/Group Id List
     * @return 사용자 List에 대해서 할당되어진 Menu List
     */
    public static List<OmcSchemaMenuVO> getMenuListForSetWithNames(List<String> comUserNameList){
        return getInstance().menuAccessService.getMenuListForCommonUserWithNames(comUserNameList,true);
    }
    /**
     * 
     *
     * @param comUserNameList
     * @return User/Role/Group 에 대해서할당되어진 Menu Set를 Return함.
     */
    public static Set<String> getMenuSetForCommonUserWithNames(List<String> comUserNameList){
        return getInstance().menuAccessService.getMenuSetForCommonUserWithNames(comUserNameList,true);
    }
    /**
     * 
     *
     * @param userId
     * @param roleSet
     * @param groupSet
     * @return userId/roleSet/groupSet에 할당되어진 Menu Set을 Return함.
     */
    public static Set<String> getMenuSet(String userId,Set<String> roleSet,Set<String> groupSet){
        List<String> allList = new ArrayList<String>();
        allList.add(userId);
        allList.addAll(roleSet);
        allList.addAll(groupSet);
        return getInstance().menuAccessService.getMenuSetForCommonUserWithNames(allList,true);
    }
    /**
     * 
     *
     * @param searchInfo
     * @return 사용자에 대한 Local Time을 Return함.
     */
    public static Date getSessionUserLocalTimeForUser(UserPropertyVO searchInfo){
        return(getInstance().foundationUserService.getSessionUserLocalTimeForUser(searchInfo));
    }
    
    public static Map<String,Object> getUserSessionInfo(String userId){
    	
    	Map<String,Object> userSessionMap = new HashMap<String,Object>();
    	SysUserVO sysUserVO =  getUserInfo(userId);
    	Map<String,String> propertyMap = sysUserVO.getPropertyList();

    	String divisionUnitCode   = propertyMap.get(UserPropertyConstants.USER_PROPERTY_DR);
    	String businessUnitCode   = propertyMap.get(UserPropertyConstants.USER_PROPERTY_BUSINESS_UNIT);
    	String plantUnitCode      = propertyMap.get(UserPropertyConstants.USER_PROPERTY_MR);
        String companyCode      = propertyMap.get(UserPropertyConstants.USER_PROPERTY_COMPANY);

    	String locale = propertyMap.get(UserPropertyConstants.USER_PROPERTY_LOCALE);
    	if(StrUtil.isEmpty(locale)) locale = GlobalConstants.DEFAULT_LANG;
    	String timeZone = propertyMap.get(UserPropertyConstants.USER_PROPERTY_TIME_ZONE);

    	if(StrUtil.isEmpty(timeZone)) timeZone = GlobalConstants.DEFAULT_TIME_ZONE;//Asia/Seoul";

    	userSessionMap.put(UserSessionMappingKey.companyCode, companyCode);
    	userSessionMap.put(UserSessionMappingKey.companyCodeDesc, companyCode);
    	 
    	userSessionMap.put(UserSessionMappingKey.businessUnitCode, plantUnitCode);
    	userSessionMap.put(UserSessionMappingKey.businessUnitCodeDesc, businessUnitCode);

    	userSessionMap.put(UserSessionMappingKey.divisionUnitCode, divisionUnitCode);
    	userSessionMap.put(UserSessionMappingKey.divisionUnitCodeDesc, divisionUnitCode);

    	userSessionMap.put(UserSessionMappingKey.plantUnitCode, plantUnitCode);
    	userSessionMap.put(UserSessionMappingKey.plantUnitCodeDesc, plantUnitCode);

    	userSessionMap.put(UserSessionMappingKey.email,  sysUserVO.getEmailId());

    	userSessionMap.put(UserSessionMappingKey.privateFolder, propertyMap.get(UserPropertyConstants.USER_PROPERTY_PRIVATE_FOLDER));
    	userSessionMap.put(UserSessionMappingKey.defaultPrivateFolder, propertyMap.get(UserPropertyConstants.USER_PROPERTY_DEFAULT_PRIVATE_FOLDER));
    	userSessionMap.put(UserSessionMappingKey.defaultProject, propertyMap.get(UserPropertyConstants.USER_PROPERTY_DEFAULT_PROJECT));

    	userSessionMap.put(UserSessionMappingKey.telephone, "Not Defined");
    	userSessionMap.put(UserSessionMappingKey.timeStamp, sysUserVO.getTimeStamp());
    	userSessionMap.put(UserSessionMappingKey.userBizObid, propertyMap.get(UserPropertyConstants.USER_PROPERTY_USER_OBID));

        userSessionMap.put(UserSessionMappingKey.userLocale, locale);
    	userSessionMap.put(UserSessionMappingKey.userSite, sysUserVO.getSite());
    	userSessionMap.put(UserSessionMappingKey.userNameKor, sysUserVO.getDescriptions());
    	userSessionMap.put(UserSessionMappingKey.userTimeZone, timeZone);
    	return userSessionMap;
    }

}
