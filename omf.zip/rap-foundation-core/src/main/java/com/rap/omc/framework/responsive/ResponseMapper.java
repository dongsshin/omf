package com.rap.omc.framework.responsive;

import com.rap.omc.constants.ResponseConstants;
import lombok.Builder;

import java.util.HashMap;


public class ResponseMapper {


    private int status = ResponseConstants.STATUS_SUCCESS;
    private String message = "Success";
    private HashMap<String, Object> data = new HashMap<String, Object>();

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public HashMap<String, Object> getData() {
        return data;
    }

    public void setData(HashMap<String, Object> data) {
        this.data = data;
    }

    public void addDataItem(String id, Object object) {
        this.data.put(id, object);
    }

    public Object getDataItem(String id) {
        return this.data.get(id);
    }
    @Builder
    public ResponseMapper(int statusCode, String message, String key, Object data) {
        this.status = statusCode;
        this.message = message;
        this.data.put(key,data);
    }
    @Builder
    public ResponseMapper(int statusCode, String message, HashMap<String, Object> data) {
        this.status = statusCode;
        this.message = message;
        this.data = data;
    }
    @Builder
    public ResponseMapper(String key, Object data){
        this.data.put(key,data);
        this.message = "Success";
    }
    @Builder
    public ResponseMapper(String message) {
        this.message = message;
    }
    @Builder
    public ResponseMapper(HashMap<String, Object> data){
        this.data = data;
    }
}
