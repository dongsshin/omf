package com.rap.omc.controller;


import com.rap.omc.controller.service.FoundationRestService;
import com.event.publish.vo.EventCodeVO;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.CommonCodeSyncUtil;
import com.rap.omc.util.biz.BizCommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class FoundationCodeController extends RestBaseController {

    @Autowired
    private FoundationRestService foundationRestService;

    private final String ERR_MES_FOUNDATION_GET_CLASS_INFO = "foundation.error.class.get.general";

    @RequestMapping(value = "/foundation/codemaster/{masterCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getMasterCode(@PathVariable("masterCode") String masterCode) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,BizCommonUtil.getCodeMaster(masterCode)), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
    @RequestMapping(value = "/foundation/codes/{masterCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeList(@PathVariable("masterCode") String masterCode,
                                                       @RequestParam(name="organizationCode",required = false,defaultValue = "LGE") String organizationCode,
                                                       @RequestParam(name="activeOnlyYN",required = false,defaultValue = "Y") String activeOnlyYN) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,BizCommonUtil.getCodeList(masterCode,organizationCode,activeOnlyYN)),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
    @RequestMapping(value = "/foundation/code/{masterCode}/{code}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCode(@PathVariable("masterCode") String masterCode,
                                                   @PathVariable("code") String code) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,BizCommonUtil.getCode(masterCode,code)),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
    @RequestMapping(value = "/foundation/code/orgstructure",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getOrganizationStructure(@RequestParam(name = "organizationType",required = true,defaultValue = "Company") String organizationType,
                                                                    @RequestParam(name = "organizationCode",required = true,defaultValue = "LGE") String organizationCode,
                                                                    @RequestParam(name = "explosionLevel",required = true,defaultValue = "5") String explosionLevel) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,BizCommonUtil.getOrgStructure(organizationType,organizationCode,Integer.parseInt(explosionLevel))),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
    @RequestMapping(value = "/foundation/codes/refresh",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?>  synchronizeCodes() {
        try{
            CommonCodeSyncUtil.synchronizeCodes();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Successful Completion"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
    @RequestMapping(value = "/foundation/code/eventsynch",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> synchronizeCode(@RequestBody EventCodeVO eventCodeVO){
        try{
            CommonCodeSyncUtil.synchronizeCode(eventCodeVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
}