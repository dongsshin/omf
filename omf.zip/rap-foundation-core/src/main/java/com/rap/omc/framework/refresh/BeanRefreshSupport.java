package com.rap.omc.framework.refresh;

public abstract interface BeanRefreshSupport {
}
