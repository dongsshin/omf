package com.rap.omc.dataaccess.paging.model;

/**
 * ===========================================
 * System Name : Foundation
 * Program ID : OmfPagingTTEntity.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2020. 09. 17. DongSik.Shin Initial
 * ===========================================
 */

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.lang.reflect.Method;
import java.util.HashMap;

/**
 * <pre>
 * Class : OmcPagingList
 * Description : TODO
 * </pre>
 *
 * @author DongSik.Shin
 */
@SuppressWarnings("serial")
public class PagingEntity {
    /**
     * 전체 건수
     */
    private int totalCount = 0;

    private int targetRow = 1;//Start Row

    private int rowSize = 30;//Paging 당 데이터 건수

    private int currentPage = 1;

    private String orderBy;

    public PagingEntity(int targetRow, int rowSize, int currentPage, String orderBy) {
        this.targetRow = targetRow;
        this.rowSize = rowSize;
        this.orderBy = orderBy;
        this.currentPage = currentPage;
    }
    public PagingEntity() {
    }


    @JsonIgnore
    HashMap<String, Object> pagingParameter;
    @JsonIgnore
    public HashMap<String, Object> getPagingParameter() {
        return pagingParameter;
    }
    @JsonIgnore
    public void setPagingParameter(HashMap<String, Object> pagingParameter) {
        this.pagingParameter = pagingParameter;
    }

    public String getOrderBy() {
        return orderBy;
    }

    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    /**
     *
     *
     * @return the totalCount
     */
    public int getTotalCount(){
        return totalCount;
    }

    /**
     *
     *
     * @param totalCount the totalCount to set
     */
    public void setTotalCount(int totalCount){
        this.totalCount = totalCount;
    }

    /**
     *
     *
     * @return the targetRow
     */
    public int getTargetRow(){
        return targetRow;
    }

    /**
     *
     *
     * @param targetRow the targetRow to set
     */
    public void setTargetRow(int targetRow){
        this.targetRow = targetRow;
    }

    /**
     *
     *
     * @return the rowSize
     */
    public int getRowSize(){
        return rowSize;
    }

    /**
     *
     *
     * @param rowSize the rowSize to set
     */
    public void setRowSize(int rowSize){
        this.rowSize = rowSize;
    }

    /**
     *
     *
     * @return the currentPage
     */
    public int getCurrentPage(){
        return currentPage;
    }

    /**
     *
     *
     * @param currentPage the currentPage to set
     */
    public void setCurrentPage(int currentPage){
        this.currentPage = currentPage;
    }

    public void setCurrentPage(int targetRow, int rowSize){
        this.setCurrentPage((int)Math.ceil((float)targetRow / rowSize));
    }
    public <T> T getAttribute(String attribute){
        StringBuffer methodBufStr = new StringBuffer();
        methodBufStr.append("get").append(attribute.substring(0, 1).toUpperCase()).append(attribute.substring(1));
        try {
            Method method = this.getClass().getMethod(methodBufStr.toString());
            return (T)method.invoke(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return(null);
    }
}
