package com.rap.omc.dataaccess.mybatis.interceptor;

import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.annotation.OMFAuthority;
import com.rap.omc.framework.exception.OmfSystemException;
import com.rap.omc.schema.object.model.OmcSchemaCheckItemVO;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSchemaServiceUtils;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

@Component
@Aspect
@Slf4j
public class OmfAccessCheckInterceptor {
    @Autowired
    private UserSession userSession;
    @Before("@annotation(com.rap.omc.framework.annotation.OMFAuthority)")
    public void checkAccess(JoinPoint joinPoint) throws NoSuchMethodException {
        /*
        String baseController = PropertiesUtil.getString("foundation.controller.class.base");
        if(!joinPoint.getTarget().getClass().isAssignableFrom(RestBaseController.class));

        if(StrUtil.isEmpty(baseController)) throw new OmfSystemException(HttpStatus.INTERNAL_SERVER_ERROR,"Server Configuration Error.'foundation.controller.class.base' is not configured!!");
        //RestBaseController에서 상속을 받았는지 Check함.
        if(!RestBaseController.class.isAssignableFrom(joinPoint.getTarget().getClass())) throw new OmfSystemException(HttpStatus.INTERNAL_SERVER_ERROR,"Controller's parent class should be extended from '" + baseController + "' !!");

        String controllerClassName = joinPoint.getTarget().getClass().getCanonicalName();
        String controllerMethodName = joinPoint.getSignature().getName();
        */
        Object[] args = joinPoint.getArgs();
        Class<?>[] clsArray = new Class<?>[args.length];
        for(int i = 0; i < args.length; i++){
            clsArray[i] = args[i].getClass();
        }
        String parameterClass = StrUtil.getClassString(args);
        //Method method= joinPoint.getTarget().getClass().getDeclaredMethod(joinPoint.getSignature().getName(), clsArray);
        Method method= getMethod(joinPoint);
        if(NullUtil.isNull(method)) throw new OmfSystemException(HttpStatus.INTERNAL_SERVER_ERROR,"Cannot find method!!");

        OMFAuthority omfAuthority = method.getAnnotation(OMFAuthority.class);
        Set<String> definedSet = new HashSet<String>();
        if(!NullUtil.isNull(omfAuthority)){
            if(!NullUtil.isNone(omfAuthority.groups())) definedSet.addAll(StrUtil.convertArrayToSet(omfAuthority.groups()));
            if(!NullUtil.isNone(omfAuthority.roles())) definedSet.addAll(StrUtil.convertArrayToSet(omfAuthority.roles()));
            if(!NullUtil.isNone(omfAuthority.users())) definedSet.addAll(StrUtil.convertArrayToSet(omfAuthority.users()));
        }
        //Database에 가지않고 Check할 수 있는 것은 먼저 Check(성능을 위해)
        if(!definedSet.isEmpty()){
            //현재 사용자가 Check Item에 할당되어져 있으면 성공
            if(definedSet.contains(userSession.getUserId())) return;
            //현재 사용자의 Role이 Check Item에 할당되어져 있으면 성공
            if(!NullUtil.isNone(userSession.getRoleSet()) && StrUtil.in(definedSet,userSession.getRoleSet())) return;
            //현재 사용자가 소속되어진 Group이 Check Item에 할당되어져 있으면 성공
            if(!NullUtil.isNone(userSession.getGroupSet()) && StrUtil.in(definedSet,userSession.getGroupSet())) return;
        }
        //이래부터는 Check Item에 Online상에서 권한을 주었을 경우 추가적인 Check를 함.
        if(StrUtil.isEmpty(omfAuthority.checkItem())) throw new OmfSystemException(HttpStatus.INTERNAL_SERVER_ERROR,"Check item is empty!!");
        OmcSchemaCheckItemVO itemVO = OmcSchemaServiceUtils.getCheckItemWithNames(omfAuthority.checkItem());
        if(NullUtil.isNull(itemVO)){
            log.warn("'" + omfAuthority.checkItem() + "' Not Found");
            return;
        }
        //모든 사용자에 대한 권한을 주는 것인지 Check
        if(Bit.isInclude(itemVO.getFlags(), OmcSystemConstants.CHECKITEM_FLAG_AllUser)) return;

        //Check Item에 할당되어진 User, Group, Role를 찾아옴.
        Set<String> commonUserSet = OmcSchemaServiceUtils.getGrantedCommonUserSet(itemVO);

        //현재 사용자가 Check Item에 할당되어져 있으면 성공
        if(commonUserSet.contains(userSession.getUserId())) return;
        //현재 사용자의 Role이 Check Item에 할당되어져 있으면 성공
        if(!NullUtil.isNone(userSession.getRoleSet()) && StrUtil.in(commonUserSet,userSession.getRoleSet())) return;
        //현재 사용자가 소속도어진 Group이 Check Item에 할당되어져 있으면 성공
        if(!NullUtil.isNone(userSession.getGroupSet()) && StrUtil.in(commonUserSet,userSession.getGroupSet())) return;

        throw new OmfSystemException(HttpStatus.INTERNAL_SERVER_ERROR,"You does not have authority.(Check Item:" + omfAuthority.checkItem() + ",User Id:" + userSession.getUserId() + ")");
        /*
        RequestMapping requestMapping = method.getAnnotation(RequestMapping.class);
        String uri = "";
        String httpMethod = "";
        if(!NullUtil.isNull(requestMapping)){
            uri = StrUtil.convertArrayToString(requestMapping.value());
            httpMethod = StrUtil.getString(requestMapping.method());
        }
        log.info("controllerClassName : " + controllerClassName);
        log.info("controllerMethodName : " + controllerMethodName);
        log.info("parameterClass : " + parameterClass);
        log.info("URI : " + uri);
        log.info("http Method : " + httpMethod);
        */
    }
    private Method getMethod(JoinPoint joinPoint){
        Map<String,String> map = new HashMap<String,String>();
        //Primitive Type Check Mapping
        map.put("int","Integer")    ;map.put("Integer","int");
        map.put("long","Long")      ;map.put("Long","long");
        map.put("float","Float")    ;map.put("Float","float");
        map.put("double","Double")  ;map.put("Double","double");
        map.put("boolean","Boolean");map.put("Boolean","boolean");
        Set<String> allSet = new HashSet<String>();
        allSet.addAll(map.keySet());

        Object[] args = joinPoint.getArgs();
        Class<?>[] clsArray = new Class<?>[args.length];
        for(int i = 0; i < args.length; i++){
            clsArray[i] = args[i].getClass();
        }
        String methodName = joinPoint.getSignature().getName();
        Method[] methods= joinPoint.getTarget().getClass().getDeclaredMethods();
        for(Method method : methods){
            if(methodName.equals(method.getName())){
                Class[] params = method.getParameterTypes();
                boolean isOk = true;
                for(int i = 0; i < params.length; i++){
                    if(!clsArray[i].isAssignableFrom(params[i])){
                        String paramsName =  params[i].getSimpleName();
                        String argName =  clsArray[i].getSimpleName();
                        if(!(allSet.contains(params[i].getSimpleName()) &&  map.get(params[i].getSimpleName()).equals(clsArray[i].getSimpleName()))){
                            isOk = false;
                            break;
                        }
                    }
                 }
                if(isOk) return method;
            }
        }
        for(Method method : methods){
            Class[] params = method.getParameterTypes();
            if(methodName.equals(method.getName()) && args.length > params.length){
                return method;
            }
        }
        return null;
    }
}