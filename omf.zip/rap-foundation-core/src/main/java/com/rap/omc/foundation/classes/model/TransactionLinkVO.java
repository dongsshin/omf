package com.rap.omc.foundation.classes.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.rap.api.object.foundation.model.JsonDeserializerDateHandler;
import com.rap.api.object.foundation.model.JsonSerializerDateHandler;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSystemConstants;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Setter
@Getter
public class TransactionLinkVO {
    private Integer transactionSeq;
    private Long flags = OmcSystemConstants.TRANSACTION_FLAG_Default;
    private String globalTransactionId;
    private String subTransactionId;
    private String transactionType;
    private String uri;
    private String obid;
    private String className;
    private String creator;
    @JsonDeserialize(using = JsonDeserializerDateHandler.class)
    @JsonSerialize(using = JsonSerializerDateHandler.class)
    private Date created;
    private String jsonBefore;
    private String jsonAfter;
    public boolean isRollback(){
        return Bit.isInclude(this.flags, OmcSystemConstants.TRANSACTION_FLAG_Rollback);
    }
    public boolean errorOccurred(){
        return Bit.isInclude(this.flags, OmcSystemConstants.TRANSACTION_FLAG_RollbackError);
    }
}