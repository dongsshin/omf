package com.rap.omc.framework.message.file;

import com.rap.omc.framework.message.exception.OmfMessageException;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.FileSystemResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;

import java.io.IOException;

public class FileMessageResourceLoader extends DefaultResourceLoader
{
    public Resource getResource(String location)
    {
        Resource resource = super.getResource(location);
        
        if (resource.exists())
        {
            String absolutePath = null;
            try
            {
                absolutePath = resource.getFile().getAbsolutePath();
                } catch (IOException ex) {
                throw new OmfMessageException(HttpStatus.INTERNAL_SERVER_ERROR,absolutePath + " is not existed.");
            }
            return new FileSystemResource(absolutePath);
        }
        return resource;
    }
}