/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CommonServiceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.config.datasource.dao.FoundationDao;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.TransactionTypeConstants;
import com.rap.omc.core.util.general.FoundationDbProxy;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;
import com.rap.omc.foundation.classes.service.CommonCoreFoundationService;
import com.rap.omc.foundation.classes.service.CommonService;
import com.rap.omc.foundation.common.model.KeyInfo;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * Class : CommonCoreServiceImpl
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
@Service("commonCoreFoundationService")
public class CommonCoreFoundationServiceImpl implements CommonCoreFoundationService {
    @Resource(name = "foundationDao")
    private FoundationDao foundationDao;

    @Autowired
    private CommonService commonService;

    @Autowired
    private ObjectMapper transactionObjectMapper;

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public void createTransactionLink(ObjectRootVO currentVO, ObjectRootVO previousVO, TransactionTypeConstants.TYPE transactionType){
        String uri = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.requestUri,"");
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        TransactionLinkVO linkVO = makeLinkVO(currentVO,previousVO,transactionType,userId,uri);
        foundationDao.insert("Transaction.insertTransactionLink", linkVO);
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    @Override
    public void createTransactionLink(List<? extends ObjectRootVO>  currentVOList, List<? extends ObjectRootVO>  previousVOList, TransactionTypeConstants.TYPE transactionType){
        if(!FoundationDbProxy.getTransactionLogFlag()) return;

        String uri = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.requestUri,"");
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);

        List<TransactionLinkVO> linkVOList = new ArrayList<TransactionLinkVO>();
        Map<String,ObjectRootVO> preMapDB = new HashMap<String,ObjectRootVO>();
        if(transactionType.name().startsWith("Modify") || transactionType.name().startsWith("Delete")) preMapDB = makeMapDB(previousVOList);
        for(ObjectRootVO currentVO : currentVOList){
            if(transactionType.name().startsWith("Modify") || transactionType.name().startsWith("Delete")){
                linkVOList.add(makeLinkVO(currentVO,preMapDB.get(currentVO.getObid()),transactionType,userId,uri));
            }else{
                linkVOList.add(makeLinkVO(currentVO,null,transactionType,userId,uri));
            }
        }
        Map<String,List<TransactionLinkVO>> parmMap = new HashMap<String,List<TransactionLinkVO>>();
        parmMap.put(GlobalConstants.MAP_KEY_VO_LIST,linkVOList);
        foundationDao.insert("Transaction.insertTransactionLinkSet", parmMap);
    }
    private Map<String,ObjectRootVO> makeMapDB(List<? extends ObjectRootVO>  previousVOList){
        Map<String,ObjectRootVO> mapdb = new HashMap<String,ObjectRootVO>();
        for(ObjectRootVO vo : previousVOList) mapdb.put(vo.getObid(),vo);
        return mapdb;
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void setRollbackTransactionLink(TransactionLinkVO linkVO){
        linkVO.setFlags(Bit.or(linkVO.getFlags(), OmcSystemConstants.TRANSACTION_FLAG_Rollback));
        foundationDao.update("Transaction.updateTransactionLink", linkVO);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void createFoundationTableSet(Map<String, Object> map) {
        foundationDao.insert("Common.insertFoundationDBObjectSet", map);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void createFoundationTable(ObjectRootVO input) {
        foundationDao.insert("Common.insertFoundationDBObject", input);
    }

    @Override
    public void deleteFoundationTableSet(Map<String, Object> map) {
        foundationDao.delete("Common.deleteFoundationDBObjectSet", map);
    }

    @Override
    public void deleteFoundationTable(ObjectRootVO input) {
        foundationDao.delete("Common.deleteFoundationDBObject", input);
    }

    @Override
    public void modifyFoundationTable(KeyInfo keyInfo) {
        foundationDao.update("Common.updateFoundationDBObject", keyInfo);
    }
    @Override
    public void modifyFoundationTable(ObjectRootVO objVO) {
        foundationDao.update("Common.updateFoundationDBObject", objVO);
    }
    @Override
    @Cacheable(value = "objectKeyTable", key = "#obid")
    public KeyInfo getFoundationKeyInfo(String obid){
        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setObid(obid);
        return foundationDao.select("Common.getFoundationKeyInfo", keyInfo);
    }
    @Override
    public List<FilesVO> getFileObjects(FilesVO vo){
        return foundationDao.select("file.getFilesTemp", vo);
    }

    private TransactionLinkVO makeLinkVO(ObjectRootVO currentVO,ObjectRootVO previousVO, TransactionTypeConstants.TYPE transactionType,String userId, String uri){

        if (!(transactionType.name().startsWith("Create") ||
              transactionType.name().startsWith("Modify") ||
              transactionType.name().startsWith("Delete")))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Transaction Type is error!");

        if((transactionType.name().startsWith("Create") || transactionType.name().startsWith("Modify")) && NullUtil.isNull(currentVO))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Create and Modify Transaction Type must have current Object Info!");

        if((transactionType.name().startsWith("Modify") || transactionType.name().startsWith("Delete")) && NullUtil.isNull(previousVO))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Modify Delete Transaction Type must have previous Object Info!");

        TransactionLinkVO linkVO = new TransactionLinkVO();
        linkVO.setClassName(currentVO.getClassName());
        linkVO.setObid(currentVO.getObid());
        linkVO.setGlobalTransactionId(currentVO.getGlobalTransactionId());
        //Thread Local정보에서 subTransactionId가 있으면(Setting되어져 있으면)
        String subTransactionId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.subTransactionId,currentVO.getGlobalTransactionId());
        linkVO.setSubTransactionId(subTransactionId);
        linkVO.setUri(uri);
        linkVO.setCreator(userId);
        linkVO.setTransactionType(transactionType.name());
        String jsonAfter = "{}";
        String jsonBefore = "{}";
        try {
            if(transactionType.name().startsWith("Create") || transactionType.name().startsWith("Modify")){
                jsonAfter = transactionObjectMapper.writeValueAsString(currentVO);
            }
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        if(transactionType.name().startsWith("Modify") || transactionType.name().startsWith("Delete")){
            try {
                jsonBefore = transactionObjectMapper.writeValueAsString(previousVO);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
        }
        linkVO.setJsonAfter(jsonAfter);
        linkVO.setJsonBefore(jsonBefore);
        return linkVO;
    }
}
