package com.rap.omc.framework.exception;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJackson2JsonView;

import java.util.HashMap;
import java.util.Map;

public class OmfJsonException extends OmfFoundationBaseException {
    private static final long serialVersionUID = -6108327756860350046L;

    public OmfJsonException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfJsonException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfJsonException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfJsonException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfJsonException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfJsonException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfJsonException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
    public ModelAndView asModelAndView() {
    	MappingJackson2JsonView jsonView = new MappingJackson2JsonView();
        Map<String, String> model = new HashMap<String, String>();
        model.put("message", this.getMessage());
        model.put("code", this.getCode());
        return new ModelAndView(jsonView, model);
    }
}