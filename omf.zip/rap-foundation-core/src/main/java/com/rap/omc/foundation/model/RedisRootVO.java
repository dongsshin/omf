package com.rap.omc.foundation.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RedisRootVO {

}