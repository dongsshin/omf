package com.rap.omc.dataaccess.paging.handler;

import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import org.apache.ibatis.session.ResultContext;
import org.apache.ibatis.session.ResultHandler;

@SuppressWarnings({"rawtypes","unchecked"})
public class PagingResultHandler implements ResultHandler
{
	private final OmfPagingList<Object> list;
	public PagingResultHandler()
    {
    	this.list = new OmfPagingList();
    }
	public void handleResult(ResultContext context)
    {
    	this.list.add(context.getResultObject());
    }
    public OmfPagingList<Object> getResultList()
    {
    	return this.list;
    }
}