package com.rap.omc.foundation.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class RedisCodeDetailVO extends RedisRootVO{
    private String  masterCode;
    private String  code;
    private String  states;
    private String  displayName;
    private String  displayNameKr;
    private Integer sequences;
    private Boolean isDefault;
    private String  usingOrganizationList;
    private String  subCodeMaster;
    private String  attribute01;
    private String  attribute02;
    private String  attribute03;
    private String  attribute04;
    private String  attribute05;
}