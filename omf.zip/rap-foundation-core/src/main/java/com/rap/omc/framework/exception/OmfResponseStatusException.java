package com.rap.omc.framework.exception;

import com.rap.omc.core.util.MessageUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.NullUtil;
import org.springframework.core.NestedExceptionUtils;
import org.springframework.core.NestedRuntimeException;
import org.springframework.http.HttpStatus;
import org.springframework.util.Assert;

@SuppressWarnings("serial")
public class OmfResponseStatusException extends NestedRuntimeException {

    private HttpStatus status;

    private String reason = "Empty";
    private String messageCode = "Not Found";

    public OmfResponseStatusException(HttpStatus status) {
        this(status, null);
    }
    public OmfResponseStatusException(HttpStatus status, String messageCode) {
        this(status, messageCode, new Object[]{});
    }
    public OmfResponseStatusException(HttpStatus status, String messageCode, Object[] objArray) {
        this(status, messageCode, null, objArray);
    }
    public OmfResponseStatusException(HttpStatus status, String messageCode, Throwable cause) {
        this(status, messageCode, cause, "");
    }
    public OmfResponseStatusException(HttpStatus status, String messageCode, Throwable cause, Object...objArray) {
        super(null, cause);
        Assert.notNull(status, "HttpStatus is required");
        this.status = status;
        String message = "";
        if(!StrUtil.isEmpty(messageCode)){
            this.reason = messageCode;
            if(NullUtil.isNone(objArray)){
                message = MessageUtil.getMessage(messageCode);
            }else{
                message = MessageUtil.getMessage(messageCode,objArray);
            }
            if(!StrUtil.isEmpty(message)) {
                this.messageCode = messageCode;
                this.reason = message;
            }
        }
    }

    public HttpStatus getStatus() {
        return this.status;
    }

    public String getReason() {
        return this.reason;
    }

    public String getMessageCode() {
        return this.messageCode;
    }

        @Override
    public String getMessage() {
        String msg = this.status + "\"," + this.messageCode + "\"" + (this.reason != null ? " \"" + this.reason + "\"" : "");
        return NestedExceptionUtils.buildMessage(msg, getCause());
    }
}