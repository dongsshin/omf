package com.rap.omc.foundation.layout;

import com.rap.omc.foundation.layout.model.LayoutInfo;

public interface LayoutInfoService {
    public LayoutInfo getLayoutInfo(String layoutName);
}
