package com.rap.omc.framework.publish.classes.handler;

import com.constants.ServiceConstants;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.framework.publish.classes.ClassObjectEvent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Async;

//@Component
@Slf4j
public class ClassFileServiceEventHandler extends ClassEventGenericHandler {
    public ClassFileServiceEventHandler() {
        super(ServiceConstants.SERVICE_EXAMPLE);
    }
    @EventListener
    @Order(Ordered.HIGHEST_PRECEDENCE+8)
    @Async("threadPoolTaskExecutor")
    public void onMyEvent(ClassObjectEvent event) {
        if(log.isTraceEnabled()) log.trace("Call User Synchronization For " + this.getServiceName() + " Service Module Started....................");
        if(log.isTraceEnabled()) ThreadLocalUtil.print();
        if(true) return;
        try {
            super.execute(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}