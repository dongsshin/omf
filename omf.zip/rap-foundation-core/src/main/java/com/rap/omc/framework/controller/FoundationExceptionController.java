package com.rap.omc.framework.controller;

import com.rap.omc.framework.exception.OmfBaseException;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.Map;

@RestController
@RequestMapping(value = "/exception")
public class FoundationExceptionController {
    @GetMapping(value = "/loginfail/{message}")
    public @ResponseBody ResponseEntity<?> entrypointException(@PathVariable String message) {
        throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"foundation.error.request.loginfail",new Object[]{message});
    }
    @GetMapping(value = "/accessdenied/{message}")
    public @ResponseBody ResponseEntity<?> accessdeniedException(@PathVariable String message) {
        throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"foundation.error.request.accessdenied");
    }
    @GetMapping(value = "/invalidrequest")
    public @ResponseBody ResponseEntity<?> invalidRequestException(HttpServletRequest request) {
        Map<String,Object> errorData = (Map<String,Object> )request.getSession().getAttribute(StatusConstants.MAP_ERROR_SESSION_ATTR);
        Exception exception = (Exception)errorData.get(StatusConstants.MAP_ERROR_KEY_exception);
        HttpStatus httpStatus = StatusConstants.BAD_REQUEST;
        try{
            if(exception instanceof OmfBaseException){
                //Foundation에서 지정한 Error인 경우 원 에러의 정보를 이용
                httpStatus = ((OmfBaseException)exception).getHttpStatus();
                errorData.put(StatusConstants.MAP_ERROR_KEY_errorStatusCode,httpStatus.value());
            }else{
                httpStatus = HttpStatus.resolve((Integer)errorData.get(StatusConstants.MAP_ERROR_KEY_errorStatusCode));
            }
        }catch (Exception e){
            ;
        }
        throw new OmfResponseStatusException(httpStatus,"foundation.error.request.general",exception,new Object[]{errorData.get(StatusConstants.MAP_ERROR_KEY_errorStatusCode),errorData.get(StatusConstants.MAP_ERROR_KEY_errorMessage),errorData.get(StatusConstants.MAP_ERROR_KEY_errorRequestUri)});
    }
}
