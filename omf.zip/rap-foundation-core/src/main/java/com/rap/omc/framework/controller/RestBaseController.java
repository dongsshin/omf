/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : RestBaseController.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 2. 2.  hyeyoung.park   Initial
 * ===========================================
 */
package com.rap.omc.framework.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.foundation.user.model.UserSession;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.validation.Validator;

import javax.annotation.Resource;

/**
 * <pre>
 * Class : RestBaseController
 * Description : Rest W/S를 처리하는 모든 Controller가 상속받아야 하는 Controller
 * </pre>
 * 
 * @author hyeyoung.park
 */
@Slf4j
public class RestBaseController {

    protected final String ERR_MSG_GEN_CREATE = "common.error.gen.create.general";
    protected final String ERR_MSG_GEN_MODIFY = "common.error.gen.modify.general";
    protected final String ERR_MSG_GEN_DELETE = "common.error.gen.delete.general";
    protected final String ERR_MSG_GEN_CUD = "common.error.gen.cud.general";
    protected final String ERR_MSG_GEN_GET = "common.error.gen.get.general";
    protected final String ERR_MSG_GEN_FIND = "common.error.gen.find.general";
    protected final String ERR_MSG_GEN_EXECUTE = "common.error.gen.execute.general";

    public static final String RETURN_KEY = GlobalConstants.M_RESULT;
    /**
     * MessageSource
     */
    @Resource(name = "messageSource")
    protected MessageSource messageSource;

    @Autowired
    protected ObjectMapper objectMapper;

    /**
     * MessageSourceAccessor.
     */
    @Resource(name = "messageSourceAccessor")
    protected MessageSourceAccessor messageSourceAccessor;

    /**
     * Bean Validator
     */
    @Resource(name="beanValidator")
    protected Validator validator;

}
