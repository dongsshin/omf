package com.rap.omc.foundation.classes.model;
/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : ClassInfo.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2020. 07. ??. DongSik Initial
 * ===========================================
 */


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rap.omc.core.oql.utility.OmcUtility;
import com.rap.omc.util.StrUtil;
import com.rap.omc.foundation.common.model.ModelRootVO;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcDBMSConstants;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.BaseFoundationUtil;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.foundation.LifeCycleUtil;

import java.math.BigDecimal;
import java.util.*;
import java.util.regex.Pattern;

public class ClassInfo extends ModelRootVO{

    @JsonIgnore
    private long   flags;
    @JsonIgnore
    private long   classInfoFlags;
    private String className;
    private String classNameParent;
    private String javaPackage;
    private String javaPackageParent;
    private String dbmsTable;
    private List<ColumnInfo> columnList;
    private String displayedName;
    private String displayedNameKr;
    private String defaultPolicy;
    private String workflowUrl;
    private String classIcon;
    private String classIconSmall;
    
    private String classIconReal;
    private String classIconSmallReal;

    @JsonIgnore
    private String upperClassListStr;
    @JsonIgnore
    private String lowerClassListStr;
    private long cardinalityFrom;
    private long cardinalityTo;
    private long revisionRuleFrom;
    private long revisionRuleTo;

    private Object sampleInstance = null;

    private String moduleName;

    public String getModuleName() {
        return moduleName;
    }

    public void setDisplayedNameKr(String displayedNameKr) {
        this.displayedNameKr = displayedNameKr;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public Object getSampleInstance() {
        return sampleInstance;
    }

    public void setSampleInstance(Object sampleInstance) {
        this.sampleInstance = sampleInstance;
    }

    @JsonIgnore
    private List<String> upperClassList;
    @JsonIgnore
    private List<String> lowerClassList;
    @JsonIgnore
    private List<ClassDbmsTableVO> instantiableClassList;
    @JsonIgnore
    private List<ClassNameForDisplayVO> childClassListForCombo;
    @JsonIgnore
    private String obid;
    private String classMenu;
    private String structureMenu;
    private List<String> allowedLifeCycleList;
    private List<AllowedClassInfo> allowedClassInfo;
    
    private List<AllowedClassInfo> relatedClassInfo;
    
    private Set<String> allowedFromClassSet;
    private Set<String> allowedToClassSet;


    public Set<String> getAllowedFromClassSet(){
        return allowedFromClassSet;
    }

    public void setAllowedFromClassSet(Set<String> allowedFromClassSet){
        this.allowedFromClassSet = allowedFromClassSet;
    }

    public Set<String> getAllowedToClassSet(){
        return allowedToClassSet;
    }

    public void setAllowedToClassSet(Set<String> allowedToClassSet){
        this.allowedToClassSet = allowedToClassSet;
    }




    public List<AllowedClassInfo> getRelatedClassInfo(){
        return relatedClassInfo;
    }



    
    public void setRelatedClassInfo(List<AllowedClassInfo> relatedClassInfo){
        this.relatedClassInfo = relatedClassInfo;
    }



    public List<String> getAllowedLifeCycleList(){
        return allowedLifeCycleList;
    }


    
    public void setAllowedLifeCycleList(List<String> allowedLifeCycleList){
        this.allowedLifeCycleList = allowedLifeCycleList;
    }


    public List<ClassNameForDisplayVO> getChildClassListForCombo(){
        return childClassListForCombo;
    }


    public void setChildClassListForCombo(List<ClassNameForDisplayVO> childClassListForCombo){
        this.childClassListForCombo = childClassListForCombo;
    }

    public List<ClassDbmsTableVO> getInstantiableClassList(){
        return instantiableClassList;
    }

    public void setInstantiableClassList(List<ClassDbmsTableVO> instantiableClassList){
        this.instantiableClassList = instantiableClassList;
    }



    public String getStructureMenu(){
        return structureMenu;
    }


    
    public void setStructureMenu(String structureMenu){
        this.structureMenu = structureMenu;
    }
    
    
    
    public String getClassIconReal(){
        return classIconReal;
    }

    
    public String getClassIconSmallReal(){
        return classIconSmallReal;
    }

    
    public void setClassIconReal(String classIconReal){
        this.classIconReal = classIconReal;
    }

    
    public void setClassIconSmallReal(String classIconSmallReal){
        this.classIconSmallReal = classIconSmallReal;
    }

    public String getClassMenu(){
        return classMenu;
    }
    
    public void setClassMenu(String classMenu){
        this.classMenu = classMenu;
    }
    public String getClassNameParent(){
        return classNameParent;
    }
    public String getJavaPackageParent(){
        return javaPackageParent;
    }
    public void setClassNameParent(String classNameParent){
        this.classNameParent = classNameParent;
    }
    public void setJavaPackageParent(String javaPackageParent){
        this.javaPackageParent = javaPackageParent;
    }
    public List<AllowedClassInfo> getAllowedClassInfo(){
        return allowedClassInfo;
    }

    
    public void setAllowedClassInfo(List<AllowedClassInfo> allowedClassInfo){
        this.allowedClassInfo = allowedClassInfo;
    }

    public String getObid(){
        return obid;
    }
    public void setObid(String obid){
        this.obid = obid;
    }




    public long getClassInfoFlags(){
        return classInfoFlags;
    }


    
    
    public String getUpperClassListStr(){
        return upperClassListStr;
    }



    
    public String getLowerClassListStr(){
        return lowerClassListStr;
    }



    
    public void setUpperClassListStr(String upperClassListStr){
        String[] strArray = upperClassListStr.split(Pattern.quote(","));
        List<String> strList = new ArrayList<String>();
        for(int i = 0; i < strArray.length; i++){
            strList.add(strArray[i]);
        }
        this.upperClassListStr = upperClassListStr;
        this.upperClassList = strList;
    }
    public void setLowerClassListStr(String lowerClassListStr){
        String[] strArray = lowerClassListStr.split(Pattern.quote(","));
        List<String> strList = new ArrayList<String>();
        for(int i = 0; i < strArray.length; i++){
            strList.add(strArray[i]);
        }
        this.lowerClassListStr = lowerClassListStr;
        this.lowerClassList = strList;
    }
    public void setClassInfoFlags(long classInfoFlags){
        this.classInfoFlags = classInfoFlags;
    }

    
    public List<String> getUpperClassList(){
        return upperClassList;
    }

    
    public List<String> getLowerClassList(){
        return lowerClassList;
    }

    
    public void setUpperClassList(List<String> upperClassList){
        this.upperClassList = upperClassList;
    }
    public void setUpperClassList(String upperClassList){
        String[] strArray = upperClassList.split(Pattern.quote(","));
        this.upperClassList = Arrays.asList(strArray);
    }
    public void setLowerClassList(List<String> lowerClassList){
        this.lowerClassList = lowerClassList;
    }
    public void setLowerClassList(String lowerClassList){
        String[] strArray = lowerClassList.split(Pattern.quote(","));
        this.lowerClassList = Arrays.asList(strArray);;
    }
    public long getFlags(){
        return flags;
    }
    
    public String getClassName(){
        return className;
    }
    
    public String getJavaPackage(){
        return javaPackage;
    }
    
    public String getDbmsTable(){
        return dbmsTable;
    }
    
    public String getDisplayedName(){
        return displayedName;
    }
    
    public String getDisplayedNameKr(){
        return displayedNameKr;
    }
    
    public String getDefaultPolicy(){
        return defaultPolicy;
    }
    
    public String getWorkflowUrl(){
        return workflowUrl;
    }
    
    public String getClassIcon(){
        return classIcon;
    }
    
    public String getClassIconSmall(){
        return classIconSmall;
    }
    
    public long getCardinalityFrom(){
        return cardinalityFrom;
    }
    
    public long getCardinalityTo(){
        return cardinalityTo;
    }
    
    public long getRevisionRuleFrom(){
        return revisionRuleFrom;
    }
    
    public long getRevisionRuleTo(){
        return revisionRuleTo;
    }
    
    public void setFlags(long flags){
        this.flags = flags;
    }
    
    public void setClassName(String className){
        this.className = className;
    }
    
    public void setJavaPackage(String javaPackage){
        this.javaPackage = javaPackage;
    }
    
    public void setDbmsTable(String dbmsTable){
        this.dbmsTable = dbmsTable;
    }
    
    public void setColumnList(List<ColumnInfo> columnList){
        this.columnList = columnList;
    }
    
    public void setDisplayedName(String displayedName){
        this.displayedName = displayedName;
    }
    
    public void setDefaultPolicy(String defaultPolicy){
        this.defaultPolicy = defaultPolicy;
    }
    
    public void setWorkflowUrl(String workflowUrl){
        this.workflowUrl = workflowUrl;
    }
    
    public void setClassIcon(String classIcon){
        this.classIcon = classIcon;
    }
    
    public void setClassIconSmall(String classIconSmall){
        this.classIconSmall = classIconSmall;
    }
    
    public void setCardinalityFrom(long cardinalityFrom){
        this.cardinalityFrom = cardinalityFrom;
    }
    
    public void setCardinalityTo(long cardinalityTo){
        this.cardinalityTo = cardinalityTo;
    }
    
    public void setRevisionRuleFrom(long revisionRuleFrom){
        this.revisionRuleFrom = revisionRuleFrom;
    }
    
    public void setRevisionRuleTo(long revisionRuleTo){
        this.revisionRuleTo = revisionRuleTo;
    }
    /**
     * 
     * 
     * @return the columList
     */
    public List<ColumnInfo> getColumnList(){
        return columnList;
    }
    /**
     * 
     *
     * @param columnList the columList to set
     */
    public void setColumList(List<ColumnInfo> columnList){
        this.columnList = columnList;
    }
    @JsonIgnore
    public String getColumnListString(){
        String strColumns = null;
        if (!NullUtil.isNone(columnList)) {
            StringBuffer sb = new StringBuffer();
            for (ColumnInfo column : columnList) {
                sb.append(column.getDbmsColumn()).append(",");
            }
            strColumns = sb.toString();
            strColumns = strColumns.substring(0, strColumns.length() - 1);
        }
        return strColumns;
    }
    public String getConvert2SelectString(){
        return getConvert2SelectString(true);
    }
    public String makeWhereString(Set<String> attributes){
        StringBuffer strBuf = new StringBuffer();
        for(String attribute : attributes){
            for (ColumnInfo column : columnList) {
                if(attribute.equals(column.getAttributeName())){
                    if(strBuf.length() > 0) strBuf.append(" and ");
                    strBuf.append(column.getDbmsColumn()).append( "=").append("#{item.").append(attribute).append("}");
                }
            }
        }
        return strBuf.toString();
    }
    public Set<String> getAttributeSet(boolean includeFoundationAttr){
        Set<String> strSet = new HashSet<String>();
        for(ColumnInfo columnInfo : this.columnList){
            if(includeFoundationAttr){
                strSet.add(columnInfo.getAttributeName());
            }else{
                if(OmcSystemConstants.FOUNDATION_ATTRIBUTE_SET.contains(columnInfo.getAttributeName())){
                    strSet.add(columnInfo.getAttributeName());
                }
            }
        }
        return strSet;
    }
    public String getConvert2SelectString(boolean includeNameAttr){
        String strColumns = null;
        if (!NullUtil.isNone(columnList)) {
            StringBuffer sb = new StringBuffer();
            for (ColumnInfo column : columnList) {
                if (column.getDataType()== OmcSystemConstants.SCHEMA_DATA_TYPE_DATE) {
                    sb.append(OmcDBMSConstants.DBMS_UTC2LOCAL_FUNCTION).append("(").append(column.getDbmsColumn()).append(") as ").append(OmcDBMSConstants.CDEL).append(column.getColumnAlias()).append(OmcDBMSConstants.CDEL).append(",");
                } else {
                    sb.append(column.getDbmsColumn()).append(" as ").append(OmcDBMSConstants.CDEL).append(column.getColumnAlias()).append(OmcDBMSConstants.CDEL).append(",");
                }
                if(includeNameAttr){
                    if(Bit.isInclude(column.getFlags(),OmcSystemConstants.SYSCLASSATTR_FLAG_IsNameAttribute)){
                        String nameQuerystr = OmcUtility.getSelectStrForNameAttr(column.getValueSettingInfo(),column.getDbmsColumn(),BaseFoundationUtil.convert2CamelCase(column.getColumnAlias()));
                        if(!NullUtil.isNone(nameQuerystr)){
                            StringBuffer tSel = new StringBuffer();
                            tSel.append(nameQuerystr.replace("#{omcDbColumn}", "PTITLES").replace("#omcAttr", "Titles"));
                            tSel.append(",");
                            tSel.append(nameQuerystr.replace("#{omcDbColumn}", "OBID").replace("#omcAttr", "Obid"));
                            sb.append(tSel).append(",");
                        }
                    }                    
                }
                if(includeNameAttr){
                    if(column.getDataType() == OmcSystemConstants.SCHEMA_DATA_TYPE_USERID){
                        sb.append(OmcUtility.makeUserTitles(column.getDbmsColumn(),column.getColumnAlias(),true)).append(",");
                        sb.append(OmcUtility.makeUserObid(column.getDbmsColumn(),column.getColumnAlias(),true)).append(",");
                    }                    
                }
                if(includeNameAttr & Bit.isInclude(column.getFlags(),OmcSystemConstants.SYSCLASSATTR_FLAG_IsCodeAttribute)){
                    String codeQueryStr = OmcUtility.getSelectStrForCodeAttr(column.getValueSettingInfo(),column.getDbmsColumn(),BaseFoundationUtil.convert2CamelCase(column.getColumnAlias()));
                    if(!NullUtil.isNone(codeQueryStr)){
                        StringBuffer tSel = new StringBuffer();
                        tSel.append(codeQueryStr.replace("#omcAttr", "CodeTitles"));
                        sb.append(tSel).append(",");
                    }
                }
            }
            strColumns = sb.toString();
            strColumns = strColumns.substring(0, strColumns.length() - 1);
        }
        return strColumns;
    }
    @JsonIgnore
    public HashMap<String,Object> makeCreateJsonStr(){
        HashMap<String,Object> createExampleMap = new HashMap<String,Object>();
        HashMap<String,Object> modifyExampleMap = new HashMap<String,Object>();
        HashMap<String,Object> returnMap = new HashMap<String,Object>();

        String[] JSON_EXCEPT_BIZ_CREATE = {"obid","globalTransactionId","flags","locker","checkouter","checkouted","owner","creator","created","modified","modifier","struLatestObid","struRelationClass","previousObid","nextObid","branchTo"};
        String[] JSON_EXCEPT_REL_CREATE = {"obid","globalTransactionId","flags","locker","checkouter","checkouted","owner","creator","created","modified","modifier","fromClass","fromObid","toClass","toObid"};

        String[] JSON_EXCEPT_BIZ_MODIFY = {"flags","locker","checkouter","checkouted","owner","creator","created","modified","modifier","struLatestObid","struRelationClass","previousObid","nextObid","branchTo","states","lifeCycle"};
        String[] JSON_EXCEPT_REL_MODIFY = {"flags","locker","checkouter","checkouted","owner","creator","created","modified","modifier","fromClass","fromObid","toClass","toObid"};

        Set<String> EXCEPT_BIZ_CREATE_SET = StrUtil.convertArrayToSet(JSON_EXCEPT_BIZ_CREATE);
        Set<String> EXCEPT_REL_CREATE_SET = StrUtil.convertArrayToSet(JSON_EXCEPT_REL_CREATE);
        Set<String> EXCEPT_BIZ_MODIFY_SET = StrUtil.convertArrayToSet(JSON_EXCEPT_BIZ_MODIFY);
        Set<String> EXCEPT_REL_MODIFY_SET = StrUtil.convertArrayToSet(JSON_EXCEPT_REL_MODIFY);

        for(ColumnInfo col: this.getColumnList()){
            Object value = null;
            switch(col.getDataType()){
                case OmcSystemConstants.SCHEMA_DATA_TYPE_STRING:
                    value = "StringValue";
                    if(col.getAttributeName().equals("names"))  value = "name:BusinessKey";
                    if(col.getAttributeName().equals("className"))  value = this.getClassName();
                    if(col.getAttributeName().equals("titles"))  value = "SimpleDesc";
                    if(col.getAttributeName().equals("descriptions"))  value = "LongDesc";
                    if(col.getAttributeName().equals("lifeCycle"))  value = this.getDefaultPolicy();
                    if(col.getAttributeName().equals("states"))  value = LifeCycleUtil.getDefaultState(this.getDefaultPolicy());
                    if(col.getAttributeName().equals("obid"))  value = "UniqueKey";
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_USERID:
                    value = "userId";
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_LONGSTRING:
                    value = "Text";
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_INTEGER:
                    value = 100;
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_FLOAT:
                    value = 1.0f;
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_DATE:
                    value = new Date();
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_BOOLEAN:
                    value = 1;
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_LONG:
                    value = 1000l;
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_DOUBLE:
                    value = 1000;
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_BIGDECIMAL:
                    value = BigDecimal.valueOf(999999999);
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_ATTRIBUTESET:
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_ARRAY:
                    break;
                case OmcSystemConstants.SCHEMA_DATA_TYPE_FILE:
                    break;
                default:
                    break;
            }
            if(Bit.isInclude(this.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_Relation)){
                if(!EXCEPT_REL_CREATE_SET.contains(col.getAttributeName())){
                    createExampleMap.put(col.getAttributeName(),value);
                }
                if(!EXCEPT_REL_MODIFY_SET.contains(col.getAttributeName())){
                    modifyExampleMap.put(col.getAttributeName(),value);
                }
            }else{
                if(!EXCEPT_BIZ_CREATE_SET.contains(col.getAttributeName())){
                    createExampleMap.put(col.getAttributeName(),value);
                }
                if(!EXCEPT_BIZ_MODIFY_SET.contains(col.getAttributeName())){
                    modifyExampleMap.put(col.getAttributeName(),value);
                }
            }
        }
        returnMap.put("Create Object Sample Json",createExampleMap);
        returnMap.put("Modify Object Sample Json",modifyExampleMap);
        return returnMap;
    }
    public Map<String, String> makeInsertSqlForRollback(){
        Map<String,String> map = new HashMap<String,String>();
        StringBuffer columnsBuf = new StringBuffer();
        StringBuffer valuesBuf = new StringBuffer();
        for(ColumnInfo colInfo : this.columnList){
            columnsBuf.append(",").append(colInfo.getDbmsColumn());
            valuesBuf.append(",").append("#{").append(BaseFoundationUtil.convert2CamelCase(colInfo.getColumnAlias())).append("}");
        }
        map.put("columns",columnsBuf.toString().substring(1));
        map.put("values",valuesBuf.toString().substring(1));
        return map;
    }
    public String makeUpdateSqlForRollback(){
        StringBuffer valuesBuf = new StringBuffer();
        for(ColumnInfo colInfo : this.columnList){
            if(!colInfo.getAttributeName().equals("obid")) valuesBuf.append(",").append(colInfo.getDbmsColumn()).append(" = ").append("#{").append(BaseFoundationUtil.convert2CamelCase(colInfo.getColumnAlias())).append("}");
        }
        return valuesBuf.toString().substring(1);
    }
}