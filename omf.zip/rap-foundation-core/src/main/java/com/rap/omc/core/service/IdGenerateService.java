package com.rap.omc.core.service;

public interface IdGenerateService {
    public String[] generateUniqueNameSet(int wantedCount);
    public String generateUniqueName(String idKey);
}
