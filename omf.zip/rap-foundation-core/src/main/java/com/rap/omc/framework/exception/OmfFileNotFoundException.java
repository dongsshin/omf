package com.rap.omc.framework.exception;

import com.rap.omc.framework.file.exception.OmfFileBaseException;
import org.springframework.http.HttpStatus;

public class OmfFileNotFoundException extends OmfFileBaseException {
    private static final long serialVersionUID = 1L;
    public OmfFileNotFoundException(HttpStatus httpStatus, String message)
    {
        super(httpStatus,message);
    }
    public OmfFileNotFoundException(HttpStatus httpStatus, String code, String message)
    {
        super(httpStatus,code, message);
    }
    public OmfFileNotFoundException(HttpStatus httpStatus, Throwable cause)
    {
        super(httpStatus,cause);
    }
    public OmfFileNotFoundException(HttpStatus httpStatus, String code, String message, Throwable cause)
    {
        super(httpStatus,code, message, cause);
    }
    public OmfFileNotFoundException(HttpStatus httpStatus, String message, Throwable cause)
    {
        super(httpStatus,message, cause);
    }
}
