package com.rap.omc.controller.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CSysServiceVO {
    private String serviceName;
    private String serviceUrl;
    private String activateFlag="Active";
}
