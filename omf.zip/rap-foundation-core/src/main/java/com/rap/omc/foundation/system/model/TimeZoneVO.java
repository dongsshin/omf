package com.rap.omc.foundation.system.model;

/**
 * 
 * <pre>
 * Class : TimeZoneVO
 * Description : TODO
 * </pre>
 * 
 * @author youngmi.won
 */
public class TimeZoneVO {
    private String names;
    private String titles;
    
    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public String getTitles() {
        return titles;
    }

    public void setTitles(String titles) {
        this.titles = titles;
    }
}
