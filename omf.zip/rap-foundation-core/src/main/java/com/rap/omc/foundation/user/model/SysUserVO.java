/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : SysUserVO.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 4. 15. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.user.model;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.rap.api.object.foundation.model.JsonDeserializerDateHandler;
import com.rap.api.object.foundation.model.JsonSerializerDateHandler;
import com.rap.omc.controller.model.CSysUserVO;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.object.model.OmcSchemaUserVO;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import org.springframework.http.HttpStatus;

import java.util.*;
import java.util.regex.Pattern;

/**
 * <pre>
 * Class : SysUserVO
 * Description : TODO
 * </pre>
 * 
 * @author hyeyoung.park
 */
public class SysUserVO{

    private String obid;

    //@JsonIgnore
    private long   flags;

    private String userId;
    
    private String descriptions;

    //@JsonIgnore
    private long kinds;

    //@JsonIgnore
    private String kindsStr;
    
    private String password;

    private String site;
    
    private String emailId;

    //@JsonIgnore
    private String creator;

    @JsonDeserialize(using = JsonDeserializerDateHandler.class)
    @JsonSerialize(using = JsonSerializerDateHandler.class)
    private Date checkouted;
    @JsonDeserialize(using = JsonDeserializerDateHandler.class)
    @JsonSerialize(using = JsonSerializerDateHandler.class)
    private Date created;

    //@JsonIgnore
    private String modifier;

    @JsonDeserialize(using = JsonDeserializerDateHandler.class)
    @JsonSerialize(using = JsonSerializerDateHandler.class)
    private Date modified;

    //@JsonIgnore
    private String timeStamp;
       
    private Set<String> roleSet = new HashSet<String>();
    
    private Set<String> groupSet= new HashSet<String>();;
    
    private Map<String,String> propertyList = new HashMap<String,String>();
    
    
    public SysUserVO() {
        super();
    }


    public SysUserVO(CSysUserVO cSysUserVO) {
        super();
        this.userId = cSysUserVO.getUserId();
        this.descriptions = cSysUserVO.getDescriptions();
        this.password = cSysUserVO.getPassword();
        this.site = cSysUserVO.getSite();
        this.emailId = cSysUserVO.getEmailId();
        this.propertyList = cSysUserVO.getProperty();

        Set<String> rolSet  = new HashSet<String>();
        if(!NullUtil.isNone(cSysUserVO.getRoleSet())){
            for(int i = 0; i < cSysUserVO.getRoleSet().length; i++){
                rolSet.add( cSysUserVO.getRoleSet()[i]);
            }
        }
        this.roleSet = rolSet;
        Set<String> groupSet  = new HashSet<String>();
        if(!NullUtil.isNone(cSysUserVO.getGroupSet())){
            for(int i = 0; i < cSysUserVO.getGroupSet().length; i++){
                rolSet.add( cSysUserVO.getGroupSet()[i]);
            }
        }
        this.groupSet = groupSet;
    }

    public SysUserVO(OmcSchemaUserVO schemaUserVO) {
        super();
        this.obid = schemaUserVO.getObid();
        this.flags = schemaUserVO.getFlags();
        this.userId = schemaUserVO.getNames();
        this.descriptions = schemaUserVO.getDescriptions();
        this.kinds = schemaUserVO.getKinds();
        this.kindsStr = schemaUserVO.getKindsStr();
        this.password = schemaUserVO.getPassword();
        this.site = schemaUserVO.getSite();
        this.emailId = schemaUserVO.getEmailId();
        this.timeStamp = schemaUserVO.getTimeStamp();
        this.creator = schemaUserVO.getCreator();
        this.created = schemaUserVO.getCreated();
        this.modifier = schemaUserVO.getModifier();
        this.modified = schemaUserVO.getModified();
    }
    
    public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public void setTimeStamp(String timeStamp) {
		this.timeStamp = timeStamp;
	}
	public String getTimeStamp() {
		return timeStamp;
	}
	public Set<String> getRoleSet(){
        return roleSet;
    }
    
    public Set<String> getGroupSet(){
        return groupSet;
    }

    
    public void setGroupSet(Set<String> groupSet){
        this.groupSet = groupSet;
    }



    public Map<String, String> getPropertyList(){
        return propertyList;
    }



    
    public void setRoleSet(Set<String> roleSet){
        this.roleSet = roleSet;
    }



    
    public void setPropertyList(Map<String, String> propertyList){
        this.propertyList = propertyList;
    }



    public String getUserId(){
        return userId;
    }


    
    public void setUserId(String userId){
        this.userId = userId;
    }


    public String getObid(){
        return obid;
    }

    
    public long getFlags(){
        return flags;
    }
    
    public String getDescriptions(){
        return descriptions;
    }

    
    public long getKinds(){
        return kinds;
    }

    
    public String getKindsStr(){
        return kindsStr;
    }

    
    public String getPassword(){
        return password;
    }

    
    public String getSite(){
        return site;
    }

    
    public String getCreator(){
        return creator;
    }

    
    public Date getCreated(){
        return created;
    }

    
    public String getModifier(){
        return modifier;
    }

    
    public Date getModified(){
        return modified;
    }

    public void setObid(String obid){
        this.obid = obid;
    }

    
    public void setFlags(long flags){
        this.flags = flags;
    }


    
    public void setDescriptions(String descriptions){
        this.descriptions = descriptions;
    }

    
    public void setKinds(long kinds){
        this.kinds = kinds;
    }

    
    public void setKindsStr(String kindsStr){
        this.kindsStr = kindsStr;
    }

    
    public void setPassword(String password){
        this.password = password;
    }

    
    public void setSite(String site){
        this.site = site;
    }

    
    public void setCreator(String creator){
        this.creator = creator;
    }

    
    public void setCreated(Date created){
        this.created = created;
    }

    
    public void setModifier(String modifier){
        this.modifier = modifier;
    }
    
    public void setModified(Date modified){
        this.modified = modified;
    }
    public void setGroupSet(String groupList){
        if(this.groupSet == null) this.groupSet = new HashSet<String>();
        String[] array = groupList.split(",");
        if(!NullUtil.isNone(groupList)){
            for(int i = 0; i < array.length; i ++){
                this.groupSet.add(array[i]);
            }     
        }
    }
    public void setRoleSet(String roleList){
        String[] roleArray = roleList.split(",");
        if(this.roleSet == null) this.roleSet = new HashSet<String>();
        if(!NullUtil.isNone(roleList)){
            for(int i = 0; i < roleArray.length; i ++){
                this.roleSet.add(roleArray[i]);
            }
        }
    }

    public void setPropertyList(String propertyList){
        String[] ptyArray = propertyList.split(Pattern.quote(OmcSystemConstants.ATTRIBUTE_DELIMINATOR_NAME));
        if(NullUtil.isNone(this.propertyList)) this.propertyList = new HashMap<String,String>();
        if(!NullUtil.isNone(propertyList)){
            for(int i = 0; i < ptyArray.length; i ++){
                String[] valueArray = ptyArray[i].split(Pattern.quote(OmcSystemConstants.ATTRIBUTE_DELIMINATOR_VALUE));
                if(valueArray.length != 2) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Property Format Error");
                this.propertyList.put(valueArray[0],valueArray[1]);
            }            
        }
    }
}
