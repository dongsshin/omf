package com.rap.omc.framework.exception;

import com.rap.omc.core.util.MessageUtil;
import com.rap.omc.framework.exception.model.ExceptionOptionalInfo;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

import java.util.Locale;

public class OmfBusinessException extends OmfBaseException
{

    private static final long serialVersionUID = 1L;

    private ExceptionOptionalInfo optionInfo;

    private Object[] messageParameters;

    public OmfBusinessException(HttpStatus httpStatus, String message)
    {
        super(httpStatus,message);
    }


    public OmfBusinessException(HttpStatus httpStatus, Throwable cause)
    {
        super(httpStatus,cause);
    }


    public OmfBusinessException(HttpStatus httpStatus, String message, Throwable cause)
    {
        super(httpStatus,message, cause);
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, MessageSource messageSource)
    {
        super(httpStatus,code, messageSource);
        super.setMessage(MessageUtil.getMessage(code, messageParameters));
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, Object[] messageParameters)
    {
        super(httpStatus,code, messageParameters);
        this.messageParameters = messageParameters;
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters)
    {
        super(httpStatus,code, messageSource, messageParameters);
        this.messageParameters = messageParameters;
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause)
    {
        super(httpStatus,code, messageParameters, cause);
        this.messageParameters = messageParameters;
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters,
                                Throwable cause)
    {
        super(httpStatus,code, messageSource, messageParameters, cause);
        this.messageParameters = messageParameters;
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters,
                                Locale locale)
    {
        super(httpStatus,code, messageSource, messageParameters, locale);
        this.messageParameters = messageParameters;
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, MessageSource messageSource, Object[] messageParameters,
                                Locale locale, Throwable cause)
    {
        super(httpStatus,code, messageSource, messageParameters, locale, cause);
        this.messageParameters = messageParameters;
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, ExceptionOptionalInfo optionInfo)
    {
        super(httpStatus,code);
        setOptionalInfo(optionInfo);
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, Throwable cause, ExceptionOptionalInfo optionInfo)
    {
        super(httpStatus,cause);
        super.setCode(code);
        setOptionalInfo(optionInfo);
    }


    public OmfBusinessException(HttpStatus httpStatus, String code, Object[] messageParameters, ExceptionOptionalInfo optionInfo)
    {
        super(httpStatus,code, messageParameters);
        this.messageParameters = messageParameters;
        setOptionalInfo(optionInfo);
    }


    public void setOptionalInfo(ExceptionOptionalInfo extraInfo)
    {
        this.optionInfo = extraInfo;
    }


    public ExceptionOptionalInfo getOptionalInfo()
    {
        return this.optionInfo;
    }


    public Object[] getMessageParameters()
    {
        return this.messageParameters;
    }


    public String toString()
    {
        String str = super.getClass().getName();
        String message = super.getMessage();
        String code = super.getCode();
    
        StringBuilder stringBuilder = new StringBuilder(str);
        stringBuilder.append((message != null) ? ": " + message : "");
        stringBuilder.append(((code != null) && (!("".equals(code)))) ? "(" + code + ")" : " ");
        return stringBuilder.toString();
    }
}