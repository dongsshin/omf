/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : ApplicationException.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 2. 3. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.framework.exception.model;


import com.rap.omc.core.util.MessageUtil;
import com.rap.omc.framework.exception.OmfBusinessException;
import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;


/**
 * <pre>
 * Class : ApplicationException
 * Description : 프로젝트에서 비즈니스 Rule 위반 시 발생시키는 Exception
 * </pre>
 * 
 * @author hyeyoung.park
 */
@SuppressWarnings("serial")
public class OmfNotFoundException extends OmfBusinessException {
    public OmfNotFoundException(String code) {
        super(HttpStatus.NOT_FOUND,code);
    }
    public OmfNotFoundException(Throwable cause) {
        super(HttpStatus.NOT_FOUND,cause);
    }
    public OmfNotFoundException(String code, MessageSource messageSource) {
        super(HttpStatus.NOT_FOUND,code, messageSource);
    }

    public OmfNotFoundException(String code, Throwable cause) {
        super(HttpStatus.NOT_FOUND,code, cause);
    }
    public OmfNotFoundException(String code, Object[] messageParameters) {
        super(HttpStatus.NOT_FOUND,code);
        super.setMessage(MessageUtil.getMessage(code, messageParameters));
    }

    public OmfNotFoundException(String code, Object[] messageParameters, Throwable cause) {
        super(HttpStatus.NOT_FOUND,code, null, cause);
        super.setMessage(MessageUtil.getMessage(code, messageParameters));
    }
    public OmfNotFoundException(String code, MessageSource messageSource, Object[] messageParameters) {
        super(HttpStatus.NOT_FOUND,code, messageSource, messageParameters);
    }
}
