package com.rap.omc.core.oql.model;

import java.util.HashMap;
import java.util.Map;

public class OmcSQLVariableParameter extends OmcSQLDefaultMap {
 public OmcSQLVariableParameter() {
		super();
	}
private Map<String,Object> attributeMap = new HashMap<String,Object>();
  
public Map<String, Object> getAttributeMap(){
    return attributeMap;
}

public void setAttributeValue(String attribute, Object value){
    this.attributeMap.put(attribute, value);
}

public void setAttributeMap(Map<String, Object> attributeMap){
    this.attributeMap = attributeMap;
}
private String funVariable_00001 ;
 private String funVariable_00002 ;
 private String funVariable_00003 ;
 private String funVariable_00004 ;
 private String funVariable_00005 ;
 private String funVariable_00006 ;
 private String funVariable_00007 ;
 private String funVariable_00008 ;
 private String funVariable_00009 ;
 private String funVariable_00010 ;
 private String funVariable_00011 ;
 private String funVariable_00012 ;
 private String funVariable_00013 ;
 private String funVariable_00014 ;
 private String funVariable_00015 ;
 private String funVariable_00016 ;
 private String funVariable_00017 ;
 private String funVariable_00018 ;
 private String funVariable_00019 ;
 private String funVariable_00020 ;
 private String funVariable_00021 ;
 private String funVariable_00022 ;
 private String funVariable_00023 ;
 private String funVariable_00024 ;
 private String funVariable_00025 ;
 private String funVariable_00026 ;
 private String funVariable_00027 ;
 private String funVariable_00028 ;
 private String funVariable_00029 ;
 private String funVariable_00030 ;
 private String funVariable_00031 ;
 private String funVariable_00032 ;
 private String funVariable_00033 ;
 private String funVariable_00034 ;
 private String funVariable_00035 ;
 private String funVariable_00036 ;
 private String funVariable_00037 ;
 private String funVariable_00038 ;
 private String funVariable_00039 ;
 private String funVariable_00040 ;
 private String funVariable_00041 ;
 private String funVariable_00042 ;
 private String funVariable_00043 ;
 private String funVariable_00044 ;
 private String funVariable_00045 ;
 private String funVariable_00046 ;
 private String funVariable_00047 ;
 private String funVariable_00048 ;
 private String funVariable_00049 ;
 private String funVariable_00050 ;
 private String funVariable_00051 ;
 private String funVariable_00052 ;
 private String funVariable_00053 ;
 private String funVariable_00054 ;
 private String funVariable_00055 ;
 private String funVariable_00056 ;
 private String funVariable_00057 ;
 private String funVariable_00058 ;
 private String funVariable_00059 ;
 private String funVariable_00060 ;
 private String funVariable_00061 ;
 private String funVariable_00062 ;
 private String funVariable_00063 ;
 private String funVariable_00064 ;
 private String funVariable_00065 ;
 private String funVariable_00066 ;
 private String funVariable_00067 ;
 private String funVariable_00068 ;
 private String funVariable_00069 ;
 private String funVariable_00070 ;
 private String funVariable_00071 ;
 private String funVariable_00072 ;
 private String funVariable_00073 ;
 private String funVariable_00074 ;
 private String funVariable_00075 ;
 private String funVariable_00076 ;
 private String funVariable_00077 ;
 private String funVariable_00078 ;
 private String funVariable_00079 ;
 private String funVariable_00080 ;
 private String funVariable_00081 ;
 private String funVariable_00082 ;
 private String funVariable_00083 ;
 private String funVariable_00084 ;
 private String funVariable_00085 ;
 private String funVariable_00086 ;
 private String funVariable_00087 ;
 private String funVariable_00088 ;
 private String funVariable_00089 ;
 private String funVariable_00090 ;
 private String funVariable_00091 ;
 private String funVariable_00092 ;
 private String funVariable_00093 ;
 private String funVariable_00094 ;
 private String funVariable_00095 ;
 private String funVariable_00096 ;
 private String funVariable_00097 ;
 private String funVariable_00098 ;
 private String funVariable_00099 ;
 private String funVariable_00100 ;
 private String funVariable_00101 ;
 private String funVariable_00102 ;
 private String funVariable_00103 ;
 private String funVariable_00104 ;
 private String funVariable_00105 ;
 private String funVariable_00106 ;
 private String funVariable_00107 ;
 private String funVariable_00108 ;
 private String funVariable_00109 ;
 private String funVariable_00110 ;
 private String funVariable_00111 ;
 private String funVariable_00112 ;
 private String funVariable_00113 ;
 private String funVariable_00114 ;
 private String funVariable_00115 ;
 private String funVariable_00116 ;
 private String funVariable_00117 ;
 private String funVariable_00118 ;
 private String funVariable_00119 ;
 private String funVariable_00120 ;
 private String funVariable_00121 ;
 private String funVariable_00122 ;
 private String funVariable_00123 ;
 private String funVariable_00124 ;
 private String funVariable_00125 ;
 private String funVariable_00126 ;
 private String funVariable_00127 ;
 private String funVariable_00128 ;
 private String funVariable_00129 ;
 private String funVariable_00130 ;
 private String funVariable_00131 ;
 private String funVariable_00132 ;
 private String funVariable_00133 ;
 private String funVariable_00134 ;
 private String funVariable_00135 ;
 private String funVariable_00136 ;
 private String funVariable_00137 ;
 private String funVariable_00138 ;
 private String funVariable_00139 ;
 private String funVariable_00140 ;
 private String funVariable_00141 ;
 private String funVariable_00142 ;
 private String funVariable_00143 ;
 private String funVariable_00144 ;
 private String funVariable_00145 ;
 private String funVariable_00146 ;
 private String funVariable_00147 ;
 private String funVariable_00148 ;
 private String funVariable_00149 ;
 private String funVariable_00150 ;
 private String funVariable_00151 ;
 private String funVariable_00152 ;
 private String funVariable_00153 ;
 private String funVariable_00154 ;
 private String funVariable_00155 ;
 private String funVariable_00156 ;
 private String funVariable_00157 ;
 private String funVariable_00158 ;
 private String funVariable_00159 ;
 private String funVariable_00160 ;
 private String funVariable_00161 ;
 private String funVariable_00162 ;
 private String funVariable_00163 ;
 private String funVariable_00164 ;
 private String funVariable_00165 ;
 private String funVariable_00166 ;
 private String funVariable_00167 ;
 private String funVariable_00168 ;
 private String funVariable_00169 ;
 private String funVariable_00170 ;
 private String funVariable_00171 ;
 private String funVariable_00172 ;
 private String funVariable_00173 ;
 private String funVariable_00174 ;
 private String funVariable_00175 ;
 private String funVariable_00176 ;
 private String funVariable_00177 ;
 private String funVariable_00178 ;
 private String funVariable_00179 ;
 private String funVariable_00180 ;
 private String funVariable_00181 ;
 private String funVariable_00182 ;
 private String funVariable_00183 ;
 private String funVariable_00184 ;
 private String funVariable_00185 ;
 private String funVariable_00186 ;
 private String funVariable_00187 ;
 private String funVariable_00188 ;
 private String funVariable_00189 ;
 private String funVariable_00190 ;
 private String funVariable_00191 ;
 private String funVariable_00192 ;
 private String funVariable_00193 ;
 private String funVariable_00194 ;
 private String funVariable_00195 ;
 private String funVariable_00196 ;
 private String funVariable_00197 ;
 private String funVariable_00198 ;
 private String funVariable_00199 ;
 private String funVariable_00200 ;
 private String funVariable_00201 ;
 private String funVariable_00202 ;
 private String funVariable_00203 ;
 private String funVariable_00204 ;
 private String funVariable_00205 ;
 private String funVariable_00206 ;
 private String funVariable_00207 ;
 private String funVariable_00208 ;
 private String funVariable_00209 ;
 private String funVariable_00210 ;
 private String funVariable_00211 ;
 private String funVariable_00212 ;
 private String funVariable_00213 ;
 private String funVariable_00214 ;
 private String funVariable_00215 ;
 private String funVariable_00216 ;
 private String funVariable_00217 ;
 private String funVariable_00218 ;
 private String funVariable_00219 ;
 private String funVariable_00220 ;
 private String funVariable_00221 ;
 private String funVariable_00222 ;
 private String funVariable_00223 ;
 private String funVariable_00224 ;
 private String funVariable_00225 ;
 private String funVariable_00226 ;
 private String funVariable_00227 ;
 private String funVariable_00228 ;
 private String funVariable_00229 ;
 private String funVariable_00230 ;
 private String funVariable_00231 ;
 private String funVariable_00232 ;
 private String funVariable_00233 ;
 private String funVariable_00234 ;
 private String funVariable_00235 ;
 private String funVariable_00236 ;
 private String funVariable_00237 ;
 private String funVariable_00238 ;
 private String funVariable_00239 ;
 private String funVariable_00240 ;
 private String funVariable_00241 ;
 private String funVariable_00242 ;
 private String funVariable_00243 ;
 private String funVariable_00244 ;
 private String funVariable_00245 ;
 private String funVariable_00246 ;
 private String funVariable_00247 ;
 private String funVariable_00248 ;
 private String funVariable_00249 ;
 private String funVariable_00250 ;
 private String funVariable_00251 ;
 private String funVariable_00252 ;
 private String funVariable_00253 ;
 private String funVariable_00254 ;
 private String funVariable_00255 ;
 private String funVariable_00256 ;
 private String funVariable_00257 ;
 private String funVariable_00258 ;
 private String funVariable_00259 ;
 private String funVariable_00260 ;
 private String funVariable_00261 ;
 private String funVariable_00262 ;
 private String funVariable_00263 ;
 private String funVariable_00264 ;
 private String funVariable_00265 ;
 private String funVariable_00266 ;
 private String funVariable_00267 ;
 private String funVariable_00268 ;
 private String funVariable_00269 ;
 private String funVariable_00270 ;
 private String funVariable_00271 ;
 private String funVariable_00272 ;
 private String funVariable_00273 ;
 private String funVariable_00274 ;
 private String funVariable_00275 ;
 private String funVariable_00276 ;
 private String funVariable_00277 ;
 private String funVariable_00278 ;
 private String funVariable_00279 ;
 private String funVariable_00280 ;
 private String funVariable_00281 ;
 private String funVariable_00282 ;
 private String funVariable_00283 ;
 private String funVariable_00284 ;
 private String funVariable_00285 ;
 private String funVariable_00286 ;
 private String funVariable_00287 ;
 private String funVariable_00288 ;
 private String funVariable_00289 ;
 private String funVariable_00290 ;
 private String funVariable_00291 ;
 private String funVariable_00292 ;
 private String funVariable_00293 ;
 private String funVariable_00294 ;
 private String funVariable_00295 ;
 private String funVariable_00296 ;
 private String funVariable_00297 ;
 private String funVariable_00298 ;
 private String funVariable_00299 ;
 private String funVariable_00300 ;
 private String funVariable_00301 ;
 private String funVariable_00302 ;
 private String funVariable_00303 ;
 private String funVariable_00304 ;
 private String funVariable_00305 ;
 private String funVariable_00306 ;
 private String funVariable_00307 ;
 private String funVariable_00308 ;
 private String funVariable_00309 ;
 private String funVariable_00310 ;
 private String funVariable_00311 ;
 private String funVariable_00312 ;
 private String funVariable_00313 ;
 private String funVariable_00314 ;
 private String funVariable_00315 ;
 private String funVariable_00316 ;
 private String funVariable_00317 ;
 private String funVariable_00318 ;
 private String funVariable_00319 ;
 private String funVariable_00320 ;
 private String funVariable_00321 ;
 private String funVariable_00322 ;
 private String funVariable_00323 ;
 private String funVariable_00324 ;
 private String funVariable_00325 ;
 private String funVariable_00326 ;
 private String funVariable_00327 ;
 private String funVariable_00328 ;
 private String funVariable_00329 ;
 private String funVariable_00330 ;
 private String funVariable_00331 ;
 private String funVariable_00332 ;
 private String funVariable_00333 ;
 private String funVariable_00334 ;
 private String funVariable_00335 ;
 private String funVariable_00336 ;
 private String funVariable_00337 ;
 private String funVariable_00338 ;
 private String funVariable_00339 ;
 private String funVariable_00340 ;
 private String funVariable_00341 ;
 private String funVariable_00342 ;
 private String funVariable_00343 ;
 private String funVariable_00344 ;
 private String funVariable_00345 ;
 private String funVariable_00346 ;
 private String funVariable_00347 ;
 private String funVariable_00348 ;
 private String funVariable_00349 ;
 private String funVariable_00350 ;
 private String funVariable_00351 ;
 private String funVariable_00352 ;
 private String funVariable_00353 ;
 private String funVariable_00354 ;
 private String funVariable_00355 ;
 private String funVariable_00356 ;
 private String funVariable_00357 ;
 private String funVariable_00358 ;
 private String funVariable_00359 ;
 private String funVariable_00360 ;
 private String funVariable_00361 ;
 private String funVariable_00362 ;
 private String funVariable_00363 ;
 private String funVariable_00364 ;
 private String funVariable_00365 ;
 private String funVariable_00366 ;
 private String funVariable_00367 ;
 private String funVariable_00368 ;
 private String funVariable_00369 ;
 private String funVariable_00370 ;
 private String funVariable_00371 ;
 private String funVariable_00372 ;
 private String funVariable_00373 ;
 private String funVariable_00374 ;
 private String funVariable_00375 ;
 private String funVariable_00376 ;
 private String funVariable_00377 ;
 private String funVariable_00378 ;
 private String funVariable_00379 ;
 private String funVariable_00380 ;
 private String funVariable_00381 ;
 private String funVariable_00382 ;
 private String funVariable_00383 ;
 private String funVariable_00384 ;
 private String funVariable_00385 ;
 private String funVariable_00386 ;
 private String funVariable_00387 ;
 private String funVariable_00388 ;
 private String funVariable_00389 ;
 private String funVariable_00390 ;
 private String funVariable_00391 ;
 private String funVariable_00392 ;
 private String funVariable_00393 ;
 private String funVariable_00394 ;
 private String funVariable_00395 ;
 private String funVariable_00396 ;
 private String funVariable_00397 ;
 private String funVariable_00398 ;
 private String funVariable_00399 ;
 private String funVariable_00400 ;
 private String funVariable_00401 ;
 private String funVariable_00402 ;
 private String funVariable_00403 ;
 private String funVariable_00404 ;
 private String funVariable_00405 ;
 private String funVariable_00406 ;
 private String funVariable_00407 ;
 private String funVariable_00408 ;
 private String funVariable_00409 ;
 private String funVariable_00410 ;
 private String funVariable_00411 ;
 private String funVariable_00412 ;
 private String funVariable_00413 ;
 private String funVariable_00414 ;
 private String funVariable_00415 ;
 private String funVariable_00416 ;
 private String funVariable_00417 ;
 private String funVariable_00418 ;
 private String funVariable_00419 ;
 private String funVariable_00420 ;
 private String funVariable_00421 ;
 private String funVariable_00422 ;
 private String funVariable_00423 ;
 private String funVariable_00424 ;
 private String funVariable_00425 ;
 private String funVariable_00426 ;
 private String funVariable_00427 ;
 private String funVariable_00428 ;
 private String funVariable_00429 ;
 private String funVariable_00430 ;
 private String funVariable_00431 ;
 private String funVariable_00432 ;
 private String funVariable_00433 ;
 private String funVariable_00434 ;
 private String funVariable_00435 ;
 private String funVariable_00436 ;
 private String funVariable_00437 ;
 private String funVariable_00438 ;
 private String funVariable_00439 ;
 private String funVariable_00440 ;
 private String funVariable_00441 ;
 private String funVariable_00442 ;
 private String funVariable_00443 ;
 private String funVariable_00444 ;
 private String funVariable_00445 ;
 private String funVariable_00446 ;
 private String funVariable_00447 ;
 private String funVariable_00448 ;
 private String funVariable_00449 ;
 private String funVariable_00450 ;
 private String funVariable_00451 ;
 private String funVariable_00452 ;
 private String funVariable_00453 ;
 private String funVariable_00454 ;
 private String funVariable_00455 ;
 private String funVariable_00456 ;
 private String funVariable_00457 ;
 private String funVariable_00458 ;
 private String funVariable_00459 ;
 private String funVariable_00460 ;
 private String funVariable_00461 ;
 private String funVariable_00462 ;
 private String funVariable_00463 ;
 private String funVariable_00464 ;
 private String funVariable_00465 ;
 private String funVariable_00466 ;
 private String funVariable_00467 ;
 private String funVariable_00468 ;
 private String funVariable_00469 ;
 private String funVariable_00470 ;
 private String funVariable_00471 ;
 private String funVariable_00472 ;
 private String funVariable_00473 ;
 private String funVariable_00474 ;
 private String funVariable_00475 ;
 private String funVariable_00476 ;
 private String funVariable_00477 ;
 private String funVariable_00478 ;
 private String funVariable_00479 ;
 private String funVariable_00480 ;
 private String funVariable_00481 ;
 private String funVariable_00482 ;
 private String funVariable_00483 ;
 private String funVariable_00484 ;
 private String funVariable_00485 ;
 private String funVariable_00486 ;
 private String funVariable_00487 ;
 private String funVariable_00488 ;
 private String funVariable_00489 ;
 private String funVariable_00490 ;
 private String funVariable_00491 ;
 private String funVariable_00492 ;
 private String funVariable_00493 ;
 private String funVariable_00494 ;
 private String funVariable_00495 ;
 private String funVariable_00496 ;
 private String funVariable_00497 ;
 private String funVariable_00498 ;
 private String funVariable_00499 ;
 private String funVariable_00500 ;
 private String funVariable_00501;
 private String funVariable_00502;
 private String funVariable_00503;
 private String funVariable_00504;
 private String funVariable_00505;
 private String funVariable_00506;
 private String funVariable_00507;
 private String funVariable_00508;
 private String funVariable_00509;
 private String funVariable_00510;
 private String funVariable_00511;
 private String funVariable_00512;
 private String funVariable_00513;
 private String funVariable_00514;
 private String funVariable_00515;
 private String funVariable_00516;
 private String funVariable_00517;
 private String funVariable_00518;
 private String funVariable_00519;
 private String funVariable_00520;
 private String funVariable_00521;
 private String funVariable_00522;
 private String funVariable_00523;
 private String funVariable_00524;
 private String funVariable_00525;
 private String funVariable_00526;
 private String funVariable_00527;
 private String funVariable_00528;
 private String funVariable_00529;
 private String funVariable_00530;
 private String funVariable_00531;
 private String funVariable_00532;
 private String funVariable_00533;
 private String funVariable_00534;
 private String funVariable_00535;
 private String funVariable_00536;
 private String funVariable_00537;
 private String funVariable_00538;
 private String funVariable_00539;
 private String funVariable_00540;
 private String funVariable_00541;
 private String funVariable_00542;
 private String funVariable_00543;
 private String funVariable_00544;
 private String funVariable_00545;
 private String funVariable_00546;
 private String funVariable_00547;
 private String funVariable_00548;
 private String funVariable_00549;
 private String funVariable_00550;
 private String funVariable_00551;
 private String funVariable_00552;
 private String funVariable_00553;
 private String funVariable_00554;
 private String funVariable_00555;
 private String funVariable_00556;
 private String funVariable_00557;
 private String funVariable_00558;
 private String funVariable_00559;
 private String funVariable_00560;
 private String funVariable_00561;
 private String funVariable_00562;
 private String funVariable_00563;
 private String funVariable_00564;
 private String funVariable_00565;
 private String funVariable_00566;
 private String funVariable_00567;
 private String funVariable_00568;
 private String funVariable_00569;
 private String funVariable_00570;
 private String funVariable_00571;
 private String funVariable_00572;
 private String funVariable_00573;
 private String funVariable_00574;
 private String funVariable_00575;
 private String funVariable_00576;
 private String funVariable_00577;
 private String funVariable_00578;
 private String funVariable_00579;
 private String funVariable_00580;
 private String funVariable_00581;
 private String funVariable_00582;
 private String funVariable_00583;
 private String funVariable_00584;
 private String funVariable_00585;
 private String funVariable_00586;
 private String funVariable_00587;
 private String funVariable_00588;
 private String funVariable_00589;
 private String funVariable_00590;
 private String funVariable_00591;
 private String funVariable_00592;
 private String funVariable_00593;
 private String funVariable_00594;
 private String funVariable_00595;
 private String funVariable_00596;
 private String funVariable_00597;
 private String funVariable_00598;
 private String funVariable_00599;
 private String funVariable_00600;
 private String funVariable_00601;
 private String funVariable_00602;
 private String funVariable_00603;
 private String funVariable_00604;
 private String funVariable_00605;
 private String funVariable_00606;
 private String funVariable_00607;
 private String funVariable_00608;
 private String funVariable_00609;
 private String funVariable_00610;
 private String funVariable_00611;
 private String funVariable_00612;
 private String funVariable_00613;
 private String funVariable_00614;
 private String funVariable_00615;
 private String funVariable_00616;
 private String funVariable_00617;
 private String funVariable_00618;
 private String funVariable_00619;
 private String funVariable_00620;
 private String funVariable_00621;
 private String funVariable_00622;
 private String funVariable_00623;
 private String funVariable_00624;
 private String funVariable_00625;
 private String funVariable_00626;
 private String funVariable_00627;
 private String funVariable_00628;
 private String funVariable_00629;
 private String funVariable_00630;
 private String funVariable_00631;
 private String funVariable_00632;
 private String funVariable_00633;
 private String funVariable_00634;
 private String funVariable_00635;
 private String funVariable_00636;
 private String funVariable_00637;
 private String funVariable_00638;
 private String funVariable_00639;
 private String funVariable_00640;
 private String funVariable_00641;
 private String funVariable_00642;
 private String funVariable_00643;
 private String funVariable_00644;
 private String funVariable_00645;
 private String funVariable_00646;
 private String funVariable_00647;
 private String funVariable_00648;
 private String funVariable_00649;
 private String funVariable_00650;
 private String funVariable_00651;
 private String funVariable_00652;
 private String funVariable_00653;
 private String funVariable_00654;
 private String funVariable_00655;
 private String funVariable_00656;
 private String funVariable_00657;
 private String funVariable_00658;
 private String funVariable_00659;
 private String funVariable_00660;
 private String funVariable_00661;
 private String funVariable_00662;
 private String funVariable_00663;
 private String funVariable_00664;
 private String funVariable_00665;
 private String funVariable_00666;
 private String funVariable_00667;
 private String funVariable_00668;
 private String funVariable_00669;
 private String funVariable_00670;
 private String funVariable_00671;
 private String funVariable_00672;
 private String funVariable_00673;
 private String funVariable_00674;
 private String funVariable_00675;
 private String funVariable_00676;
 private String funVariable_00677;
 private String funVariable_00678;
 private String funVariable_00679;
 private String funVariable_00680;
 private String funVariable_00681;
 private String funVariable_00682;
 private String funVariable_00683;
 private String funVariable_00684;
 private String funVariable_00685;
 private String funVariable_00686;
 private String funVariable_00687;
 private String funVariable_00688;
 private String funVariable_00689;
 private String funVariable_00690;
 private String funVariable_00691;
 private String funVariable_00692;
 private String funVariable_00693;
 private String funVariable_00694;
 private String funVariable_00695;
 private String funVariable_00696;
 private String funVariable_00697;
 private String funVariable_00698;
 private String funVariable_00699;
 private String funVariable_00700;
 private String funVariable_00701;
 private String funVariable_00702;
 private String funVariable_00703;
 private String funVariable_00704;
 private String funVariable_00705;
 private String funVariable_00706;
 private String funVariable_00707;
 private String funVariable_00708;
 private String funVariable_00709;
 private String funVariable_00710;
 private String funVariable_00711;
 private String funVariable_00712;
 private String funVariable_00713;
 private String funVariable_00714;
 private String funVariable_00715;
 private String funVariable_00716;
 private String funVariable_00717;
 private String funVariable_00718;
 private String funVariable_00719;
 private String funVariable_00720;
 private String funVariable_00721;
 private String funVariable_00722;
 private String funVariable_00723;
 private String funVariable_00724;
 private String funVariable_00725;
 private String funVariable_00726;
 private String funVariable_00727;
 private String funVariable_00728;
 private String funVariable_00729;
 private String funVariable_00730;
 private String funVariable_00731;
 private String funVariable_00732;
 private String funVariable_00733;
 private String funVariable_00734;
 private String funVariable_00735;
 private String funVariable_00736;
 private String funVariable_00737;
 private String funVariable_00738;
 private String funVariable_00739;
 private String funVariable_00740;
 private String funVariable_00741;
 private String funVariable_00742;
 private String funVariable_00743;
 private String funVariable_00744;
 private String funVariable_00745;
 private String funVariable_00746;
 private String funVariable_00747;
 private String funVariable_00748;
 private String funVariable_00749;
 private String funVariable_00750;
 private String funVariable_00751;
 private String funVariable_00752;
 private String funVariable_00753;
 private String funVariable_00754;
 private String funVariable_00755;
 private String funVariable_00756;
 private String funVariable_00757;
 private String funVariable_00758;
 private String funVariable_00759;
 private String funVariable_00760;
 private String funVariable_00761;
 private String funVariable_00762;
 private String funVariable_00763;
 private String funVariable_00764;
 private String funVariable_00765;
 private String funVariable_00766;
 private String funVariable_00767;
 private String funVariable_00768;
 private String funVariable_00769;
 private String funVariable_00770;
 private String funVariable_00771;
 private String funVariable_00772;
 private String funVariable_00773;
 private String funVariable_00774;
 private String funVariable_00775;
 private String funVariable_00776;
 private String funVariable_00777;
 private String funVariable_00778;
 private String funVariable_00779;
 private String funVariable_00780;
 private String funVariable_00781;
 private String funVariable_00782;
 private String funVariable_00783;
 private String funVariable_00784;
 private String funVariable_00785;
 private String funVariable_00786;
 private String funVariable_00787;
 private String funVariable_00788;
 private String funVariable_00789;
 private String funVariable_00790;
 private String funVariable_00791;
 private String funVariable_00792;
 private String funVariable_00793;
 private String funVariable_00794;
 private String funVariable_00795;
 private String funVariable_00796;
 private String funVariable_00797;
 private String funVariable_00798;
 private String funVariable_00799;
 private String funVariable_00800;
 private String funVariable_00801;
 private String funVariable_00802;
 private String funVariable_00803;
 private String funVariable_00804;
 private String funVariable_00805;
 private String funVariable_00806;
 private String funVariable_00807;
 private String funVariable_00808;
 private String funVariable_00809;
 private String funVariable_00810;
 private String funVariable_00811;
 private String funVariable_00812;
 private String funVariable_00813;
 private String funVariable_00814;
 private String funVariable_00815;
 private String funVariable_00816;
 private String funVariable_00817;
 private String funVariable_00818;
 private String funVariable_00819;
 private String funVariable_00820;
 private String funVariable_00821;
 private String funVariable_00822;
 private String funVariable_00823;
 private String funVariable_00824;
 private String funVariable_00825;
 private String funVariable_00826;
 private String funVariable_00827;
 private String funVariable_00828;
 private String funVariable_00829;
 private String funVariable_00830;
 private String funVariable_00831;
 private String funVariable_00832;
 private String funVariable_00833;
 private String funVariable_00834;
 private String funVariable_00835;
 private String funVariable_00836;
 private String funVariable_00837;
 private String funVariable_00838;
 private String funVariable_00839;
 private String funVariable_00840;
 private String funVariable_00841;
 private String funVariable_00842;
 private String funVariable_00843;
 private String funVariable_00844;
 private String funVariable_00845;
 private String funVariable_00846;
 private String funVariable_00847;
 private String funVariable_00848;
 private String funVariable_00849;
 private String funVariable_00850;
 private String funVariable_00851;
 private String funVariable_00852;
 private String funVariable_00853;
 private String funVariable_00854;
 private String funVariable_00855;
 private String funVariable_00856;
 private String funVariable_00857;
 private String funVariable_00858;
 private String funVariable_00859;
 private String funVariable_00860;
 private String funVariable_00861;
 private String funVariable_00862;
 private String funVariable_00863;
 private String funVariable_00864;
 private String funVariable_00865;
 private String funVariable_00866;
 private String funVariable_00867;
 private String funVariable_00868;
 private String funVariable_00869;
 private String funVariable_00870;
 private String funVariable_00871;
 private String funVariable_00872;
 private String funVariable_00873;
 
/**
 * 
 * 
 * @return the funVariable_00601
 */
public String getFunVariable_00601(){
    return funVariable_00601;
}


/**
 * 
 * 
 * @param funVariable_00601 the funVariable_00601 to set
 */
public void setFunVariable_00601(String funVariable_00601){
    this.funVariable_00601 = funVariable_00601;
}


/**
 * 
 * 
 * @return the funVariable_00602
 */
public String getFunVariable_00602(){
    return funVariable_00602;
}


/**
 * 
 * 
 * @param funVariable_00602 the funVariable_00602 to set
 */
public void setFunVariable_00602(String funVariable_00602){
    this.funVariable_00602 = funVariable_00602;
}


/**
 * 
 * 
 * @return the funVariable_00603
 */
public String getFunVariable_00603(){
    return funVariable_00603;
}


/**
 * 
 * 
 * @param funVariable_00603 the funVariable_00603 to set
 */
public void setFunVariable_00603(String funVariable_00603){
    this.funVariable_00603 = funVariable_00603;
}


/**
 * 
 * 
 * @return the funVariable_00604
 */
public String getFunVariable_00604(){
    return funVariable_00604;
}


/**
 * 
 * 
 * @param funVariable_00604 the funVariable_00604 to set
 */
public void setFunVariable_00604(String funVariable_00604){
    this.funVariable_00604 = funVariable_00604;
}


/**
 * 
 * 
 * @return the funVariable_00605
 */
public String getFunVariable_00605(){
    return funVariable_00605;
}


/**
 * 
 * 
 * @param funVariable_00605 the funVariable_00605 to set
 */
public void setFunVariable_00605(String funVariable_00605){
    this.funVariable_00605 = funVariable_00605;
}


/**
 * 
 * 
 * @return the funVariable_00606
 */
public String getFunVariable_00606(){
    return funVariable_00606;
}


/**
 * 
 * 
 * @param funVariable_00606 the funVariable_00606 to set
 */
public void setFunVariable_00606(String funVariable_00606){
    this.funVariable_00606 = funVariable_00606;
}


/**
 * 
 * 
 * @return the funVariable_00607
 */
public String getFunVariable_00607(){
    return funVariable_00607;
}


/**
 * 
 * 
 * @param funVariable_00607 the funVariable_00607 to set
 */
public void setFunVariable_00607(String funVariable_00607){
    this.funVariable_00607 = funVariable_00607;
}


/**
 * 
 * 
 * @return the funVariable_00608
 */
public String getFunVariable_00608(){
    return funVariable_00608;
}


/**
 * 
 * 
 * @param funVariable_00608 the funVariable_00608 to set
 */
public void setFunVariable_00608(String funVariable_00608){
    this.funVariable_00608 = funVariable_00608;
}


/**
 * 
 * 
 * @return the funVariable_00609
 */
public String getFunVariable_00609(){
    return funVariable_00609;
}


/**
 * 
 * 
 * @param funVariable_00609 the funVariable_00609 to set
 */
public void setFunVariable_00609(String funVariable_00609){
    this.funVariable_00609 = funVariable_00609;
}


/**
 * 
 * 
 * @return the funVariable_00610
 */
public String getFunVariable_00610(){
    return funVariable_00610;
}


/**
 * 
 * 
 * @param funVariable_00610 the funVariable_00610 to set
 */
public void setFunVariable_00610(String funVariable_00610){
    this.funVariable_00610 = funVariable_00610;
}


/**
 * 
 * 
 * @return the funVariable_00611
 */
public String getFunVariable_00611(){
    return funVariable_00611;
}


/**
 * 
 * 
 * @param funVariable_00611 the funVariable_00611 to set
 */
public void setFunVariable_00611(String funVariable_00611){
    this.funVariable_00611 = funVariable_00611;
}


/**
 * 
 * 
 * @return the funVariable_00612
 */
public String getFunVariable_00612(){
    return funVariable_00612;
}


/**
 * 
 * 
 * @param funVariable_00612 the funVariable_00612 to set
 */
public void setFunVariable_00612(String funVariable_00612){
    this.funVariable_00612 = funVariable_00612;
}


/**
 * 
 * 
 * @return the funVariable_00613
 */
public String getFunVariable_00613(){
    return funVariable_00613;
}


/**
 * 
 * 
 * @param funVariable_00613 the funVariable_00613 to set
 */
public void setFunVariable_00613(String funVariable_00613){
    this.funVariable_00613 = funVariable_00613;
}


/**
 * 
 * 
 * @return the funVariable_00614
 */
public String getFunVariable_00614(){
    return funVariable_00614;
}


/**
 * 
 * 
 * @param funVariable_00614 the funVariable_00614 to set
 */
public void setFunVariable_00614(String funVariable_00614){
    this.funVariable_00614 = funVariable_00614;
}


/**
 * 
 * 
 * @return the funVariable_00615
 */
public String getFunVariable_00615(){
    return funVariable_00615;
}


/**
 * 
 * 
 * @param funVariable_00615 the funVariable_00615 to set
 */
public void setFunVariable_00615(String funVariable_00615){
    this.funVariable_00615 = funVariable_00615;
}


/**
 * 
 * 
 * @return the funVariable_00616
 */
public String getFunVariable_00616(){
    return funVariable_00616;
}


/**
 * 
 * 
 * @param funVariable_00616 the funVariable_00616 to set
 */
public void setFunVariable_00616(String funVariable_00616){
    this.funVariable_00616 = funVariable_00616;
}


/**
 * 
 * 
 * @return the funVariable_00617
 */
public String getFunVariable_00617(){
    return funVariable_00617;
}


/**
 * 
 * 
 * @param funVariable_00617 the funVariable_00617 to set
 */
public void setFunVariable_00617(String funVariable_00617){
    this.funVariable_00617 = funVariable_00617;
}


/**
 * 
 * 
 * @return the funVariable_00618
 */
public String getFunVariable_00618(){
    return funVariable_00618;
}


/**
 * 
 * 
 * @param funVariable_00618 the funVariable_00618 to set
 */
public void setFunVariable_00618(String funVariable_00618){
    this.funVariable_00618 = funVariable_00618;
}


/**
 * 
 * 
 * @return the funVariable_00619
 */
public String getFunVariable_00619(){
    return funVariable_00619;
}


/**
 * 
 * 
 * @param funVariable_00619 the funVariable_00619 to set
 */
public void setFunVariable_00619(String funVariable_00619){
    this.funVariable_00619 = funVariable_00619;
}


/**
 * 
 * 
 * @return the funVariable_00620
 */
public String getFunVariable_00620(){
    return funVariable_00620;
}


/**
 * 
 * 
 * @param funVariable_00620 the funVariable_00620 to set
 */
public void setFunVariable_00620(String funVariable_00620){
    this.funVariable_00620 = funVariable_00620;
}


/**
 * 
 * 
 * @return the funVariable_00621
 */
public String getFunVariable_00621(){
    return funVariable_00621;
}


/**
 * 
 * 
 * @param funVariable_00621 the funVariable_00621 to set
 */
public void setFunVariable_00621(String funVariable_00621){
    this.funVariable_00621 = funVariable_00621;
}


/**
 * 
 * 
 * @return the funVariable_00622
 */
public String getFunVariable_00622(){
    return funVariable_00622;
}


/**
 * 
 * 
 * @param funVariable_00622 the funVariable_00622 to set
 */
public void setFunVariable_00622(String funVariable_00622){
    this.funVariable_00622 = funVariable_00622;
}


/**
 * 
 * 
 * @return the funVariable_00623
 */
public String getFunVariable_00623(){
    return funVariable_00623;
}


/**
 * 
 * 
 * @param funVariable_00623 the funVariable_00623 to set
 */
public void setFunVariable_00623(String funVariable_00623){
    this.funVariable_00623 = funVariable_00623;
}


/**
 * 
 * 
 * @return the funVariable_00624
 */
public String getFunVariable_00624(){
    return funVariable_00624;
}


/**
 * 
 * 
 * @param funVariable_00624 the funVariable_00624 to set
 */
public void setFunVariable_00624(String funVariable_00624){
    this.funVariable_00624 = funVariable_00624;
}


/**
 * 
 * 
 * @return the funVariable_00625
 */
public String getFunVariable_00625(){
    return funVariable_00625;
}


/**
 * 
 * 
 * @param funVariable_00625 the funVariable_00625 to set
 */
public void setFunVariable_00625(String funVariable_00625){
    this.funVariable_00625 = funVariable_00625;
}


/**
 * 
 * 
 * @return the funVariable_00626
 */
public String getFunVariable_00626(){
    return funVariable_00626;
}


/**
 * 
 * 
 * @param funVariable_00626 the funVariable_00626 to set
 */
public void setFunVariable_00626(String funVariable_00626){
    this.funVariable_00626 = funVariable_00626;
}


/**
 * 
 * 
 * @return the funVariable_00627
 */
public String getFunVariable_00627(){
    return funVariable_00627;
}


/**
 * 
 * 
 * @param funVariable_00627 the funVariable_00627 to set
 */
public void setFunVariable_00627(String funVariable_00627){
    this.funVariable_00627 = funVariable_00627;
}


/**
 * 
 * 
 * @return the funVariable_00628
 */
public String getFunVariable_00628(){
    return funVariable_00628;
}


/**
 * 
 * 
 * @param funVariable_00628 the funVariable_00628 to set
 */
public void setFunVariable_00628(String funVariable_00628){
    this.funVariable_00628 = funVariable_00628;
}


/**
 * 
 * 
 * @return the funVariable_00629
 */
public String getFunVariable_00629(){
    return funVariable_00629;
}


/**
 * 
 * 
 * @param funVariable_00629 the funVariable_00629 to set
 */
public void setFunVariable_00629(String funVariable_00629){
    this.funVariable_00629 = funVariable_00629;
}


/**
 * 
 * 
 * @return the funVariable_00630
 */
public String getFunVariable_00630(){
    return funVariable_00630;
}


/**
 * 
 * 
 * @param funVariable_00630 the funVariable_00630 to set
 */
public void setFunVariable_00630(String funVariable_00630){
    this.funVariable_00630 = funVariable_00630;
}


/**
 * 
 * 
 * @return the funVariable_00631
 */
public String getFunVariable_00631(){
    return funVariable_00631;
}


/**
 * 
 * 
 * @param funVariable_00631 the funVariable_00631 to set
 */
public void setFunVariable_00631(String funVariable_00631){
    this.funVariable_00631 = funVariable_00631;
}


/**
 * 
 * 
 * @return the funVariable_00632
 */
public String getFunVariable_00632(){
    return funVariable_00632;
}


/**
 * 
 * 
 * @param funVariable_00632 the funVariable_00632 to set
 */
public void setFunVariable_00632(String funVariable_00632){
    this.funVariable_00632 = funVariable_00632;
}


/**
 * 
 * 
 * @return the funVariable_00633
 */
public String getFunVariable_00633(){
    return funVariable_00633;
}


/**
 * 
 * 
 * @param funVariable_00633 the funVariable_00633 to set
 */
public void setFunVariable_00633(String funVariable_00633){
    this.funVariable_00633 = funVariable_00633;
}


/**
 * 
 * 
 * @return the funVariable_00634
 */
public String getFunVariable_00634(){
    return funVariable_00634;
}


/**
 * 
 * 
 * @param funVariable_00634 the funVariable_00634 to set
 */
public void setFunVariable_00634(String funVariable_00634){
    this.funVariable_00634 = funVariable_00634;
}


/**
 * 
 * 
 * @return the funVariable_00635
 */
public String getFunVariable_00635(){
    return funVariable_00635;
}


/**
 * 
 * 
 * @param funVariable_00635 the funVariable_00635 to set
 */
public void setFunVariable_00635(String funVariable_00635){
    this.funVariable_00635 = funVariable_00635;
}


/**
 * 
 * 
 * @return the funVariable_00636
 */
public String getFunVariable_00636(){
    return funVariable_00636;
}


/**
 * 
 * 
 * @param funVariable_00636 the funVariable_00636 to set
 */
public void setFunVariable_00636(String funVariable_00636){
    this.funVariable_00636 = funVariable_00636;
}


/**
 * 
 * 
 * @return the funVariable_00637
 */
public String getFunVariable_00637(){
    return funVariable_00637;
}


/**
 * 
 * 
 * @param funVariable_00637 the funVariable_00637 to set
 */
public void setFunVariable_00637(String funVariable_00637){
    this.funVariable_00637 = funVariable_00637;
}


/**
 * 
 * 
 * @return the funVariable_00638
 */
public String getFunVariable_00638(){
    return funVariable_00638;
}


/**
 * 
 * 
 * @param funVariable_00638 the funVariable_00638 to set
 */
public void setFunVariable_00638(String funVariable_00638){
    this.funVariable_00638 = funVariable_00638;
}


/**
 * 
 * 
 * @return the funVariable_00639
 */
public String getFunVariable_00639(){
    return funVariable_00639;
}


/**
 * 
 * 
 * @param funVariable_00639 the funVariable_00639 to set
 */
public void setFunVariable_00639(String funVariable_00639){
    this.funVariable_00639 = funVariable_00639;
}


/**
 * 
 * 
 * @return the funVariable_00640
 */
public String getFunVariable_00640(){
    return funVariable_00640;
}


/**
 * 
 * 
 * @param funVariable_00640 the funVariable_00640 to set
 */
public void setFunVariable_00640(String funVariable_00640){
    this.funVariable_00640 = funVariable_00640;
}


/**
 * 
 * 
 * @return the funVariable_00641
 */
public String getFunVariable_00641(){
    return funVariable_00641;
}


/**
 * 
 * 
 * @param funVariable_00641 the funVariable_00641 to set
 */
public void setFunVariable_00641(String funVariable_00641){
    this.funVariable_00641 = funVariable_00641;
}


/**
 * 
 * 
 * @return the funVariable_00642
 */
public String getFunVariable_00642(){
    return funVariable_00642;
}


/**
 * 
 * 
 * @param funVariable_00642 the funVariable_00642 to set
 */
public void setFunVariable_00642(String funVariable_00642){
    this.funVariable_00642 = funVariable_00642;
}


/**
 * 
 * 
 * @return the funVariable_00643
 */
public String getFunVariable_00643(){
    return funVariable_00643;
}


/**
 * 
 * 
 * @param funVariable_00643 the funVariable_00643 to set
 */
public void setFunVariable_00643(String funVariable_00643){
    this.funVariable_00643 = funVariable_00643;
}


/**
 * 
 * 
 * @return the funVariable_00644
 */
public String getFunVariable_00644(){
    return funVariable_00644;
}


/**
 * 
 * 
 * @param funVariable_00644 the funVariable_00644 to set
 */
public void setFunVariable_00644(String funVariable_00644){
    this.funVariable_00644 = funVariable_00644;
}


/**
 * 
 * 
 * @return the funVariable_00645
 */
public String getFunVariable_00645(){
    return funVariable_00645;
}


/**
 * 
 * 
 * @param funVariable_00645 the funVariable_00645 to set
 */
public void setFunVariable_00645(String funVariable_00645){
    this.funVariable_00645 = funVariable_00645;
}


/**
 * 
 * 
 * @return the funVariable_00646
 */
public String getFunVariable_00646(){
    return funVariable_00646;
}


/**
 * 
 * 
 * @param funVariable_00646 the funVariable_00646 to set
 */
public void setFunVariable_00646(String funVariable_00646){
    this.funVariable_00646 = funVariable_00646;
}


/**
 * 
 * 
 * @return the funVariable_00647
 */
public String getFunVariable_00647(){
    return funVariable_00647;
}


/**
 * 
 * 
 * @param funVariable_00647 the funVariable_00647 to set
 */
public void setFunVariable_00647(String funVariable_00647){
    this.funVariable_00647 = funVariable_00647;
}


/**
 * 
 * 
 * @return the funVariable_00648
 */
public String getFunVariable_00648(){
    return funVariable_00648;
}


/**
 * 
 * 
 * @param funVariable_00648 the funVariable_00648 to set
 */
public void setFunVariable_00648(String funVariable_00648){
    this.funVariable_00648 = funVariable_00648;
}


/**
 * 
 * 
 * @return the funVariable_00649
 */
public String getFunVariable_00649(){
    return funVariable_00649;
}


/**
 * 
 * 
 * @param funVariable_00649 the funVariable_00649 to set
 */
public void setFunVariable_00649(String funVariable_00649){
    this.funVariable_00649 = funVariable_00649;
}


/**
 * 
 * 
 * @return the funVariable_00650
 */
public String getFunVariable_00650(){
    return funVariable_00650;
}


/**
 * 
 * 
 * @param funVariable_00650 the funVariable_00650 to set
 */
public void setFunVariable_00650(String funVariable_00650){
    this.funVariable_00650 = funVariable_00650;
}


/**
 * 
 * 
 * @return the funVariable_00651
 */
public String getFunVariable_00651(){
    return funVariable_00651;
}


/**
 * 
 * 
 * @param funVariable_00651 the funVariable_00651 to set
 */
public void setFunVariable_00651(String funVariable_00651){
    this.funVariable_00651 = funVariable_00651;
}


/**
 * 
 * 
 * @return the funVariable_00652
 */
public String getFunVariable_00652(){
    return funVariable_00652;
}


/**
 * 
 * 
 * @param funVariable_00652 the funVariable_00652 to set
 */
public void setFunVariable_00652(String funVariable_00652){
    this.funVariable_00652 = funVariable_00652;
}


/**
 * 
 * 
 * @return the funVariable_00653
 */
public String getFunVariable_00653(){
    return funVariable_00653;
}


/**
 * 
 * 
 * @param funVariable_00653 the funVariable_00653 to set
 */
public void setFunVariable_00653(String funVariable_00653){
    this.funVariable_00653 = funVariable_00653;
}


/**
 * 
 * 
 * @return the funVariable_00654
 */
public String getFunVariable_00654(){
    return funVariable_00654;
}


/**
 * 
 * 
 * @param funVariable_00654 the funVariable_00654 to set
 */
public void setFunVariable_00654(String funVariable_00654){
    this.funVariable_00654 = funVariable_00654;
}


/**
 * 
 * 
 * @return the funVariable_00655
 */
public String getFunVariable_00655(){
    return funVariable_00655;
}


/**
 * 
 * 
 * @param funVariable_00655 the funVariable_00655 to set
 */
public void setFunVariable_00655(String funVariable_00655){
    this.funVariable_00655 = funVariable_00655;
}


/**
 * 
 * 
 * @return the funVariable_00656
 */
public String getFunVariable_00656(){
    return funVariable_00656;
}


/**
 * 
 * 
 * @param funVariable_00656 the funVariable_00656 to set
 */
public void setFunVariable_00656(String funVariable_00656){
    this.funVariable_00656 = funVariable_00656;
}


/**
 * 
 * 
 * @return the funVariable_00657
 */
public String getFunVariable_00657(){
    return funVariable_00657;
}


/**
 * 
 * 
 * @param funVariable_00657 the funVariable_00657 to set
 */
public void setFunVariable_00657(String funVariable_00657){
    this.funVariable_00657 = funVariable_00657;
}


/**
 * 
 * 
 * @return the funVariable_00658
 */
public String getFunVariable_00658(){
    return funVariable_00658;
}


/**
 * 
 * 
 * @param funVariable_00658 the funVariable_00658 to set
 */
public void setFunVariable_00658(String funVariable_00658){
    this.funVariable_00658 = funVariable_00658;
}


/**
 * 
 * 
 * @return the funVariable_00659
 */
public String getFunVariable_00659(){
    return funVariable_00659;
}


/**
 * 
 * 
 * @param funVariable_00659 the funVariable_00659 to set
 */
public void setFunVariable_00659(String funVariable_00659){
    this.funVariable_00659 = funVariable_00659;
}


/**
 * 
 * 
 * @return the funVariable_00660
 */
public String getFunVariable_00660(){
    return funVariable_00660;
}


/**
 * 
 * 
 * @param funVariable_00660 the funVariable_00660 to set
 */
public void setFunVariable_00660(String funVariable_00660){
    this.funVariable_00660 = funVariable_00660;
}


/**
 * 
 * 
 * @return the funVariable_00661
 */
public String getFunVariable_00661(){
    return funVariable_00661;
}


/**
 * 
 * 
 * @param funVariable_00661 the funVariable_00661 to set
 */
public void setFunVariable_00661(String funVariable_00661){
    this.funVariable_00661 = funVariable_00661;
}


/**
 * 
 * 
 * @return the funVariable_00662
 */
public String getFunVariable_00662(){
    return funVariable_00662;
}


/**
 * 
 * 
 * @param funVariable_00662 the funVariable_00662 to set
 */
public void setFunVariable_00662(String funVariable_00662){
    this.funVariable_00662 = funVariable_00662;
}


/**
 * 
 * 
 * @return the funVariable_00663
 */
public String getFunVariable_00663(){
    return funVariable_00663;
}


/**
 * 
 * 
 * @param funVariable_00663 the funVariable_00663 to set
 */
public void setFunVariable_00663(String funVariable_00663){
    this.funVariable_00663 = funVariable_00663;
}


/**
 * 
 * 
 * @return the funVariable_00664
 */
public String getFunVariable_00664(){
    return funVariable_00664;
}


/**
 * 
 * 
 * @param funVariable_00664 the funVariable_00664 to set
 */
public void setFunVariable_00664(String funVariable_00664){
    this.funVariable_00664 = funVariable_00664;
}


/**
 * 
 * 
 * @return the funVariable_00665
 */
public String getFunVariable_00665(){
    return funVariable_00665;
}


/**
 * 
 * 
 * @param funVariable_00665 the funVariable_00665 to set
 */
public void setFunVariable_00665(String funVariable_00665){
    this.funVariable_00665 = funVariable_00665;
}


/**
 * 
 * 
 * @return the funVariable_00666
 */
public String getFunVariable_00666(){
    return funVariable_00666;
}


/**
 * 
 * 
 * @param funVariable_00666 the funVariable_00666 to set
 */
public void setFunVariable_00666(String funVariable_00666){
    this.funVariable_00666 = funVariable_00666;
}


/**
 * 
 * 
 * @return the funVariable_00667
 */
public String getFunVariable_00667(){
    return funVariable_00667;
}


/**
 * 
 * 
 * @param funVariable_00667 the funVariable_00667 to set
 */
public void setFunVariable_00667(String funVariable_00667){
    this.funVariable_00667 = funVariable_00667;
}


/**
 * 
 * 
 * @return the funVariable_00668
 */
public String getFunVariable_00668(){
    return funVariable_00668;
}


/**
 * 
 * 
 * @param funVariable_00668 the funVariable_00668 to set
 */
public void setFunVariable_00668(String funVariable_00668){
    this.funVariable_00668 = funVariable_00668;
}


/**
 * 
 * 
 * @return the funVariable_00669
 */
public String getFunVariable_00669(){
    return funVariable_00669;
}


/**
 * 
 * 
 * @param funVariable_00669 the funVariable_00669 to set
 */
public void setFunVariable_00669(String funVariable_00669){
    this.funVariable_00669 = funVariable_00669;
}


/**
 * 
 * 
 * @return the funVariable_00670
 */
public String getFunVariable_00670(){
    return funVariable_00670;
}


/**
 * 
 * 
 * @param funVariable_00670 the funVariable_00670 to set
 */
public void setFunVariable_00670(String funVariable_00670){
    this.funVariable_00670 = funVariable_00670;
}


/**
 * 
 * 
 * @return the funVariable_00671
 */
public String getFunVariable_00671(){
    return funVariable_00671;
}


/**
 * 
 * 
 * @param funVariable_00671 the funVariable_00671 to set
 */
public void setFunVariable_00671(String funVariable_00671){
    this.funVariable_00671 = funVariable_00671;
}


/**
 * 
 * 
 * @return the funVariable_00672
 */
public String getFunVariable_00672(){
    return funVariable_00672;
}


/**
 * 
 * 
 * @param funVariable_00672 the funVariable_00672 to set
 */
public void setFunVariable_00672(String funVariable_00672){
    this.funVariable_00672 = funVariable_00672;
}


/**
 * 
 * 
 * @return the funVariable_00673
 */
public String getFunVariable_00673(){
    return funVariable_00673;
}


/**
 * 
 * 
 * @param funVariable_00673 the funVariable_00673 to set
 */
public void setFunVariable_00673(String funVariable_00673){
    this.funVariable_00673 = funVariable_00673;
}


/**
 * 
 * 
 * @return the funVariable_00674
 */
public String getFunVariable_00674(){
    return funVariable_00674;
}


/**
 * 
 * 
 * @param funVariable_00674 the funVariable_00674 to set
 */
public void setFunVariable_00674(String funVariable_00674){
    this.funVariable_00674 = funVariable_00674;
}


/**
 * 
 * 
 * @return the funVariable_00675
 */
public String getFunVariable_00675(){
    return funVariable_00675;
}


/**
 * 
 * 
 * @param funVariable_00675 the funVariable_00675 to set
 */
public void setFunVariable_00675(String funVariable_00675){
    this.funVariable_00675 = funVariable_00675;
}


/**
 * 
 * 
 * @return the funVariable_00676
 */
public String getFunVariable_00676(){
    return funVariable_00676;
}


/**
 * 
 * 
 * @param funVariable_00676 the funVariable_00676 to set
 */
public void setFunVariable_00676(String funVariable_00676){
    this.funVariable_00676 = funVariable_00676;
}


/**
 * 
 * 
 * @return the funVariable_00677
 */
public String getFunVariable_00677(){
    return funVariable_00677;
}


/**
 * 
 * 
 * @param funVariable_00677 the funVariable_00677 to set
 */
public void setFunVariable_00677(String funVariable_00677){
    this.funVariable_00677 = funVariable_00677;
}


/**
 * 
 * 
 * @return the funVariable_00678
 */
public String getFunVariable_00678(){
    return funVariable_00678;
}


/**
 * 
 * 
 * @param funVariable_00678 the funVariable_00678 to set
 */
public void setFunVariable_00678(String funVariable_00678){
    this.funVariable_00678 = funVariable_00678;
}


/**
 * 
 * 
 * @return the funVariable_00679
 */
public String getFunVariable_00679(){
    return funVariable_00679;
}


/**
 * 
 * 
 * @param funVariable_00679 the funVariable_00679 to set
 */
public void setFunVariable_00679(String funVariable_00679){
    this.funVariable_00679 = funVariable_00679;
}


/**
 * 
 * 
 * @return the funVariable_00680
 */
public String getFunVariable_00680(){
    return funVariable_00680;
}


/**
 * 
 * 
 * @param funVariable_00680 the funVariable_00680 to set
 */
public void setFunVariable_00680(String funVariable_00680){
    this.funVariable_00680 = funVariable_00680;
}


/**
 * 
 * 
 * @return the funVariable_00681
 */
public String getFunVariable_00681(){
    return funVariable_00681;
}


/**
 * 
 * 
 * @param funVariable_00681 the funVariable_00681 to set
 */
public void setFunVariable_00681(String funVariable_00681){
    this.funVariable_00681 = funVariable_00681;
}


/**
 * 
 * 
 * @return the funVariable_00682
 */
public String getFunVariable_00682(){
    return funVariable_00682;
}


/**
 * 
 * 
 * @param funVariable_00682 the funVariable_00682 to set
 */
public void setFunVariable_00682(String funVariable_00682){
    this.funVariable_00682 = funVariable_00682;
}


/**
 * 
 * 
 * @return the funVariable_00683
 */
public String getFunVariable_00683(){
    return funVariable_00683;
}


/**
 * 
 * 
 * @param funVariable_00683 the funVariable_00683 to set
 */
public void setFunVariable_00683(String funVariable_00683){
    this.funVariable_00683 = funVariable_00683;
}


/**
 * 
 * 
 * @return the funVariable_00684
 */
public String getFunVariable_00684(){
    return funVariable_00684;
}


/**
 * 
 * 
 * @param funVariable_00684 the funVariable_00684 to set
 */
public void setFunVariable_00684(String funVariable_00684){
    this.funVariable_00684 = funVariable_00684;
}


/**
 * 
 * 
 * @return the funVariable_00685
 */
public String getFunVariable_00685(){
    return funVariable_00685;
}


/**
 * 
 * 
 * @param funVariable_00685 the funVariable_00685 to set
 */
public void setFunVariable_00685(String funVariable_00685){
    this.funVariable_00685 = funVariable_00685;
}


/**
 * 
 * 
 * @return the funVariable_00686
 */
public String getFunVariable_00686(){
    return funVariable_00686;
}


/**
 * 
 * 
 * @param funVariable_00686 the funVariable_00686 to set
 */
public void setFunVariable_00686(String funVariable_00686){
    this.funVariable_00686 = funVariable_00686;
}


/**
 * 
 * 
 * @return the funVariable_00687
 */
public String getFunVariable_00687(){
    return funVariable_00687;
}


/**
 * 
 * 
 * @param funVariable_00687 the funVariable_00687 to set
 */
public void setFunVariable_00687(String funVariable_00687){
    this.funVariable_00687 = funVariable_00687;
}


/**
 * 
 * 
 * @return the funVariable_00688
 */
public String getFunVariable_00688(){
    return funVariable_00688;
}


/**
 * 
 * 
 * @param funVariable_00688 the funVariable_00688 to set
 */
public void setFunVariable_00688(String funVariable_00688){
    this.funVariable_00688 = funVariable_00688;
}


/**
 * 
 * 
 * @return the funVariable_00689
 */
public String getFunVariable_00689(){
    return funVariable_00689;
}


/**
 * 
 * 
 * @param funVariable_00689 the funVariable_00689 to set
 */
public void setFunVariable_00689(String funVariable_00689){
    this.funVariable_00689 = funVariable_00689;
}


/**
 * 
 * 
 * @return the funVariable_00690
 */
public String getFunVariable_00690(){
    return funVariable_00690;
}


/**
 * 
 * 
 * @param funVariable_00690 the funVariable_00690 to set
 */
public void setFunVariable_00690(String funVariable_00690){
    this.funVariable_00690 = funVariable_00690;
}


/**
 * 
 * 
 * @return the funVariable_00691
 */
public String getFunVariable_00691(){
    return funVariable_00691;
}


/**
 * 
 * 
 * @param funVariable_00691 the funVariable_00691 to set
 */
public void setFunVariable_00691(String funVariable_00691){
    this.funVariable_00691 = funVariable_00691;
}


/**
 * 
 * 
 * @return the funVariable_00692
 */
public String getFunVariable_00692(){
    return funVariable_00692;
}


/**
 * 
 * 
 * @param funVariable_00692 the funVariable_00692 to set
 */
public void setFunVariable_00692(String funVariable_00692){
    this.funVariable_00692 = funVariable_00692;
}


/**
 * 
 * 
 * @return the funVariable_00693
 */
public String getFunVariable_00693(){
    return funVariable_00693;
}


/**
 * 
 * 
 * @param funVariable_00693 the funVariable_00693 to set
 */
public void setFunVariable_00693(String funVariable_00693){
    this.funVariable_00693 = funVariable_00693;
}


/**
 * 
 * 
 * @return the funVariable_00694
 */
public String getFunVariable_00694(){
    return funVariable_00694;
}


/**
 * 
 * 
 * @param funVariable_00694 the funVariable_00694 to set
 */
public void setFunVariable_00694(String funVariable_00694){
    this.funVariable_00694 = funVariable_00694;
}


/**
 * 
 * 
 * @return the funVariable_00695
 */
public String getFunVariable_00695(){
    return funVariable_00695;
}


/**
 * 
 * 
 * @param funVariable_00695 the funVariable_00695 to set
 */
public void setFunVariable_00695(String funVariable_00695){
    this.funVariable_00695 = funVariable_00695;
}


/**
 * 
 * 
 * @return the funVariable_00696
 */
public String getFunVariable_00696(){
    return funVariable_00696;
}


/**
 * 
 * 
 * @param funVariable_00696 the funVariable_00696 to set
 */
public void setFunVariable_00696(String funVariable_00696){
    this.funVariable_00696 = funVariable_00696;
}


/**
 * 
 * 
 * @return the funVariable_00697
 */
public String getFunVariable_00697(){
    return funVariable_00697;
}


/**
 * 
 * 
 * @param funVariable_00697 the funVariable_00697 to set
 */
public void setFunVariable_00697(String funVariable_00697){
    this.funVariable_00697 = funVariable_00697;
}


/**
 * 
 * 
 * @return the funVariable_00698
 */
public String getFunVariable_00698(){
    return funVariable_00698;
}


/**
 * 
 * 
 * @param funVariable_00698 the funVariable_00698 to set
 */
public void setFunVariable_00698(String funVariable_00698){
    this.funVariable_00698 = funVariable_00698;
}


/**
 * 
 * 
 * @return the funVariable_00699
 */
public String getFunVariable_00699(){
    return funVariable_00699;
}


/**
 * 
 * 
 * @param funVariable_00699 the funVariable_00699 to set
 */
public void setFunVariable_00699(String funVariable_00699){
    this.funVariable_00699 = funVariable_00699;
}


/**
 * 
 * 
 * @return the funVariable_00700
 */
public String getFunVariable_00700(){
    return funVariable_00700;
}


/**
 * 
 * 
 * @param funVariable_00700 the funVariable_00700 to set
 */
public void setFunVariable_00700(String funVariable_00700){
    this.funVariable_00700 = funVariable_00700;
}


/**
 * 
 * 
 * @return the funVariable_00701
 */
public String getFunVariable_00701(){
    return funVariable_00701;
}


/**
 * 
 * 
 * @param funVariable_00701 the funVariable_00701 to set
 */
public void setFunVariable_00701(String funVariable_00701){
    this.funVariable_00701 = funVariable_00701;
}


/**
 * 
 * 
 * @return the funVariable_00702
 */
public String getFunVariable_00702(){
    return funVariable_00702;
}


/**
 * 
 * 
 * @param funVariable_00702 the funVariable_00702 to set
 */
public void setFunVariable_00702(String funVariable_00702){
    this.funVariable_00702 = funVariable_00702;
}


/**
 * 
 * 
 * @return the funVariable_00703
 */
public String getFunVariable_00703(){
    return funVariable_00703;
}


/**
 * 
 * 
 * @param funVariable_00703 the funVariable_00703 to set
 */
public void setFunVariable_00703(String funVariable_00703){
    this.funVariable_00703 = funVariable_00703;
}


/**
 * 
 * 
 * @return the funVariable_00704
 */
public String getFunVariable_00704(){
    return funVariable_00704;
}


/**
 * 
 * 
 * @param funVariable_00704 the funVariable_00704 to set
 */
public void setFunVariable_00704(String funVariable_00704){
    this.funVariable_00704 = funVariable_00704;
}


/**
 * 
 * 
 * @return the funVariable_00705
 */
public String getFunVariable_00705(){
    return funVariable_00705;
}


/**
 * 
 * 
 * @param funVariable_00705 the funVariable_00705 to set
 */
public void setFunVariable_00705(String funVariable_00705){
    this.funVariable_00705 = funVariable_00705;
}


/**
 * 
 * 
 * @return the funVariable_00706
 */
public String getFunVariable_00706(){
    return funVariable_00706;
}


/**
 * 
 * 
 * @param funVariable_00706 the funVariable_00706 to set
 */
public void setFunVariable_00706(String funVariable_00706){
    this.funVariable_00706 = funVariable_00706;
}


/**
 * 
 * 
 * @return the funVariable_00707
 */
public String getFunVariable_00707(){
    return funVariable_00707;
}


/**
 * 
 * 
 * @param funVariable_00707 the funVariable_00707 to set
 */
public void setFunVariable_00707(String funVariable_00707){
    this.funVariable_00707 = funVariable_00707;
}


/**
 * 
 * 
 * @return the funVariable_00708
 */
public String getFunVariable_00708(){
    return funVariable_00708;
}


/**
 * 
 * 
 * @param funVariable_00708 the funVariable_00708 to set
 */
public void setFunVariable_00708(String funVariable_00708){
    this.funVariable_00708 = funVariable_00708;
}


/**
 * 
 * 
 * @return the funVariable_00709
 */
public String getFunVariable_00709(){
    return funVariable_00709;
}


/**
 * 
 * 
 * @param funVariable_00709 the funVariable_00709 to set
 */
public void setFunVariable_00709(String funVariable_00709){
    this.funVariable_00709 = funVariable_00709;
}


/**
 * 
 * 
 * @return the funVariable_00710
 */
public String getFunVariable_00710(){
    return funVariable_00710;
}


/**
 * 
 * 
 * @param funVariable_00710 the funVariable_00710 to set
 */
public void setFunVariable_00710(String funVariable_00710){
    this.funVariable_00710 = funVariable_00710;
}


/**
 * 
 * 
 * @return the funVariable_00711
 */
public String getFunVariable_00711(){
    return funVariable_00711;
}


/**
 * 
 * 
 * @param funVariable_00711 the funVariable_00711 to set
 */
public void setFunVariable_00711(String funVariable_00711){
    this.funVariable_00711 = funVariable_00711;
}


/**
 * 
 * 
 * @return the funVariable_00712
 */
public String getFunVariable_00712(){
    return funVariable_00712;
}


/**
 * 
 * 
 * @param funVariable_00712 the funVariable_00712 to set
 */
public void setFunVariable_00712(String funVariable_00712){
    this.funVariable_00712 = funVariable_00712;
}


/**
 * 
 * 
 * @return the funVariable_00713
 */
public String getFunVariable_00713(){
    return funVariable_00713;
}


/**
 * 
 * 
 * @param funVariable_00713 the funVariable_00713 to set
 */
public void setFunVariable_00713(String funVariable_00713){
    this.funVariable_00713 = funVariable_00713;
}


/**
 * 
 * 
 * @return the funVariable_00714
 */
public String getFunVariable_00714(){
    return funVariable_00714;
}


/**
 * 
 * 
 * @param funVariable_00714 the funVariable_00714 to set
 */
public void setFunVariable_00714(String funVariable_00714){
    this.funVariable_00714 = funVariable_00714;
}


/**
 * 
 * 
 * @return the funVariable_00715
 */
public String getFunVariable_00715(){
    return funVariable_00715;
}


/**
 * 
 * 
 * @param funVariable_00715 the funVariable_00715 to set
 */
public void setFunVariable_00715(String funVariable_00715){
    this.funVariable_00715 = funVariable_00715;
}


/**
 * 
 * 
 * @return the funVariable_00716
 */
public String getFunVariable_00716(){
    return funVariable_00716;
}


/**
 * 
 * 
 * @param funVariable_00716 the funVariable_00716 to set
 */
public void setFunVariable_00716(String funVariable_00716){
    this.funVariable_00716 = funVariable_00716;
}


/**
 * 
 * 
 * @return the funVariable_00717
 */
public String getFunVariable_00717(){
    return funVariable_00717;
}


/**
 * 
 * 
 * @param funVariable_00717 the funVariable_00717 to set
 */
public void setFunVariable_00717(String funVariable_00717){
    this.funVariable_00717 = funVariable_00717;
}


/**
 * 
 * 
 * @return the funVariable_00718
 */
public String getFunVariable_00718(){
    return funVariable_00718;
}


/**
 * 
 * 
 * @param funVariable_00718 the funVariable_00718 to set
 */
public void setFunVariable_00718(String funVariable_00718){
    this.funVariable_00718 = funVariable_00718;
}


/**
 * 
 * 
 * @return the funVariable_00719
 */
public String getFunVariable_00719(){
    return funVariable_00719;
}


/**
 * 
 * 
 * @param funVariable_00719 the funVariable_00719 to set
 */
public void setFunVariable_00719(String funVariable_00719){
    this.funVariable_00719 = funVariable_00719;
}


/**
 * 
 * 
 * @return the funVariable_00720
 */
public String getFunVariable_00720(){
    return funVariable_00720;
}


/**
 * 
 * 
 * @param funVariable_00720 the funVariable_00720 to set
 */
public void setFunVariable_00720(String funVariable_00720){
    this.funVariable_00720 = funVariable_00720;
}


/**
 * 
 * 
 * @return the funVariable_00721
 */
public String getFunVariable_00721(){
    return funVariable_00721;
}


/**
 * 
 * 
 * @param funVariable_00721 the funVariable_00721 to set
 */
public void setFunVariable_00721(String funVariable_00721){
    this.funVariable_00721 = funVariable_00721;
}


/**
 * 
 * 
 * @return the funVariable_00722
 */
public String getFunVariable_00722(){
    return funVariable_00722;
}


/**
 * 
 * 
 * @param funVariable_00722 the funVariable_00722 to set
 */
public void setFunVariable_00722(String funVariable_00722){
    this.funVariable_00722 = funVariable_00722;
}


/**
 * 
 * 
 * @return the funVariable_00723
 */
public String getFunVariable_00723(){
    return funVariable_00723;
}


/**
 * 
 * 
 * @param funVariable_00723 the funVariable_00723 to set
 */
public void setFunVariable_00723(String funVariable_00723){
    this.funVariable_00723 = funVariable_00723;
}


/**
 * 
 * 
 * @return the funVariable_00724
 */
public String getFunVariable_00724(){
    return funVariable_00724;
}


/**
 * 
 * 
 * @param funVariable_00724 the funVariable_00724 to set
 */
public void setFunVariable_00724(String funVariable_00724){
    this.funVariable_00724 = funVariable_00724;
}


/**
 * 
 * 
 * @return the funVariable_00725
 */
public String getFunVariable_00725(){
    return funVariable_00725;
}


/**
 * 
 * 
 * @param funVariable_00725 the funVariable_00725 to set
 */
public void setFunVariable_00725(String funVariable_00725){
    this.funVariable_00725 = funVariable_00725;
}


/**
 * 
 * 
 * @return the funVariable_00726
 */
public String getFunVariable_00726(){
    return funVariable_00726;
}


/**
 * 
 * 
 * @param funVariable_00726 the funVariable_00726 to set
 */
public void setFunVariable_00726(String funVariable_00726){
    this.funVariable_00726 = funVariable_00726;
}


/**
 * 
 * 
 * @return the funVariable_00727
 */
public String getFunVariable_00727(){
    return funVariable_00727;
}


/**
 * 
 * 
 * @param funVariable_00727 the funVariable_00727 to set
 */
public void setFunVariable_00727(String funVariable_00727){
    this.funVariable_00727 = funVariable_00727;
}


/**
 * 
 * 
 * @return the funVariable_00728
 */
public String getFunVariable_00728(){
    return funVariable_00728;
}


/**
 * 
 * 
 * @param funVariable_00728 the funVariable_00728 to set
 */
public void setFunVariable_00728(String funVariable_00728){
    this.funVariable_00728 = funVariable_00728;
}


/**
 * 
 * 
 * @return the funVariable_00729
 */
public String getFunVariable_00729(){
    return funVariable_00729;
}


/**
 * 
 * 
 * @param funVariable_00729 the funVariable_00729 to set
 */
public void setFunVariable_00729(String funVariable_00729){
    this.funVariable_00729 = funVariable_00729;
}


/**
 * 
 * 
 * @return the funVariable_00730
 */
public String getFunVariable_00730(){
    return funVariable_00730;
}


/**
 * 
 * 
 * @param funVariable_00730 the funVariable_00730 to set
 */
public void setFunVariable_00730(String funVariable_00730){
    this.funVariable_00730 = funVariable_00730;
}


/**
 * 
 * 
 * @return the funVariable_00731
 */
public String getFunVariable_00731(){
    return funVariable_00731;
}


/**
 * 
 * 
 * @param funVariable_00731 the funVariable_00731 to set
 */
public void setFunVariable_00731(String funVariable_00731){
    this.funVariable_00731 = funVariable_00731;
}


/**
 * 
 * 
 * @return the funVariable_00732
 */
public String getFunVariable_00732(){
    return funVariable_00732;
}


/**
 * 
 * 
 * @param funVariable_00732 the funVariable_00732 to set
 */
public void setFunVariable_00732(String funVariable_00732){
    this.funVariable_00732 = funVariable_00732;
}


/**
 * 
 * 
 * @return the funVariable_00733
 */
public String getFunVariable_00733(){
    return funVariable_00733;
}


/**
 * 
 * 
 * @param funVariable_00733 the funVariable_00733 to set
 */
public void setFunVariable_00733(String funVariable_00733){
    this.funVariable_00733 = funVariable_00733;
}


/**
 * 
 * 
 * @return the funVariable_00734
 */
public String getFunVariable_00734(){
    return funVariable_00734;
}


/**
 * 
 * 
 * @param funVariable_00734 the funVariable_00734 to set
 */
public void setFunVariable_00734(String funVariable_00734){
    this.funVariable_00734 = funVariable_00734;
}


/**
 * 
 * 
 * @return the funVariable_00735
 */
public String getFunVariable_00735(){
    return funVariable_00735;
}


/**
 * 
 * 
 * @param funVariable_00735 the funVariable_00735 to set
 */
public void setFunVariable_00735(String funVariable_00735){
    this.funVariable_00735 = funVariable_00735;
}


/**
 * 
 * 
 * @return the funVariable_00736
 */
public String getFunVariable_00736(){
    return funVariable_00736;
}


/**
 * 
 * 
 * @param funVariable_00736 the funVariable_00736 to set
 */
public void setFunVariable_00736(String funVariable_00736){
    this.funVariable_00736 = funVariable_00736;
}


/**
 * 
 * 
 * @return the funVariable_00737
 */
public String getFunVariable_00737(){
    return funVariable_00737;
}


/**
 * 
 * 
 * @param funVariable_00737 the funVariable_00737 to set
 */
public void setFunVariable_00737(String funVariable_00737){
    this.funVariable_00737 = funVariable_00737;
}


/**
 * 
 * 
 * @return the funVariable_00738
 */
public String getFunVariable_00738(){
    return funVariable_00738;
}


/**
 * 
 * 
 * @param funVariable_00738 the funVariable_00738 to set
 */
public void setFunVariable_00738(String funVariable_00738){
    this.funVariable_00738 = funVariable_00738;
}


/**
 * 
 * 
 * @return the funVariable_00739
 */
public String getFunVariable_00739(){
    return funVariable_00739;
}


/**
 * 
 * 
 * @param funVariable_00739 the funVariable_00739 to set
 */
public void setFunVariable_00739(String funVariable_00739){
    this.funVariable_00739 = funVariable_00739;
}


/**
 * 
 * 
 * @return the funVariable_00740
 */
public String getFunVariable_00740(){
    return funVariable_00740;
}


/**
 * 
 * 
 * @param funVariable_00740 the funVariable_00740 to set
 */
public void setFunVariable_00740(String funVariable_00740){
    this.funVariable_00740 = funVariable_00740;
}


/**
 * 
 * 
 * @return the funVariable_00741
 */
public String getFunVariable_00741(){
    return funVariable_00741;
}


/**
 * 
 * 
 * @param funVariable_00741 the funVariable_00741 to set
 */
public void setFunVariable_00741(String funVariable_00741){
    this.funVariable_00741 = funVariable_00741;
}


/**
 * 
 * 
 * @return the funVariable_00742
 */
public String getFunVariable_00742(){
    return funVariable_00742;
}


/**
 * 
 * 
 * @param funVariable_00742 the funVariable_00742 to set
 */
public void setFunVariable_00742(String funVariable_00742){
    this.funVariable_00742 = funVariable_00742;
}


/**
 * 
 * 
 * @return the funVariable_00743
 */
public String getFunVariable_00743(){
    return funVariable_00743;
}


/**
 * 
 * 
 * @param funVariable_00743 the funVariable_00743 to set
 */
public void setFunVariable_00743(String funVariable_00743){
    this.funVariable_00743 = funVariable_00743;
}


/**
 * 
 * 
 * @return the funVariable_00744
 */
public String getFunVariable_00744(){
    return funVariable_00744;
}


/**
 * 
 * 
 * @param funVariable_00744 the funVariable_00744 to set
 */
public void setFunVariable_00744(String funVariable_00744){
    this.funVariable_00744 = funVariable_00744;
}


/**
 * 
 * 
 * @return the funVariable_00745
 */
public String getFunVariable_00745(){
    return funVariable_00745;
}


/**
 * 
 * 
 * @param funVariable_00745 the funVariable_00745 to set
 */
public void setFunVariable_00745(String funVariable_00745){
    this.funVariable_00745 = funVariable_00745;
}


/**
 * 
 * 
 * @return the funVariable_00746
 */
public String getFunVariable_00746(){
    return funVariable_00746;
}


/**
 * 
 * 
 * @param funVariable_00746 the funVariable_00746 to set
 */
public void setFunVariable_00746(String funVariable_00746){
    this.funVariable_00746 = funVariable_00746;
}


/**
 * 
 * 
 * @return the funVariable_00747
 */
public String getFunVariable_00747(){
    return funVariable_00747;
}


/**
 * 
 * 
 * @param funVariable_00747 the funVariable_00747 to set
 */
public void setFunVariable_00747(String funVariable_00747){
    this.funVariable_00747 = funVariable_00747;
}


/**
 * 
 * 
 * @return the funVariable_00748
 */
public String getFunVariable_00748(){
    return funVariable_00748;
}


/**
 * 
 * 
 * @param funVariable_00748 the funVariable_00748 to set
 */
public void setFunVariable_00748(String funVariable_00748){
    this.funVariable_00748 = funVariable_00748;
}


/**
 * 
 * 
 * @return the funVariable_00749
 */
public String getFunVariable_00749(){
    return funVariable_00749;
}


/**
 * 
 * 
 * @param funVariable_00749 the funVariable_00749 to set
 */
public void setFunVariable_00749(String funVariable_00749){
    this.funVariable_00749 = funVariable_00749;
}


/**
 * 
 * 
 * @return the funVariable_00750
 */
public String getFunVariable_00750(){
    return funVariable_00750;
}


/**
 * 
 * 
 * @param funVariable_00750 the funVariable_00750 to set
 */
public void setFunVariable_00750(String funVariable_00750){
    this.funVariable_00750 = funVariable_00750;
}


/**
 * 
 * 
 * @return the funVariable_00751
 */
public String getFunVariable_00751(){
    return funVariable_00751;
}


/**
 * 
 * 
 * @param funVariable_00751 the funVariable_00751 to set
 */
public void setFunVariable_00751(String funVariable_00751){
    this.funVariable_00751 = funVariable_00751;
}


/**
 * 
 * 
 * @return the funVariable_00752
 */
public String getFunVariable_00752(){
    return funVariable_00752;
}


/**
 * 
 * 
 * @param funVariable_00752 the funVariable_00752 to set
 */
public void setFunVariable_00752(String funVariable_00752){
    this.funVariable_00752 = funVariable_00752;
}


/**
 * 
 * 
 * @return the funVariable_00753
 */
public String getFunVariable_00753(){
    return funVariable_00753;
}


/**
 * 
 * 
 * @param funVariable_00753 the funVariable_00753 to set
 */
public void setFunVariable_00753(String funVariable_00753){
    this.funVariable_00753 = funVariable_00753;
}


/**
 * 
 * 
 * @return the funVariable_00754
 */
public String getFunVariable_00754(){
    return funVariable_00754;
}


/**
 * 
 * 
 * @param funVariable_00754 the funVariable_00754 to set
 */
public void setFunVariable_00754(String funVariable_00754){
    this.funVariable_00754 = funVariable_00754;
}


/**
 * 
 * 
 * @return the funVariable_00755
 */
public String getFunVariable_00755(){
    return funVariable_00755;
}


/**
 * 
 * 
 * @param funVariable_00755 the funVariable_00755 to set
 */
public void setFunVariable_00755(String funVariable_00755){
    this.funVariable_00755 = funVariable_00755;
}


/**
 * 
 * 
 * @return the funVariable_00756
 */
public String getFunVariable_00756(){
    return funVariable_00756;
}


/**
 * 
 * 
 * @param funVariable_00756 the funVariable_00756 to set
 */
public void setFunVariable_00756(String funVariable_00756){
    this.funVariable_00756 = funVariable_00756;
}


/**
 * 
 * 
 * @return the funVariable_00757
 */
public String getFunVariable_00757(){
    return funVariable_00757;
}


/**
 * 
 * 
 * @param funVariable_00757 the funVariable_00757 to set
 */
public void setFunVariable_00757(String funVariable_00757){
    this.funVariable_00757 = funVariable_00757;
}


/**
 * 
 * 
 * @return the funVariable_00758
 */
public String getFunVariable_00758(){
    return funVariable_00758;
}


/**
 * 
 * 
 * @param funVariable_00758 the funVariable_00758 to set
 */
public void setFunVariable_00758(String funVariable_00758){
    this.funVariable_00758 = funVariable_00758;
}


/**
 * 
 * 
 * @return the funVariable_00759
 */
public String getFunVariable_00759(){
    return funVariable_00759;
}


/**
 * 
 * 
 * @param funVariable_00759 the funVariable_00759 to set
 */
public void setFunVariable_00759(String funVariable_00759){
    this.funVariable_00759 = funVariable_00759;
}


/**
 * 
 * 
 * @return the funVariable_00760
 */
public String getFunVariable_00760(){
    return funVariable_00760;
}


/**
 * 
 * 
 * @param funVariable_00760 the funVariable_00760 to set
 */
public void setFunVariable_00760(String funVariable_00760){
    this.funVariable_00760 = funVariable_00760;
}


/**
 * 
 * 
 * @return the funVariable_00761
 */
public String getFunVariable_00761(){
    return funVariable_00761;
}


/**
 * 
 * 
 * @param funVariable_00761 the funVariable_00761 to set
 */
public void setFunVariable_00761(String funVariable_00761){
    this.funVariable_00761 = funVariable_00761;
}


/**
 * 
 * 
 * @return the funVariable_00762
 */
public String getFunVariable_00762(){
    return funVariable_00762;
}


/**
 * 
 * 
 * @param funVariable_00762 the funVariable_00762 to set
 */
public void setFunVariable_00762(String funVariable_00762){
    this.funVariable_00762 = funVariable_00762;
}


/**
 * 
 * 
 * @return the funVariable_00763
 */
public String getFunVariable_00763(){
    return funVariable_00763;
}


/**
 * 
 * 
 * @param funVariable_00763 the funVariable_00763 to set
 */
public void setFunVariable_00763(String funVariable_00763){
    this.funVariable_00763 = funVariable_00763;
}


/**
 * 
 * 
 * @return the funVariable_00764
 */
public String getFunVariable_00764(){
    return funVariable_00764;
}


/**
 * 
 * 
 * @param funVariable_00764 the funVariable_00764 to set
 */
public void setFunVariable_00764(String funVariable_00764){
    this.funVariable_00764 = funVariable_00764;
}


/**
 * 
 * 
 * @return the funVariable_00765
 */
public String getFunVariable_00765(){
    return funVariable_00765;
}


/**
 * 
 * 
 * @param funVariable_00765 the funVariable_00765 to set
 */
public void setFunVariable_00765(String funVariable_00765){
    this.funVariable_00765 = funVariable_00765;
}


/**
 * 
 * 
 * @return the funVariable_00766
 */
public String getFunVariable_00766(){
    return funVariable_00766;
}


/**
 * 
 * 
 * @param funVariable_00766 the funVariable_00766 to set
 */
public void setFunVariable_00766(String funVariable_00766){
    this.funVariable_00766 = funVariable_00766;
}


/**
 * 
 * 
 * @return the funVariable_00767
 */
public String getFunVariable_00767(){
    return funVariable_00767;
}


/**
 * 
 * 
 * @param funVariable_00767 the funVariable_00767 to set
 */
public void setFunVariable_00767(String funVariable_00767){
    this.funVariable_00767 = funVariable_00767;
}


/**
 * 
 * 
 * @return the funVariable_00768
 */
public String getFunVariable_00768(){
    return funVariable_00768;
}


/**
 * 
 * 
 * @param funVariable_00768 the funVariable_00768 to set
 */
public void setFunVariable_00768(String funVariable_00768){
    this.funVariable_00768 = funVariable_00768;
}


/**
 * 
 * 
 * @return the funVariable_00769
 */
public String getFunVariable_00769(){
    return funVariable_00769;
}


/**
 * 
 * 
 * @param funVariable_00769 the funVariable_00769 to set
 */
public void setFunVariable_00769(String funVariable_00769){
    this.funVariable_00769 = funVariable_00769;
}


/**
 * 
 * 
 * @return the funVariable_00770
 */
public String getFunVariable_00770(){
    return funVariable_00770;
}


/**
 * 
 * 
 * @param funVariable_00770 the funVariable_00770 to set
 */
public void setFunVariable_00770(String funVariable_00770){
    this.funVariable_00770 = funVariable_00770;
}


/**
 * 
 * 
 * @return the funVariable_00771
 */
public String getFunVariable_00771(){
    return funVariable_00771;
}


/**
 * 
 * 
 * @param funVariable_00771 the funVariable_00771 to set
 */
public void setFunVariable_00771(String funVariable_00771){
    this.funVariable_00771 = funVariable_00771;
}


/**
 * 
 * 
 * @return the funVariable_00772
 */
public String getFunVariable_00772(){
    return funVariable_00772;
}


/**
 * 
 * 
 * @param funVariable_00772 the funVariable_00772 to set
 */
public void setFunVariable_00772(String funVariable_00772){
    this.funVariable_00772 = funVariable_00772;
}


/**
 * 
 * 
 * @return the funVariable_00773
 */
public String getFunVariable_00773(){
    return funVariable_00773;
}


/**
 * 
 * 
 * @param funVariable_00773 the funVariable_00773 to set
 */
public void setFunVariable_00773(String funVariable_00773){
    this.funVariable_00773 = funVariable_00773;
}


/**
 * 
 * 
 * @return the funVariable_00774
 */
public String getFunVariable_00774(){
    return funVariable_00774;
}


/**
 * 
 * 
 * @param funVariable_00774 the funVariable_00774 to set
 */
public void setFunVariable_00774(String funVariable_00774){
    this.funVariable_00774 = funVariable_00774;
}


/**
 * 
 * 
 * @return the funVariable_00775
 */
public String getFunVariable_00775(){
    return funVariable_00775;
}


/**
 * 
 * 
 * @param funVariable_00775 the funVariable_00775 to set
 */
public void setFunVariable_00775(String funVariable_00775){
    this.funVariable_00775 = funVariable_00775;
}


/**
 * 
 * 
 * @return the funVariable_00776
 */
public String getFunVariable_00776(){
    return funVariable_00776;
}


/**
 * 
 * 
 * @param funVariable_00776 the funVariable_00776 to set
 */
public void setFunVariable_00776(String funVariable_00776){
    this.funVariable_00776 = funVariable_00776;
}


/**
 * 
 * 
 * @return the funVariable_00777
 */
public String getFunVariable_00777(){
    return funVariable_00777;
}


/**
 * 
 * 
 * @param funVariable_00777 the funVariable_00777 to set
 */
public void setFunVariable_00777(String funVariable_00777){
    this.funVariable_00777 = funVariable_00777;
}


/**
 * 
 * 
 * @return the funVariable_00778
 */
public String getFunVariable_00778(){
    return funVariable_00778;
}


/**
 * 
 * 
 * @param funVariable_00778 the funVariable_00778 to set
 */
public void setFunVariable_00778(String funVariable_00778){
    this.funVariable_00778 = funVariable_00778;
}


/**
 * 
 * 
 * @return the funVariable_00779
 */
public String getFunVariable_00779(){
    return funVariable_00779;
}


/**
 * 
 * 
 * @param funVariable_00779 the funVariable_00779 to set
 */
public void setFunVariable_00779(String funVariable_00779){
    this.funVariable_00779 = funVariable_00779;
}


/**
 * 
 * 
 * @return the funVariable_00780
 */
public String getFunVariable_00780(){
    return funVariable_00780;
}


/**
 * 
 * 
 * @param funVariable_00780 the funVariable_00780 to set
 */
public void setFunVariable_00780(String funVariable_00780){
    this.funVariable_00780 = funVariable_00780;
}


/**
 * 
 * 
 * @return the funVariable_00781
 */
public String getFunVariable_00781(){
    return funVariable_00781;
}


/**
 * 
 * 
 * @param funVariable_00781 the funVariable_00781 to set
 */
public void setFunVariable_00781(String funVariable_00781){
    this.funVariable_00781 = funVariable_00781;
}


/**
 * 
 * 
 * @return the funVariable_00782
 */
public String getFunVariable_00782(){
    return funVariable_00782;
}


/**
 * 
 * 
 * @param funVariable_00782 the funVariable_00782 to set
 */
public void setFunVariable_00782(String funVariable_00782){
    this.funVariable_00782 = funVariable_00782;
}


/**
 * 
 * 
 * @return the funVariable_00783
 */
public String getFunVariable_00783(){
    return funVariable_00783;
}


/**
 * 
 * 
 * @param funVariable_00783 the funVariable_00783 to set
 */
public void setFunVariable_00783(String funVariable_00783){
    this.funVariable_00783 = funVariable_00783;
}


/**
 * 
 * 
 * @return the funVariable_00784
 */
public String getFunVariable_00784(){
    return funVariable_00784;
}


/**
 * 
 * 
 * @param funVariable_00784 the funVariable_00784 to set
 */
public void setFunVariable_00784(String funVariable_00784){
    this.funVariable_00784 = funVariable_00784;
}


/**
 * 
 * 
 * @return the funVariable_00785
 */
public String getFunVariable_00785(){
    return funVariable_00785;
}


/**
 * 
 * 
 * @param funVariable_00785 the funVariable_00785 to set
 */
public void setFunVariable_00785(String funVariable_00785){
    this.funVariable_00785 = funVariable_00785;
}


/**
 * 
 * 
 * @return the funVariable_00786
 */
public String getFunVariable_00786(){
    return funVariable_00786;
}


/**
 * 
 * 
 * @param funVariable_00786 the funVariable_00786 to set
 */
public void setFunVariable_00786(String funVariable_00786){
    this.funVariable_00786 = funVariable_00786;
}


/**
 * 
 * 
 * @return the funVariable_00787
 */
public String getFunVariable_00787(){
    return funVariable_00787;
}


/**
 * 
 * 
 * @param funVariable_00787 the funVariable_00787 to set
 */
public void setFunVariable_00787(String funVariable_00787){
    this.funVariable_00787 = funVariable_00787;
}


/**
 * 
 * 
 * @return the funVariable_00788
 */
public String getFunVariable_00788(){
    return funVariable_00788;
}


/**
 * 
 * 
 * @param funVariable_00788 the funVariable_00788 to set
 */
public void setFunVariable_00788(String funVariable_00788){
    this.funVariable_00788 = funVariable_00788;
}


/**
 * 
 * 
 * @return the funVariable_00789
 */
public String getFunVariable_00789(){
    return funVariable_00789;
}


/**
 * 
 * 
 * @param funVariable_00789 the funVariable_00789 to set
 */
public void setFunVariable_00789(String funVariable_00789){
    this.funVariable_00789 = funVariable_00789;
}


/**
 * 
 * 
 * @return the funVariable_00790
 */
public String getFunVariable_00790(){
    return funVariable_00790;
}


/**
 * 
 * 
 * @param funVariable_00790 the funVariable_00790 to set
 */
public void setFunVariable_00790(String funVariable_00790){
    this.funVariable_00790 = funVariable_00790;
}


/**
 * 
 * 
 * @return the funVariable_00791
 */
public String getFunVariable_00791(){
    return funVariable_00791;
}


/**
 * 
 * 
 * @param funVariable_00791 the funVariable_00791 to set
 */
public void setFunVariable_00791(String funVariable_00791){
    this.funVariable_00791 = funVariable_00791;
}


/**
 * 
 * 
 * @return the funVariable_00792
 */
public String getFunVariable_00792(){
    return funVariable_00792;
}


/**
 * 
 * 
 * @param funVariable_00792 the funVariable_00792 to set
 */
public void setFunVariable_00792(String funVariable_00792){
    this.funVariable_00792 = funVariable_00792;
}


/**
 * 
 * 
 * @return the funVariable_00793
 */
public String getFunVariable_00793(){
    return funVariable_00793;
}


/**
 * 
 * 
 * @param funVariable_00793 the funVariable_00793 to set
 */
public void setFunVariable_00793(String funVariable_00793){
    this.funVariable_00793 = funVariable_00793;
}


/**
 * 
 * 
 * @return the funVariable_00794
 */
public String getFunVariable_00794(){
    return funVariable_00794;
}


/**
 * 
 * 
 * @param funVariable_00794 the funVariable_00794 to set
 */
public void setFunVariable_00794(String funVariable_00794){
    this.funVariable_00794 = funVariable_00794;
}


/**
 * 
 * 
 * @return the funVariable_00795
 */
public String getFunVariable_00795(){
    return funVariable_00795;
}


/**
 * 
 * 
 * @param funVariable_00795 the funVariable_00795 to set
 */
public void setFunVariable_00795(String funVariable_00795){
    this.funVariable_00795 = funVariable_00795;
}


/**
 * 
 * 
 * @return the funVariable_00796
 */
public String getFunVariable_00796(){
    return funVariable_00796;
}


/**
 * 
 * 
 * @param funVariable_00796 the funVariable_00796 to set
 */
public void setFunVariable_00796(String funVariable_00796){
    this.funVariable_00796 = funVariable_00796;
}


/**
 * 
 * 
 * @return the funVariable_00797
 */
public String getFunVariable_00797(){
    return funVariable_00797;
}


/**
 * 
 * 
 * @param funVariable_00797 the funVariable_00797 to set
 */
public void setFunVariable_00797(String funVariable_00797){
    this.funVariable_00797 = funVariable_00797;
}


/**
 * 
 * 
 * @return the funVariable_00798
 */
public String getFunVariable_00798(){
    return funVariable_00798;
}


/**
 * 
 * 
 * @param funVariable_00798 the funVariable_00798 to set
 */
public void setFunVariable_00798(String funVariable_00798){
    this.funVariable_00798 = funVariable_00798;
}


/**
 * 
 * 
 * @return the funVariable_00799
 */
public String getFunVariable_00799(){
    return funVariable_00799;
}


/**
 * 
 * 
 * @param funVariable_00799 the funVariable_00799 to set
 */
public void setFunVariable_00799(String funVariable_00799){
    this.funVariable_00799 = funVariable_00799;
}


/**
 * 
 * 
 * @return the funVariable_00800
 */
public String getFunVariable_00800(){
    return funVariable_00800;
}


/**
 * 
 * 
 * @param funVariable_00800 the funVariable_00800 to set
 */
public void setFunVariable_00800(String funVariable_00800){
    this.funVariable_00800 = funVariable_00800;
}


/**
 * 
 * 
 * @return the funVariable_00801
 */
public String getFunVariable_00801(){
    return funVariable_00801;
}


/**
 * 
 * 
 * @param funVariable_00801 the funVariable_00801 to set
 */
public void setFunVariable_00801(String funVariable_00801){
    this.funVariable_00801 = funVariable_00801;
}


/**
 * 
 * 
 * @return the funVariable_00802
 */
public String getFunVariable_00802(){
    return funVariable_00802;
}


/**
 * 
 * 
 * @param funVariable_00802 the funVariable_00802 to set
 */
public void setFunVariable_00802(String funVariable_00802){
    this.funVariable_00802 = funVariable_00802;
}


/**
 * 
 * 
 * @return the funVariable_00803
 */
public String getFunVariable_00803(){
    return funVariable_00803;
}


/**
 * 
 * 
 * @param funVariable_00803 the funVariable_00803 to set
 */
public void setFunVariable_00803(String funVariable_00803){
    this.funVariable_00803 = funVariable_00803;
}


/**
 * 
 * 
 * @return the funVariable_00804
 */
public String getFunVariable_00804(){
    return funVariable_00804;
}


/**
 * 
 * 
 * @param funVariable_00804 the funVariable_00804 to set
 */
public void setFunVariable_00804(String funVariable_00804){
    this.funVariable_00804 = funVariable_00804;
}


/**
 * 
 * 
 * @return the funVariable_00805
 */
public String getFunVariable_00805(){
    return funVariable_00805;
}


/**
 * 
 * 
 * @param funVariable_00805 the funVariable_00805 to set
 */
public void setFunVariable_00805(String funVariable_00805){
    this.funVariable_00805 = funVariable_00805;
}


/**
 * 
 * 
 * @return the funVariable_00806
 */
public String getFunVariable_00806(){
    return funVariable_00806;
}


/**
 * 
 * 
 * @param funVariable_00806 the funVariable_00806 to set
 */
public void setFunVariable_00806(String funVariable_00806){
    this.funVariable_00806 = funVariable_00806;
}


/**
 * 
 * 
 * @return the funVariable_00807
 */
public String getFunVariable_00807(){
    return funVariable_00807;
}


/**
 * 
 * 
 * @param funVariable_00807 the funVariable_00807 to set
 */
public void setFunVariable_00807(String funVariable_00807){
    this.funVariable_00807 = funVariable_00807;
}


/**
 * 
 * 
 * @return the funVariable_00808
 */
public String getFunVariable_00808(){
    return funVariable_00808;
}


/**
 * 
 * 
 * @param funVariable_00808 the funVariable_00808 to set
 */
public void setFunVariable_00808(String funVariable_00808){
    this.funVariable_00808 = funVariable_00808;
}


/**
 * 
 * 
 * @return the funVariable_00809
 */
public String getFunVariable_00809(){
    return funVariable_00809;
}


/**
 * 
 * 
 * @param funVariable_00809 the funVariable_00809 to set
 */
public void setFunVariable_00809(String funVariable_00809){
    this.funVariable_00809 = funVariable_00809;
}


/**
 * 
 * 
 * @return the funVariable_00810
 */
public String getFunVariable_00810(){
    return funVariable_00810;
}


/**
 * 
 * 
 * @param funVariable_00810 the funVariable_00810 to set
 */
public void setFunVariable_00810(String funVariable_00810){
    this.funVariable_00810 = funVariable_00810;
}


/**
 * 
 * 
 * @return the funVariable_00811
 */
public String getFunVariable_00811(){
    return funVariable_00811;
}


/**
 * 
 * 
 * @param funVariable_00811 the funVariable_00811 to set
 */
public void setFunVariable_00811(String funVariable_00811){
    this.funVariable_00811 = funVariable_00811;
}


/**
 * 
 * 
 * @return the funVariable_00812
 */
public String getFunVariable_00812(){
    return funVariable_00812;
}


/**
 * 
 * 
 * @param funVariable_00812 the funVariable_00812 to set
 */
public void setFunVariable_00812(String funVariable_00812){
    this.funVariable_00812 = funVariable_00812;
}


/**
 * 
 * 
 * @return the funVariable_00813
 */
public String getFunVariable_00813(){
    return funVariable_00813;
}


/**
 * 
 * 
 * @param funVariable_00813 the funVariable_00813 to set
 */
public void setFunVariable_00813(String funVariable_00813){
    this.funVariable_00813 = funVariable_00813;
}


/**
 * 
 * 
 * @return the funVariable_00814
 */
public String getFunVariable_00814(){
    return funVariable_00814;
}


/**
 * 
 * 
 * @param funVariable_00814 the funVariable_00814 to set
 */
public void setFunVariable_00814(String funVariable_00814){
    this.funVariable_00814 = funVariable_00814;
}


/**
 * 
 * 
 * @return the funVariable_00815
 */
public String getFunVariable_00815(){
    return funVariable_00815;
}


/**
 * 
 * 
 * @param funVariable_00815 the funVariable_00815 to set
 */
public void setFunVariable_00815(String funVariable_00815){
    this.funVariable_00815 = funVariable_00815;
}


/**
 * 
 * 
 * @return the funVariable_00816
 */
public String getFunVariable_00816(){
    return funVariable_00816;
}


/**
 * 
 * 
 * @param funVariable_00816 the funVariable_00816 to set
 */
public void setFunVariable_00816(String funVariable_00816){
    this.funVariable_00816 = funVariable_00816;
}


/**
 * 
 * 
 * @return the funVariable_00817
 */
public String getFunVariable_00817(){
    return funVariable_00817;
}


/**
 * 
 * 
 * @param funVariable_00817 the funVariable_00817 to set
 */
public void setFunVariable_00817(String funVariable_00817){
    this.funVariable_00817 = funVariable_00817;
}


/**
 * 
 * 
 * @return the funVariable_00818
 */
public String getFunVariable_00818(){
    return funVariable_00818;
}


/**
 * 
 * 
 * @param funVariable_00818 the funVariable_00818 to set
 */
public void setFunVariable_00818(String funVariable_00818){
    this.funVariable_00818 = funVariable_00818;
}


/**
 * 
 * 
 * @return the funVariable_00819
 */
public String getFunVariable_00819(){
    return funVariable_00819;
}


/**
 * 
 * 
 * @param funVariable_00819 the funVariable_00819 to set
 */
public void setFunVariable_00819(String funVariable_00819){
    this.funVariable_00819 = funVariable_00819;
}


/**
 * 
 * 
 * @return the funVariable_00820
 */
public String getFunVariable_00820(){
    return funVariable_00820;
}


/**
 * 
 * 
 * @param funVariable_00820 the funVariable_00820 to set
 */
public void setFunVariable_00820(String funVariable_00820){
    this.funVariable_00820 = funVariable_00820;
}


/**
 * 
 * 
 * @return the funVariable_00821
 */
public String getFunVariable_00821(){
    return funVariable_00821;
}


/**
 * 
 * 
 * @param funVariable_00821 the funVariable_00821 to set
 */
public void setFunVariable_00821(String funVariable_00821){
    this.funVariable_00821 = funVariable_00821;
}


/**
 * 
 * 
 * @return the funVariable_00822
 */
public String getFunVariable_00822(){
    return funVariable_00822;
}


/**
 * 
 * 
 * @param funVariable_00822 the funVariable_00822 to set
 */
public void setFunVariable_00822(String funVariable_00822){
    this.funVariable_00822 = funVariable_00822;
}


/**
 * 
 * 
 * @return the funVariable_00823
 */
public String getFunVariable_00823(){
    return funVariable_00823;
}


/**
 * 
 * 
 * @param funVariable_00823 the funVariable_00823 to set
 */
public void setFunVariable_00823(String funVariable_00823){
    this.funVariable_00823 = funVariable_00823;
}


/**
 * 
 * 
 * @return the funVariable_00824
 */
public String getFunVariable_00824(){
    return funVariable_00824;
}


/**
 * 
 * 
 * @param funVariable_00824 the funVariable_00824 to set
 */
public void setFunVariable_00824(String funVariable_00824){
    this.funVariable_00824 = funVariable_00824;
}


/**
 * 
 * 
 * @return the funVariable_00825
 */
public String getFunVariable_00825(){
    return funVariable_00825;
}


/**
 * 
 * 
 * @param funVariable_00825 the funVariable_00825 to set
 */
public void setFunVariable_00825(String funVariable_00825){
    this.funVariable_00825 = funVariable_00825;
}


/**
 * 
 * 
 * @return the funVariable_00826
 */
public String getFunVariable_00826(){
    return funVariable_00826;
}


/**
 * 
 * 
 * @param funVariable_00826 the funVariable_00826 to set
 */
public void setFunVariable_00826(String funVariable_00826){
    this.funVariable_00826 = funVariable_00826;
}


/**
 * 
 * 
 * @return the funVariable_00827
 */
public String getFunVariable_00827(){
    return funVariable_00827;
}


/**
 * 
 * 
 * @param funVariable_00827 the funVariable_00827 to set
 */
public void setFunVariable_00827(String funVariable_00827){
    this.funVariable_00827 = funVariable_00827;
}


/**
 * 
 * 
 * @return the funVariable_00828
 */
public String getFunVariable_00828(){
    return funVariable_00828;
}


/**
 * 
 * 
 * @param funVariable_00828 the funVariable_00828 to set
 */
public void setFunVariable_00828(String funVariable_00828){
    this.funVariable_00828 = funVariable_00828;
}


/**
 * 
 * 
 * @return the funVariable_00829
 */
public String getFunVariable_00829(){
    return funVariable_00829;
}


/**
 * 
 * 
 * @param funVariable_00829 the funVariable_00829 to set
 */
public void setFunVariable_00829(String funVariable_00829){
    this.funVariable_00829 = funVariable_00829;
}


/**
 * 
 * 
 * @return the funVariable_00830
 */
public String getFunVariable_00830(){
    return funVariable_00830;
}


/**
 * 
 * 
 * @param funVariable_00830 the funVariable_00830 to set
 */
public void setFunVariable_00830(String funVariable_00830){
    this.funVariable_00830 = funVariable_00830;
}


/**
 * 
 * 
 * @return the funVariable_00831
 */
public String getFunVariable_00831(){
    return funVariable_00831;
}


/**
 * 
 * 
 * @param funVariable_00831 the funVariable_00831 to set
 */
public void setFunVariable_00831(String funVariable_00831){
    this.funVariable_00831 = funVariable_00831;
}


/**
 * 
 * 
 * @return the funVariable_00832
 */
public String getFunVariable_00832(){
    return funVariable_00832;
}


/**
 * 
 * 
 * @param funVariable_00832 the funVariable_00832 to set
 */
public void setFunVariable_00832(String funVariable_00832){
    this.funVariable_00832 = funVariable_00832;
}


/**
 * 
 * 
 * @return the funVariable_00833
 */
public String getFunVariable_00833(){
    return funVariable_00833;
}


/**
 * 
 * 
 * @param funVariable_00833 the funVariable_00833 to set
 */
public void setFunVariable_00833(String funVariable_00833){
    this.funVariable_00833 = funVariable_00833;
}


/**
 * 
 * 
 * @return the funVariable_00834
 */
public String getFunVariable_00834(){
    return funVariable_00834;
}


/**
 * 
 * 
 * @param funVariable_00834 the funVariable_00834 to set
 */
public void setFunVariable_00834(String funVariable_00834){
    this.funVariable_00834 = funVariable_00834;
}


/**
 * 
 * 
 * @return the funVariable_00835
 */
public String getFunVariable_00835(){
    return funVariable_00835;
}


/**
 * 
 * 
 * @param funVariable_00835 the funVariable_00835 to set
 */
public void setFunVariable_00835(String funVariable_00835){
    this.funVariable_00835 = funVariable_00835;
}


/**
 * 
 * 
 * @return the funVariable_00836
 */
public String getFunVariable_00836(){
    return funVariable_00836;
}


/**
 * 
 * 
 * @param funVariable_00836 the funVariable_00836 to set
 */
public void setFunVariable_00836(String funVariable_00836){
    this.funVariable_00836 = funVariable_00836;
}


/**
 * 
 * 
 * @return the funVariable_00837
 */
public String getFunVariable_00837(){
    return funVariable_00837;
}


/**
 * 
 * 
 * @param funVariable_00837 the funVariable_00837 to set
 */
public void setFunVariable_00837(String funVariable_00837){
    this.funVariable_00837 = funVariable_00837;
}


/**
 * 
 * 
 * @return the funVariable_00838
 */
public String getFunVariable_00838(){
    return funVariable_00838;
}


/**
 * 
 * 
 * @param funVariable_00838 the funVariable_00838 to set
 */
public void setFunVariable_00838(String funVariable_00838){
    this.funVariable_00838 = funVariable_00838;
}


/**
 * 
 * 
 * @return the funVariable_00839
 */
public String getFunVariable_00839(){
    return funVariable_00839;
}


/**
 * 
 * 
 * @param funVariable_00839 the funVariable_00839 to set
 */
public void setFunVariable_00839(String funVariable_00839){
    this.funVariable_00839 = funVariable_00839;
}


/**
 * 
 * 
 * @return the funVariable_00840
 */
public String getFunVariable_00840(){
    return funVariable_00840;
}


/**
 * 
 * 
 * @param funVariable_00840 the funVariable_00840 to set
 */
public void setFunVariable_00840(String funVariable_00840){
    this.funVariable_00840 = funVariable_00840;
}


/**
 * 
 * 
 * @return the funVariable_00841
 */
public String getFunVariable_00841(){
    return funVariable_00841;
}


/**
 * 
 * 
 * @param funVariable_00841 the funVariable_00841 to set
 */
public void setFunVariable_00841(String funVariable_00841){
    this.funVariable_00841 = funVariable_00841;
}


/**
 * 
 * 
 * @return the funVariable_00842
 */
public String getFunVariable_00842(){
    return funVariable_00842;
}


/**
 * 
 * 
 * @param funVariable_00842 the funVariable_00842 to set
 */
public void setFunVariable_00842(String funVariable_00842){
    this.funVariable_00842 = funVariable_00842;
}


/**
 * 
 * 
 * @return the funVariable_00843
 */
public String getFunVariable_00843(){
    return funVariable_00843;
}


/**
 * 
 * 
 * @param funVariable_00843 the funVariable_00843 to set
 */
public void setFunVariable_00843(String funVariable_00843){
    this.funVariable_00843 = funVariable_00843;
}


/**
 * 
 * 
 * @return the funVariable_00844
 */
public String getFunVariable_00844(){
    return funVariable_00844;
}


/**
 * 
 * 
 * @param funVariable_00844 the funVariable_00844 to set
 */
public void setFunVariable_00844(String funVariable_00844){
    this.funVariable_00844 = funVariable_00844;
}


/**
 * 
 * 
 * @return the funVariable_00845
 */
public String getFunVariable_00845(){
    return funVariable_00845;
}


/**
 * 
 * 
 * @param funVariable_00845 the funVariable_00845 to set
 */
public void setFunVariable_00845(String funVariable_00845){
    this.funVariable_00845 = funVariable_00845;
}


/**
 * 
 * 
 * @return the funVariable_00846
 */
public String getFunVariable_00846(){
    return funVariable_00846;
}


/**
 * 
 * 
 * @param funVariable_00846 the funVariable_00846 to set
 */
public void setFunVariable_00846(String funVariable_00846){
    this.funVariable_00846 = funVariable_00846;
}


/**
 * 
 * 
 * @return the funVariable_00847
 */
public String getFunVariable_00847(){
    return funVariable_00847;
}


/**
 * 
 * 
 * @param funVariable_00847 the funVariable_00847 to set
 */
public void setFunVariable_00847(String funVariable_00847){
    this.funVariable_00847 = funVariable_00847;
}


/**
 * 
 * 
 * @return the funVariable_00848
 */
public String getFunVariable_00848(){
    return funVariable_00848;
}


/**
 * 
 * 
 * @param funVariable_00848 the funVariable_00848 to set
 */
public void setFunVariable_00848(String funVariable_00848){
    this.funVariable_00848 = funVariable_00848;
}


/**
 * 
 * 
 * @return the funVariable_00849
 */
public String getFunVariable_00849(){
    return funVariable_00849;
}


/**
 * 
 * 
 * @param funVariable_00849 the funVariable_00849 to set
 */
public void setFunVariable_00849(String funVariable_00849){
    this.funVariable_00849 = funVariable_00849;
}


/**
 * 
 * 
 * @return the funVariable_00850
 */
public String getFunVariable_00850(){
    return funVariable_00850;
}


/**
 * 
 * 
 * @param funVariable_00850 the funVariable_00850 to set
 */
public void setFunVariable_00850(String funVariable_00850){
    this.funVariable_00850 = funVariable_00850;
}


/**
 * 
 * 
 * @return the funVariable_00851
 */
public String getFunVariable_00851(){
    return funVariable_00851;
}


/**
 * 
 * 
 * @param funVariable_00851 the funVariable_00851 to set
 */
public void setFunVariable_00851(String funVariable_00851){
    this.funVariable_00851 = funVariable_00851;
}


/**
 * 
 * 
 * @return the funVariable_00852
 */
public String getFunVariable_00852(){
    return funVariable_00852;
}


/**
 * 
 * 
 * @param funVariable_00852 the funVariable_00852 to set
 */
public void setFunVariable_00852(String funVariable_00852){
    this.funVariable_00852 = funVariable_00852;
}


/**
 * 
 * 
 * @return the funVariable_00853
 */
public String getFunVariable_00853(){
    return funVariable_00853;
}


/**
 * 
 * 
 * @param funVariable_00853 the funVariable_00853 to set
 */
public void setFunVariable_00853(String funVariable_00853){
    this.funVariable_00853 = funVariable_00853;
}


/**
 * 
 * 
 * @return the funVariable_00854
 */
public String getFunVariable_00854(){
    return funVariable_00854;
}


/**
 * 
 * 
 * @param funVariable_00854 the funVariable_00854 to set
 */
public void setFunVariable_00854(String funVariable_00854){
    this.funVariable_00854 = funVariable_00854;
}


/**
 * 
 * 
 * @return the funVariable_00855
 */
public String getFunVariable_00855(){
    return funVariable_00855;
}


/**
 * 
 * 
 * @param funVariable_00855 the funVariable_00855 to set
 */
public void setFunVariable_00855(String funVariable_00855){
    this.funVariable_00855 = funVariable_00855;
}


/**
 * 
 * 
 * @return the funVariable_00856
 */
public String getFunVariable_00856(){
    return funVariable_00856;
}


/**
 * 
 * 
 * @param funVariable_00856 the funVariable_00856 to set
 */
public void setFunVariable_00856(String funVariable_00856){
    this.funVariable_00856 = funVariable_00856;
}


/**
 * 
 * 
 * @return the funVariable_00857
 */
public String getFunVariable_00857(){
    return funVariable_00857;
}


/**
 * 
 * 
 * @param funVariable_00857 the funVariable_00857 to set
 */
public void setFunVariable_00857(String funVariable_00857){
    this.funVariable_00857 = funVariable_00857;
}


/**
 * 
 * 
 * @return the funVariable_00858
 */
public String getFunVariable_00858(){
    return funVariable_00858;
}


/**
 * 
 * 
 * @param funVariable_00858 the funVariable_00858 to set
 */
public void setFunVariable_00858(String funVariable_00858){
    this.funVariable_00858 = funVariable_00858;
}


/**
 * 
 * 
 * @return the funVariable_00859
 */
public String getFunVariable_00859(){
    return funVariable_00859;
}


/**
 * 
 * 
 * @param funVariable_00859 the funVariable_00859 to set
 */
public void setFunVariable_00859(String funVariable_00859){
    this.funVariable_00859 = funVariable_00859;
}


/**
 * 
 * 
 * @return the funVariable_00860
 */
public String getFunVariable_00860(){
    return funVariable_00860;
}


/**
 * 
 * 
 * @param funVariable_00860 the funVariable_00860 to set
 */
public void setFunVariable_00860(String funVariable_00860){
    this.funVariable_00860 = funVariable_00860;
}


/**
 * 
 * 
 * @return the funVariable_00861
 */
public String getFunVariable_00861(){
    return funVariable_00861;
}


/**
 * 
 * 
 * @param funVariable_00861 the funVariable_00861 to set
 */
public void setFunVariable_00861(String funVariable_00861){
    this.funVariable_00861 = funVariable_00861;
}


/**
 * 
 * 
 * @return the funVariable_00862
 */
public String getFunVariable_00862(){
    return funVariable_00862;
}


/**
 * 
 * 
 * @param funVariable_00862 the funVariable_00862 to set
 */
public void setFunVariable_00862(String funVariable_00862){
    this.funVariable_00862 = funVariable_00862;
}


/**
 * 
 * 
 * @return the funVariable_00863
 */
public String getFunVariable_00863(){
    return funVariable_00863;
}


/**
 * 
 * 
 * @param funVariable_00863 the funVariable_00863 to set
 */
public void setFunVariable_00863(String funVariable_00863){
    this.funVariable_00863 = funVariable_00863;
}


/**
 * 
 * 
 * @return the funVariable_00864
 */
public String getFunVariable_00864(){
    return funVariable_00864;
}


/**
 * 
 * 
 * @param funVariable_00864 the funVariable_00864 to set
 */
public void setFunVariable_00864(String funVariable_00864){
    this.funVariable_00864 = funVariable_00864;
}


/**
 * 
 * 
 * @return the funVariable_00865
 */
public String getFunVariable_00865(){
    return funVariable_00865;
}


/**
 * 
 * 
 * @param funVariable_00865 the funVariable_00865 to set
 */
public void setFunVariable_00865(String funVariable_00865){
    this.funVariable_00865 = funVariable_00865;
}


/**
 * 
 * 
 * @return the funVariable_00866
 */
public String getFunVariable_00866(){
    return funVariable_00866;
}


/**
 * 
 * 
 * @param funVariable_00866 the funVariable_00866 to set
 */
public void setFunVariable_00866(String funVariable_00866){
    this.funVariable_00866 = funVariable_00866;
}


/**
 * 
 * 
 * @return the funVariable_00867
 */
public String getFunVariable_00867(){
    return funVariable_00867;
}


/**
 * 
 * 
 * @param funVariable_00867 the funVariable_00867 to set
 */
public void setFunVariable_00867(String funVariable_00867){
    this.funVariable_00867 = funVariable_00867;
}


/**
 * 
 * 
 * @return the funVariable_00868
 */
public String getFunVariable_00868(){
    return funVariable_00868;
}


/**
 * 
 * 
 * @param funVariable_00868 the funVariable_00868 to set
 */
public void setFunVariable_00868(String funVariable_00868){
    this.funVariable_00868 = funVariable_00868;
}


/**
 * 
 * 
 * @return the funVariable_00869
 */
public String getFunVariable_00869(){
    return funVariable_00869;
}


/**
 * 
 * 
 * @param funVariable_00869 the funVariable_00869 to set
 */
public void setFunVariable_00869(String funVariable_00869){
    this.funVariable_00869 = funVariable_00869;
}


/**
 * 
 * 
 * @return the funVariable_00870
 */
public String getFunVariable_00870(){
    return funVariable_00870;
}


/**
 * 
 * 
 * @param funVariable_00870 the funVariable_00870 to set
 */
public void setFunVariable_00870(String funVariable_00870){
    this.funVariable_00870 = funVariable_00870;
}


/**
 * 
 * 
 * @return the funVariable_00871
 */
public String getFunVariable_00871(){
    return funVariable_00871;
}


/**
 * 
 * 
 * @param funVariable_00871 the funVariable_00871 to set
 */
public void setFunVariable_00871(String funVariable_00871){
    this.funVariable_00871 = funVariable_00871;
}


/**
 * 
 * 
 * @return the funVariable_00872
 */
public String getFunVariable_00872(){
    return funVariable_00872;
}


/**
 * 
 * 
 * @param funVariable_00872 the funVariable_00872 to set
 */
public void setFunVariable_00872(String funVariable_00872){
    this.funVariable_00872 = funVariable_00872;
}


/**
 * 
 * 
 * @return the funVariable_00873
 */
public String getFunVariable_00873(){
    return funVariable_00873;
}


/**
 * 
 * 
 * @param funVariable_00873 the funVariable_00873 to set
 */
public void setFunVariable_00873(String funVariable_00873){
    this.funVariable_00873 = funVariable_00873;
}


/**
 * 
 * 
 * @return the funVariable_00874
 */
public String getFunVariable_00874(){
    return funVariable_00874;
}


/**
 * 
 * 
 * @param funVariable_00874 the funVariable_00874 to set
 */
public void setFunVariable_00874(String funVariable_00874){
    this.funVariable_00874 = funVariable_00874;
}


/**
 * 
 * 
 * @return the funVariable_00875
 */
public String getFunVariable_00875(){
    return funVariable_00875;
}


/**
 * 
 * 
 * @param funVariable_00875 the funVariable_00875 to set
 */
public void setFunVariable_00875(String funVariable_00875){
    this.funVariable_00875 = funVariable_00875;
}


/**
 * 
 * 
 * @return the funVariable_00876
 */
public String getFunVariable_00876(){
    return funVariable_00876;
}


/**
 * 
 * 
 * @param funVariable_00876 the funVariable_00876 to set
 */
public void setFunVariable_00876(String funVariable_00876){
    this.funVariable_00876 = funVariable_00876;
}


/**
 * 
 * 
 * @return the funVariable_00877
 */
public String getFunVariable_00877(){
    return funVariable_00877;
}


/**
 * 
 * 
 * @param funVariable_00877 the funVariable_00877 to set
 */
public void setFunVariable_00877(String funVariable_00877){
    this.funVariable_00877 = funVariable_00877;
}


/**
 * 
 * 
 * @return the funVariable_00878
 */
public String getFunVariable_00878(){
    return funVariable_00878;
}


/**
 * 
 * 
 * @param funVariable_00878 the funVariable_00878 to set
 */
public void setFunVariable_00878(String funVariable_00878){
    this.funVariable_00878 = funVariable_00878;
}


/**
 * 
 * 
 * @return the funVariable_00879
 */
public String getFunVariable_00879(){
    return funVariable_00879;
}


/**
 * 
 * 
 * @param funVariable_00879 the funVariable_00879 to set
 */
public void setFunVariable_00879(String funVariable_00879){
    this.funVariable_00879 = funVariable_00879;
}


/**
 * 
 * 
 * @return the funVariable_00880
 */
public String getFunVariable_00880(){
    return funVariable_00880;
}


/**
 * 
 * 
 * @param funVariable_00880 the funVariable_00880 to set
 */
public void setFunVariable_00880(String funVariable_00880){
    this.funVariable_00880 = funVariable_00880;
}


/**
 * 
 * 
 * @return the funVariable_00881
 */
public String getFunVariable_00881(){
    return funVariable_00881;
}


/**
 * 
 * 
 * @param funVariable_00881 the funVariable_00881 to set
 */
public void setFunVariable_00881(String funVariable_00881){
    this.funVariable_00881 = funVariable_00881;
}


/**
 * 
 * 
 * @return the funVariable_00882
 */
public String getFunVariable_00882(){
    return funVariable_00882;
}


/**
 * 
 * 
 * @param funVariable_00882 the funVariable_00882 to set
 */
public void setFunVariable_00882(String funVariable_00882){
    this.funVariable_00882 = funVariable_00882;
}


/**
 * 
 * 
 * @return the funVariable_00883
 */
public String getFunVariable_00883(){
    return funVariable_00883;
}


/**
 * 
 * 
 * @param funVariable_00883 the funVariable_00883 to set
 */
public void setFunVariable_00883(String funVariable_00883){
    this.funVariable_00883 = funVariable_00883;
}


/**
 * 
 * 
 * @return the funVariable_00884
 */
public String getFunVariable_00884(){
    return funVariable_00884;
}


/**
 * 
 * 
 * @param funVariable_00884 the funVariable_00884 to set
 */
public void setFunVariable_00884(String funVariable_00884){
    this.funVariable_00884 = funVariable_00884;
}


/**
 * 
 * 
 * @return the funVariable_00885
 */
public String getFunVariable_00885(){
    return funVariable_00885;
}


/**
 * 
 * 
 * @param funVariable_00885 the funVariable_00885 to set
 */
public void setFunVariable_00885(String funVariable_00885){
    this.funVariable_00885 = funVariable_00885;
}


/**
 * 
 * 
 * @return the funVariable_00886
 */
public String getFunVariable_00886(){
    return funVariable_00886;
}


/**
 * 
 * 
 * @param funVariable_00886 the funVariable_00886 to set
 */
public void setFunVariable_00886(String funVariable_00886){
    this.funVariable_00886 = funVariable_00886;
}


/**
 * 
 * 
 * @return the funVariable_00887
 */
public String getFunVariable_00887(){
    return funVariable_00887;
}


/**
 * 
 * 
 * @param funVariable_00887 the funVariable_00887 to set
 */
public void setFunVariable_00887(String funVariable_00887){
    this.funVariable_00887 = funVariable_00887;
}


/**
 * 
 * 
 * @return the funVariable_00888
 */
public String getFunVariable_00888(){
    return funVariable_00888;
}


/**
 * 
 * 
 * @param funVariable_00888 the funVariable_00888 to set
 */
public void setFunVariable_00888(String funVariable_00888){
    this.funVariable_00888 = funVariable_00888;
}


/**
 * 
 * 
 * @return the funVariable_00889
 */
public String getFunVariable_00889(){
    return funVariable_00889;
}


/**
 * 
 * 
 * @param funVariable_00889 the funVariable_00889 to set
 */
public void setFunVariable_00889(String funVariable_00889){
    this.funVariable_00889 = funVariable_00889;
}


/**
 * 
 * 
 * @return the funVariable_00890
 */
public String getFunVariable_00890(){
    return funVariable_00890;
}


/**
 * 
 * 
 * @param funVariable_00890 the funVariable_00890 to set
 */
public void setFunVariable_00890(String funVariable_00890){
    this.funVariable_00890 = funVariable_00890;
}


/**
 * 
 * 
 * @return the funVariable_00891
 */
public String getFunVariable_00891(){
    return funVariable_00891;
}


/**
 * 
 * 
 * @param funVariable_00891 the funVariable_00891 to set
 */
public void setFunVariable_00891(String funVariable_00891){
    this.funVariable_00891 = funVariable_00891;
}


/**
 * 
 * 
 * @return the funVariable_00892
 */
public String getFunVariable_00892(){
    return funVariable_00892;
}


/**
 * 
 * 
 * @param funVariable_00892 the funVariable_00892 to set
 */
public void setFunVariable_00892(String funVariable_00892){
    this.funVariable_00892 = funVariable_00892;
}


/**
 * 
 * 
 * @return the funVariable_00893
 */
public String getFunVariable_00893(){
    return funVariable_00893;
}


/**
 * 
 * 
 * @param funVariable_00893 the funVariable_00893 to set
 */
public void setFunVariable_00893(String funVariable_00893){
    this.funVariable_00893 = funVariable_00893;
}


/**
 * 
 * 
 * @return the funVariable_00894
 */
public String getFunVariable_00894(){
    return funVariable_00894;
}


/**
 * 
 * 
 * @param funVariable_00894 the funVariable_00894 to set
 */
public void setFunVariable_00894(String funVariable_00894){
    this.funVariable_00894 = funVariable_00894;
}


/**
 * 
 * 
 * @return the funVariable_00895
 */
public String getFunVariable_00895(){
    return funVariable_00895;
}


/**
 * 
 * 
 * @param funVariable_00895 the funVariable_00895 to set
 */
public void setFunVariable_00895(String funVariable_00895){
    this.funVariable_00895 = funVariable_00895;
}


/**
 * 
 * 
 * @return the funVariable_00896
 */
public String getFunVariable_00896(){
    return funVariable_00896;
}


/**
 * 
 * 
 * @param funVariable_00896 the funVariable_00896 to set
 */
public void setFunVariable_00896(String funVariable_00896){
    this.funVariable_00896 = funVariable_00896;
}


/**
 * 
 * 
 * @return the funVariable_00897
 */
public String getFunVariable_00897(){
    return funVariable_00897;
}


/**
 * 
 * 
 * @param funVariable_00897 the funVariable_00897 to set
 */
public void setFunVariable_00897(String funVariable_00897){
    this.funVariable_00897 = funVariable_00897;
}


/**
 * 
 * 
 * @return the funVariable_00898
 */
public String getFunVariable_00898(){
    return funVariable_00898;
}


/**
 * 
 * 
 * @param funVariable_00898 the funVariable_00898 to set
 */
public void setFunVariable_00898(String funVariable_00898){
    this.funVariable_00898 = funVariable_00898;
}


/**
 * 
 * 
 * @return the funVariable_00899
 */
public String getFunVariable_00899(){
    return funVariable_00899;
}


/**
 * 
 * 
 * @param funVariable_00899 the funVariable_00899 to set
 */
public void setFunVariable_00899(String funVariable_00899){
    this.funVariable_00899 = funVariable_00899;
}


/**
 * 
 * 
 * @return the funVariable_00900
 */
public String getFunVariable_00900(){
    return funVariable_00900;
}


/**
 * 
 * 
 * @param funVariable_00900 the funVariable_00900 to set
 */
public void setFunVariable_00900(String funVariable_00900){
    this.funVariable_00900 = funVariable_00900;
}
private String funVariable_00874;
 private String funVariable_00875;
 private String funVariable_00876;
 private String funVariable_00877;
 private String funVariable_00878;
 private String funVariable_00879;
 private String funVariable_00880;
 private String funVariable_00881;
 private String funVariable_00882;
 private String funVariable_00883;
 private String funVariable_00884;
 private String funVariable_00885;
 private String funVariable_00886;
 private String funVariable_00887;
 private String funVariable_00888;
 private String funVariable_00889;
 private String funVariable_00890;
 private String funVariable_00891;
 private String funVariable_00892;
 private String funVariable_00893;
 private String funVariable_00894;
 private String funVariable_00895;
 private String funVariable_00896;
 private String funVariable_00897;
 private String funVariable_00898;
 private String funVariable_00899;
 private String funVariable_00900;
 
 private String omcVariable_a00001 ;
 private String omcVariable_a00002 ;
 private String omcVariable_a00003 ;
 private String omcVariable_a00004 ;
 private String omcVariable_a00005 ;
 private String omcVariable_a00006 ;
 private String omcVariable_a00007 ;
 private String omcVariable_a00008 ;
 private String omcVariable_a00009 ;
 private String omcVariable_a00010 ;
 private String omcVariable_a00011 ;
 private String omcVariable_a00012 ;
 private String omcVariable_a00013 ;
 private String omcVariable_a00014 ;
 private String omcVariable_a00015 ;
 private String omcVariable_a00016 ;
 private String omcVariable_a00017 ;
 private String omcVariable_a00018 ;
 private String omcVariable_a00019 ;
 private String omcVariable_a00020 ;
 private String omcVariable_a00021 ;
 private String omcVariable_a00022 ;
 private String omcVariable_a00023 ;
 private String omcVariable_a00024 ;
 private String omcVariable_a00025 ;
 private String omcVariable_a00026 ;
 private String omcVariable_a00027 ;
 private String omcVariable_a00028 ;
 private String omcVariable_a00029 ;
 private String omcVariable_a00030 ;
 private String omcVariable_a00031 ;
 private String omcVariable_a00032 ;
 private String omcVariable_a00033 ;
 private String omcVariable_a00034 ;
 private String omcVariable_a00035 ;
 private String omcVariable_a00036 ;
 private String omcVariable_a00037 ;
 private String omcVariable_a00038 ;
 private String omcVariable_a00039 ;
 private String omcVariable_a00040 ;
 private String omcVariable_a00041 ;
 private String omcVariable_a00042 ;
 private String omcVariable_a00043 ;
 private String omcVariable_a00044 ;
 private String omcVariable_a00045 ;
 private String omcVariable_a00046 ;
 private String omcVariable_a00047 ;
 private String omcVariable_a00048 ;
 private String omcVariable_a00049 ;
 private String omcVariable_a00050 ;
 private String omcVariable_a00051 ;
 private String omcVariable_a00052 ;
 private String omcVariable_a00053 ;
 private String omcVariable_a00054 ;
 private String omcVariable_a00055 ;
 private String omcVariable_a00056 ;
 private String omcVariable_a00057 ;
 private String omcVariable_a00058 ;
 private String omcVariable_a00059 ;
 private String omcVariable_a00060 ;
 private String omcVariable_a00061 ;
 private String omcVariable_a00062 ;
 private String omcVariable_a00063 ;
 private String omcVariable_a00064 ;
 private String omcVariable_a00065 ;
 private String omcVariable_a00066 ;
 private String omcVariable_a00067 ;
 private String omcVariable_a00068 ;
 private String omcVariable_a00069 ;
 private String omcVariable_a00070 ;
 private String omcVariable_a00071 ;
 private String omcVariable_a00072 ;
 private String omcVariable_a00073 ;
 private String omcVariable_a00074 ;
 private String omcVariable_a00075 ;
 private String omcVariable_a00076 ;
 private String omcVariable_a00077 ;
 private String omcVariable_a00078 ;
 private String omcVariable_a00079 ;
 private String omcVariable_a00080 ;
 private String omcVariable_a00081 ;
 private String omcVariable_a00082 ;
 private String omcVariable_a00083 ;
 private String omcVariable_a00084 ;
 private String omcVariable_a00085 ;
 private String omcVariable_a00086 ;
 private String omcVariable_a00087 ;
 private String omcVariable_a00088 ;
 private String omcVariable_a00089 ;
 private String omcVariable_a00090 ;
 private String omcVariable_a00091 ;
 private String omcVariable_a00092 ;
 private String omcVariable_a00093 ;
 private String omcVariable_a00094 ;
 private String omcVariable_a00095 ;
 private String omcVariable_a00096 ;
 private String omcVariable_a00097 ;
 private String omcVariable_a00098 ;
 private String omcVariable_a00099 ;
 private String omcVariable_a00100 ;
 private String omcVariable_a00101 ;
 private String omcVariable_a00102 ;
 private String omcVariable_a00103 ;
 private String omcVariable_a00104 ;
 private String omcVariable_a00105 ;
 private String omcVariable_a00106 ;
 private String omcVariable_a00107 ;
 private String omcVariable_a00108 ;
 private String omcVariable_a00109 ;
 private String omcVariable_a00110 ;
 private String omcVariable_a00111 ;
 private String omcVariable_a00112 ;
 private String omcVariable_a00113 ;
 private String omcVariable_a00114 ;
 private String omcVariable_a00115 ;
 private String omcVariable_a00116 ;
 private String omcVariable_a00117 ;
 private String omcVariable_a00118 ;
 private String omcVariable_a00119 ;
 private String omcVariable_a00120 ;
 private String omcVariable_a00121 ;
 private String omcVariable_a00122 ;
 private String omcVariable_a00123 ;
 private String omcVariable_a00124 ;
 private String omcVariable_a00125 ;
 private String omcVariable_a00126 ;
 private String omcVariable_a00127 ;
 private String omcVariable_a00128 ;
 private String omcVariable_a00129 ;
 private String omcVariable_a00130 ;
 private String omcVariable_a00131 ;
 private String omcVariable_a00132 ;
 private String omcVariable_a00133 ;
 private String omcVariable_a00134 ;
 private String omcVariable_a00135 ;
 private String omcVariable_a00136 ;
 private String omcVariable_a00137 ;
 private String omcVariable_a00138 ;
 private String omcVariable_a00139 ;
 private String omcVariable_a00140 ;
 private String omcVariable_a00141 ;
 private String omcVariable_a00142 ;
 private String omcVariable_a00143 ;
 private String omcVariable_a00144 ;
 private String omcVariable_a00145 ;
 private String omcVariable_a00146 ;
 private String omcVariable_a00147 ;
 private String omcVariable_a00148 ;
 private String omcVariable_a00149 ;
 private String omcVariable_a00150 ;
 private String omcVariable_a00151 ;
 private String omcVariable_a00152 ;
 private String omcVariable_a00153 ;
 private String omcVariable_a00154 ;
 private String omcVariable_a00155 ;
 private String omcVariable_a00156 ;
 private String omcVariable_a00157 ;
 private String omcVariable_a00158 ;
 private String omcVariable_a00159 ;
 private String omcVariable_a00160 ;
 private String omcVariable_a00161 ;
 private String omcVariable_a00162 ;
 private String omcVariable_a00163 ;
 private String omcVariable_a00164 ;
 private String omcVariable_a00165 ;
 private String omcVariable_a00166 ;
 private String omcVariable_a00167 ;
 private String omcVariable_a00168 ;
 private String omcVariable_a00169 ;
 private String omcVariable_a00170 ;
 private String omcVariable_a00171 ;
 private String omcVariable_a00172 ;
 private String omcVariable_a00173 ;
 private String omcVariable_a00174 ;
 private String omcVariable_a00175 ;
 private String omcVariable_a00176 ;
 private String omcVariable_a00177 ;
 private String omcVariable_a00178 ;
 private String omcVariable_a00179 ;
 private String omcVariable_a00180 ;
 private String omcVariable_a00181 ;
 private String omcVariable_a00182 ;
 private String omcVariable_a00183 ;
 private String omcVariable_a00184 ;
 private String omcVariable_a00185 ;
 private String omcVariable_a00186 ;
 private String omcVariable_a00187 ;
 private String omcVariable_a00188 ;
 private String omcVariable_a00189 ;
 private String omcVariable_a00190 ;
 private String omcVariable_a00191 ;
 private String omcVariable_a00192 ;
 private String omcVariable_a00193 ;
 private String omcVariable_a00194 ;
 private String omcVariable_a00195 ;
 private String omcVariable_a00196 ;
 private String omcVariable_a00197 ;
 private String omcVariable_a00198 ;
 private String omcVariable_a00199 ;
 private String omcVariable_a00200 ;
 private String omcVariable_a00201 ;
 private String omcVariable_a00202 ;
 private String omcVariable_a00203 ;
 private String omcVariable_a00204 ;
 private String omcVariable_a00205 ;
 private String omcVariable_a00206 ;
 private String omcVariable_a00207 ;
 private String omcVariable_a00208 ;
 private String omcVariable_a00209 ;
 private String omcVariable_a00210 ;
 private String omcVariable_a00211 ;
 private String omcVariable_a00212 ;
 private String omcVariable_a00213 ;
 private String omcVariable_a00214 ;
 private String omcVariable_a00215 ;
 private String omcVariable_a00216 ;
 private String omcVariable_a00217 ;
 private String omcVariable_a00218 ;
 private String omcVariable_a00219 ;
 private String omcVariable_a00220 ;
 private String omcVariable_a00221 ;
 private String omcVariable_a00222 ;
 private String omcVariable_a00223 ;
 private String omcVariable_a00224 ;
 private String omcVariable_a00225 ;
 private String omcVariable_a00226 ;
 private String omcVariable_a00227 ;
 private String omcVariable_a00228 ;
 private String omcVariable_a00229 ;
 private String omcVariable_a00230 ;
 private String omcVariable_a00231 ;
 private String omcVariable_a00232 ;
 private String omcVariable_a00233 ;
 private String omcVariable_a00234 ;
 private String omcVariable_a00235 ;
 private String omcVariable_a00236 ;
 private String omcVariable_a00237 ;
 private String omcVariable_a00238 ;
 private String omcVariable_a00239 ;
 private String omcVariable_a00240 ;
 private String omcVariable_a00241 ;
 private String omcVariable_a00242 ;
 private String omcVariable_a00243 ;
 private String omcVariable_a00244 ;
 private String omcVariable_a00245 ;
 private String omcVariable_a00246 ;
 private String omcVariable_a00247 ;
 private String omcVariable_a00248 ;
 private String omcVariable_a00249 ;
 private String omcVariable_a00250 ;
 private String omcVariable_a00251 ;
 private String omcVariable_a00252 ;
 private String omcVariable_a00253 ;
 private String omcVariable_a00254 ;
 private String omcVariable_a00255 ;
 private String omcVariable_a00256 ;
 private String omcVariable_a00257 ;
 private String omcVariable_a00258 ;
 private String omcVariable_a00259 ;
 private String omcVariable_a00260 ;
 private String omcVariable_a00261 ;
 private String omcVariable_a00262 ;
 private String omcVariable_a00263 ;
 private String omcVariable_a00264 ;
 private String omcVariable_a00265 ;
 private String omcVariable_a00266 ;
 private String omcVariable_a00267 ;
 private String omcVariable_a00268 ;
 private String omcVariable_a00269 ;
 private String omcVariable_a00270 ;
 private String omcVariable_a00271 ;
 private String omcVariable_a00272 ;
 private String omcVariable_a00273 ;
 private String omcVariable_a00274 ;
 private String omcVariable_a00275 ;
 private String omcVariable_a00276 ;
 private String omcVariable_a00277 ;
 private String omcVariable_a00278 ;
 private String omcVariable_a00279 ;
 private String omcVariable_a00280 ;
 private String omcVariable_a00281 ;
 private String omcVariable_a00282 ;
 private String omcVariable_a00283 ;
 private String omcVariable_a00284 ;
 private String omcVariable_a00285 ;
 private String omcVariable_a00286 ;
 private String omcVariable_a00287 ;
 private String omcVariable_a00288 ;
 private String omcVariable_a00289 ;
 private String omcVariable_a00290 ;
 private String omcVariable_a00291 ;
 private String omcVariable_a00292 ;
 private String omcVariable_a00293 ;
 private String omcVariable_a00294 ;
 private String omcVariable_a00295 ;
 private String omcVariable_a00296 ;
 private String omcVariable_a00297 ;
 private String omcVariable_a00298 ;
 private String omcVariable_a00299 ;
 private String omcVariable_a00300 ;
 private String omcVariable_a00301 ;
 private String omcVariable_a00302 ;
 private String omcVariable_a00303 ;
 private String omcVariable_a00304 ;
 private String omcVariable_a00305 ;
 private String omcVariable_a00306 ;
 private String omcVariable_a00307 ;
 private String omcVariable_a00308 ;
 private String omcVariable_a00309 ;
 private String omcVariable_a00310 ;
 private String omcVariable_a00311 ;
 private String omcVariable_a00312 ;
 private String omcVariable_a00313 ;
 private String omcVariable_a00314 ;
 private String omcVariable_a00315 ;
 private String omcVariable_a00316 ;
 private String omcVariable_a00317 ;
 private String omcVariable_a00318 ;
 private String omcVariable_a00319 ;
 private String omcVariable_a00320 ;
 private String omcVariable_a00321 ;
 private String omcVariable_a00322 ;
 private String omcVariable_a00323 ;
 private String omcVariable_a00324 ;
 private String omcVariable_a00325 ;
 private String omcVariable_a00326 ;
 private String omcVariable_a00327 ;
 private String omcVariable_a00328 ;
 private String omcVariable_a00329 ;
 private String omcVariable_a00330 ;
 private String omcVariable_a00331 ;
 private String omcVariable_a00332 ;
 private String omcVariable_a00333 ;
 private String omcVariable_a00334 ;
 private String omcVariable_a00335 ;
 private String omcVariable_a00336 ;
 private String omcVariable_a00337 ;
 private String omcVariable_a00338 ;
 private String omcVariable_a00339 ;
 private String omcVariable_a00340 ;
 private String omcVariable_a00341 ;
 private String omcVariable_a00342 ;
 private String omcVariable_a00343 ;
 private String omcVariable_a00344 ;
 private String omcVariable_a00345 ;
 private String omcVariable_a00346 ;
 private String omcVariable_a00347 ;
 private String omcVariable_a00348 ;
 private String omcVariable_a00349 ;
 private String omcVariable_a00350 ;
 private String omcVariable_a00351 ;
 private String omcVariable_a00352 ;
 private String omcVariable_a00353 ;
 private String omcVariable_a00354 ;
 private String omcVariable_a00355 ;
 private String omcVariable_a00356 ;
 private String omcVariable_a00357 ;
 private String omcVariable_a00358 ;
 private String omcVariable_a00359 ;
 private String omcVariable_a00360 ;
 private String omcVariable_a00361 ;
 private String omcVariable_a00362 ;
 private String omcVariable_a00363 ;
 private String omcVariable_a00364 ;
 private String omcVariable_a00365 ;
 private String omcVariable_a00366 ;
 private String omcVariable_a00367 ;
 private String omcVariable_a00368 ;
 private String omcVariable_a00369 ;
 private String omcVariable_a00370 ;
 private String omcVariable_a00371 ;
 private String omcVariable_a00372 ;
 private String omcVariable_a00373 ;
 private String omcVariable_a00374 ;
 private String omcVariable_a00375 ;
 private String omcVariable_a00376 ;
 private String omcVariable_a00377 ;
 private String omcVariable_a00378 ;
 private String omcVariable_a00379 ;
 private String omcVariable_a00380 ;
 private String omcVariable_a00381 ;
 private String omcVariable_a00382 ;
 private String omcVariable_a00383 ;
 private String omcVariable_a00384 ;
 private String omcVariable_a00385 ;
 private String omcVariable_a00386 ;
 private String omcVariable_a00387 ;
 private String omcVariable_a00388 ;
 private String omcVariable_a00389 ;
 private String omcVariable_a00390 ;
 private String omcVariable_a00391 ;
 private String omcVariable_a00392 ;
 private String omcVariable_a00393 ;
 private String omcVariable_a00394 ;
 private String omcVariable_a00395 ;
 private String omcVariable_a00396 ;
 private String omcVariable_a00397 ;
 private String omcVariable_a00398 ;
 private String omcVariable_a00399 ;
 private String omcVariable_a00400 ;
 private String omcVariable_a00401 ;
 private String omcVariable_a00402 ;
 private String omcVariable_a00403 ;
 private String omcVariable_a00404 ;
 private String omcVariable_a00405 ;
 private String omcVariable_a00406 ;
 private String omcVariable_a00407 ;
 private String omcVariable_a00408 ;
 private String omcVariable_a00409 ;
 private String omcVariable_a00410 ;
 private String omcVariable_a00411 ;
 private String omcVariable_a00412 ;
 private String omcVariable_a00413 ;
 private String omcVariable_a00414 ;
 private String omcVariable_a00415 ;
 private String omcVariable_a00416 ;
 private String omcVariable_a00417 ;
 private String omcVariable_a00418 ;
 private String omcVariable_a00419 ;
 private String omcVariable_a00420 ;
 private String omcVariable_a00421 ;
 private String omcVariable_a00422 ;
 private String omcVariable_a00423 ;
 private String omcVariable_a00424 ;
 private String omcVariable_a00425 ;
 private String omcVariable_a00426 ;
 private String omcVariable_a00427 ;
 private String omcVariable_a00428 ;
 private String omcVariable_a00429 ;
 private String omcVariable_a00430 ;
 private String omcVariable_a00431 ;
 private String omcVariable_a00432 ;
 private String omcVariable_a00433 ;
 private String omcVariable_a00434 ;
 private String omcVariable_a00435 ;
 private String omcVariable_a00436 ;
 private String omcVariable_a00437 ;
 private String omcVariable_a00438 ;
 private String omcVariable_a00439 ;
 private String omcVariable_a00440 ;
 private String omcVariable_a00441 ;
 private String omcVariable_a00442 ;
 private String omcVariable_a00443 ;
 private String omcVariable_a00444 ;
 private String omcVariable_a00445 ;
 private String omcVariable_a00446 ;
 private String omcVariable_a00447 ;
 private String omcVariable_a00448 ;
 private String omcVariable_a00449 ;
 private String omcVariable_a00450 ;
 private String omcVariable_a00451 ;
 private String omcVariable_a00452 ;
 private String omcVariable_a00453 ;
 private String omcVariable_a00454 ;
 private String omcVariable_a00455 ;
 private String omcVariable_a00456 ;
 private String omcVariable_a00457 ;
 private String omcVariable_a00458 ;
 private String omcVariable_a00459 ;
 private String omcVariable_a00460 ;
 private String omcVariable_a00461 ;
 private String omcVariable_a00462 ;
 private String omcVariable_a00463 ;
 private String omcVariable_a00464 ;
 private String omcVariable_a00465 ;
 private String omcVariable_a00466 ;
 private String omcVariable_a00467 ;
 private String omcVariable_a00468 ;
 private String omcVariable_a00469 ;
 private String omcVariable_a00470 ;
 private String omcVariable_a00471 ;
 private String omcVariable_a00472 ;
 private String omcVariable_a00473 ;
 private String omcVariable_a00474 ;
 private String omcVariable_a00475 ;
 private String omcVariable_a00476 ;
 private String omcVariable_a00477 ;
 private String omcVariable_a00478 ;
 private String omcVariable_a00479 ;
 private String omcVariable_a00480 ;
 private String omcVariable_a00481 ;
 private String omcVariable_a00482 ;
 private String omcVariable_a00483 ;
 private String omcVariable_a00484 ;
 private String omcVariable_a00485 ;
 private String omcVariable_a00486 ;
 private String omcVariable_a00487 ;
 private String omcVariable_a00488 ;
 private String omcVariable_a00489 ;
 private String omcVariable_a00490 ;
 private String omcVariable_a00491 ;
 private String omcVariable_a00492 ;
 private String omcVariable_a00493 ;
 private String omcVariable_a00494 ;
 private String omcVariable_a00495 ;
 private String omcVariable_a00496 ;
 private String omcVariable_a00497 ;
 private String omcVariable_a00498 ;
 private String omcVariable_a00499 ;
 private String omcVariable_a00500 ;

public String getFunVariable_00001(){
    return funVariable_00001;
}

public void setFunVariable_00001(String funVariable_00001){
    this.funVariable_00001 = funVariable_00001;
}

public String getFunVariable_00002(){
    return funVariable_00002;
}

public void setFunVariable_00002(String funVariable_00002){
    this.funVariable_00002 = funVariable_00002;
}

public String getFunVariable_00003(){
    return funVariable_00003;
}

public void setFunVariable_00003(String funVariable_00003){
    this.funVariable_00003 = funVariable_00003;
}

public String getFunVariable_00004(){
    return funVariable_00004;
}

public void setFunVariable_00004(String funVariable_00004){
    this.funVariable_00004 = funVariable_00004;
}

public String getFunVariable_00005(){
    return funVariable_00005;
}

public void setFunVariable_00005(String funVariable_00005){
    this.funVariable_00005 = funVariable_00005;
}

public String getFunVariable_00006(){
    return funVariable_00006;
}

public void setFunVariable_00006(String funVariable_00006){
    this.funVariable_00006 = funVariable_00006;
}

public String getFunVariable_00007(){
    return funVariable_00007;
}

public void setFunVariable_00007(String funVariable_00007){
    this.funVariable_00007 = funVariable_00007;
}

public String getFunVariable_00008(){
    return funVariable_00008;
}

public void setFunVariable_00008(String funVariable_00008){
    this.funVariable_00008 = funVariable_00008;
}

public String getFunVariable_00009(){
    return funVariable_00009;
}

public void setFunVariable_00009(String funVariable_00009){
    this.funVariable_00009 = funVariable_00009;
}

public String getFunVariable_00010(){
    return funVariable_00010;
}

public void setFunVariable_00010(String funVariable_00010){
    this.funVariable_00010 = funVariable_00010;
}

public String getFunVariable_00011(){
    return funVariable_00011;
}

public void setFunVariable_00011(String funVariable_00011){
    this.funVariable_00011 = funVariable_00011;
}

public String getFunVariable_00012(){
    return funVariable_00012;
}

public void setFunVariable_00012(String funVariable_00012){
    this.funVariable_00012 = funVariable_00012;
}

public String getFunVariable_00013(){
    return funVariable_00013;
}

public void setFunVariable_00013(String funVariable_00013){
    this.funVariable_00013 = funVariable_00013;
}

public String getFunVariable_00014(){
    return funVariable_00014;
}

public void setFunVariable_00014(String funVariable_00014){
    this.funVariable_00014 = funVariable_00014;
}

public String getFunVariable_00015(){
    return funVariable_00015;
}

public void setFunVariable_00015(String funVariable_00015){
    this.funVariable_00015 = funVariable_00015;
}

public String getFunVariable_00016(){
    return funVariable_00016;
}

public void setFunVariable_00016(String funVariable_00016){
    this.funVariable_00016 = funVariable_00016;
}

public String getFunVariable_00017(){
    return funVariable_00017;
}

public void setFunVariable_00017(String funVariable_00017){
    this.funVariable_00017 = funVariable_00017;
}

public String getFunVariable_00018(){
    return funVariable_00018;
}

public void setFunVariable_00018(String funVariable_00018){
    this.funVariable_00018 = funVariable_00018;
}

public String getFunVariable_00019(){
    return funVariable_00019;
}

public void setFunVariable_00019(String funVariable_00019){
    this.funVariable_00019 = funVariable_00019;
}

public String getFunVariable_00020(){
    return funVariable_00020;
}

public void setFunVariable_00020(String funVariable_00020){
    this.funVariable_00020 = funVariable_00020;
}

public String getFunVariable_00021(){
    return funVariable_00021;
}

public void setFunVariable_00021(String funVariable_00021){
    this.funVariable_00021 = funVariable_00021;
}

public String getFunVariable_00022(){
    return funVariable_00022;
}

public void setFunVariable_00022(String funVariable_00022){
    this.funVariable_00022 = funVariable_00022;
}

public String getFunVariable_00023(){
    return funVariable_00023;
}

public void setFunVariable_00023(String funVariable_00023){
    this.funVariable_00023 = funVariable_00023;
}

public String getFunVariable_00024(){
    return funVariable_00024;
}

public void setFunVariable_00024(String funVariable_00024){
    this.funVariable_00024 = funVariable_00024;
}

public String getFunVariable_00025(){
    return funVariable_00025;
}

public void setFunVariable_00025(String funVariable_00025){
    this.funVariable_00025 = funVariable_00025;
}

public String getFunVariable_00026(){
    return funVariable_00026;
}

public void setFunVariable_00026(String funVariable_00026){
    this.funVariable_00026 = funVariable_00026;
}

public String getFunVariable_00027(){
    return funVariable_00027;
}

public void setFunVariable_00027(String funVariable_00027){
    this.funVariable_00027 = funVariable_00027;
}

public String getFunVariable_00028(){
    return funVariable_00028;
}

public void setFunVariable_00028(String funVariable_00028){
    this.funVariable_00028 = funVariable_00028;
}

public String getFunVariable_00029(){
    return funVariable_00029;
}

public void setFunVariable_00029(String funVariable_00029){
    this.funVariable_00029 = funVariable_00029;
}

public String getFunVariable_00030(){
    return funVariable_00030;
}

public void setFunVariable_00030(String funVariable_00030){
    this.funVariable_00030 = funVariable_00030;
}

public String getFunVariable_00031(){
    return funVariable_00031;
}

public void setFunVariable_00031(String funVariable_00031){
    this.funVariable_00031 = funVariable_00031;
}

public String getFunVariable_00032(){
    return funVariable_00032;
}

public void setFunVariable_00032(String funVariable_00032){
    this.funVariable_00032 = funVariable_00032;
}

public String getFunVariable_00033(){
    return funVariable_00033;
}

public void setFunVariable_00033(String funVariable_00033){
    this.funVariable_00033 = funVariable_00033;
}

public String getFunVariable_00034(){
    return funVariable_00034;
}

public void setFunVariable_00034(String funVariable_00034){
    this.funVariable_00034 = funVariable_00034;
}

public String getFunVariable_00035(){
    return funVariable_00035;
}

public void setFunVariable_00035(String funVariable_00035){
    this.funVariable_00035 = funVariable_00035;
}

public String getFunVariable_00036(){
    return funVariable_00036;
}

public void setFunVariable_00036(String funVariable_00036){
    this.funVariable_00036 = funVariable_00036;
}

public String getFunVariable_00037(){
    return funVariable_00037;
}

public void setFunVariable_00037(String funVariable_00037){
    this.funVariable_00037 = funVariable_00037;
}

public String getFunVariable_00038(){
    return funVariable_00038;
}

public void setFunVariable_00038(String funVariable_00038){
    this.funVariable_00038 = funVariable_00038;
}

public String getFunVariable_00039(){
    return funVariable_00039;
}

public void setFunVariable_00039(String funVariable_00039){
    this.funVariable_00039 = funVariable_00039;
}

public String getFunVariable_00040(){
    return funVariable_00040;
}

public void setFunVariable_00040(String funVariable_00040){
    this.funVariable_00040 = funVariable_00040;
}

public String getFunVariable_00041(){
    return funVariable_00041;
}

public void setFunVariable_00041(String funVariable_00041){
    this.funVariable_00041 = funVariable_00041;
}

public String getFunVariable_00042(){
    return funVariable_00042;
}

public void setFunVariable_00042(String funVariable_00042){
    this.funVariable_00042 = funVariable_00042;
}

public String getFunVariable_00043(){
    return funVariable_00043;
}

public void setFunVariable_00043(String funVariable_00043){
    this.funVariable_00043 = funVariable_00043;
}

public String getFunVariable_00044(){
    return funVariable_00044;
}

public void setFunVariable_00044(String funVariable_00044){
    this.funVariable_00044 = funVariable_00044;
}

public String getFunVariable_00045(){
    return funVariable_00045;
}

public void setFunVariable_00045(String funVariable_00045){
    this.funVariable_00045 = funVariable_00045;
}

public String getFunVariable_00046(){
    return funVariable_00046;
}

public void setFunVariable_00046(String funVariable_00046){
    this.funVariable_00046 = funVariable_00046;
}

public String getFunVariable_00047(){
    return funVariable_00047;
}

public void setFunVariable_00047(String funVariable_00047){
    this.funVariable_00047 = funVariable_00047;
}

public String getFunVariable_00048(){
    return funVariable_00048;
}

public void setFunVariable_00048(String funVariable_00048){
    this.funVariable_00048 = funVariable_00048;
}

public String getFunVariable_00049(){
    return funVariable_00049;
}

public void setFunVariable_00049(String funVariable_00049){
    this.funVariable_00049 = funVariable_00049;
}

public String getFunVariable_00050(){
    return funVariable_00050;
}

public void setFunVariable_00050(String funVariable_00050){
    this.funVariable_00050 = funVariable_00050;
}

public String getFunVariable_00051(){
    return funVariable_00051;
}

public void setFunVariable_00051(String funVariable_00051){
    this.funVariable_00051 = funVariable_00051;
}

public String getFunVariable_00052(){
    return funVariable_00052;
}

public void setFunVariable_00052(String funVariable_00052){
    this.funVariable_00052 = funVariable_00052;
}

public String getFunVariable_00053(){
    return funVariable_00053;
}

public void setFunVariable_00053(String funVariable_00053){
    this.funVariable_00053 = funVariable_00053;
}

public String getFunVariable_00054(){
    return funVariable_00054;
}

public void setFunVariable_00054(String funVariable_00054){
    this.funVariable_00054 = funVariable_00054;
}

public String getFunVariable_00055(){
    return funVariable_00055;
}

public void setFunVariable_00055(String funVariable_00055){
    this.funVariable_00055 = funVariable_00055;
}

public String getFunVariable_00056(){
    return funVariable_00056;
}

public void setFunVariable_00056(String funVariable_00056){
    this.funVariable_00056 = funVariable_00056;
}

public String getFunVariable_00057(){
    return funVariable_00057;
}

public void setFunVariable_00057(String funVariable_00057){
    this.funVariable_00057 = funVariable_00057;
}

public String getFunVariable_00058(){
    return funVariable_00058;
}

public void setFunVariable_00058(String funVariable_00058){
    this.funVariable_00058 = funVariable_00058;
}

public String getFunVariable_00059(){
    return funVariable_00059;
}

public void setFunVariable_00059(String funVariable_00059){
    this.funVariable_00059 = funVariable_00059;
}

public String getFunVariable_00060(){
    return funVariable_00060;
}

public void setFunVariable_00060(String funVariable_00060){
    this.funVariable_00060 = funVariable_00060;
}

public String getFunVariable_00061(){
    return funVariable_00061;
}

public void setFunVariable_00061(String funVariable_00061){
    this.funVariable_00061 = funVariable_00061;
}

public String getFunVariable_00062(){
    return funVariable_00062;
}

public void setFunVariable_00062(String funVariable_00062){
    this.funVariable_00062 = funVariable_00062;
}

public String getFunVariable_00063(){
    return funVariable_00063;
}

public void setFunVariable_00063(String funVariable_00063){
    this.funVariable_00063 = funVariable_00063;
}

public String getFunVariable_00064(){
    return funVariable_00064;
}

public void setFunVariable_00064(String funVariable_00064){
    this.funVariable_00064 = funVariable_00064;
}

public String getFunVariable_00065(){
    return funVariable_00065;
}

public void setFunVariable_00065(String funVariable_00065){
    this.funVariable_00065 = funVariable_00065;
}

public String getFunVariable_00066(){
    return funVariable_00066;
}

public void setFunVariable_00066(String funVariable_00066){
    this.funVariable_00066 = funVariable_00066;
}

public String getFunVariable_00067(){
    return funVariable_00067;
}

public void setFunVariable_00067(String funVariable_00067){
    this.funVariable_00067 = funVariable_00067;
}

public String getFunVariable_00068(){
    return funVariable_00068;
}

public void setFunVariable_00068(String funVariable_00068){
    this.funVariable_00068 = funVariable_00068;
}

public String getFunVariable_00069(){
    return funVariable_00069;
}

public void setFunVariable_00069(String funVariable_00069){
    this.funVariable_00069 = funVariable_00069;
}

public String getFunVariable_00070(){
    return funVariable_00070;
}

public void setFunVariable_00070(String funVariable_00070){
    this.funVariable_00070 = funVariable_00070;
}

public String getFunVariable_00071(){
    return funVariable_00071;
}

public void setFunVariable_00071(String funVariable_00071){
    this.funVariable_00071 = funVariable_00071;
}

public String getFunVariable_00072(){
    return funVariable_00072;
}

public void setFunVariable_00072(String funVariable_00072){
    this.funVariable_00072 = funVariable_00072;
}

public String getFunVariable_00073(){
    return funVariable_00073;
}

public void setFunVariable_00073(String funVariable_00073){
    this.funVariable_00073 = funVariable_00073;
}

public String getFunVariable_00074(){
    return funVariable_00074;
}

public void setFunVariable_00074(String funVariable_00074){
    this.funVariable_00074 = funVariable_00074;
}

public String getFunVariable_00075(){
    return funVariable_00075;
}

public void setFunVariable_00075(String funVariable_00075){
    this.funVariable_00075 = funVariable_00075;
}

public String getFunVariable_00076(){
    return funVariable_00076;
}

public void setFunVariable_00076(String funVariable_00076){
    this.funVariable_00076 = funVariable_00076;
}

public String getFunVariable_00077(){
    return funVariable_00077;
}

public void setFunVariable_00077(String funVariable_00077){
    this.funVariable_00077 = funVariable_00077;
}

public String getFunVariable_00078(){
    return funVariable_00078;
}

public void setFunVariable_00078(String funVariable_00078){
    this.funVariable_00078 = funVariable_00078;
}

public String getFunVariable_00079(){
    return funVariable_00079;
}

public void setFunVariable_00079(String funVariable_00079){
    this.funVariable_00079 = funVariable_00079;
}

public String getFunVariable_00080(){
    return funVariable_00080;
}

public void setFunVariable_00080(String funVariable_00080){
    this.funVariable_00080 = funVariable_00080;
}

public String getFunVariable_00081(){
    return funVariable_00081;
}

public void setFunVariable_00081(String funVariable_00081){
    this.funVariable_00081 = funVariable_00081;
}

public String getFunVariable_00082(){
    return funVariable_00082;
}

public void setFunVariable_00082(String funVariable_00082){
    this.funVariable_00082 = funVariable_00082;
}

public String getFunVariable_00083(){
    return funVariable_00083;
}

public void setFunVariable_00083(String funVariable_00083){
    this.funVariable_00083 = funVariable_00083;
}

public String getFunVariable_00084(){
    return funVariable_00084;
}

public void setFunVariable_00084(String funVariable_00084){
    this.funVariable_00084 = funVariable_00084;
}

public String getFunVariable_00085(){
    return funVariable_00085;
}

public void setFunVariable_00085(String funVariable_00085){
    this.funVariable_00085 = funVariable_00085;
}

public String getFunVariable_00086(){
    return funVariable_00086;
}

public void setFunVariable_00086(String funVariable_00086){
    this.funVariable_00086 = funVariable_00086;
}

public String getFunVariable_00087(){
    return funVariable_00087;
}

public void setFunVariable_00087(String funVariable_00087){
    this.funVariable_00087 = funVariable_00087;
}

public String getFunVariable_00088(){
    return funVariable_00088;
}

public void setFunVariable_00088(String funVariable_00088){
    this.funVariable_00088 = funVariable_00088;
}

public String getFunVariable_00089(){
    return funVariable_00089;
}

public void setFunVariable_00089(String funVariable_00089){
    this.funVariable_00089 = funVariable_00089;
}

public String getFunVariable_00090(){
    return funVariable_00090;
}

public void setFunVariable_00090(String funVariable_00090){
    this.funVariable_00090 = funVariable_00090;
}

public String getFunVariable_00091(){
    return funVariable_00091;
}

public void setFunVariable_00091(String funVariable_00091){
    this.funVariable_00091 = funVariable_00091;
}

public String getFunVariable_00092(){
    return funVariable_00092;
}

public void setFunVariable_00092(String funVariable_00092){
    this.funVariable_00092 = funVariable_00092;
}

public String getFunVariable_00093(){
    return funVariable_00093;
}

public void setFunVariable_00093(String funVariable_00093){
    this.funVariable_00093 = funVariable_00093;
}

public String getFunVariable_00094(){
    return funVariable_00094;
}

public void setFunVariable_00094(String funVariable_00094){
    this.funVariable_00094 = funVariable_00094;
}

public String getFunVariable_00095(){
    return funVariable_00095;
}

public void setFunVariable_00095(String funVariable_00095){
    this.funVariable_00095 = funVariable_00095;
}

public String getFunVariable_00096(){
    return funVariable_00096;
}

public void setFunVariable_00096(String funVariable_00096){
    this.funVariable_00096 = funVariable_00096;
}

public String getFunVariable_00097(){
    return funVariable_00097;
}

public void setFunVariable_00097(String funVariable_00097){
    this.funVariable_00097 = funVariable_00097;
}

public String getFunVariable_00098(){
    return funVariable_00098;
}

public void setFunVariable_00098(String funVariable_00098){
    this.funVariable_00098 = funVariable_00098;
}

public String getFunVariable_00099(){
    return funVariable_00099;
}

public void setFunVariable_00099(String funVariable_00099){
    this.funVariable_00099 = funVariable_00099;
}

public String getFunVariable_00100(){
    return funVariable_00100;
}

public void setFunVariable_00100(String funVariable_00100){
    this.funVariable_00100 = funVariable_00100;
}

public String getFunVariable_00101(){
    return funVariable_00101;
}

public void setFunVariable_00101(String funVariable_00101){
    this.funVariable_00101 = funVariable_00101;
}

public String getFunVariable_00102(){
    return funVariable_00102;
}

public void setFunVariable_00102(String funVariable_00102){
    this.funVariable_00102 = funVariable_00102;
}

public String getFunVariable_00103(){
    return funVariable_00103;
}

public void setFunVariable_00103(String funVariable_00103){
    this.funVariable_00103 = funVariable_00103;
}

public String getFunVariable_00104(){
    return funVariable_00104;
}

public void setFunVariable_00104(String funVariable_00104){
    this.funVariable_00104 = funVariable_00104;
}

public String getFunVariable_00105(){
    return funVariable_00105;
}

public void setFunVariable_00105(String funVariable_00105){
    this.funVariable_00105 = funVariable_00105;
}

public String getFunVariable_00106(){
    return funVariable_00106;
}

public void setFunVariable_00106(String funVariable_00106){
    this.funVariable_00106 = funVariable_00106;
}

public String getFunVariable_00107(){
    return funVariable_00107;
}

public void setFunVariable_00107(String funVariable_00107){
    this.funVariable_00107 = funVariable_00107;
}

public String getFunVariable_00108(){
    return funVariable_00108;
}

public void setFunVariable_00108(String funVariable_00108){
    this.funVariable_00108 = funVariable_00108;
}

public String getFunVariable_00109(){
    return funVariable_00109;
}

public void setFunVariable_00109(String funVariable_00109){
    this.funVariable_00109 = funVariable_00109;
}

public String getFunVariable_00110(){
    return funVariable_00110;
}

public void setFunVariable_00110(String funVariable_00110){
    this.funVariable_00110 = funVariable_00110;
}

public String getFunVariable_00111(){
    return funVariable_00111;
}

public void setFunVariable_00111(String funVariable_00111){
    this.funVariable_00111 = funVariable_00111;
}

public String getFunVariable_00112(){
    return funVariable_00112;
}

public void setFunVariable_00112(String funVariable_00112){
    this.funVariable_00112 = funVariable_00112;
}

public String getFunVariable_00113(){
    return funVariable_00113;
}

public void setFunVariable_00113(String funVariable_00113){
    this.funVariable_00113 = funVariable_00113;
}

public String getFunVariable_00114(){
    return funVariable_00114;
}

public void setFunVariable_00114(String funVariable_00114){
    this.funVariable_00114 = funVariable_00114;
}

public String getFunVariable_00115(){
    return funVariable_00115;
}

public void setFunVariable_00115(String funVariable_00115){
    this.funVariable_00115 = funVariable_00115;
}

public String getFunVariable_00116(){
    return funVariable_00116;
}

public void setFunVariable_00116(String funVariable_00116){
    this.funVariable_00116 = funVariable_00116;
}

public String getFunVariable_00117(){
    return funVariable_00117;
}

public void setFunVariable_00117(String funVariable_00117){
    this.funVariable_00117 = funVariable_00117;
}

public String getFunVariable_00118(){
    return funVariable_00118;
}

public void setFunVariable_00118(String funVariable_00118){
    this.funVariable_00118 = funVariable_00118;
}

public String getFunVariable_00119(){
    return funVariable_00119;
}

public void setFunVariable_00119(String funVariable_00119){
    this.funVariable_00119 = funVariable_00119;
}

public String getFunVariable_00120(){
    return funVariable_00120;
}

public void setFunVariable_00120(String funVariable_00120){
    this.funVariable_00120 = funVariable_00120;
}

public String getFunVariable_00121(){
    return funVariable_00121;
}

public void setFunVariable_00121(String funVariable_00121){
    this.funVariable_00121 = funVariable_00121;
}

public String getFunVariable_00122(){
    return funVariable_00122;
}

public void setFunVariable_00122(String funVariable_00122){
    this.funVariable_00122 = funVariable_00122;
}

public String getFunVariable_00123(){
    return funVariable_00123;
}

public void setFunVariable_00123(String funVariable_00123){
    this.funVariable_00123 = funVariable_00123;
}

public String getFunVariable_00124(){
    return funVariable_00124;
}

public void setFunVariable_00124(String funVariable_00124){
    this.funVariable_00124 = funVariable_00124;
}

public String getFunVariable_00125(){
    return funVariable_00125;
}

public void setFunVariable_00125(String funVariable_00125){
    this.funVariable_00125 = funVariable_00125;
}

public String getFunVariable_00126(){
    return funVariable_00126;
}

public void setFunVariable_00126(String funVariable_00126){
    this.funVariable_00126 = funVariable_00126;
}

public String getFunVariable_00127(){
    return funVariable_00127;
}

public void setFunVariable_00127(String funVariable_00127){
    this.funVariable_00127 = funVariable_00127;
}

public String getFunVariable_00128(){
    return funVariable_00128;
}

public void setFunVariable_00128(String funVariable_00128){
    this.funVariable_00128 = funVariable_00128;
}

public String getFunVariable_00129(){
    return funVariable_00129;
}

public void setFunVariable_00129(String funVariable_00129){
    this.funVariable_00129 = funVariable_00129;
}

public String getFunVariable_00130(){
    return funVariable_00130;
}

public void setFunVariable_00130(String funVariable_00130){
    this.funVariable_00130 = funVariable_00130;
}

public String getFunVariable_00131(){
    return funVariable_00131;
}

public void setFunVariable_00131(String funVariable_00131){
    this.funVariable_00131 = funVariable_00131;
}

public String getFunVariable_00132(){
    return funVariable_00132;
}

public void setFunVariable_00132(String funVariable_00132){
    this.funVariable_00132 = funVariable_00132;
}

public String getFunVariable_00133(){
    return funVariable_00133;
}

public void setFunVariable_00133(String funVariable_00133){
    this.funVariable_00133 = funVariable_00133;
}

public String getFunVariable_00134(){
    return funVariable_00134;
}

public void setFunVariable_00134(String funVariable_00134){
    this.funVariable_00134 = funVariable_00134;
}

public String getFunVariable_00135(){
    return funVariable_00135;
}

public void setFunVariable_00135(String funVariable_00135){
    this.funVariable_00135 = funVariable_00135;
}

public String getFunVariable_00136(){
    return funVariable_00136;
}

public void setFunVariable_00136(String funVariable_00136){
    this.funVariable_00136 = funVariable_00136;
}

public String getFunVariable_00137(){
    return funVariable_00137;
}

public void setFunVariable_00137(String funVariable_00137){
    this.funVariable_00137 = funVariable_00137;
}

public String getFunVariable_00138(){
    return funVariable_00138;
}

public void setFunVariable_00138(String funVariable_00138){
    this.funVariable_00138 = funVariable_00138;
}

public String getFunVariable_00139(){
    return funVariable_00139;
}

public void setFunVariable_00139(String funVariable_00139){
    this.funVariable_00139 = funVariable_00139;
}

public String getFunVariable_00140(){
    return funVariable_00140;
}

public void setFunVariable_00140(String funVariable_00140){
    this.funVariable_00140 = funVariable_00140;
}

public String getFunVariable_00141(){
    return funVariable_00141;
}

public void setFunVariable_00141(String funVariable_00141){
    this.funVariable_00141 = funVariable_00141;
}

public String getFunVariable_00142(){
    return funVariable_00142;
}

public void setFunVariable_00142(String funVariable_00142){
    this.funVariable_00142 = funVariable_00142;
}

public String getFunVariable_00143(){
    return funVariable_00143;
}

public void setFunVariable_00143(String funVariable_00143){
    this.funVariable_00143 = funVariable_00143;
}

public String getFunVariable_00144(){
    return funVariable_00144;
}

public void setFunVariable_00144(String funVariable_00144){
    this.funVariable_00144 = funVariable_00144;
}

public String getFunVariable_00145(){
    return funVariable_00145;
}

public void setFunVariable_00145(String funVariable_00145){
    this.funVariable_00145 = funVariable_00145;
}

public String getFunVariable_00146(){
    return funVariable_00146;
}

public void setFunVariable_00146(String funVariable_00146){
    this.funVariable_00146 = funVariable_00146;
}

public String getFunVariable_00147(){
    return funVariable_00147;
}

public void setFunVariable_00147(String funVariable_00147){
    this.funVariable_00147 = funVariable_00147;
}

public String getFunVariable_00148(){
    return funVariable_00148;
}

public void setFunVariable_00148(String funVariable_00148){
    this.funVariable_00148 = funVariable_00148;
}

public String getFunVariable_00149(){
    return funVariable_00149;
}

public void setFunVariable_00149(String funVariable_00149){
    this.funVariable_00149 = funVariable_00149;
}

public String getFunVariable_00150(){
    return funVariable_00150;
}

public void setFunVariable_00150(String funVariable_00150){
    this.funVariable_00150 = funVariable_00150;
}

public String getFunVariable_00151(){
    return funVariable_00151;
}

public void setFunVariable_00151(String funVariable_00151){
    this.funVariable_00151 = funVariable_00151;
}

public String getFunVariable_00152(){
    return funVariable_00152;
}

public void setFunVariable_00152(String funVariable_00152){
    this.funVariable_00152 = funVariable_00152;
}

public String getFunVariable_00153(){
    return funVariable_00153;
}

public void setFunVariable_00153(String funVariable_00153){
    this.funVariable_00153 = funVariable_00153;
}

public String getFunVariable_00154(){
    return funVariable_00154;
}

public void setFunVariable_00154(String funVariable_00154){
    this.funVariable_00154 = funVariable_00154;
}

public String getFunVariable_00155(){
    return funVariable_00155;
}

public void setFunVariable_00155(String funVariable_00155){
    this.funVariable_00155 = funVariable_00155;
}

public String getFunVariable_00156(){
    return funVariable_00156;
}

public void setFunVariable_00156(String funVariable_00156){
    this.funVariable_00156 = funVariable_00156;
}

public String getFunVariable_00157(){
    return funVariable_00157;
}

public void setFunVariable_00157(String funVariable_00157){
    this.funVariable_00157 = funVariable_00157;
}

public String getFunVariable_00158(){
    return funVariable_00158;
}

public void setFunVariable_00158(String funVariable_00158){
    this.funVariable_00158 = funVariable_00158;
}

public String getFunVariable_00159(){
    return funVariable_00159;
}

public void setFunVariable_00159(String funVariable_00159){
    this.funVariable_00159 = funVariable_00159;
}

public String getFunVariable_00160(){
    return funVariable_00160;
}

public void setFunVariable_00160(String funVariable_00160){
    this.funVariable_00160 = funVariable_00160;
}

public String getFunVariable_00161(){
    return funVariable_00161;
}

public void setFunVariable_00161(String funVariable_00161){
    this.funVariable_00161 = funVariable_00161;
}

public String getFunVariable_00162(){
    return funVariable_00162;
}

public void setFunVariable_00162(String funVariable_00162){
    this.funVariable_00162 = funVariable_00162;
}

public String getFunVariable_00163(){
    return funVariable_00163;
}

public void setFunVariable_00163(String funVariable_00163){
    this.funVariable_00163 = funVariable_00163;
}

public String getFunVariable_00164(){
    return funVariable_00164;
}

public void setFunVariable_00164(String funVariable_00164){
    this.funVariable_00164 = funVariable_00164;
}

public String getFunVariable_00165(){
    return funVariable_00165;
}

public void setFunVariable_00165(String funVariable_00165){
    this.funVariable_00165 = funVariable_00165;
}

public String getFunVariable_00166(){
    return funVariable_00166;
}

public void setFunVariable_00166(String funVariable_00166){
    this.funVariable_00166 = funVariable_00166;
}

public String getFunVariable_00167(){
    return funVariable_00167;
}

public void setFunVariable_00167(String funVariable_00167){
    this.funVariable_00167 = funVariable_00167;
}

public String getFunVariable_00168(){
    return funVariable_00168;
}

public void setFunVariable_00168(String funVariable_00168){
    this.funVariable_00168 = funVariable_00168;
}

public String getFunVariable_00169(){
    return funVariable_00169;
}

public void setFunVariable_00169(String funVariable_00169){
    this.funVariable_00169 = funVariable_00169;
}

public String getFunVariable_00170(){
    return funVariable_00170;
}

public void setFunVariable_00170(String funVariable_00170){
    this.funVariable_00170 = funVariable_00170;
}

public String getFunVariable_00171(){
    return funVariable_00171;
}

public void setFunVariable_00171(String funVariable_00171){
    this.funVariable_00171 = funVariable_00171;
}

public String getFunVariable_00172(){
    return funVariable_00172;
}

public void setFunVariable_00172(String funVariable_00172){
    this.funVariable_00172 = funVariable_00172;
}

public String getFunVariable_00173(){
    return funVariable_00173;
}

public void setFunVariable_00173(String funVariable_00173){
    this.funVariable_00173 = funVariable_00173;
}

public String getFunVariable_00174(){
    return funVariable_00174;
}

public void setFunVariable_00174(String funVariable_00174){
    this.funVariable_00174 = funVariable_00174;
}

public String getFunVariable_00175(){
    return funVariable_00175;
}

public void setFunVariable_00175(String funVariable_00175){
    this.funVariable_00175 = funVariable_00175;
}

public String getFunVariable_00176(){
    return funVariable_00176;
}

public void setFunVariable_00176(String funVariable_00176){
    this.funVariable_00176 = funVariable_00176;
}

public String getFunVariable_00177(){
    return funVariable_00177;
}

public void setFunVariable_00177(String funVariable_00177){
    this.funVariable_00177 = funVariable_00177;
}

public String getFunVariable_00178(){
    return funVariable_00178;
}

public void setFunVariable_00178(String funVariable_00178){
    this.funVariable_00178 = funVariable_00178;
}

public String getFunVariable_00179(){
    return funVariable_00179;
}

public void setFunVariable_00179(String funVariable_00179){
    this.funVariable_00179 = funVariable_00179;
}

public String getFunVariable_00180(){
    return funVariable_00180;
}

public void setFunVariable_00180(String funVariable_00180){
    this.funVariable_00180 = funVariable_00180;
}

public String getFunVariable_00181(){
    return funVariable_00181;
}

public void setFunVariable_00181(String funVariable_00181){
    this.funVariable_00181 = funVariable_00181;
}

public String getFunVariable_00182(){
    return funVariable_00182;
}

public void setFunVariable_00182(String funVariable_00182){
    this.funVariable_00182 = funVariable_00182;
}

public String getFunVariable_00183(){
    return funVariable_00183;
}

public void setFunVariable_00183(String funVariable_00183){
    this.funVariable_00183 = funVariable_00183;
}

public String getFunVariable_00184(){
    return funVariable_00184;
}

public void setFunVariable_00184(String funVariable_00184){
    this.funVariable_00184 = funVariable_00184;
}

public String getFunVariable_00185(){
    return funVariable_00185;
}

public void setFunVariable_00185(String funVariable_00185){
    this.funVariable_00185 = funVariable_00185;
}

public String getFunVariable_00186(){
    return funVariable_00186;
}

public void setFunVariable_00186(String funVariable_00186){
    this.funVariable_00186 = funVariable_00186;
}

public String getFunVariable_00187(){
    return funVariable_00187;
}

public void setFunVariable_00187(String funVariable_00187){
    this.funVariable_00187 = funVariable_00187;
}

public String getFunVariable_00188(){
    return funVariable_00188;
}

public void setFunVariable_00188(String funVariable_00188){
    this.funVariable_00188 = funVariable_00188;
}

public String getFunVariable_00189(){
    return funVariable_00189;
}

public void setFunVariable_00189(String funVariable_00189){
    this.funVariable_00189 = funVariable_00189;
}

public String getFunVariable_00190(){
    return funVariable_00190;
}

public void setFunVariable_00190(String funVariable_00190){
    this.funVariable_00190 = funVariable_00190;
}

public String getFunVariable_00191(){
    return funVariable_00191;
}

public void setFunVariable_00191(String funVariable_00191){
    this.funVariable_00191 = funVariable_00191;
}

public String getFunVariable_00192(){
    return funVariable_00192;
}

public void setFunVariable_00192(String funVariable_00192){
    this.funVariable_00192 = funVariable_00192;
}

public String getFunVariable_00193(){
    return funVariable_00193;
}

public void setFunVariable_00193(String funVariable_00193){
    this.funVariable_00193 = funVariable_00193;
}

public String getFunVariable_00194(){
    return funVariable_00194;
}

public void setFunVariable_00194(String funVariable_00194){
    this.funVariable_00194 = funVariable_00194;
}

public String getFunVariable_00195(){
    return funVariable_00195;
}

public void setFunVariable_00195(String funVariable_00195){
    this.funVariable_00195 = funVariable_00195;
}

public String getFunVariable_00196(){
    return funVariable_00196;
}

public void setFunVariable_00196(String funVariable_00196){
    this.funVariable_00196 = funVariable_00196;
}

public String getFunVariable_00197(){
    return funVariable_00197;
}

public void setFunVariable_00197(String funVariable_00197){
    this.funVariable_00197 = funVariable_00197;
}

public String getFunVariable_00198(){
    return funVariable_00198;
}

public void setFunVariable_00198(String funVariable_00198){
    this.funVariable_00198 = funVariable_00198;
}

public String getFunVariable_00199(){
    return funVariable_00199;
}

public void setFunVariable_00199(String funVariable_00199){
    this.funVariable_00199 = funVariable_00199;
}

public String getFunVariable_00200(){
    return funVariable_00200;
}

public void setFunVariable_00200(String funVariable_00200){
    this.funVariable_00200 = funVariable_00200;
}

public String getFunVariable_00201(){
    return funVariable_00201;
}

public void setFunVariable_00201(String funVariable_00201){
    this.funVariable_00201 = funVariable_00201;
}

public String getFunVariable_00202(){
    return funVariable_00202;
}

public void setFunVariable_00202(String funVariable_00202){
    this.funVariable_00202 = funVariable_00202;
}

public String getFunVariable_00203(){
    return funVariable_00203;
}

public void setFunVariable_00203(String funVariable_00203){
    this.funVariable_00203 = funVariable_00203;
}

public String getFunVariable_00204(){
    return funVariable_00204;
}

public void setFunVariable_00204(String funVariable_00204){
    this.funVariable_00204 = funVariable_00204;
}

public String getFunVariable_00205(){
    return funVariable_00205;
}

public void setFunVariable_00205(String funVariable_00205){
    this.funVariable_00205 = funVariable_00205;
}

public String getFunVariable_00206(){
    return funVariable_00206;
}

public void setFunVariable_00206(String funVariable_00206){
    this.funVariable_00206 = funVariable_00206;
}

public String getFunVariable_00207(){
    return funVariable_00207;
}

public void setFunVariable_00207(String funVariable_00207){
    this.funVariable_00207 = funVariable_00207;
}

public String getFunVariable_00208(){
    return funVariable_00208;
}

public void setFunVariable_00208(String funVariable_00208){
    this.funVariable_00208 = funVariable_00208;
}

public String getFunVariable_00209(){
    return funVariable_00209;
}

public void setFunVariable_00209(String funVariable_00209){
    this.funVariable_00209 = funVariable_00209;
}

public String getFunVariable_00210(){
    return funVariable_00210;
}

public void setFunVariable_00210(String funVariable_00210){
    this.funVariable_00210 = funVariable_00210;
}

public String getFunVariable_00211(){
    return funVariable_00211;
}

public void setFunVariable_00211(String funVariable_00211){
    this.funVariable_00211 = funVariable_00211;
}

public String getFunVariable_00212(){
    return funVariable_00212;
}

public void setFunVariable_00212(String funVariable_00212){
    this.funVariable_00212 = funVariable_00212;
}

public String getFunVariable_00213(){
    return funVariable_00213;
}

public void setFunVariable_00213(String funVariable_00213){
    this.funVariable_00213 = funVariable_00213;
}

public String getFunVariable_00214(){
    return funVariable_00214;
}

public void setFunVariable_00214(String funVariable_00214){
    this.funVariable_00214 = funVariable_00214;
}

public String getFunVariable_00215(){
    return funVariable_00215;
}

public void setFunVariable_00215(String funVariable_00215){
    this.funVariable_00215 = funVariable_00215;
}

public String getFunVariable_00216(){
    return funVariable_00216;
}

public void setFunVariable_00216(String funVariable_00216){
    this.funVariable_00216 = funVariable_00216;
}

public String getFunVariable_00217(){
    return funVariable_00217;
}

public void setFunVariable_00217(String funVariable_00217){
    this.funVariable_00217 = funVariable_00217;
}

public String getFunVariable_00218(){
    return funVariable_00218;
}

public void setFunVariable_00218(String funVariable_00218){
    this.funVariable_00218 = funVariable_00218;
}

public String getFunVariable_00219(){
    return funVariable_00219;
}

public void setFunVariable_00219(String funVariable_00219){
    this.funVariable_00219 = funVariable_00219;
}

public String getFunVariable_00220(){
    return funVariable_00220;
}

public void setFunVariable_00220(String funVariable_00220){
    this.funVariable_00220 = funVariable_00220;
}

public String getFunVariable_00221(){
    return funVariable_00221;
}

public void setFunVariable_00221(String funVariable_00221){
    this.funVariable_00221 = funVariable_00221;
}

public String getFunVariable_00222(){
    return funVariable_00222;
}

public void setFunVariable_00222(String funVariable_00222){
    this.funVariable_00222 = funVariable_00222;
}

public String getFunVariable_00223(){
    return funVariable_00223;
}

public void setFunVariable_00223(String funVariable_00223){
    this.funVariable_00223 = funVariable_00223;
}

public String getFunVariable_00224(){
    return funVariable_00224;
}

public void setFunVariable_00224(String funVariable_00224){
    this.funVariable_00224 = funVariable_00224;
}

public String getFunVariable_00225(){
    return funVariable_00225;
}

public void setFunVariable_00225(String funVariable_00225){
    this.funVariable_00225 = funVariable_00225;
}

public String getFunVariable_00226(){
    return funVariable_00226;
}

public void setFunVariable_00226(String funVariable_00226){
    this.funVariable_00226 = funVariable_00226;
}

public String getFunVariable_00227(){
    return funVariable_00227;
}

public void setFunVariable_00227(String funVariable_00227){
    this.funVariable_00227 = funVariable_00227;
}

public String getFunVariable_00228(){
    return funVariable_00228;
}

public void setFunVariable_00228(String funVariable_00228){
    this.funVariable_00228 = funVariable_00228;
}

public String getFunVariable_00229(){
    return funVariable_00229;
}

public void setFunVariable_00229(String funVariable_00229){
    this.funVariable_00229 = funVariable_00229;
}

public String getFunVariable_00230(){
    return funVariable_00230;
}

public void setFunVariable_00230(String funVariable_00230){
    this.funVariable_00230 = funVariable_00230;
}

public String getFunVariable_00231(){
    return funVariable_00231;
}

public void setFunVariable_00231(String funVariable_00231){
    this.funVariable_00231 = funVariable_00231;
}

public String getFunVariable_00232(){
    return funVariable_00232;
}

public void setFunVariable_00232(String funVariable_00232){
    this.funVariable_00232 = funVariable_00232;
}

public String getFunVariable_00233(){
    return funVariable_00233;
}

public void setFunVariable_00233(String funVariable_00233){
    this.funVariable_00233 = funVariable_00233;
}

public String getFunVariable_00234(){
    return funVariable_00234;
}

public void setFunVariable_00234(String funVariable_00234){
    this.funVariable_00234 = funVariable_00234;
}

public String getFunVariable_00235(){
    return funVariable_00235;
}

public void setFunVariable_00235(String funVariable_00235){
    this.funVariable_00235 = funVariable_00235;
}

public String getFunVariable_00236(){
    return funVariable_00236;
}

public void setFunVariable_00236(String funVariable_00236){
    this.funVariable_00236 = funVariable_00236;
}

public String getFunVariable_00237(){
    return funVariable_00237;
}

public void setFunVariable_00237(String funVariable_00237){
    this.funVariable_00237 = funVariable_00237;
}

public String getFunVariable_00238(){
    return funVariable_00238;
}

public void setFunVariable_00238(String funVariable_00238){
    this.funVariable_00238 = funVariable_00238;
}

public String getFunVariable_00239(){
    return funVariable_00239;
}

public void setFunVariable_00239(String funVariable_00239){
    this.funVariable_00239 = funVariable_00239;
}

public String getFunVariable_00240(){
    return funVariable_00240;
}

public void setFunVariable_00240(String funVariable_00240){
    this.funVariable_00240 = funVariable_00240;
}

public String getFunVariable_00241(){
    return funVariable_00241;
}

public void setFunVariable_00241(String funVariable_00241){
    this.funVariable_00241 = funVariable_00241;
}

public String getFunVariable_00242(){
    return funVariable_00242;
}

public void setFunVariable_00242(String funVariable_00242){
    this.funVariable_00242 = funVariable_00242;
}

public String getFunVariable_00243(){
    return funVariable_00243;
}

public void setFunVariable_00243(String funVariable_00243){
    this.funVariable_00243 = funVariable_00243;
}

public String getFunVariable_00244(){
    return funVariable_00244;
}

public void setFunVariable_00244(String funVariable_00244){
    this.funVariable_00244 = funVariable_00244;
}

public String getFunVariable_00245(){
    return funVariable_00245;
}

public void setFunVariable_00245(String funVariable_00245){
    this.funVariable_00245 = funVariable_00245;
}

public String getFunVariable_00246(){
    return funVariable_00246;
}

public void setFunVariable_00246(String funVariable_00246){
    this.funVariable_00246 = funVariable_00246;
}

public String getFunVariable_00247(){
    return funVariable_00247;
}

public void setFunVariable_00247(String funVariable_00247){
    this.funVariable_00247 = funVariable_00247;
}

public String getFunVariable_00248(){
    return funVariable_00248;
}

public void setFunVariable_00248(String funVariable_00248){
    this.funVariable_00248 = funVariable_00248;
}

public String getFunVariable_00249(){
    return funVariable_00249;
}

public void setFunVariable_00249(String funVariable_00249){
    this.funVariable_00249 = funVariable_00249;
}

public String getFunVariable_00250(){
    return funVariable_00250;
}

public void setFunVariable_00250(String funVariable_00250){
    this.funVariable_00250 = funVariable_00250;
}

public String getFunVariable_00251(){
    return funVariable_00251;
}

public void setFunVariable_00251(String funVariable_00251){
    this.funVariable_00251 = funVariable_00251;
}

public String getFunVariable_00252(){
    return funVariable_00252;
}

public void setFunVariable_00252(String funVariable_00252){
    this.funVariable_00252 = funVariable_00252;
}

public String getFunVariable_00253(){
    return funVariable_00253;
}

public void setFunVariable_00253(String funVariable_00253){
    this.funVariable_00253 = funVariable_00253;
}

public String getFunVariable_00254(){
    return funVariable_00254;
}

public void setFunVariable_00254(String funVariable_00254){
    this.funVariable_00254 = funVariable_00254;
}

public String getFunVariable_00255(){
    return funVariable_00255;
}

public void setFunVariable_00255(String funVariable_00255){
    this.funVariable_00255 = funVariable_00255;
}

public String getFunVariable_00256(){
    return funVariable_00256;
}

public void setFunVariable_00256(String funVariable_00256){
    this.funVariable_00256 = funVariable_00256;
}

public String getFunVariable_00257(){
    return funVariable_00257;
}

public void setFunVariable_00257(String funVariable_00257){
    this.funVariable_00257 = funVariable_00257;
}

public String getFunVariable_00258(){
    return funVariable_00258;
}

public void setFunVariable_00258(String funVariable_00258){
    this.funVariable_00258 = funVariable_00258;
}

public String getFunVariable_00259(){
    return funVariable_00259;
}

public void setFunVariable_00259(String funVariable_00259){
    this.funVariable_00259 = funVariable_00259;
}

public String getFunVariable_00260(){
    return funVariable_00260;
}

public void setFunVariable_00260(String funVariable_00260){
    this.funVariable_00260 = funVariable_00260;
}

public String getFunVariable_00261(){
    return funVariable_00261;
}

public void setFunVariable_00261(String funVariable_00261){
    this.funVariable_00261 = funVariable_00261;
}

public String getFunVariable_00262(){
    return funVariable_00262;
}

public void setFunVariable_00262(String funVariable_00262){
    this.funVariable_00262 = funVariable_00262;
}

public String getFunVariable_00263(){
    return funVariable_00263;
}

public void setFunVariable_00263(String funVariable_00263){
    this.funVariable_00263 = funVariable_00263;
}

public String getFunVariable_00264(){
    return funVariable_00264;
}

public void setFunVariable_00264(String funVariable_00264){
    this.funVariable_00264 = funVariable_00264;
}

public String getFunVariable_00265(){
    return funVariable_00265;
}

public void setFunVariable_00265(String funVariable_00265){
    this.funVariable_00265 = funVariable_00265;
}

public String getFunVariable_00266(){
    return funVariable_00266;
}

public void setFunVariable_00266(String funVariable_00266){
    this.funVariable_00266 = funVariable_00266;
}

public String getFunVariable_00267(){
    return funVariable_00267;
}

public void setFunVariable_00267(String funVariable_00267){
    this.funVariable_00267 = funVariable_00267;
}

public String getFunVariable_00268(){
    return funVariable_00268;
}

public void setFunVariable_00268(String funVariable_00268){
    this.funVariable_00268 = funVariable_00268;
}

public String getFunVariable_00269(){
    return funVariable_00269;
}

public void setFunVariable_00269(String funVariable_00269){
    this.funVariable_00269 = funVariable_00269;
}

public String getFunVariable_00270(){
    return funVariable_00270;
}

public void setFunVariable_00270(String funVariable_00270){
    this.funVariable_00270 = funVariable_00270;
}

public String getFunVariable_00271(){
    return funVariable_00271;
}

public void setFunVariable_00271(String funVariable_00271){
    this.funVariable_00271 = funVariable_00271;
}

public String getFunVariable_00272(){
    return funVariable_00272;
}

public void setFunVariable_00272(String funVariable_00272){
    this.funVariable_00272 = funVariable_00272;
}

public String getFunVariable_00273(){
    return funVariable_00273;
}

public void setFunVariable_00273(String funVariable_00273){
    this.funVariable_00273 = funVariable_00273;
}

public String getFunVariable_00274(){
    return funVariable_00274;
}

public void setFunVariable_00274(String funVariable_00274){
    this.funVariable_00274 = funVariable_00274;
}

public String getFunVariable_00275(){
    return funVariable_00275;
}

public void setFunVariable_00275(String funVariable_00275){
    this.funVariable_00275 = funVariable_00275;
}

public String getFunVariable_00276(){
    return funVariable_00276;
}

public void setFunVariable_00276(String funVariable_00276){
    this.funVariable_00276 = funVariable_00276;
}

public String getFunVariable_00277(){
    return funVariable_00277;
}

public void setFunVariable_00277(String funVariable_00277){
    this.funVariable_00277 = funVariable_00277;
}

public String getFunVariable_00278(){
    return funVariable_00278;
}

public void setFunVariable_00278(String funVariable_00278){
    this.funVariable_00278 = funVariable_00278;
}

public String getFunVariable_00279(){
    return funVariable_00279;
}

public void setFunVariable_00279(String funVariable_00279){
    this.funVariable_00279 = funVariable_00279;
}

public String getFunVariable_00280(){
    return funVariable_00280;
}

public void setFunVariable_00280(String funVariable_00280){
    this.funVariable_00280 = funVariable_00280;
}

public String getFunVariable_00281(){
    return funVariable_00281;
}

public void setFunVariable_00281(String funVariable_00281){
    this.funVariable_00281 = funVariable_00281;
}

public String getFunVariable_00282(){
    return funVariable_00282;
}

public void setFunVariable_00282(String funVariable_00282){
    this.funVariable_00282 = funVariable_00282;
}

public String getFunVariable_00283(){
    return funVariable_00283;
}

public void setFunVariable_00283(String funVariable_00283){
    this.funVariable_00283 = funVariable_00283;
}

public String getFunVariable_00284(){
    return funVariable_00284;
}

public void setFunVariable_00284(String funVariable_00284){
    this.funVariable_00284 = funVariable_00284;
}

public String getFunVariable_00285(){
    return funVariable_00285;
}

public void setFunVariable_00285(String funVariable_00285){
    this.funVariable_00285 = funVariable_00285;
}

public String getFunVariable_00286(){
    return funVariable_00286;
}

public void setFunVariable_00286(String funVariable_00286){
    this.funVariable_00286 = funVariable_00286;
}

public String getFunVariable_00287(){
    return funVariable_00287;
}

public void setFunVariable_00287(String funVariable_00287){
    this.funVariable_00287 = funVariable_00287;
}

public String getFunVariable_00288(){
    return funVariable_00288;
}

public void setFunVariable_00288(String funVariable_00288){
    this.funVariable_00288 = funVariable_00288;
}

public String getFunVariable_00289(){
    return funVariable_00289;
}

public void setFunVariable_00289(String funVariable_00289){
    this.funVariable_00289 = funVariable_00289;
}

public String getFunVariable_00290(){
    return funVariable_00290;
}

public void setFunVariable_00290(String funVariable_00290){
    this.funVariable_00290 = funVariable_00290;
}

public String getFunVariable_00291(){
    return funVariable_00291;
}

public void setFunVariable_00291(String funVariable_00291){
    this.funVariable_00291 = funVariable_00291;
}

public String getFunVariable_00292(){
    return funVariable_00292;
}

public void setFunVariable_00292(String funVariable_00292){
    this.funVariable_00292 = funVariable_00292;
}

public String getFunVariable_00293(){
    return funVariable_00293;
}

public void setFunVariable_00293(String funVariable_00293){
    this.funVariable_00293 = funVariable_00293;
}

public String getFunVariable_00294(){
    return funVariable_00294;
}

public void setFunVariable_00294(String funVariable_00294){
    this.funVariable_00294 = funVariable_00294;
}

public String getFunVariable_00295(){
    return funVariable_00295;
}

public void setFunVariable_00295(String funVariable_00295){
    this.funVariable_00295 = funVariable_00295;
}

public String getFunVariable_00296(){
    return funVariable_00296;
}

public void setFunVariable_00296(String funVariable_00296){
    this.funVariable_00296 = funVariable_00296;
}

public String getFunVariable_00297(){
    return funVariable_00297;
}

public void setFunVariable_00297(String funVariable_00297){
    this.funVariable_00297 = funVariable_00297;
}

public String getFunVariable_00298(){
    return funVariable_00298;
}

public void setFunVariable_00298(String funVariable_00298){
    this.funVariable_00298 = funVariable_00298;
}

public String getFunVariable_00299(){
    return funVariable_00299;
}

public void setFunVariable_00299(String funVariable_00299){
    this.funVariable_00299 = funVariable_00299;
}

public String getFunVariable_00300(){
    return funVariable_00300;
}

public void setFunVariable_00300(String funVariable_00300){
    this.funVariable_00300 = funVariable_00300;
}

public String getFunVariable_00301(){
    return funVariable_00301;
}

public void setFunVariable_00301(String funVariable_00301){
    this.funVariable_00301 = funVariable_00301;
}

public String getFunVariable_00302(){
    return funVariable_00302;
}

public void setFunVariable_00302(String funVariable_00302){
    this.funVariable_00302 = funVariable_00302;
}

public String getFunVariable_00303(){
    return funVariable_00303;
}

public void setFunVariable_00303(String funVariable_00303){
    this.funVariable_00303 = funVariable_00303;
}

public String getFunVariable_00304(){
    return funVariable_00304;
}

public void setFunVariable_00304(String funVariable_00304){
    this.funVariable_00304 = funVariable_00304;
}

public String getFunVariable_00305(){
    return funVariable_00305;
}

public void setFunVariable_00305(String funVariable_00305){
    this.funVariable_00305 = funVariable_00305;
}

public String getFunVariable_00306(){
    return funVariable_00306;
}

public void setFunVariable_00306(String funVariable_00306){
    this.funVariable_00306 = funVariable_00306;
}

public String getFunVariable_00307(){
    return funVariable_00307;
}

public void setFunVariable_00307(String funVariable_00307){
    this.funVariable_00307 = funVariable_00307;
}

public String getFunVariable_00308(){
    return funVariable_00308;
}

public void setFunVariable_00308(String funVariable_00308){
    this.funVariable_00308 = funVariable_00308;
}

public String getFunVariable_00309(){
    return funVariable_00309;
}

public void setFunVariable_00309(String funVariable_00309){
    this.funVariable_00309 = funVariable_00309;
}

public String getFunVariable_00310(){
    return funVariable_00310;
}

public void setFunVariable_00310(String funVariable_00310){
    this.funVariable_00310 = funVariable_00310;
}

public String getFunVariable_00311(){
    return funVariable_00311;
}

public void setFunVariable_00311(String funVariable_00311){
    this.funVariable_00311 = funVariable_00311;
}

public String getFunVariable_00312(){
    return funVariable_00312;
}

public void setFunVariable_00312(String funVariable_00312){
    this.funVariable_00312 = funVariable_00312;
}

public String getFunVariable_00313(){
    return funVariable_00313;
}

public void setFunVariable_00313(String funVariable_00313){
    this.funVariable_00313 = funVariable_00313;
}

public String getFunVariable_00314(){
    return funVariable_00314;
}

public void setFunVariable_00314(String funVariable_00314){
    this.funVariable_00314 = funVariable_00314;
}

public String getFunVariable_00315(){
    return funVariable_00315;
}

public void setFunVariable_00315(String funVariable_00315){
    this.funVariable_00315 = funVariable_00315;
}

public String getFunVariable_00316(){
    return funVariable_00316;
}

public void setFunVariable_00316(String funVariable_00316){
    this.funVariable_00316 = funVariable_00316;
}

public String getFunVariable_00317(){
    return funVariable_00317;
}

public void setFunVariable_00317(String funVariable_00317){
    this.funVariable_00317 = funVariable_00317;
}

public String getFunVariable_00318(){
    return funVariable_00318;
}

public void setFunVariable_00318(String funVariable_00318){
    this.funVariable_00318 = funVariable_00318;
}

public String getFunVariable_00319(){
    return funVariable_00319;
}

public void setFunVariable_00319(String funVariable_00319){
    this.funVariable_00319 = funVariable_00319;
}

public String getFunVariable_00320(){
    return funVariable_00320;
}

public void setFunVariable_00320(String funVariable_00320){
    this.funVariable_00320 = funVariable_00320;
}

public String getFunVariable_00321(){
    return funVariable_00321;
}

public void setFunVariable_00321(String funVariable_00321){
    this.funVariable_00321 = funVariable_00321;
}

public String getFunVariable_00322(){
    return funVariable_00322;
}

public void setFunVariable_00322(String funVariable_00322){
    this.funVariable_00322 = funVariable_00322;
}

public String getFunVariable_00323(){
    return funVariable_00323;
}

public void setFunVariable_00323(String funVariable_00323){
    this.funVariable_00323 = funVariable_00323;
}

public String getFunVariable_00324(){
    return funVariable_00324;
}

public void setFunVariable_00324(String funVariable_00324){
    this.funVariable_00324 = funVariable_00324;
}

public String getFunVariable_00325(){
    return funVariable_00325;
}

public void setFunVariable_00325(String funVariable_00325){
    this.funVariable_00325 = funVariable_00325;
}

public String getFunVariable_00326(){
    return funVariable_00326;
}

public void setFunVariable_00326(String funVariable_00326){
    this.funVariable_00326 = funVariable_00326;
}

public String getFunVariable_00327(){
    return funVariable_00327;
}

public void setFunVariable_00327(String funVariable_00327){
    this.funVariable_00327 = funVariable_00327;
}

public String getFunVariable_00328(){
    return funVariable_00328;
}

public void setFunVariable_00328(String funVariable_00328){
    this.funVariable_00328 = funVariable_00328;
}

public String getFunVariable_00329(){
    return funVariable_00329;
}

public void setFunVariable_00329(String funVariable_00329){
    this.funVariable_00329 = funVariable_00329;
}

public String getFunVariable_00330(){
    return funVariable_00330;
}

public void setFunVariable_00330(String funVariable_00330){
    this.funVariable_00330 = funVariable_00330;
}

public String getFunVariable_00331(){
    return funVariable_00331;
}

public void setFunVariable_00331(String funVariable_00331){
    this.funVariable_00331 = funVariable_00331;
}

public String getFunVariable_00332(){
    return funVariable_00332;
}

public void setFunVariable_00332(String funVariable_00332){
    this.funVariable_00332 = funVariable_00332;
}

public String getFunVariable_00333(){
    return funVariable_00333;
}

public void setFunVariable_00333(String funVariable_00333){
    this.funVariable_00333 = funVariable_00333;
}

public String getFunVariable_00334(){
    return funVariable_00334;
}

public void setFunVariable_00334(String funVariable_00334){
    this.funVariable_00334 = funVariable_00334;
}

public String getFunVariable_00335(){
    return funVariable_00335;
}

public void setFunVariable_00335(String funVariable_00335){
    this.funVariable_00335 = funVariable_00335;
}

public String getFunVariable_00336(){
    return funVariable_00336;
}

public void setFunVariable_00336(String funVariable_00336){
    this.funVariable_00336 = funVariable_00336;
}

public String getFunVariable_00337(){
    return funVariable_00337;
}

public void setFunVariable_00337(String funVariable_00337){
    this.funVariable_00337 = funVariable_00337;
}

public String getFunVariable_00338(){
    return funVariable_00338;
}

public void setFunVariable_00338(String funVariable_00338){
    this.funVariable_00338 = funVariable_00338;
}

public String getFunVariable_00339(){
    return funVariable_00339;
}

public void setFunVariable_00339(String funVariable_00339){
    this.funVariable_00339 = funVariable_00339;
}

public String getFunVariable_00340(){
    return funVariable_00340;
}

public void setFunVariable_00340(String funVariable_00340){
    this.funVariable_00340 = funVariable_00340;
}

public String getFunVariable_00341(){
    return funVariable_00341;
}

public void setFunVariable_00341(String funVariable_00341){
    this.funVariable_00341 = funVariable_00341;
}

public String getFunVariable_00342(){
    return funVariable_00342;
}

public void setFunVariable_00342(String funVariable_00342){
    this.funVariable_00342 = funVariable_00342;
}

public String getFunVariable_00343(){
    return funVariable_00343;
}

public void setFunVariable_00343(String funVariable_00343){
    this.funVariable_00343 = funVariable_00343;
}

public String getFunVariable_00344(){
    return funVariable_00344;
}

public void setFunVariable_00344(String funVariable_00344){
    this.funVariable_00344 = funVariable_00344;
}

public String getFunVariable_00345(){
    return funVariable_00345;
}

public void setFunVariable_00345(String funVariable_00345){
    this.funVariable_00345 = funVariable_00345;
}

public String getFunVariable_00346(){
    return funVariable_00346;
}

public void setFunVariable_00346(String funVariable_00346){
    this.funVariable_00346 = funVariable_00346;
}

public String getFunVariable_00347(){
    return funVariable_00347;
}

public void setFunVariable_00347(String funVariable_00347){
    this.funVariable_00347 = funVariable_00347;
}

public String getFunVariable_00348(){
    return funVariable_00348;
}

public void setFunVariable_00348(String funVariable_00348){
    this.funVariable_00348 = funVariable_00348;
}

public String getFunVariable_00349(){
    return funVariable_00349;
}

public void setFunVariable_00349(String funVariable_00349){
    this.funVariable_00349 = funVariable_00349;
}

public String getFunVariable_00350(){
    return funVariable_00350;
}

public void setFunVariable_00350(String funVariable_00350){
    this.funVariable_00350 = funVariable_00350;
}

public String getFunVariable_00351(){
    return funVariable_00351;
}

public void setFunVariable_00351(String funVariable_00351){
    this.funVariable_00351 = funVariable_00351;
}

public String getFunVariable_00352(){
    return funVariable_00352;
}

public void setFunVariable_00352(String funVariable_00352){
    this.funVariable_00352 = funVariable_00352;
}

public String getFunVariable_00353(){
    return funVariable_00353;
}

public void setFunVariable_00353(String funVariable_00353){
    this.funVariable_00353 = funVariable_00353;
}

public String getFunVariable_00354(){
    return funVariable_00354;
}

public void setFunVariable_00354(String funVariable_00354){
    this.funVariable_00354 = funVariable_00354;
}

public String getFunVariable_00355(){
    return funVariable_00355;
}

public void setFunVariable_00355(String funVariable_00355){
    this.funVariable_00355 = funVariable_00355;
}

public String getFunVariable_00356(){
    return funVariable_00356;
}

public void setFunVariable_00356(String funVariable_00356){
    this.funVariable_00356 = funVariable_00356;
}

public String getFunVariable_00357(){
    return funVariable_00357;
}

public void setFunVariable_00357(String funVariable_00357){
    this.funVariable_00357 = funVariable_00357;
}

public String getFunVariable_00358(){
    return funVariable_00358;
}

public void setFunVariable_00358(String funVariable_00358){
    this.funVariable_00358 = funVariable_00358;
}

public String getFunVariable_00359(){
    return funVariable_00359;
}

public void setFunVariable_00359(String funVariable_00359){
    this.funVariable_00359 = funVariable_00359;
}

public String getFunVariable_00360(){
    return funVariable_00360;
}

public void setFunVariable_00360(String funVariable_00360){
    this.funVariable_00360 = funVariable_00360;
}

public String getFunVariable_00361(){
    return funVariable_00361;
}

public void setFunVariable_00361(String funVariable_00361){
    this.funVariable_00361 = funVariable_00361;
}

public String getFunVariable_00362(){
    return funVariable_00362;
}

public void setFunVariable_00362(String funVariable_00362){
    this.funVariable_00362 = funVariable_00362;
}

public String getFunVariable_00363(){
    return funVariable_00363;
}

public void setFunVariable_00363(String funVariable_00363){
    this.funVariable_00363 = funVariable_00363;
}

public String getFunVariable_00364(){
    return funVariable_00364;
}

public void setFunVariable_00364(String funVariable_00364){
    this.funVariable_00364 = funVariable_00364;
}

public String getFunVariable_00365(){
    return funVariable_00365;
}

public void setFunVariable_00365(String funVariable_00365){
    this.funVariable_00365 = funVariable_00365;
}

public String getFunVariable_00366(){
    return funVariable_00366;
}

public void setFunVariable_00366(String funVariable_00366){
    this.funVariable_00366 = funVariable_00366;
}

public String getFunVariable_00367(){
    return funVariable_00367;
}

public void setFunVariable_00367(String funVariable_00367){
    this.funVariable_00367 = funVariable_00367;
}

public String getFunVariable_00368(){
    return funVariable_00368;
}

public void setFunVariable_00368(String funVariable_00368){
    this.funVariable_00368 = funVariable_00368;
}

public String getFunVariable_00369(){
    return funVariable_00369;
}

public void setFunVariable_00369(String funVariable_00369){
    this.funVariable_00369 = funVariable_00369;
}

public String getFunVariable_00370(){
    return funVariable_00370;
}

public void setFunVariable_00370(String funVariable_00370){
    this.funVariable_00370 = funVariable_00370;
}

public String getFunVariable_00371(){
    return funVariable_00371;
}

public void setFunVariable_00371(String funVariable_00371){
    this.funVariable_00371 = funVariable_00371;
}

public String getFunVariable_00372(){
    return funVariable_00372;
}

public void setFunVariable_00372(String funVariable_00372){
    this.funVariable_00372 = funVariable_00372;
}

public String getFunVariable_00373(){
    return funVariable_00373;
}

public void setFunVariable_00373(String funVariable_00373){
    this.funVariable_00373 = funVariable_00373;
}

public String getFunVariable_00374(){
    return funVariable_00374;
}

public void setFunVariable_00374(String funVariable_00374){
    this.funVariable_00374 = funVariable_00374;
}

public String getFunVariable_00375(){
    return funVariable_00375;
}

public void setFunVariable_00375(String funVariable_00375){
    this.funVariable_00375 = funVariable_00375;
}

public String getFunVariable_00376(){
    return funVariable_00376;
}

public void setFunVariable_00376(String funVariable_00376){
    this.funVariable_00376 = funVariable_00376;
}

public String getFunVariable_00377(){
    return funVariable_00377;
}

public void setFunVariable_00377(String funVariable_00377){
    this.funVariable_00377 = funVariable_00377;
}

public String getFunVariable_00378(){
    return funVariable_00378;
}

public void setFunVariable_00378(String funVariable_00378){
    this.funVariable_00378 = funVariable_00378;
}

public String getFunVariable_00379(){
    return funVariable_00379;
}

public void setFunVariable_00379(String funVariable_00379){
    this.funVariable_00379 = funVariable_00379;
}

public String getFunVariable_00380(){
    return funVariable_00380;
}

public void setFunVariable_00380(String funVariable_00380){
    this.funVariable_00380 = funVariable_00380;
}

public String getFunVariable_00381(){
    return funVariable_00381;
}

public void setFunVariable_00381(String funVariable_00381){
    this.funVariable_00381 = funVariable_00381;
}

public String getFunVariable_00382(){
    return funVariable_00382;
}

public void setFunVariable_00382(String funVariable_00382){
    this.funVariable_00382 = funVariable_00382;
}

public String getFunVariable_00383(){
    return funVariable_00383;
}

public void setFunVariable_00383(String funVariable_00383){
    this.funVariable_00383 = funVariable_00383;
}

public String getFunVariable_00384(){
    return funVariable_00384;
}

public void setFunVariable_00384(String funVariable_00384){
    this.funVariable_00384 = funVariable_00384;
}

public String getFunVariable_00385(){
    return funVariable_00385;
}

public void setFunVariable_00385(String funVariable_00385){
    this.funVariable_00385 = funVariable_00385;
}

public String getFunVariable_00386(){
    return funVariable_00386;
}

public void setFunVariable_00386(String funVariable_00386){
    this.funVariable_00386 = funVariable_00386;
}

public String getFunVariable_00387(){
    return funVariable_00387;
}

public void setFunVariable_00387(String funVariable_00387){
    this.funVariable_00387 = funVariable_00387;
}

public String getFunVariable_00388(){
    return funVariable_00388;
}

public void setFunVariable_00388(String funVariable_00388){
    this.funVariable_00388 = funVariable_00388;
}

public String getFunVariable_00389(){
    return funVariable_00389;
}

public void setFunVariable_00389(String funVariable_00389){
    this.funVariable_00389 = funVariable_00389;
}

public String getFunVariable_00390(){
    return funVariable_00390;
}

public void setFunVariable_00390(String funVariable_00390){
    this.funVariable_00390 = funVariable_00390;
}

public String getFunVariable_00391(){
    return funVariable_00391;
}

public void setFunVariable_00391(String funVariable_00391){
    this.funVariable_00391 = funVariable_00391;
}

public String getFunVariable_00392(){
    return funVariable_00392;
}

public void setFunVariable_00392(String funVariable_00392){
    this.funVariable_00392 = funVariable_00392;
}

public String getFunVariable_00393(){
    return funVariable_00393;
}

public void setFunVariable_00393(String funVariable_00393){
    this.funVariable_00393 = funVariable_00393;
}

public String getFunVariable_00394(){
    return funVariable_00394;
}

public void setFunVariable_00394(String funVariable_00394){
    this.funVariable_00394 = funVariable_00394;
}

public String getFunVariable_00395(){
    return funVariable_00395;
}

public void setFunVariable_00395(String funVariable_00395){
    this.funVariable_00395 = funVariable_00395;
}

public String getFunVariable_00396(){
    return funVariable_00396;
}

public void setFunVariable_00396(String funVariable_00396){
    this.funVariable_00396 = funVariable_00396;
}

public String getFunVariable_00397(){
    return funVariable_00397;
}

public void setFunVariable_00397(String funVariable_00397){
    this.funVariable_00397 = funVariable_00397;
}

public String getFunVariable_00398(){
    return funVariable_00398;
}

public void setFunVariable_00398(String funVariable_00398){
    this.funVariable_00398 = funVariable_00398;
}

public String getFunVariable_00399(){
    return funVariable_00399;
}

public void setFunVariable_00399(String funVariable_00399){
    this.funVariable_00399 = funVariable_00399;
}

public String getFunVariable_00400(){
    return funVariable_00400;
}

public void setFunVariable_00400(String funVariable_00400){
    this.funVariable_00400 = funVariable_00400;
}

public String getFunVariable_00401(){
    return funVariable_00401;
}

public void setFunVariable_00401(String funVariable_00401){
    this.funVariable_00401 = funVariable_00401;
}

public String getFunVariable_00402(){
    return funVariable_00402;
}

public void setFunVariable_00402(String funVariable_00402){
    this.funVariable_00402 = funVariable_00402;
}

public String getFunVariable_00403(){
    return funVariable_00403;
}

public void setFunVariable_00403(String funVariable_00403){
    this.funVariable_00403 = funVariable_00403;
}

public String getFunVariable_00404(){
    return funVariable_00404;
}

public void setFunVariable_00404(String funVariable_00404){
    this.funVariable_00404 = funVariable_00404;
}

public String getFunVariable_00405(){
    return funVariable_00405;
}

public void setFunVariable_00405(String funVariable_00405){
    this.funVariable_00405 = funVariable_00405;
}

public String getFunVariable_00406(){
    return funVariable_00406;
}

public void setFunVariable_00406(String funVariable_00406){
    this.funVariable_00406 = funVariable_00406;
}

public String getFunVariable_00407(){
    return funVariable_00407;
}

public void setFunVariable_00407(String funVariable_00407){
    this.funVariable_00407 = funVariable_00407;
}

public String getFunVariable_00408(){
    return funVariable_00408;
}

public void setFunVariable_00408(String funVariable_00408){
    this.funVariable_00408 = funVariable_00408;
}

public String getFunVariable_00409(){
    return funVariable_00409;
}

public void setFunVariable_00409(String funVariable_00409){
    this.funVariable_00409 = funVariable_00409;
}

public String getFunVariable_00410(){
    return funVariable_00410;
}

public void setFunVariable_00410(String funVariable_00410){
    this.funVariable_00410 = funVariable_00410;
}

public String getFunVariable_00411(){
    return funVariable_00411;
}

public void setFunVariable_00411(String funVariable_00411){
    this.funVariable_00411 = funVariable_00411;
}

public String getFunVariable_00412(){
    return funVariable_00412;
}

public void setFunVariable_00412(String funVariable_00412){
    this.funVariable_00412 = funVariable_00412;
}

public String getFunVariable_00413(){
    return funVariable_00413;
}

public void setFunVariable_00413(String funVariable_00413){
    this.funVariable_00413 = funVariable_00413;
}

public String getFunVariable_00414(){
    return funVariable_00414;
}

public void setFunVariable_00414(String funVariable_00414){
    this.funVariable_00414 = funVariable_00414;
}

public String getFunVariable_00415(){
    return funVariable_00415;
}

public void setFunVariable_00415(String funVariable_00415){
    this.funVariable_00415 = funVariable_00415;
}

public String getFunVariable_00416(){
    return funVariable_00416;
}

public void setFunVariable_00416(String funVariable_00416){
    this.funVariable_00416 = funVariable_00416;
}

public String getFunVariable_00417(){
    return funVariable_00417;
}

public void setFunVariable_00417(String funVariable_00417){
    this.funVariable_00417 = funVariable_00417;
}

public String getFunVariable_00418(){
    return funVariable_00418;
}

public void setFunVariable_00418(String funVariable_00418){
    this.funVariable_00418 = funVariable_00418;
}

public String getFunVariable_00419(){
    return funVariable_00419;
}

public void setFunVariable_00419(String funVariable_00419){
    this.funVariable_00419 = funVariable_00419;
}

public String getFunVariable_00420(){
    return funVariable_00420;
}

public void setFunVariable_00420(String funVariable_00420){
    this.funVariable_00420 = funVariable_00420;
}

public String getFunVariable_00421(){
    return funVariable_00421;
}

public void setFunVariable_00421(String funVariable_00421){
    this.funVariable_00421 = funVariable_00421;
}

public String getFunVariable_00422(){
    return funVariable_00422;
}

public void setFunVariable_00422(String funVariable_00422){
    this.funVariable_00422 = funVariable_00422;
}

public String getFunVariable_00423(){
    return funVariable_00423;
}

public void setFunVariable_00423(String funVariable_00423){
    this.funVariable_00423 = funVariable_00423;
}

public String getFunVariable_00424(){
    return funVariable_00424;
}

public void setFunVariable_00424(String funVariable_00424){
    this.funVariable_00424 = funVariable_00424;
}

public String getFunVariable_00425(){
    return funVariable_00425;
}

public void setFunVariable_00425(String funVariable_00425){
    this.funVariable_00425 = funVariable_00425;
}

public String getFunVariable_00426(){
    return funVariable_00426;
}

public void setFunVariable_00426(String funVariable_00426){
    this.funVariable_00426 = funVariable_00426;
}

public String getFunVariable_00427(){
    return funVariable_00427;
}

public void setFunVariable_00427(String funVariable_00427){
    this.funVariable_00427 = funVariable_00427;
}

public String getFunVariable_00428(){
    return funVariable_00428;
}

public void setFunVariable_00428(String funVariable_00428){
    this.funVariable_00428 = funVariable_00428;
}

public String getFunVariable_00429(){
    return funVariable_00429;
}

public void setFunVariable_00429(String funVariable_00429){
    this.funVariable_00429 = funVariable_00429;
}

public String getFunVariable_00430(){
    return funVariable_00430;
}

public void setFunVariable_00430(String funVariable_00430){
    this.funVariable_00430 = funVariable_00430;
}

public String getFunVariable_00431(){
    return funVariable_00431;
}

public void setFunVariable_00431(String funVariable_00431){
    this.funVariable_00431 = funVariable_00431;
}

public String getFunVariable_00432(){
    return funVariable_00432;
}

public void setFunVariable_00432(String funVariable_00432){
    this.funVariable_00432 = funVariable_00432;
}

public String getFunVariable_00433(){
    return funVariable_00433;
}

public void setFunVariable_00433(String funVariable_00433){
    this.funVariable_00433 = funVariable_00433;
}

public String getFunVariable_00434(){
    return funVariable_00434;
}

public void setFunVariable_00434(String funVariable_00434){
    this.funVariable_00434 = funVariable_00434;
}

public String getFunVariable_00435(){
    return funVariable_00435;
}

public void setFunVariable_00435(String funVariable_00435){
    this.funVariable_00435 = funVariable_00435;
}

public String getFunVariable_00436(){
    return funVariable_00436;
}

public void setFunVariable_00436(String funVariable_00436){
    this.funVariable_00436 = funVariable_00436;
}

public String getFunVariable_00437(){
    return funVariable_00437;
}

public void setFunVariable_00437(String funVariable_00437){
    this.funVariable_00437 = funVariable_00437;
}

public String getFunVariable_00438(){
    return funVariable_00438;
}

public void setFunVariable_00438(String funVariable_00438){
    this.funVariable_00438 = funVariable_00438;
}

public String getFunVariable_00439(){
    return funVariable_00439;
}

public void setFunVariable_00439(String funVariable_00439){
    this.funVariable_00439 = funVariable_00439;
}

public String getFunVariable_00440(){
    return funVariable_00440;
}

public void setFunVariable_00440(String funVariable_00440){
    this.funVariable_00440 = funVariable_00440;
}

public String getFunVariable_00441(){
    return funVariable_00441;
}

public void setFunVariable_00441(String funVariable_00441){
    this.funVariable_00441 = funVariable_00441;
}

public String getFunVariable_00442(){
    return funVariable_00442;
}

public void setFunVariable_00442(String funVariable_00442){
    this.funVariable_00442 = funVariable_00442;
}

public String getFunVariable_00443(){
    return funVariable_00443;
}

public void setFunVariable_00443(String funVariable_00443){
    this.funVariable_00443 = funVariable_00443;
}

public String getFunVariable_00444(){
    return funVariable_00444;
}

public void setFunVariable_00444(String funVariable_00444){
    this.funVariable_00444 = funVariable_00444;
}

public String getFunVariable_00445(){
    return funVariable_00445;
}

public void setFunVariable_00445(String funVariable_00445){
    this.funVariable_00445 = funVariable_00445;
}

public String getFunVariable_00446(){
    return funVariable_00446;
}

public void setFunVariable_00446(String funVariable_00446){
    this.funVariable_00446 = funVariable_00446;
}

public String getFunVariable_00447(){
    return funVariable_00447;
}

public void setFunVariable_00447(String funVariable_00447){
    this.funVariable_00447 = funVariable_00447;
}

public String getFunVariable_00448(){
    return funVariable_00448;
}

public void setFunVariable_00448(String funVariable_00448){
    this.funVariable_00448 = funVariable_00448;
}

public String getFunVariable_00449(){
    return funVariable_00449;
}

public void setFunVariable_00449(String funVariable_00449){
    this.funVariable_00449 = funVariable_00449;
}

public String getFunVariable_00450(){
    return funVariable_00450;
}

public void setFunVariable_00450(String funVariable_00450){
    this.funVariable_00450 = funVariable_00450;
}

public String getFunVariable_00451(){
    return funVariable_00451;
}

public void setFunVariable_00451(String funVariable_00451){
    this.funVariable_00451 = funVariable_00451;
}

public String getFunVariable_00452(){
    return funVariable_00452;
}

public void setFunVariable_00452(String funVariable_00452){
    this.funVariable_00452 = funVariable_00452;
}

public String getFunVariable_00453(){
    return funVariable_00453;
}

public void setFunVariable_00453(String funVariable_00453){
    this.funVariable_00453 = funVariable_00453;
}

public String getFunVariable_00454(){
    return funVariable_00454;
}

public void setFunVariable_00454(String funVariable_00454){
    this.funVariable_00454 = funVariable_00454;
}

public String getFunVariable_00455(){
    return funVariable_00455;
}

public void setFunVariable_00455(String funVariable_00455){
    this.funVariable_00455 = funVariable_00455;
}

public String getFunVariable_00456(){
    return funVariable_00456;
}

public void setFunVariable_00456(String funVariable_00456){
    this.funVariable_00456 = funVariable_00456;
}

public String getFunVariable_00457(){
    return funVariable_00457;
}

public void setFunVariable_00457(String funVariable_00457){
    this.funVariable_00457 = funVariable_00457;
}

public String getFunVariable_00458(){
    return funVariable_00458;
}

public void setFunVariable_00458(String funVariable_00458){
    this.funVariable_00458 = funVariable_00458;
}

public String getFunVariable_00459(){
    return funVariable_00459;
}

public void setFunVariable_00459(String funVariable_00459){
    this.funVariable_00459 = funVariable_00459;
}

public String getFunVariable_00460(){
    return funVariable_00460;
}

public void setFunVariable_00460(String funVariable_00460){
    this.funVariable_00460 = funVariable_00460;
}

public String getFunVariable_00461(){
    return funVariable_00461;
}

public void setFunVariable_00461(String funVariable_00461){
    this.funVariable_00461 = funVariable_00461;
}

public String getFunVariable_00462(){
    return funVariable_00462;
}

public void setFunVariable_00462(String funVariable_00462){
    this.funVariable_00462 = funVariable_00462;
}

public String getFunVariable_00463(){
    return funVariable_00463;
}

public void setFunVariable_00463(String funVariable_00463){
    this.funVariable_00463 = funVariable_00463;
}

public String getFunVariable_00464(){
    return funVariable_00464;
}

public void setFunVariable_00464(String funVariable_00464){
    this.funVariable_00464 = funVariable_00464;
}

public String getFunVariable_00465(){
    return funVariable_00465;
}

public void setFunVariable_00465(String funVariable_00465){
    this.funVariable_00465 = funVariable_00465;
}

public String getFunVariable_00466(){
    return funVariable_00466;
}

public void setFunVariable_00466(String funVariable_00466){
    this.funVariable_00466 = funVariable_00466;
}

public String getFunVariable_00467(){
    return funVariable_00467;
}

public void setFunVariable_00467(String funVariable_00467){
    this.funVariable_00467 = funVariable_00467;
}

public String getFunVariable_00468(){
    return funVariable_00468;
}

public void setFunVariable_00468(String funVariable_00468){
    this.funVariable_00468 = funVariable_00468;
}

public String getFunVariable_00469(){
    return funVariable_00469;
}

public void setFunVariable_00469(String funVariable_00469){
    this.funVariable_00469 = funVariable_00469;
}

public String getFunVariable_00470(){
    return funVariable_00470;
}

public void setFunVariable_00470(String funVariable_00470){
    this.funVariable_00470 = funVariable_00470;
}

public String getFunVariable_00471(){
    return funVariable_00471;
}

public void setFunVariable_00471(String funVariable_00471){
    this.funVariable_00471 = funVariable_00471;
}

public String getFunVariable_00472(){
    return funVariable_00472;
}

public void setFunVariable_00472(String funVariable_00472){
    this.funVariable_00472 = funVariable_00472;
}

public String getFunVariable_00473(){
    return funVariable_00473;
}

public void setFunVariable_00473(String funVariable_00473){
    this.funVariable_00473 = funVariable_00473;
}

public String getFunVariable_00474(){
    return funVariable_00474;
}

public void setFunVariable_00474(String funVariable_00474){
    this.funVariable_00474 = funVariable_00474;
}

public String getFunVariable_00475(){
    return funVariable_00475;
}

public void setFunVariable_00475(String funVariable_00475){
    this.funVariable_00475 = funVariable_00475;
}

public String getFunVariable_00476(){
    return funVariable_00476;
}

public void setFunVariable_00476(String funVariable_00476){
    this.funVariable_00476 = funVariable_00476;
}

public String getFunVariable_00477(){
    return funVariable_00477;
}

public void setFunVariable_00477(String funVariable_00477){
    this.funVariable_00477 = funVariable_00477;
}

public String getFunVariable_00478(){
    return funVariable_00478;
}

public void setFunVariable_00478(String funVariable_00478){
    this.funVariable_00478 = funVariable_00478;
}

public String getFunVariable_00479(){
    return funVariable_00479;
}

public void setFunVariable_00479(String funVariable_00479){
    this.funVariable_00479 = funVariable_00479;
}

public String getFunVariable_00480(){
    return funVariable_00480;
}

public void setFunVariable_00480(String funVariable_00480){
    this.funVariable_00480 = funVariable_00480;
}

public String getFunVariable_00481(){
    return funVariable_00481;
}

public void setFunVariable_00481(String funVariable_00481){
    this.funVariable_00481 = funVariable_00481;
}

public String getFunVariable_00482(){
    return funVariable_00482;
}

public void setFunVariable_00482(String funVariable_00482){
    this.funVariable_00482 = funVariable_00482;
}

public String getFunVariable_00483(){
    return funVariable_00483;
}

public void setFunVariable_00483(String funVariable_00483){
    this.funVariable_00483 = funVariable_00483;
}

public String getFunVariable_00484(){
    return funVariable_00484;
}

public void setFunVariable_00484(String funVariable_00484){
    this.funVariable_00484 = funVariable_00484;
}

public String getFunVariable_00485(){
    return funVariable_00485;
}

public void setFunVariable_00485(String funVariable_00485){
    this.funVariable_00485 = funVariable_00485;
}

public String getFunVariable_00486(){
    return funVariable_00486;
}

public void setFunVariable_00486(String funVariable_00486){
    this.funVariable_00486 = funVariable_00486;
}

public String getFunVariable_00487(){
    return funVariable_00487;
}

public void setFunVariable_00487(String funVariable_00487){
    this.funVariable_00487 = funVariable_00487;
}

public String getFunVariable_00488(){
    return funVariable_00488;
}

public void setFunVariable_00488(String funVariable_00488){
    this.funVariable_00488 = funVariable_00488;
}

public String getFunVariable_00489(){
    return funVariable_00489;
}

public void setFunVariable_00489(String funVariable_00489){
    this.funVariable_00489 = funVariable_00489;
}

public String getFunVariable_00490(){
    return funVariable_00490;
}

public void setFunVariable_00490(String funVariable_00490){
    this.funVariable_00490 = funVariable_00490;
}

public String getFunVariable_00491(){
    return funVariable_00491;
}

public void setFunVariable_00491(String funVariable_00491){
    this.funVariable_00491 = funVariable_00491;
}

public String getFunVariable_00492(){
    return funVariable_00492;
}

public void setFunVariable_00492(String funVariable_00492){
    this.funVariable_00492 = funVariable_00492;
}

public String getFunVariable_00493(){
    return funVariable_00493;
}

public void setFunVariable_00493(String funVariable_00493){
    this.funVariable_00493 = funVariable_00493;
}

public String getFunVariable_00494(){
    return funVariable_00494;
}

public void setFunVariable_00494(String funVariable_00494){
    this.funVariable_00494 = funVariable_00494;
}

public String getFunVariable_00495(){
    return funVariable_00495;
}

public void setFunVariable_00495(String funVariable_00495){
    this.funVariable_00495 = funVariable_00495;
}

public String getFunVariable_00496(){
    return funVariable_00496;
}

public void setFunVariable_00496(String funVariable_00496){
    this.funVariable_00496 = funVariable_00496;
}

public String getFunVariable_00497(){
    return funVariable_00497;
}

public void setFunVariable_00497(String funVariable_00497){
    this.funVariable_00497 = funVariable_00497;
}

public String getFunVariable_00498(){
    return funVariable_00498;
}

public void setFunVariable_00498(String funVariable_00498){
    this.funVariable_00498 = funVariable_00498;
}

public String getFunVariable_00499(){
    return funVariable_00499;
}

public void setFunVariable_00499(String funVariable_00499){
    this.funVariable_00499 = funVariable_00499;
}

public String getFunVariable_00500(){
    return funVariable_00500;
}

public void setFunVariable_00500(String funVariable_00500){
    this.funVariable_00500 = funVariable_00500;
}

public String getFunVariable_00501(){
    return funVariable_00501;
}

public void setFunVariable_00501(String funVariable_00501){
    this.funVariable_00501 = funVariable_00501;
}

public String getFunVariable_00502(){
    return funVariable_00502;
}

public void setFunVariable_00502(String funVariable_00502){
    this.funVariable_00502 = funVariable_00502;
}

public String getFunVariable_00503(){
    return funVariable_00503;
}

public void setFunVariable_00503(String funVariable_00503){
    this.funVariable_00503 = funVariable_00503;
}

public String getFunVariable_00504(){
    return funVariable_00504;
}

public void setFunVariable_00504(String funVariable_00504){
    this.funVariable_00504 = funVariable_00504;
}

public String getFunVariable_00505(){
    return funVariable_00505;
}

public void setFunVariable_00505(String funVariable_00505){
    this.funVariable_00505 = funVariable_00505;
}

public String getFunVariable_00506(){
    return funVariable_00506;
}

public void setFunVariable_00506(String funVariable_00506){
    this.funVariable_00506 = funVariable_00506;
}

public String getFunVariable_00507(){
    return funVariable_00507;
}

public void setFunVariable_00507(String funVariable_00507){
    this.funVariable_00507 = funVariable_00507;
}

public String getFunVariable_00508(){
    return funVariable_00508;
}

public void setFunVariable_00508(String funVariable_00508){
    this.funVariable_00508 = funVariable_00508;
}

public String getFunVariable_00509(){
    return funVariable_00509;
}

public void setFunVariable_00509(String funVariable_00509){
    this.funVariable_00509 = funVariable_00509;
}

public String getFunVariable_00510(){
    return funVariable_00510;
}

public void setFunVariable_00510(String funVariable_00510){
    this.funVariable_00510 = funVariable_00510;
}

public String getFunVariable_00511(){
    return funVariable_00511;
}

public void setFunVariable_00511(String funVariable_00511){
    this.funVariable_00511 = funVariable_00511;
}

public String getFunVariable_00512(){
    return funVariable_00512;
}

public void setFunVariable_00512(String funVariable_00512){
    this.funVariable_00512 = funVariable_00512;
}

public String getFunVariable_00513(){
    return funVariable_00513;
}

public void setFunVariable_00513(String funVariable_00513){
    this.funVariable_00513 = funVariable_00513;
}

public String getFunVariable_00514(){
    return funVariable_00514;
}

public void setFunVariable_00514(String funVariable_00514){
    this.funVariable_00514 = funVariable_00514;
}

public String getFunVariable_00515(){
    return funVariable_00515;
}

public void setFunVariable_00515(String funVariable_00515){
    this.funVariable_00515 = funVariable_00515;
}

public String getFunVariable_00516(){
    return funVariable_00516;
}

public void setFunVariable_00516(String funVariable_00516){
    this.funVariable_00516 = funVariable_00516;
}

public String getFunVariable_00517(){
    return funVariable_00517;
}

public void setFunVariable_00517(String funVariable_00517){
    this.funVariable_00517 = funVariable_00517;
}

public String getFunVariable_00518(){
    return funVariable_00518;
}

public void setFunVariable_00518(String funVariable_00518){
    this.funVariable_00518 = funVariable_00518;
}

public String getFunVariable_00519(){
    return funVariable_00519;
}

public void setFunVariable_00519(String funVariable_00519){
    this.funVariable_00519 = funVariable_00519;
}

public String getFunVariable_00520(){
    return funVariable_00520;
}

public void setFunVariable_00520(String funVariable_00520){
    this.funVariable_00520 = funVariable_00520;
}

public String getFunVariable_00521(){
    return funVariable_00521;
}

public void setFunVariable_00521(String funVariable_00521){
    this.funVariable_00521 = funVariable_00521;
}

public String getFunVariable_00522(){
    return funVariable_00522;
}

public void setFunVariable_00522(String funVariable_00522){
    this.funVariable_00522 = funVariable_00522;
}

public String getFunVariable_00523(){
    return funVariable_00523;
}

public void setFunVariable_00523(String funVariable_00523){
    this.funVariable_00523 = funVariable_00523;
}

public String getFunVariable_00524(){
    return funVariable_00524;
}

public void setFunVariable_00524(String funVariable_00524){
    this.funVariable_00524 = funVariable_00524;
}

public String getFunVariable_00525(){
    return funVariable_00525;
}

public void setFunVariable_00525(String funVariable_00525){
    this.funVariable_00525 = funVariable_00525;
}

public String getFunVariable_00526(){
    return funVariable_00526;
}

public void setFunVariable_00526(String funVariable_00526){
    this.funVariable_00526 = funVariable_00526;
}

public String getFunVariable_00527(){
    return funVariable_00527;
}

public void setFunVariable_00527(String funVariable_00527){
    this.funVariable_00527 = funVariable_00527;
}

public String getFunVariable_00528(){
    return funVariable_00528;
}

public void setFunVariable_00528(String funVariable_00528){
    this.funVariable_00528 = funVariable_00528;
}

public String getFunVariable_00529(){
    return funVariable_00529;
}

public void setFunVariable_00529(String funVariable_00529){
    this.funVariable_00529 = funVariable_00529;
}

public String getFunVariable_00530(){
    return funVariable_00530;
}

public void setFunVariable_00530(String funVariable_00530){
    this.funVariable_00530 = funVariable_00530;
}

public String getFunVariable_00531(){
    return funVariable_00531;
}

public void setFunVariable_00531(String funVariable_00531){
    this.funVariable_00531 = funVariable_00531;
}

public String getFunVariable_00532(){
    return funVariable_00532;
}

public void setFunVariable_00532(String funVariable_00532){
    this.funVariable_00532 = funVariable_00532;
}

public String getFunVariable_00533(){
    return funVariable_00533;
}

public void setFunVariable_00533(String funVariable_00533){
    this.funVariable_00533 = funVariable_00533;
}

public String getFunVariable_00534(){
    return funVariable_00534;
}

public void setFunVariable_00534(String funVariable_00534){
    this.funVariable_00534 = funVariable_00534;
}

public String getFunVariable_00535(){
    return funVariable_00535;
}

public void setFunVariable_00535(String funVariable_00535){
    this.funVariable_00535 = funVariable_00535;
}

public String getFunVariable_00536(){
    return funVariable_00536;
}

public void setFunVariable_00536(String funVariable_00536){
    this.funVariable_00536 = funVariable_00536;
}

public String getFunVariable_00537(){
    return funVariable_00537;
}

public void setFunVariable_00537(String funVariable_00537){
    this.funVariable_00537 = funVariable_00537;
}

public String getFunVariable_00538(){
    return funVariable_00538;
}

public void setFunVariable_00538(String funVariable_00538){
    this.funVariable_00538 = funVariable_00538;
}

public String getFunVariable_00539(){
    return funVariable_00539;
}

public void setFunVariable_00539(String funVariable_00539){
    this.funVariable_00539 = funVariable_00539;
}

public String getFunVariable_00540(){
    return funVariable_00540;
}

public void setFunVariable_00540(String funVariable_00540){
    this.funVariable_00540 = funVariable_00540;
}

public String getFunVariable_00541(){
    return funVariable_00541;
}

public void setFunVariable_00541(String funVariable_00541){
    this.funVariable_00541 = funVariable_00541;
}

public String getFunVariable_00542(){
    return funVariable_00542;
}

public void setFunVariable_00542(String funVariable_00542){
    this.funVariable_00542 = funVariable_00542;
}

public String getFunVariable_00543(){
    return funVariable_00543;
}

public void setFunVariable_00543(String funVariable_00543){
    this.funVariable_00543 = funVariable_00543;
}

public String getFunVariable_00544(){
    return funVariable_00544;
}

public void setFunVariable_00544(String funVariable_00544){
    this.funVariable_00544 = funVariable_00544;
}

public String getFunVariable_00545(){
    return funVariable_00545;
}

public void setFunVariable_00545(String funVariable_00545){
    this.funVariable_00545 = funVariable_00545;
}

public String getFunVariable_00546(){
    return funVariable_00546;
}

public void setFunVariable_00546(String funVariable_00546){
    this.funVariable_00546 = funVariable_00546;
}

public String getFunVariable_00547(){
    return funVariable_00547;
}

public void setFunVariable_00547(String funVariable_00547){
    this.funVariable_00547 = funVariable_00547;
}

public String getFunVariable_00548(){
    return funVariable_00548;
}

public void setFunVariable_00548(String funVariable_00548){
    this.funVariable_00548 = funVariable_00548;
}

public String getFunVariable_00549(){
    return funVariable_00549;
}

public void setFunVariable_00549(String funVariable_00549){
    this.funVariable_00549 = funVariable_00549;
}

public String getFunVariable_00550(){
    return funVariable_00550;
}

public void setFunVariable_00550(String funVariable_00550){
    this.funVariable_00550 = funVariable_00550;
}

public String getFunVariable_00551(){
    return funVariable_00551;
}

public void setFunVariable_00551(String funVariable_00551){
    this.funVariable_00551 = funVariable_00551;
}

public String getFunVariable_00552(){
    return funVariable_00552;
}

public void setFunVariable_00552(String funVariable_00552){
    this.funVariable_00552 = funVariable_00552;
}

public String getFunVariable_00553(){
    return funVariable_00553;
}

public void setFunVariable_00553(String funVariable_00553){
    this.funVariable_00553 = funVariable_00553;
}

public String getFunVariable_00554(){
    return funVariable_00554;
}

public void setFunVariable_00554(String funVariable_00554){
    this.funVariable_00554 = funVariable_00554;
}

public String getFunVariable_00555(){
    return funVariable_00555;
}

public void setFunVariable_00555(String funVariable_00555){
    this.funVariable_00555 = funVariable_00555;
}

public String getFunVariable_00556(){
    return funVariable_00556;
}

public void setFunVariable_00556(String funVariable_00556){
    this.funVariable_00556 = funVariable_00556;
}

public String getFunVariable_00557(){
    return funVariable_00557;
}

public void setFunVariable_00557(String funVariable_00557){
    this.funVariable_00557 = funVariable_00557;
}

public String getFunVariable_00558(){
    return funVariable_00558;
}

public void setFunVariable_00558(String funVariable_00558){
    this.funVariable_00558 = funVariable_00558;
}

public String getFunVariable_00559(){
    return funVariable_00559;
}

public void setFunVariable_00559(String funVariable_00559){
    this.funVariable_00559 = funVariable_00559;
}

public String getFunVariable_00560(){
    return funVariable_00560;
}

public void setFunVariable_00560(String funVariable_00560){
    this.funVariable_00560 = funVariable_00560;
}

public String getFunVariable_00561(){
    return funVariable_00561;
}

public void setFunVariable_00561(String funVariable_00561){
    this.funVariable_00561 = funVariable_00561;
}

public String getFunVariable_00562(){
    return funVariable_00562;
}

public void setFunVariable_00562(String funVariable_00562){
    this.funVariable_00562 = funVariable_00562;
}

public String getFunVariable_00563(){
    return funVariable_00563;
}

public void setFunVariable_00563(String funVariable_00563){
    this.funVariable_00563 = funVariable_00563;
}

public String getFunVariable_00564(){
    return funVariable_00564;
}

public void setFunVariable_00564(String funVariable_00564){
    this.funVariable_00564 = funVariable_00564;
}

public String getFunVariable_00565(){
    return funVariable_00565;
}

public void setFunVariable_00565(String funVariable_00565){
    this.funVariable_00565 = funVariable_00565;
}

public String getFunVariable_00566(){
    return funVariable_00566;
}

public void setFunVariable_00566(String funVariable_00566){
    this.funVariable_00566 = funVariable_00566;
}

public String getFunVariable_00567(){
    return funVariable_00567;
}

public void setFunVariable_00567(String funVariable_00567){
    this.funVariable_00567 = funVariable_00567;
}

public String getFunVariable_00568(){
    return funVariable_00568;
}

public void setFunVariable_00568(String funVariable_00568){
    this.funVariable_00568 = funVariable_00568;
}

public String getFunVariable_00569(){
    return funVariable_00569;
}

public void setFunVariable_00569(String funVariable_00569){
    this.funVariable_00569 = funVariable_00569;
}

public String getFunVariable_00570(){
    return funVariable_00570;
}

public void setFunVariable_00570(String funVariable_00570){
    this.funVariable_00570 = funVariable_00570;
}

public String getFunVariable_00571(){
    return funVariable_00571;
}

public void setFunVariable_00571(String funVariable_00571){
    this.funVariable_00571 = funVariable_00571;
}

public String getFunVariable_00572(){
    return funVariable_00572;
}

public void setFunVariable_00572(String funVariable_00572){
    this.funVariable_00572 = funVariable_00572;
}

public String getFunVariable_00573(){
    return funVariable_00573;
}

public void setFunVariable_00573(String funVariable_00573){
    this.funVariable_00573 = funVariable_00573;
}

public String getFunVariable_00574(){
    return funVariable_00574;
}

public void setFunVariable_00574(String funVariable_00574){
    this.funVariable_00574 = funVariable_00574;
}

public String getFunVariable_00575(){
    return funVariable_00575;
}

public void setFunVariable_00575(String funVariable_00575){
    this.funVariable_00575 = funVariable_00575;
}

public String getFunVariable_00576(){
    return funVariable_00576;
}

public void setFunVariable_00576(String funVariable_00576){
    this.funVariable_00576 = funVariable_00576;
}

public String getFunVariable_00577(){
    return funVariable_00577;
}

public void setFunVariable_00577(String funVariable_00577){
    this.funVariable_00577 = funVariable_00577;
}

public String getFunVariable_00578(){
    return funVariable_00578;
}

public void setFunVariable_00578(String funVariable_00578){
    this.funVariable_00578 = funVariable_00578;
}

public String getFunVariable_00579(){
    return funVariable_00579;
}

public void setFunVariable_00579(String funVariable_00579){
    this.funVariable_00579 = funVariable_00579;
}

public String getFunVariable_00580(){
    return funVariable_00580;
}

public void setFunVariable_00580(String funVariable_00580){
    this.funVariable_00580 = funVariable_00580;
}

public String getFunVariable_00581(){
    return funVariable_00581;
}

public void setFunVariable_00581(String funVariable_00581){
    this.funVariable_00581 = funVariable_00581;
}

public String getFunVariable_00582(){
    return funVariable_00582;
}

public void setFunVariable_00582(String funVariable_00582){
    this.funVariable_00582 = funVariable_00582;
}

public String getFunVariable_00583(){
    return funVariable_00583;
}

public void setFunVariable_00583(String funVariable_00583){
    this.funVariable_00583 = funVariable_00583;
}

public String getFunVariable_00584(){
    return funVariable_00584;
}

public void setFunVariable_00584(String funVariable_00584){
    this.funVariable_00584 = funVariable_00584;
}

public String getFunVariable_00585(){
    return funVariable_00585;
}

public void setFunVariable_00585(String funVariable_00585){
    this.funVariable_00585 = funVariable_00585;
}

public String getFunVariable_00586(){
    return funVariable_00586;
}

public void setFunVariable_00586(String funVariable_00586){
    this.funVariable_00586 = funVariable_00586;
}

public String getFunVariable_00587(){
    return funVariable_00587;
}

public void setFunVariable_00587(String funVariable_00587){
    this.funVariable_00587 = funVariable_00587;
}

public String getFunVariable_00588(){
    return funVariable_00588;
}

public void setFunVariable_00588(String funVariable_00588){
    this.funVariable_00588 = funVariable_00588;
}

public String getFunVariable_00589(){
    return funVariable_00589;
}

public void setFunVariable_00589(String funVariable_00589){
    this.funVariable_00589 = funVariable_00589;
}

public String getFunVariable_00590(){
    return funVariable_00590;
}

public void setFunVariable_00590(String funVariable_00590){
    this.funVariable_00590 = funVariable_00590;
}

public String getFunVariable_00591(){
    return funVariable_00591;
}

public void setFunVariable_00591(String funVariable_00591){
    this.funVariable_00591 = funVariable_00591;
}

public String getFunVariable_00592(){
    return funVariable_00592;
}

public void setFunVariable_00592(String funVariable_00592){
    this.funVariable_00592 = funVariable_00592;
}

public String getFunVariable_00593(){
    return funVariable_00593;
}

public void setFunVariable_00593(String funVariable_00593){
    this.funVariable_00593 = funVariable_00593;
}

public String getFunVariable_00594(){
    return funVariable_00594;
}

public void setFunVariable_00594(String funVariable_00594){
    this.funVariable_00594 = funVariable_00594;
}

public String getFunVariable_00595(){
    return funVariable_00595;
}

public void setFunVariable_00595(String funVariable_00595){
    this.funVariable_00595 = funVariable_00595;
}

public String getFunVariable_00596(){
    return funVariable_00596;
}

public void setFunVariable_00596(String funVariable_00596){
    this.funVariable_00596 = funVariable_00596;
}

public String getFunVariable_00597(){
    return funVariable_00597;
}

public void setFunVariable_00597(String funVariable_00597){
    this.funVariable_00597 = funVariable_00597;
}

public String getFunVariable_00598(){
    return funVariable_00598;
}

public void setFunVariable_00598(String funVariable_00598){
    this.funVariable_00598 = funVariable_00598;
}

public String getFunVariable_00599(){
    return funVariable_00599;
}

public void setFunVariable_00599(String funVariable_00599){
    this.funVariable_00599 = funVariable_00599;
}

public String getFunVariable_00600(){
    return funVariable_00600;
}

public void setFunVariable_00600(String funVariable_00600){
    this.funVariable_00600 = funVariable_00600;
}

public String getOmcVariable_a00001(){
    return omcVariable_a00001;
}

public void setOmcVariable_a00001(String omcVariable_a00001){
    this.omcVariable_a00001 = omcVariable_a00001;
}

public String getOmcVariable_a00002(){
    return omcVariable_a00002;
}

public void setOmcVariable_a00002(String omcVariable_a00002){
    this.omcVariable_a00002 = omcVariable_a00002;
}

public String getOmcVariable_a00003(){
    return omcVariable_a00003;
}

public void setOmcVariable_a00003(String omcVariable_a00003){
    this.omcVariable_a00003 = omcVariable_a00003;
}

public String getOmcVariable_a00004(){
    return omcVariable_a00004;
}

public void setOmcVariable_a00004(String omcVariable_a00004){
    this.omcVariable_a00004 = omcVariable_a00004;
}

public String getOmcVariable_a00005(){
    return omcVariable_a00005;
}

public void setOmcVariable_a00005(String omcVariable_a00005){
    this.omcVariable_a00005 = omcVariable_a00005;
}

public String getOmcVariable_a00006(){
    return omcVariable_a00006;
}

public void setOmcVariable_a00006(String omcVariable_a00006){
    this.omcVariable_a00006 = omcVariable_a00006;
}

public String getOmcVariable_a00007(){
    return omcVariable_a00007;
}

public void setOmcVariable_a00007(String omcVariable_a00007){
    this.omcVariable_a00007 = omcVariable_a00007;
}

public String getOmcVariable_a00008(){
    return omcVariable_a00008;
}

public void setOmcVariable_a00008(String omcVariable_a00008){
    this.omcVariable_a00008 = omcVariable_a00008;
}

public String getOmcVariable_a00009(){
    return omcVariable_a00009;
}

public void setOmcVariable_a00009(String omcVariable_a00009){
    this.omcVariable_a00009 = omcVariable_a00009;
}

public String getOmcVariable_a00010(){
    return omcVariable_a00010;
}

public void setOmcVariable_a00010(String omcVariable_a00010){
    this.omcVariable_a00010 = omcVariable_a00010;
}

public String getOmcVariable_a00011(){
    return omcVariable_a00011;
}

public void setOmcVariable_a00011(String omcVariable_a00011){
    this.omcVariable_a00011 = omcVariable_a00011;
}

public String getOmcVariable_a00012(){
    return omcVariable_a00012;
}

public void setOmcVariable_a00012(String omcVariable_a00012){
    this.omcVariable_a00012 = omcVariable_a00012;
}

public String getOmcVariable_a00013(){
    return omcVariable_a00013;
}

public void setOmcVariable_a00013(String omcVariable_a00013){
    this.omcVariable_a00013 = omcVariable_a00013;
}

public String getOmcVariable_a00014(){
    return omcVariable_a00014;
}

public void setOmcVariable_a00014(String omcVariable_a00014){
    this.omcVariable_a00014 = omcVariable_a00014;
}

public String getOmcVariable_a00015(){
    return omcVariable_a00015;
}

public void setOmcVariable_a00015(String omcVariable_a00015){
    this.omcVariable_a00015 = omcVariable_a00015;
}

public String getOmcVariable_a00016(){
    return omcVariable_a00016;
}

public void setOmcVariable_a00016(String omcVariable_a00016){
    this.omcVariable_a00016 = omcVariable_a00016;
}

public String getOmcVariable_a00017(){
    return omcVariable_a00017;
}

public void setOmcVariable_a00017(String omcVariable_a00017){
    this.omcVariable_a00017 = omcVariable_a00017;
}

public String getOmcVariable_a00018(){
    return omcVariable_a00018;
}

public void setOmcVariable_a00018(String omcVariable_a00018){
    this.omcVariable_a00018 = omcVariable_a00018;
}

public String getOmcVariable_a00019(){
    return omcVariable_a00019;
}

public void setOmcVariable_a00019(String omcVariable_a00019){
    this.omcVariable_a00019 = omcVariable_a00019;
}

public String getOmcVariable_a00020(){
    return omcVariable_a00020;
}

public void setOmcVariable_a00020(String omcVariable_a00020){
    this.omcVariable_a00020 = omcVariable_a00020;
}

public String getOmcVariable_a00021(){
    return omcVariable_a00021;
}

public void setOmcVariable_a00021(String omcVariable_a00021){
    this.omcVariable_a00021 = omcVariable_a00021;
}

public String getOmcVariable_a00022(){
    return omcVariable_a00022;
}

public void setOmcVariable_a00022(String omcVariable_a00022){
    this.omcVariable_a00022 = omcVariable_a00022;
}

public String getOmcVariable_a00023(){
    return omcVariable_a00023;
}

public void setOmcVariable_a00023(String omcVariable_a00023){
    this.omcVariable_a00023 = omcVariable_a00023;
}

public String getOmcVariable_a00024(){
    return omcVariable_a00024;
}

public void setOmcVariable_a00024(String omcVariable_a00024){
    this.omcVariable_a00024 = omcVariable_a00024;
}

public String getOmcVariable_a00025(){
    return omcVariable_a00025;
}

public void setOmcVariable_a00025(String omcVariable_a00025){
    this.omcVariable_a00025 = omcVariable_a00025;
}

public String getOmcVariable_a00026(){
    return omcVariable_a00026;
}

public void setOmcVariable_a00026(String omcVariable_a00026){
    this.omcVariable_a00026 = omcVariable_a00026;
}

public String getOmcVariable_a00027(){
    return omcVariable_a00027;
}

public void setOmcVariable_a00027(String omcVariable_a00027){
    this.omcVariable_a00027 = omcVariable_a00027;
}

public String getOmcVariable_a00028(){
    return omcVariable_a00028;
}

public void setOmcVariable_a00028(String omcVariable_a00028){
    this.omcVariable_a00028 = omcVariable_a00028;
}

public String getOmcVariable_a00029(){
    return omcVariable_a00029;
}

public void setOmcVariable_a00029(String omcVariable_a00029){
    this.omcVariable_a00029 = omcVariable_a00029;
}

public String getOmcVariable_a00030(){
    return omcVariable_a00030;
}

public void setOmcVariable_a00030(String omcVariable_a00030){
    this.omcVariable_a00030 = omcVariable_a00030;
}

public String getOmcVariable_a00031(){
    return omcVariable_a00031;
}

public void setOmcVariable_a00031(String omcVariable_a00031){
    this.omcVariable_a00031 = omcVariable_a00031;
}

public String getOmcVariable_a00032(){
    return omcVariable_a00032;
}

public void setOmcVariable_a00032(String omcVariable_a00032){
    this.omcVariable_a00032 = omcVariable_a00032;
}

public String getOmcVariable_a00033(){
    return omcVariable_a00033;
}

public void setOmcVariable_a00033(String omcVariable_a00033){
    this.omcVariable_a00033 = omcVariable_a00033;
}

public String getOmcVariable_a00034(){
    return omcVariable_a00034;
}

public void setOmcVariable_a00034(String omcVariable_a00034){
    this.omcVariable_a00034 = omcVariable_a00034;
}

public String getOmcVariable_a00035(){
    return omcVariable_a00035;
}

public void setOmcVariable_a00035(String omcVariable_a00035){
    this.omcVariable_a00035 = omcVariable_a00035;
}

public String getOmcVariable_a00036(){
    return omcVariable_a00036;
}

public void setOmcVariable_a00036(String omcVariable_a00036){
    this.omcVariable_a00036 = omcVariable_a00036;
}

public String getOmcVariable_a00037(){
    return omcVariable_a00037;
}

public void setOmcVariable_a00037(String omcVariable_a00037){
    this.omcVariable_a00037 = omcVariable_a00037;
}

public String getOmcVariable_a00038(){
    return omcVariable_a00038;
}

public void setOmcVariable_a00038(String omcVariable_a00038){
    this.omcVariable_a00038 = omcVariable_a00038;
}

public String getOmcVariable_a00039(){
    return omcVariable_a00039;
}

public void setOmcVariable_a00039(String omcVariable_a00039){
    this.omcVariable_a00039 = omcVariable_a00039;
}

public String getOmcVariable_a00040(){
    return omcVariable_a00040;
}

public void setOmcVariable_a00040(String omcVariable_a00040){
    this.omcVariable_a00040 = omcVariable_a00040;
}

public String getOmcVariable_a00041(){
    return omcVariable_a00041;
}

public void setOmcVariable_a00041(String omcVariable_a00041){
    this.omcVariable_a00041 = omcVariable_a00041;
}

public String getOmcVariable_a00042(){
    return omcVariable_a00042;
}

public void setOmcVariable_a00042(String omcVariable_a00042){
    this.omcVariable_a00042 = omcVariable_a00042;
}

public String getOmcVariable_a00043(){
    return omcVariable_a00043;
}

public void setOmcVariable_a00043(String omcVariable_a00043){
    this.omcVariable_a00043 = omcVariable_a00043;
}

public String getOmcVariable_a00044(){
    return omcVariable_a00044;
}

public void setOmcVariable_a00044(String omcVariable_a00044){
    this.omcVariable_a00044 = omcVariable_a00044;
}

public String getOmcVariable_a00045(){
    return omcVariable_a00045;
}

public void setOmcVariable_a00045(String omcVariable_a00045){
    this.omcVariable_a00045 = omcVariable_a00045;
}

public String getOmcVariable_a00046(){
    return omcVariable_a00046;
}

public void setOmcVariable_a00046(String omcVariable_a00046){
    this.omcVariable_a00046 = omcVariable_a00046;
}

public String getOmcVariable_a00047(){
    return omcVariable_a00047;
}

public void setOmcVariable_a00047(String omcVariable_a00047){
    this.omcVariable_a00047 = omcVariable_a00047;
}

public String getOmcVariable_a00048(){
    return omcVariable_a00048;
}

public void setOmcVariable_a00048(String omcVariable_a00048){
    this.omcVariable_a00048 = omcVariable_a00048;
}

public String getOmcVariable_a00049(){
    return omcVariable_a00049;
}

public void setOmcVariable_a00049(String omcVariable_a00049){
    this.omcVariable_a00049 = omcVariable_a00049;
}

public String getOmcVariable_a00050(){
    return omcVariable_a00050;
}

public void setOmcVariable_a00050(String omcVariable_a00050){
    this.omcVariable_a00050 = omcVariable_a00050;
}

public String getOmcVariable_a00051(){
    return omcVariable_a00051;
}

public void setOmcVariable_a00051(String omcVariable_a00051){
    this.omcVariable_a00051 = omcVariable_a00051;
}

public String getOmcVariable_a00052(){
    return omcVariable_a00052;
}

public void setOmcVariable_a00052(String omcVariable_a00052){
    this.omcVariable_a00052 = omcVariable_a00052;
}

public String getOmcVariable_a00053(){
    return omcVariable_a00053;
}

public void setOmcVariable_a00053(String omcVariable_a00053){
    this.omcVariable_a00053 = omcVariable_a00053;
}

public String getOmcVariable_a00054(){
    return omcVariable_a00054;
}

public void setOmcVariable_a00054(String omcVariable_a00054){
    this.omcVariable_a00054 = omcVariable_a00054;
}

public String getOmcVariable_a00055(){
    return omcVariable_a00055;
}

public void setOmcVariable_a00055(String omcVariable_a00055){
    this.omcVariable_a00055 = omcVariable_a00055;
}

public String getOmcVariable_a00056(){
    return omcVariable_a00056;
}

public void setOmcVariable_a00056(String omcVariable_a00056){
    this.omcVariable_a00056 = omcVariable_a00056;
}

public String getOmcVariable_a00057(){
    return omcVariable_a00057;
}

public void setOmcVariable_a00057(String omcVariable_a00057){
    this.omcVariable_a00057 = omcVariable_a00057;
}

public String getOmcVariable_a00058(){
    return omcVariable_a00058;
}

public void setOmcVariable_a00058(String omcVariable_a00058){
    this.omcVariable_a00058 = omcVariable_a00058;
}

public String getOmcVariable_a00059(){
    return omcVariable_a00059;
}

public void setOmcVariable_a00059(String omcVariable_a00059){
    this.omcVariable_a00059 = omcVariable_a00059;
}

public String getOmcVariable_a00060(){
    return omcVariable_a00060;
}

public void setOmcVariable_a00060(String omcVariable_a00060){
    this.omcVariable_a00060 = omcVariable_a00060;
}

public String getOmcVariable_a00061(){
    return omcVariable_a00061;
}

public void setOmcVariable_a00061(String omcVariable_a00061){
    this.omcVariable_a00061 = omcVariable_a00061;
}

public String getOmcVariable_a00062(){
    return omcVariable_a00062;
}

public void setOmcVariable_a00062(String omcVariable_a00062){
    this.omcVariable_a00062 = omcVariable_a00062;
}

public String getOmcVariable_a00063(){
    return omcVariable_a00063;
}

public void setOmcVariable_a00063(String omcVariable_a00063){
    this.omcVariable_a00063 = omcVariable_a00063;
}

public String getOmcVariable_a00064(){
    return omcVariable_a00064;
}

public void setOmcVariable_a00064(String omcVariable_a00064){
    this.omcVariable_a00064 = omcVariable_a00064;
}

public String getOmcVariable_a00065(){
    return omcVariable_a00065;
}

public void setOmcVariable_a00065(String omcVariable_a00065){
    this.omcVariable_a00065 = omcVariable_a00065;
}

public String getOmcVariable_a00066(){
    return omcVariable_a00066;
}

public void setOmcVariable_a00066(String omcVariable_a00066){
    this.omcVariable_a00066 = omcVariable_a00066;
}

public String getOmcVariable_a00067(){
    return omcVariable_a00067;
}

public void setOmcVariable_a00067(String omcVariable_a00067){
    this.omcVariable_a00067 = omcVariable_a00067;
}

public String getOmcVariable_a00068(){
    return omcVariable_a00068;
}

public void setOmcVariable_a00068(String omcVariable_a00068){
    this.omcVariable_a00068 = omcVariable_a00068;
}

public String getOmcVariable_a00069(){
    return omcVariable_a00069;
}

public void setOmcVariable_a00069(String omcVariable_a00069){
    this.omcVariable_a00069 = omcVariable_a00069;
}

public String getOmcVariable_a00070(){
    return omcVariable_a00070;
}

public void setOmcVariable_a00070(String omcVariable_a00070){
    this.omcVariable_a00070 = omcVariable_a00070;
}

public String getOmcVariable_a00071(){
    return omcVariable_a00071;
}

public void setOmcVariable_a00071(String omcVariable_a00071){
    this.omcVariable_a00071 = omcVariable_a00071;
}

public String getOmcVariable_a00072(){
    return omcVariable_a00072;
}

public void setOmcVariable_a00072(String omcVariable_a00072){
    this.omcVariable_a00072 = omcVariable_a00072;
}

public String getOmcVariable_a00073(){
    return omcVariable_a00073;
}

public void setOmcVariable_a00073(String omcVariable_a00073){
    this.omcVariable_a00073 = omcVariable_a00073;
}

public String getOmcVariable_a00074(){
    return omcVariable_a00074;
}

public void setOmcVariable_a00074(String omcVariable_a00074){
    this.omcVariable_a00074 = omcVariable_a00074;
}

public String getOmcVariable_a00075(){
    return omcVariable_a00075;
}

public void setOmcVariable_a00075(String omcVariable_a00075){
    this.omcVariable_a00075 = omcVariable_a00075;
}

public String getOmcVariable_a00076(){
    return omcVariable_a00076;
}

public void setOmcVariable_a00076(String omcVariable_a00076){
    this.omcVariable_a00076 = omcVariable_a00076;
}

public String getOmcVariable_a00077(){
    return omcVariable_a00077;
}

public void setOmcVariable_a00077(String omcVariable_a00077){
    this.omcVariable_a00077 = omcVariable_a00077;
}

public String getOmcVariable_a00078(){
    return omcVariable_a00078;
}

public void setOmcVariable_a00078(String omcVariable_a00078){
    this.omcVariable_a00078 = omcVariable_a00078;
}

public String getOmcVariable_a00079(){
    return omcVariable_a00079;
}

public void setOmcVariable_a00079(String omcVariable_a00079){
    this.omcVariable_a00079 = omcVariable_a00079;
}

public String getOmcVariable_a00080(){
    return omcVariable_a00080;
}

public void setOmcVariable_a00080(String omcVariable_a00080){
    this.omcVariable_a00080 = omcVariable_a00080;
}

public String getOmcVariable_a00081(){
    return omcVariable_a00081;
}

public void setOmcVariable_a00081(String omcVariable_a00081){
    this.omcVariable_a00081 = omcVariable_a00081;
}

public String getOmcVariable_a00082(){
    return omcVariable_a00082;
}

public void setOmcVariable_a00082(String omcVariable_a00082){
    this.omcVariable_a00082 = omcVariable_a00082;
}

public String getOmcVariable_a00083(){
    return omcVariable_a00083;
}

public void setOmcVariable_a00083(String omcVariable_a00083){
    this.omcVariable_a00083 = omcVariable_a00083;
}

public String getOmcVariable_a00084(){
    return omcVariable_a00084;
}

public void setOmcVariable_a00084(String omcVariable_a00084){
    this.omcVariable_a00084 = omcVariable_a00084;
}

public String getOmcVariable_a00085(){
    return omcVariable_a00085;
}

public void setOmcVariable_a00085(String omcVariable_a00085){
    this.omcVariable_a00085 = omcVariable_a00085;
}

public String getOmcVariable_a00086(){
    return omcVariable_a00086;
}

public void setOmcVariable_a00086(String omcVariable_a00086){
    this.omcVariable_a00086 = omcVariable_a00086;
}

public String getOmcVariable_a00087(){
    return omcVariable_a00087;
}

public void setOmcVariable_a00087(String omcVariable_a00087){
    this.omcVariable_a00087 = omcVariable_a00087;
}

public String getOmcVariable_a00088(){
    return omcVariable_a00088;
}

public void setOmcVariable_a00088(String omcVariable_a00088){
    this.omcVariable_a00088 = omcVariable_a00088;
}

public String getOmcVariable_a00089(){
    return omcVariable_a00089;
}

public void setOmcVariable_a00089(String omcVariable_a00089){
    this.omcVariable_a00089 = omcVariable_a00089;
}

public String getOmcVariable_a00090(){
    return omcVariable_a00090;
}

public void setOmcVariable_a00090(String omcVariable_a00090){
    this.omcVariable_a00090 = omcVariable_a00090;
}

public String getOmcVariable_a00091(){
    return omcVariable_a00091;
}

public void setOmcVariable_a00091(String omcVariable_a00091){
    this.omcVariable_a00091 = omcVariable_a00091;
}

public String getOmcVariable_a00092(){
    return omcVariable_a00092;
}

public void setOmcVariable_a00092(String omcVariable_a00092){
    this.omcVariable_a00092 = omcVariable_a00092;
}

public String getOmcVariable_a00093(){
    return omcVariable_a00093;
}

public void setOmcVariable_a00093(String omcVariable_a00093){
    this.omcVariable_a00093 = omcVariable_a00093;
}

public String getOmcVariable_a00094(){
    return omcVariable_a00094;
}

public void setOmcVariable_a00094(String omcVariable_a00094){
    this.omcVariable_a00094 = omcVariable_a00094;
}

public String getOmcVariable_a00095(){
    return omcVariable_a00095;
}

public void setOmcVariable_a00095(String omcVariable_a00095){
    this.omcVariable_a00095 = omcVariable_a00095;
}

public String getOmcVariable_a00096(){
    return omcVariable_a00096;
}

public void setOmcVariable_a00096(String omcVariable_a00096){
    this.omcVariable_a00096 = omcVariable_a00096;
}

public String getOmcVariable_a00097(){
    return omcVariable_a00097;
}

public void setOmcVariable_a00097(String omcVariable_a00097){
    this.omcVariable_a00097 = omcVariable_a00097;
}

public String getOmcVariable_a00098(){
    return omcVariable_a00098;
}

public void setOmcVariable_a00098(String omcVariable_a00098){
    this.omcVariable_a00098 = omcVariable_a00098;
}

public String getOmcVariable_a00099(){
    return omcVariable_a00099;
}

public void setOmcVariable_a00099(String omcVariable_a00099){
    this.omcVariable_a00099 = omcVariable_a00099;
}

public String getOmcVariable_a00100(){
    return omcVariable_a00100;
}

public void setOmcVariable_a00100(String omcVariable_a00100){
    this.omcVariable_a00100 = omcVariable_a00100;
}

public String getOmcVariable_a00101(){
    return omcVariable_a00101;
}

public void setOmcVariable_a00101(String omcVariable_a00101){
    this.omcVariable_a00101 = omcVariable_a00101;
}

public String getOmcVariable_a00102(){
    return omcVariable_a00102;
}

public void setOmcVariable_a00102(String omcVariable_a00102){
    this.omcVariable_a00102 = omcVariable_a00102;
}

public String getOmcVariable_a00103(){
    return omcVariable_a00103;
}

public void setOmcVariable_a00103(String omcVariable_a00103){
    this.omcVariable_a00103 = omcVariable_a00103;
}

public String getOmcVariable_a00104(){
    return omcVariable_a00104;
}

public void setOmcVariable_a00104(String omcVariable_a00104){
    this.omcVariable_a00104 = omcVariable_a00104;
}

public String getOmcVariable_a00105(){
    return omcVariable_a00105;
}

public void setOmcVariable_a00105(String omcVariable_a00105){
    this.omcVariable_a00105 = omcVariable_a00105;
}

public String getOmcVariable_a00106(){
    return omcVariable_a00106;
}

public void setOmcVariable_a00106(String omcVariable_a00106){
    this.omcVariable_a00106 = omcVariable_a00106;
}

public String getOmcVariable_a00107(){
    return omcVariable_a00107;
}

public void setOmcVariable_a00107(String omcVariable_a00107){
    this.omcVariable_a00107 = omcVariable_a00107;
}

public String getOmcVariable_a00108(){
    return omcVariable_a00108;
}

public void setOmcVariable_a00108(String omcVariable_a00108){
    this.omcVariable_a00108 = omcVariable_a00108;
}

public String getOmcVariable_a00109(){
    return omcVariable_a00109;
}

public void setOmcVariable_a00109(String omcVariable_a00109){
    this.omcVariable_a00109 = omcVariable_a00109;
}

public String getOmcVariable_a00110(){
    return omcVariable_a00110;
}

public void setOmcVariable_a00110(String omcVariable_a00110){
    this.omcVariable_a00110 = omcVariable_a00110;
}

public String getOmcVariable_a00111(){
    return omcVariable_a00111;
}

public void setOmcVariable_a00111(String omcVariable_a00111){
    this.omcVariable_a00111 = omcVariable_a00111;
}

public String getOmcVariable_a00112(){
    return omcVariable_a00112;
}

public void setOmcVariable_a00112(String omcVariable_a00112){
    this.omcVariable_a00112 = omcVariable_a00112;
}

public String getOmcVariable_a00113(){
    return omcVariable_a00113;
}

public void setOmcVariable_a00113(String omcVariable_a00113){
    this.omcVariable_a00113 = omcVariable_a00113;
}

public String getOmcVariable_a00114(){
    return omcVariable_a00114;
}

public void setOmcVariable_a00114(String omcVariable_a00114){
    this.omcVariable_a00114 = omcVariable_a00114;
}

public String getOmcVariable_a00115(){
    return omcVariable_a00115;
}

public void setOmcVariable_a00115(String omcVariable_a00115){
    this.omcVariable_a00115 = omcVariable_a00115;
}

public String getOmcVariable_a00116(){
    return omcVariable_a00116;
}

public void setOmcVariable_a00116(String omcVariable_a00116){
    this.omcVariable_a00116 = omcVariable_a00116;
}

public String getOmcVariable_a00117(){
    return omcVariable_a00117;
}

public void setOmcVariable_a00117(String omcVariable_a00117){
    this.omcVariable_a00117 = omcVariable_a00117;
}

public String getOmcVariable_a00118(){
    return omcVariable_a00118;
}

public void setOmcVariable_a00118(String omcVariable_a00118){
    this.omcVariable_a00118 = omcVariable_a00118;
}

public String getOmcVariable_a00119(){
    return omcVariable_a00119;
}

public void setOmcVariable_a00119(String omcVariable_a00119){
    this.omcVariable_a00119 = omcVariable_a00119;
}

public String getOmcVariable_a00120(){
    return omcVariable_a00120;
}

public void setOmcVariable_a00120(String omcVariable_a00120){
    this.omcVariable_a00120 = omcVariable_a00120;
}

public String getOmcVariable_a00121(){
    return omcVariable_a00121;
}

public void setOmcVariable_a00121(String omcVariable_a00121){
    this.omcVariable_a00121 = omcVariable_a00121;
}

public String getOmcVariable_a00122(){
    return omcVariable_a00122;
}

public void setOmcVariable_a00122(String omcVariable_a00122){
    this.omcVariable_a00122 = omcVariable_a00122;
}

public String getOmcVariable_a00123(){
    return omcVariable_a00123;
}

public void setOmcVariable_a00123(String omcVariable_a00123){
    this.omcVariable_a00123 = omcVariable_a00123;
}

public String getOmcVariable_a00124(){
    return omcVariable_a00124;
}

public void setOmcVariable_a00124(String omcVariable_a00124){
    this.omcVariable_a00124 = omcVariable_a00124;
}

public String getOmcVariable_a00125(){
    return omcVariable_a00125;
}

public void setOmcVariable_a00125(String omcVariable_a00125){
    this.omcVariable_a00125 = omcVariable_a00125;
}

public String getOmcVariable_a00126(){
    return omcVariable_a00126;
}

public void setOmcVariable_a00126(String omcVariable_a00126){
    this.omcVariable_a00126 = omcVariable_a00126;
}

public String getOmcVariable_a00127(){
    return omcVariable_a00127;
}

public void setOmcVariable_a00127(String omcVariable_a00127){
    this.omcVariable_a00127 = omcVariable_a00127;
}

public String getOmcVariable_a00128(){
    return omcVariable_a00128;
}

public void setOmcVariable_a00128(String omcVariable_a00128){
    this.omcVariable_a00128 = omcVariable_a00128;
}

public String getOmcVariable_a00129(){
    return omcVariable_a00129;
}

public void setOmcVariable_a00129(String omcVariable_a00129){
    this.omcVariable_a00129 = omcVariable_a00129;
}

public String getOmcVariable_a00130(){
    return omcVariable_a00130;
}

public void setOmcVariable_a00130(String omcVariable_a00130){
    this.omcVariable_a00130 = omcVariable_a00130;
}

public String getOmcVariable_a00131(){
    return omcVariable_a00131;
}

public void setOmcVariable_a00131(String omcVariable_a00131){
    this.omcVariable_a00131 = omcVariable_a00131;
}

public String getOmcVariable_a00132(){
    return omcVariable_a00132;
}

public void setOmcVariable_a00132(String omcVariable_a00132){
    this.omcVariable_a00132 = omcVariable_a00132;
}

public String getOmcVariable_a00133(){
    return omcVariable_a00133;
}

public void setOmcVariable_a00133(String omcVariable_a00133){
    this.omcVariable_a00133 = omcVariable_a00133;
}

public String getOmcVariable_a00134(){
    return omcVariable_a00134;
}

public void setOmcVariable_a00134(String omcVariable_a00134){
    this.omcVariable_a00134 = omcVariable_a00134;
}

public String getOmcVariable_a00135(){
    return omcVariable_a00135;
}

public void setOmcVariable_a00135(String omcVariable_a00135){
    this.omcVariable_a00135 = omcVariable_a00135;
}

public String getOmcVariable_a00136(){
    return omcVariable_a00136;
}

public void setOmcVariable_a00136(String omcVariable_a00136){
    this.omcVariable_a00136 = omcVariable_a00136;
}

public String getOmcVariable_a00137(){
    return omcVariable_a00137;
}

public void setOmcVariable_a00137(String omcVariable_a00137){
    this.omcVariable_a00137 = omcVariable_a00137;
}

public String getOmcVariable_a00138(){
    return omcVariable_a00138;
}

public void setOmcVariable_a00138(String omcVariable_a00138){
    this.omcVariable_a00138 = omcVariable_a00138;
}

public String getOmcVariable_a00139(){
    return omcVariable_a00139;
}

public void setOmcVariable_a00139(String omcVariable_a00139){
    this.omcVariable_a00139 = omcVariable_a00139;
}

public String getOmcVariable_a00140(){
    return omcVariable_a00140;
}

public void setOmcVariable_a00140(String omcVariable_a00140){
    this.omcVariable_a00140 = omcVariable_a00140;
}

public String getOmcVariable_a00141(){
    return omcVariable_a00141;
}

public void setOmcVariable_a00141(String omcVariable_a00141){
    this.omcVariable_a00141 = omcVariable_a00141;
}

public String getOmcVariable_a00142(){
    return omcVariable_a00142;
}

public void setOmcVariable_a00142(String omcVariable_a00142){
    this.omcVariable_a00142 = omcVariable_a00142;
}

public String getOmcVariable_a00143(){
    return omcVariable_a00143;
}

public void setOmcVariable_a00143(String omcVariable_a00143){
    this.omcVariable_a00143 = omcVariable_a00143;
}

public String getOmcVariable_a00144(){
    return omcVariable_a00144;
}

public void setOmcVariable_a00144(String omcVariable_a00144){
    this.omcVariable_a00144 = omcVariable_a00144;
}

public String getOmcVariable_a00145(){
    return omcVariable_a00145;
}

public void setOmcVariable_a00145(String omcVariable_a00145){
    this.omcVariable_a00145 = omcVariable_a00145;
}

public String getOmcVariable_a00146(){
    return omcVariable_a00146;
}

public void setOmcVariable_a00146(String omcVariable_a00146){
    this.omcVariable_a00146 = omcVariable_a00146;
}

public String getOmcVariable_a00147(){
    return omcVariable_a00147;
}

public void setOmcVariable_a00147(String omcVariable_a00147){
    this.omcVariable_a00147 = omcVariable_a00147;
}

public String getOmcVariable_a00148(){
    return omcVariable_a00148;
}

public void setOmcVariable_a00148(String omcVariable_a00148){
    this.omcVariable_a00148 = omcVariable_a00148;
}

public String getOmcVariable_a00149(){
    return omcVariable_a00149;
}

public void setOmcVariable_a00149(String omcVariable_a00149){
    this.omcVariable_a00149 = omcVariable_a00149;
}

public String getOmcVariable_a00150(){
    return omcVariable_a00150;
}

public void setOmcVariable_a00150(String omcVariable_a00150){
    this.omcVariable_a00150 = omcVariable_a00150;
}

public String getOmcVariable_a00151(){
    return omcVariable_a00151;
}

public void setOmcVariable_a00151(String omcVariable_a00151){
    this.omcVariable_a00151 = omcVariable_a00151;
}

public String getOmcVariable_a00152(){
    return omcVariable_a00152;
}

public void setOmcVariable_a00152(String omcVariable_a00152){
    this.omcVariable_a00152 = omcVariable_a00152;
}

public String getOmcVariable_a00153(){
    return omcVariable_a00153;
}

public void setOmcVariable_a00153(String omcVariable_a00153){
    this.omcVariable_a00153 = omcVariable_a00153;
}

public String getOmcVariable_a00154(){
    return omcVariable_a00154;
}

public void setOmcVariable_a00154(String omcVariable_a00154){
    this.omcVariable_a00154 = omcVariable_a00154;
}

public String getOmcVariable_a00155(){
    return omcVariable_a00155;
}

public void setOmcVariable_a00155(String omcVariable_a00155){
    this.omcVariable_a00155 = omcVariable_a00155;
}

public String getOmcVariable_a00156(){
    return omcVariable_a00156;
}

public void setOmcVariable_a00156(String omcVariable_a00156){
    this.omcVariable_a00156 = omcVariable_a00156;
}

public String getOmcVariable_a00157(){
    return omcVariable_a00157;
}

public void setOmcVariable_a00157(String omcVariable_a00157){
    this.omcVariable_a00157 = omcVariable_a00157;
}

public String getOmcVariable_a00158(){
    return omcVariable_a00158;
}

public void setOmcVariable_a00158(String omcVariable_a00158){
    this.omcVariable_a00158 = omcVariable_a00158;
}

public String getOmcVariable_a00159(){
    return omcVariable_a00159;
}

public void setOmcVariable_a00159(String omcVariable_a00159){
    this.omcVariable_a00159 = omcVariable_a00159;
}

public String getOmcVariable_a00160(){
    return omcVariable_a00160;
}

public void setOmcVariable_a00160(String omcVariable_a00160){
    this.omcVariable_a00160 = omcVariable_a00160;
}

public String getOmcVariable_a00161(){
    return omcVariable_a00161;
}

public void setOmcVariable_a00161(String omcVariable_a00161){
    this.omcVariable_a00161 = omcVariable_a00161;
}

public String getOmcVariable_a00162(){
    return omcVariable_a00162;
}

public void setOmcVariable_a00162(String omcVariable_a00162){
    this.omcVariable_a00162 = omcVariable_a00162;
}

public String getOmcVariable_a00163(){
    return omcVariable_a00163;
}

public void setOmcVariable_a00163(String omcVariable_a00163){
    this.omcVariable_a00163 = omcVariable_a00163;
}

public String getOmcVariable_a00164(){
    return omcVariable_a00164;
}

public void setOmcVariable_a00164(String omcVariable_a00164){
    this.omcVariable_a00164 = omcVariable_a00164;
}

public String getOmcVariable_a00165(){
    return omcVariable_a00165;
}

public void setOmcVariable_a00165(String omcVariable_a00165){
    this.omcVariable_a00165 = omcVariable_a00165;
}

public String getOmcVariable_a00166(){
    return omcVariable_a00166;
}

public void setOmcVariable_a00166(String omcVariable_a00166){
    this.omcVariable_a00166 = omcVariable_a00166;
}

public String getOmcVariable_a00167(){
    return omcVariable_a00167;
}

public void setOmcVariable_a00167(String omcVariable_a00167){
    this.omcVariable_a00167 = omcVariable_a00167;
}

public String getOmcVariable_a00168(){
    return omcVariable_a00168;
}

public void setOmcVariable_a00168(String omcVariable_a00168){
    this.omcVariable_a00168 = omcVariable_a00168;
}

public String getOmcVariable_a00169(){
    return omcVariable_a00169;
}

public void setOmcVariable_a00169(String omcVariable_a00169){
    this.omcVariable_a00169 = omcVariable_a00169;
}

public String getOmcVariable_a00170(){
    return omcVariable_a00170;
}

public void setOmcVariable_a00170(String omcVariable_a00170){
    this.omcVariable_a00170 = omcVariable_a00170;
}

public String getOmcVariable_a00171(){
    return omcVariable_a00171;
}

public void setOmcVariable_a00171(String omcVariable_a00171){
    this.omcVariable_a00171 = omcVariable_a00171;
}

public String getOmcVariable_a00172(){
    return omcVariable_a00172;
}

public void setOmcVariable_a00172(String omcVariable_a00172){
    this.omcVariable_a00172 = omcVariable_a00172;
}

public String getOmcVariable_a00173(){
    return omcVariable_a00173;
}

public void setOmcVariable_a00173(String omcVariable_a00173){
    this.omcVariable_a00173 = omcVariable_a00173;
}

public String getOmcVariable_a00174(){
    return omcVariable_a00174;
}

public void setOmcVariable_a00174(String omcVariable_a00174){
    this.omcVariable_a00174 = omcVariable_a00174;
}

public String getOmcVariable_a00175(){
    return omcVariable_a00175;
}

public void setOmcVariable_a00175(String omcVariable_a00175){
    this.omcVariable_a00175 = omcVariable_a00175;
}

public String getOmcVariable_a00176(){
    return omcVariable_a00176;
}

public void setOmcVariable_a00176(String omcVariable_a00176){
    this.omcVariable_a00176 = omcVariable_a00176;
}

public String getOmcVariable_a00177(){
    return omcVariable_a00177;
}

public void setOmcVariable_a00177(String omcVariable_a00177){
    this.omcVariable_a00177 = omcVariable_a00177;
}

public String getOmcVariable_a00178(){
    return omcVariable_a00178;
}

public void setOmcVariable_a00178(String omcVariable_a00178){
    this.omcVariable_a00178 = omcVariable_a00178;
}

public String getOmcVariable_a00179(){
    return omcVariable_a00179;
}

public void setOmcVariable_a00179(String omcVariable_a00179){
    this.omcVariable_a00179 = omcVariable_a00179;
}

public String getOmcVariable_a00180(){
    return omcVariable_a00180;
}

public void setOmcVariable_a00180(String omcVariable_a00180){
    this.omcVariable_a00180 = omcVariable_a00180;
}

public String getOmcVariable_a00181(){
    return omcVariable_a00181;
}

public void setOmcVariable_a00181(String omcVariable_a00181){
    this.omcVariable_a00181 = omcVariable_a00181;
}

public String getOmcVariable_a00182(){
    return omcVariable_a00182;
}

public void setOmcVariable_a00182(String omcVariable_a00182){
    this.omcVariable_a00182 = omcVariable_a00182;
}

public String getOmcVariable_a00183(){
    return omcVariable_a00183;
}

public void setOmcVariable_a00183(String omcVariable_a00183){
    this.omcVariable_a00183 = omcVariable_a00183;
}

public String getOmcVariable_a00184(){
    return omcVariable_a00184;
}

public void setOmcVariable_a00184(String omcVariable_a00184){
    this.omcVariable_a00184 = omcVariable_a00184;
}

public String getOmcVariable_a00185(){
    return omcVariable_a00185;
}

public void setOmcVariable_a00185(String omcVariable_a00185){
    this.omcVariable_a00185 = omcVariable_a00185;
}

public String getOmcVariable_a00186(){
    return omcVariable_a00186;
}

public void setOmcVariable_a00186(String omcVariable_a00186){
    this.omcVariable_a00186 = omcVariable_a00186;
}

public String getOmcVariable_a00187(){
    return omcVariable_a00187;
}

public void setOmcVariable_a00187(String omcVariable_a00187){
    this.omcVariable_a00187 = omcVariable_a00187;
}

public String getOmcVariable_a00188(){
    return omcVariable_a00188;
}

public void setOmcVariable_a00188(String omcVariable_a00188){
    this.omcVariable_a00188 = omcVariable_a00188;
}

public String getOmcVariable_a00189(){
    return omcVariable_a00189;
}

public void setOmcVariable_a00189(String omcVariable_a00189){
    this.omcVariable_a00189 = omcVariable_a00189;
}

public String getOmcVariable_a00190(){
    return omcVariable_a00190;
}

public void setOmcVariable_a00190(String omcVariable_a00190){
    this.omcVariable_a00190 = omcVariable_a00190;
}

public String getOmcVariable_a00191(){
    return omcVariable_a00191;
}

public void setOmcVariable_a00191(String omcVariable_a00191){
    this.omcVariable_a00191 = omcVariable_a00191;
}

public String getOmcVariable_a00192(){
    return omcVariable_a00192;
}

public void setOmcVariable_a00192(String omcVariable_a00192){
    this.omcVariable_a00192 = omcVariable_a00192;
}

public String getOmcVariable_a00193(){
    return omcVariable_a00193;
}

public void setOmcVariable_a00193(String omcVariable_a00193){
    this.omcVariable_a00193 = omcVariable_a00193;
}

public String getOmcVariable_a00194(){
    return omcVariable_a00194;
}

public void setOmcVariable_a00194(String omcVariable_a00194){
    this.omcVariable_a00194 = omcVariable_a00194;
}

public String getOmcVariable_a00195(){
    return omcVariable_a00195;
}

public void setOmcVariable_a00195(String omcVariable_a00195){
    this.omcVariable_a00195 = omcVariable_a00195;
}

public String getOmcVariable_a00196(){
    return omcVariable_a00196;
}

public void setOmcVariable_a00196(String omcVariable_a00196){
    this.omcVariable_a00196 = omcVariable_a00196;
}

public String getOmcVariable_a00197(){
    return omcVariable_a00197;
}

public void setOmcVariable_a00197(String omcVariable_a00197){
    this.omcVariable_a00197 = omcVariable_a00197;
}

public String getOmcVariable_a00198(){
    return omcVariable_a00198;
}

public void setOmcVariable_a00198(String omcVariable_a00198){
    this.omcVariable_a00198 = omcVariable_a00198;
}

public String getOmcVariable_a00199(){
    return omcVariable_a00199;
}

public void setOmcVariable_a00199(String omcVariable_a00199){
    this.omcVariable_a00199 = omcVariable_a00199;
}

public String getOmcVariable_a00200(){
    return omcVariable_a00200;
}

public void setOmcVariable_a00200(String omcVariable_a00200){
    this.omcVariable_a00200 = omcVariable_a00200;
}

public String getOmcVariable_a00201(){
    return omcVariable_a00201;
}

public void setOmcVariable_a00201(String omcVariable_a00201){
    this.omcVariable_a00201 = omcVariable_a00201;
}

public String getOmcVariable_a00202(){
    return omcVariable_a00202;
}

public void setOmcVariable_a00202(String omcVariable_a00202){
    this.omcVariable_a00202 = omcVariable_a00202;
}

public String getOmcVariable_a00203(){
    return omcVariable_a00203;
}

public void setOmcVariable_a00203(String omcVariable_a00203){
    this.omcVariable_a00203 = omcVariable_a00203;
}

public String getOmcVariable_a00204(){
    return omcVariable_a00204;
}

public void setOmcVariable_a00204(String omcVariable_a00204){
    this.omcVariable_a00204 = omcVariable_a00204;
}

public String getOmcVariable_a00205(){
    return omcVariable_a00205;
}

public void setOmcVariable_a00205(String omcVariable_a00205){
    this.omcVariable_a00205 = omcVariable_a00205;
}

public String getOmcVariable_a00206(){
    return omcVariable_a00206;
}

public void setOmcVariable_a00206(String omcVariable_a00206){
    this.omcVariable_a00206 = omcVariable_a00206;
}

public String getOmcVariable_a00207(){
    return omcVariable_a00207;
}

public void setOmcVariable_a00207(String omcVariable_a00207){
    this.omcVariable_a00207 = omcVariable_a00207;
}

public String getOmcVariable_a00208(){
    return omcVariable_a00208;
}

public void setOmcVariable_a00208(String omcVariable_a00208){
    this.omcVariable_a00208 = omcVariable_a00208;
}

public String getOmcVariable_a00209(){
    return omcVariable_a00209;
}

public void setOmcVariable_a00209(String omcVariable_a00209){
    this.omcVariable_a00209 = omcVariable_a00209;
}

public String getOmcVariable_a00210(){
    return omcVariable_a00210;
}

public void setOmcVariable_a00210(String omcVariable_a00210){
    this.omcVariable_a00210 = omcVariable_a00210;
}

public String getOmcVariable_a00211(){
    return omcVariable_a00211;
}

public void setOmcVariable_a00211(String omcVariable_a00211){
    this.omcVariable_a00211 = omcVariable_a00211;
}

public String getOmcVariable_a00212(){
    return omcVariable_a00212;
}

public void setOmcVariable_a00212(String omcVariable_a00212){
    this.omcVariable_a00212 = omcVariable_a00212;
}

public String getOmcVariable_a00213(){
    return omcVariable_a00213;
}

public void setOmcVariable_a00213(String omcVariable_a00213){
    this.omcVariable_a00213 = omcVariable_a00213;
}

public String getOmcVariable_a00214(){
    return omcVariable_a00214;
}

public void setOmcVariable_a00214(String omcVariable_a00214){
    this.omcVariable_a00214 = omcVariable_a00214;
}

public String getOmcVariable_a00215(){
    return omcVariable_a00215;
}

public void setOmcVariable_a00215(String omcVariable_a00215){
    this.omcVariable_a00215 = omcVariable_a00215;
}

public String getOmcVariable_a00216(){
    return omcVariable_a00216;
}

public void setOmcVariable_a00216(String omcVariable_a00216){
    this.omcVariable_a00216 = omcVariable_a00216;
}

public String getOmcVariable_a00217(){
    return omcVariable_a00217;
}

public void setOmcVariable_a00217(String omcVariable_a00217){
    this.omcVariable_a00217 = omcVariable_a00217;
}

public String getOmcVariable_a00218(){
    return omcVariable_a00218;
}

public void setOmcVariable_a00218(String omcVariable_a00218){
    this.omcVariable_a00218 = omcVariable_a00218;
}

public String getOmcVariable_a00219(){
    return omcVariable_a00219;
}

public void setOmcVariable_a00219(String omcVariable_a00219){
    this.omcVariable_a00219 = omcVariable_a00219;
}

public String getOmcVariable_a00220(){
    return omcVariable_a00220;
}

public void setOmcVariable_a00220(String omcVariable_a00220){
    this.omcVariable_a00220 = omcVariable_a00220;
}

public String getOmcVariable_a00221(){
    return omcVariable_a00221;
}

public void setOmcVariable_a00221(String omcVariable_a00221){
    this.omcVariable_a00221 = omcVariable_a00221;
}

public String getOmcVariable_a00222(){
    return omcVariable_a00222;
}

public void setOmcVariable_a00222(String omcVariable_a00222){
    this.omcVariable_a00222 = omcVariable_a00222;
}

public String getOmcVariable_a00223(){
    return omcVariable_a00223;
}

public void setOmcVariable_a00223(String omcVariable_a00223){
    this.omcVariable_a00223 = omcVariable_a00223;
}

public String getOmcVariable_a00224(){
    return omcVariable_a00224;
}

public void setOmcVariable_a00224(String omcVariable_a00224){
    this.omcVariable_a00224 = omcVariable_a00224;
}

public String getOmcVariable_a00225(){
    return omcVariable_a00225;
}

public void setOmcVariable_a00225(String omcVariable_a00225){
    this.omcVariable_a00225 = omcVariable_a00225;
}

public String getOmcVariable_a00226(){
    return omcVariable_a00226;
}

public void setOmcVariable_a00226(String omcVariable_a00226){
    this.omcVariable_a00226 = omcVariable_a00226;
}

public String getOmcVariable_a00227(){
    return omcVariable_a00227;
}

public void setOmcVariable_a00227(String omcVariable_a00227){
    this.omcVariable_a00227 = omcVariable_a00227;
}

public String getOmcVariable_a00228(){
    return omcVariable_a00228;
}

public void setOmcVariable_a00228(String omcVariable_a00228){
    this.omcVariable_a00228 = omcVariable_a00228;
}

public String getOmcVariable_a00229(){
    return omcVariable_a00229;
}

public void setOmcVariable_a00229(String omcVariable_a00229){
    this.omcVariable_a00229 = omcVariable_a00229;
}

public String getOmcVariable_a00230(){
    return omcVariable_a00230;
}

public void setOmcVariable_a00230(String omcVariable_a00230){
    this.omcVariable_a00230 = omcVariable_a00230;
}

public String getOmcVariable_a00231(){
    return omcVariable_a00231;
}

public void setOmcVariable_a00231(String omcVariable_a00231){
    this.omcVariable_a00231 = omcVariable_a00231;
}

public String getOmcVariable_a00232(){
    return omcVariable_a00232;
}

public void setOmcVariable_a00232(String omcVariable_a00232){
    this.omcVariable_a00232 = omcVariable_a00232;
}

public String getOmcVariable_a00233(){
    return omcVariable_a00233;
}

public void setOmcVariable_a00233(String omcVariable_a00233){
    this.omcVariable_a00233 = omcVariable_a00233;
}

public String getOmcVariable_a00234(){
    return omcVariable_a00234;
}

public void setOmcVariable_a00234(String omcVariable_a00234){
    this.omcVariable_a00234 = omcVariable_a00234;
}

public String getOmcVariable_a00235(){
    return omcVariable_a00235;
}

public void setOmcVariable_a00235(String omcVariable_a00235){
    this.omcVariable_a00235 = omcVariable_a00235;
}

public String getOmcVariable_a00236(){
    return omcVariable_a00236;
}

public void setOmcVariable_a00236(String omcVariable_a00236){
    this.omcVariable_a00236 = omcVariable_a00236;
}

public String getOmcVariable_a00237(){
    return omcVariable_a00237;
}

public void setOmcVariable_a00237(String omcVariable_a00237){
    this.omcVariable_a00237 = omcVariable_a00237;
}

public String getOmcVariable_a00238(){
    return omcVariable_a00238;
}

public void setOmcVariable_a00238(String omcVariable_a00238){
    this.omcVariable_a00238 = omcVariable_a00238;
}

public String getOmcVariable_a00239(){
    return omcVariable_a00239;
}

public void setOmcVariable_a00239(String omcVariable_a00239){
    this.omcVariable_a00239 = omcVariable_a00239;
}

public String getOmcVariable_a00240(){
    return omcVariable_a00240;
}

public void setOmcVariable_a00240(String omcVariable_a00240){
    this.omcVariable_a00240 = omcVariable_a00240;
}

public String getOmcVariable_a00241(){
    return omcVariable_a00241;
}

public void setOmcVariable_a00241(String omcVariable_a00241){
    this.omcVariable_a00241 = omcVariable_a00241;
}

public String getOmcVariable_a00242(){
    return omcVariable_a00242;
}

public void setOmcVariable_a00242(String omcVariable_a00242){
    this.omcVariable_a00242 = omcVariable_a00242;
}

public String getOmcVariable_a00243(){
    return omcVariable_a00243;
}

public void setOmcVariable_a00243(String omcVariable_a00243){
    this.omcVariable_a00243 = omcVariable_a00243;
}

public String getOmcVariable_a00244(){
    return omcVariable_a00244;
}

public void setOmcVariable_a00244(String omcVariable_a00244){
    this.omcVariable_a00244 = omcVariable_a00244;
}

public String getOmcVariable_a00245(){
    return omcVariable_a00245;
}

public void setOmcVariable_a00245(String omcVariable_a00245){
    this.omcVariable_a00245 = omcVariable_a00245;
}

public String getOmcVariable_a00246(){
    return omcVariable_a00246;
}

public void setOmcVariable_a00246(String omcVariable_a00246){
    this.omcVariable_a00246 = omcVariable_a00246;
}

public String getOmcVariable_a00247(){
    return omcVariable_a00247;
}

public void setOmcVariable_a00247(String omcVariable_a00247){
    this.omcVariable_a00247 = omcVariable_a00247;
}

public String getOmcVariable_a00248(){
    return omcVariable_a00248;
}

public void setOmcVariable_a00248(String omcVariable_a00248){
    this.omcVariable_a00248 = omcVariable_a00248;
}

public String getOmcVariable_a00249(){
    return omcVariable_a00249;
}

public void setOmcVariable_a00249(String omcVariable_a00249){
    this.omcVariable_a00249 = omcVariable_a00249;
}

public String getOmcVariable_a00250(){
    return omcVariable_a00250;
}

public void setOmcVariable_a00250(String omcVariable_a00250){
    this.omcVariable_a00250 = omcVariable_a00250;
}

public String getOmcVariable_a00251(){
    return omcVariable_a00251;
}

public void setOmcVariable_a00251(String omcVariable_a00251){
    this.omcVariable_a00251 = omcVariable_a00251;
}

public String getOmcVariable_a00252(){
    return omcVariable_a00252;
}

public void setOmcVariable_a00252(String omcVariable_a00252){
    this.omcVariable_a00252 = omcVariable_a00252;
}

public String getOmcVariable_a00253(){
    return omcVariable_a00253;
}

public void setOmcVariable_a00253(String omcVariable_a00253){
    this.omcVariable_a00253 = omcVariable_a00253;
}

public String getOmcVariable_a00254(){
    return omcVariable_a00254;
}

public void setOmcVariable_a00254(String omcVariable_a00254){
    this.omcVariable_a00254 = omcVariable_a00254;
}

public String getOmcVariable_a00255(){
    return omcVariable_a00255;
}

public void setOmcVariable_a00255(String omcVariable_a00255){
    this.omcVariable_a00255 = omcVariable_a00255;
}

public String getOmcVariable_a00256(){
    return omcVariable_a00256;
}

public void setOmcVariable_a00256(String omcVariable_a00256){
    this.omcVariable_a00256 = omcVariable_a00256;
}

public String getOmcVariable_a00257(){
    return omcVariable_a00257;
}

public void setOmcVariable_a00257(String omcVariable_a00257){
    this.omcVariable_a00257 = omcVariable_a00257;
}

public String getOmcVariable_a00258(){
    return omcVariable_a00258;
}

public void setOmcVariable_a00258(String omcVariable_a00258){
    this.omcVariable_a00258 = omcVariable_a00258;
}

public String getOmcVariable_a00259(){
    return omcVariable_a00259;
}

public void setOmcVariable_a00259(String omcVariable_a00259){
    this.omcVariable_a00259 = omcVariable_a00259;
}

public String getOmcVariable_a00260(){
    return omcVariable_a00260;
}

public void setOmcVariable_a00260(String omcVariable_a00260){
    this.omcVariable_a00260 = omcVariable_a00260;
}

public String getOmcVariable_a00261(){
    return omcVariable_a00261;
}

public void setOmcVariable_a00261(String omcVariable_a00261){
    this.omcVariable_a00261 = omcVariable_a00261;
}

public String getOmcVariable_a00262(){
    return omcVariable_a00262;
}

public void setOmcVariable_a00262(String omcVariable_a00262){
    this.omcVariable_a00262 = omcVariable_a00262;
}

public String getOmcVariable_a00263(){
    return omcVariable_a00263;
}

public void setOmcVariable_a00263(String omcVariable_a00263){
    this.omcVariable_a00263 = omcVariable_a00263;
}

public String getOmcVariable_a00264(){
    return omcVariable_a00264;
}

public void setOmcVariable_a00264(String omcVariable_a00264){
    this.omcVariable_a00264 = omcVariable_a00264;
}

public String getOmcVariable_a00265(){
    return omcVariable_a00265;
}

public void setOmcVariable_a00265(String omcVariable_a00265){
    this.omcVariable_a00265 = omcVariable_a00265;
}

public String getOmcVariable_a00266(){
    return omcVariable_a00266;
}

public void setOmcVariable_a00266(String omcVariable_a00266){
    this.omcVariable_a00266 = omcVariable_a00266;
}

public String getOmcVariable_a00267(){
    return omcVariable_a00267;
}

public void setOmcVariable_a00267(String omcVariable_a00267){
    this.omcVariable_a00267 = omcVariable_a00267;
}

public String getOmcVariable_a00268(){
    return omcVariable_a00268;
}

public void setOmcVariable_a00268(String omcVariable_a00268){
    this.omcVariable_a00268 = omcVariable_a00268;
}

public String getOmcVariable_a00269(){
    return omcVariable_a00269;
}

public void setOmcVariable_a00269(String omcVariable_a00269){
    this.omcVariable_a00269 = omcVariable_a00269;
}

public String getOmcVariable_a00270(){
    return omcVariable_a00270;
}

public void setOmcVariable_a00270(String omcVariable_a00270){
    this.omcVariable_a00270 = omcVariable_a00270;
}

public String getOmcVariable_a00271(){
    return omcVariable_a00271;
}

public void setOmcVariable_a00271(String omcVariable_a00271){
    this.omcVariable_a00271 = omcVariable_a00271;
}

public String getOmcVariable_a00272(){
    return omcVariable_a00272;
}

public void setOmcVariable_a00272(String omcVariable_a00272){
    this.omcVariable_a00272 = omcVariable_a00272;
}

public String getOmcVariable_a00273(){
    return omcVariable_a00273;
}

public void setOmcVariable_a00273(String omcVariable_a00273){
    this.omcVariable_a00273 = omcVariable_a00273;
}

public String getOmcVariable_a00274(){
    return omcVariable_a00274;
}

public void setOmcVariable_a00274(String omcVariable_a00274){
    this.omcVariable_a00274 = omcVariable_a00274;
}

public String getOmcVariable_a00275(){
    return omcVariable_a00275;
}

public void setOmcVariable_a00275(String omcVariable_a00275){
    this.omcVariable_a00275 = omcVariable_a00275;
}

public String getOmcVariable_a00276(){
    return omcVariable_a00276;
}

public void setOmcVariable_a00276(String omcVariable_a00276){
    this.omcVariable_a00276 = omcVariable_a00276;
}

public String getOmcVariable_a00277(){
    return omcVariable_a00277;
}

public void setOmcVariable_a00277(String omcVariable_a00277){
    this.omcVariable_a00277 = omcVariable_a00277;
}

public String getOmcVariable_a00278(){
    return omcVariable_a00278;
}

public void setOmcVariable_a00278(String omcVariable_a00278){
    this.omcVariable_a00278 = omcVariable_a00278;
}

public String getOmcVariable_a00279(){
    return omcVariable_a00279;
}

public void setOmcVariable_a00279(String omcVariable_a00279){
    this.omcVariable_a00279 = omcVariable_a00279;
}

public String getOmcVariable_a00280(){
    return omcVariable_a00280;
}

public void setOmcVariable_a00280(String omcVariable_a00280){
    this.omcVariable_a00280 = omcVariable_a00280;
}

public String getOmcVariable_a00281(){
    return omcVariable_a00281;
}

public void setOmcVariable_a00281(String omcVariable_a00281){
    this.omcVariable_a00281 = omcVariable_a00281;
}

public String getOmcVariable_a00282(){
    return omcVariable_a00282;
}

public void setOmcVariable_a00282(String omcVariable_a00282){
    this.omcVariable_a00282 = omcVariable_a00282;
}

public String getOmcVariable_a00283(){
    return omcVariable_a00283;
}

public void setOmcVariable_a00283(String omcVariable_a00283){
    this.omcVariable_a00283 = omcVariable_a00283;
}

public String getOmcVariable_a00284(){
    return omcVariable_a00284;
}

public void setOmcVariable_a00284(String omcVariable_a00284){
    this.omcVariable_a00284 = omcVariable_a00284;
}

public String getOmcVariable_a00285(){
    return omcVariable_a00285;
}

public void setOmcVariable_a00285(String omcVariable_a00285){
    this.omcVariable_a00285 = omcVariable_a00285;
}

public String getOmcVariable_a00286(){
    return omcVariable_a00286;
}

public void setOmcVariable_a00286(String omcVariable_a00286){
    this.omcVariable_a00286 = omcVariable_a00286;
}

public String getOmcVariable_a00287(){
    return omcVariable_a00287;
}

public void setOmcVariable_a00287(String omcVariable_a00287){
    this.omcVariable_a00287 = omcVariable_a00287;
}

public String getOmcVariable_a00288(){
    return omcVariable_a00288;
}

public void setOmcVariable_a00288(String omcVariable_a00288){
    this.omcVariable_a00288 = omcVariable_a00288;
}

public String getOmcVariable_a00289(){
    return omcVariable_a00289;
}

public void setOmcVariable_a00289(String omcVariable_a00289){
    this.omcVariable_a00289 = omcVariable_a00289;
}

public String getOmcVariable_a00290(){
    return omcVariable_a00290;
}

public void setOmcVariable_a00290(String omcVariable_a00290){
    this.omcVariable_a00290 = omcVariable_a00290;
}

public String getOmcVariable_a00291(){
    return omcVariable_a00291;
}

public void setOmcVariable_a00291(String omcVariable_a00291){
    this.omcVariable_a00291 = omcVariable_a00291;
}

public String getOmcVariable_a00292(){
    return omcVariable_a00292;
}

public void setOmcVariable_a00292(String omcVariable_a00292){
    this.omcVariable_a00292 = omcVariable_a00292;
}

public String getOmcVariable_a00293(){
    return omcVariable_a00293;
}

public void setOmcVariable_a00293(String omcVariable_a00293){
    this.omcVariable_a00293 = omcVariable_a00293;
}

public String getOmcVariable_a00294(){
    return omcVariable_a00294;
}

public void setOmcVariable_a00294(String omcVariable_a00294){
    this.omcVariable_a00294 = omcVariable_a00294;
}

public String getOmcVariable_a00295(){
    return omcVariable_a00295;
}

public void setOmcVariable_a00295(String omcVariable_a00295){
    this.omcVariable_a00295 = omcVariable_a00295;
}

public String getOmcVariable_a00296(){
    return omcVariable_a00296;
}

public void setOmcVariable_a00296(String omcVariable_a00296){
    this.omcVariable_a00296 = omcVariable_a00296;
}

public String getOmcVariable_a00297(){
    return omcVariable_a00297;
}

public void setOmcVariable_a00297(String omcVariable_a00297){
    this.omcVariable_a00297 = omcVariable_a00297;
}

public String getOmcVariable_a00298(){
    return omcVariable_a00298;
}

public void setOmcVariable_a00298(String omcVariable_a00298){
    this.omcVariable_a00298 = omcVariable_a00298;
}

public String getOmcVariable_a00299(){
    return omcVariable_a00299;
}

public void setOmcVariable_a00299(String omcVariable_a00299){
    this.omcVariable_a00299 = omcVariable_a00299;
}

public String getOmcVariable_a00300(){
    return omcVariable_a00300;
}

public void setOmcVariable_a00300(String omcVariable_a00300){
    this.omcVariable_a00300 = omcVariable_a00300;
}

public String getOmcVariable_a00301(){
    return omcVariable_a00301;
}

public void setOmcVariable_a00301(String omcVariable_a00301){
    this.omcVariable_a00301 = omcVariable_a00301;
}

public String getOmcVariable_a00302(){
    return omcVariable_a00302;
}

public void setOmcVariable_a00302(String omcVariable_a00302){
    this.omcVariable_a00302 = omcVariable_a00302;
}

public String getOmcVariable_a00303(){
    return omcVariable_a00303;
}

public void setOmcVariable_a00303(String omcVariable_a00303){
    this.omcVariable_a00303 = omcVariable_a00303;
}

public String getOmcVariable_a00304(){
    return omcVariable_a00304;
}

public void setOmcVariable_a00304(String omcVariable_a00304){
    this.omcVariable_a00304 = omcVariable_a00304;
}

public String getOmcVariable_a00305(){
    return omcVariable_a00305;
}

public void setOmcVariable_a00305(String omcVariable_a00305){
    this.omcVariable_a00305 = omcVariable_a00305;
}

public String getOmcVariable_a00306(){
    return omcVariable_a00306;
}

public void setOmcVariable_a00306(String omcVariable_a00306){
    this.omcVariable_a00306 = omcVariable_a00306;
}

public String getOmcVariable_a00307(){
    return omcVariable_a00307;
}

public void setOmcVariable_a00307(String omcVariable_a00307){
    this.omcVariable_a00307 = omcVariable_a00307;
}

public String getOmcVariable_a00308(){
    return omcVariable_a00308;
}

public void setOmcVariable_a00308(String omcVariable_a00308){
    this.omcVariable_a00308 = omcVariable_a00308;
}

public String getOmcVariable_a00309(){
    return omcVariable_a00309;
}

public void setOmcVariable_a00309(String omcVariable_a00309){
    this.omcVariable_a00309 = omcVariable_a00309;
}

public String getOmcVariable_a00310(){
    return omcVariable_a00310;
}

public void setOmcVariable_a00310(String omcVariable_a00310){
    this.omcVariable_a00310 = omcVariable_a00310;
}

public String getOmcVariable_a00311(){
    return omcVariable_a00311;
}

public void setOmcVariable_a00311(String omcVariable_a00311){
    this.omcVariable_a00311 = omcVariable_a00311;
}

public String getOmcVariable_a00312(){
    return omcVariable_a00312;
}

public void setOmcVariable_a00312(String omcVariable_a00312){
    this.omcVariable_a00312 = omcVariable_a00312;
}

public String getOmcVariable_a00313(){
    return omcVariable_a00313;
}

public void setOmcVariable_a00313(String omcVariable_a00313){
    this.omcVariable_a00313 = omcVariable_a00313;
}

public String getOmcVariable_a00314(){
    return omcVariable_a00314;
}

public void setOmcVariable_a00314(String omcVariable_a00314){
    this.omcVariable_a00314 = omcVariable_a00314;
}

public String getOmcVariable_a00315(){
    return omcVariable_a00315;
}

public void setOmcVariable_a00315(String omcVariable_a00315){
    this.omcVariable_a00315 = omcVariable_a00315;
}

public String getOmcVariable_a00316(){
    return omcVariable_a00316;
}

public void setOmcVariable_a00316(String omcVariable_a00316){
    this.omcVariable_a00316 = omcVariable_a00316;
}

public String getOmcVariable_a00317(){
    return omcVariable_a00317;
}

public void setOmcVariable_a00317(String omcVariable_a00317){
    this.omcVariable_a00317 = omcVariable_a00317;
}

public String getOmcVariable_a00318(){
    return omcVariable_a00318;
}

public void setOmcVariable_a00318(String omcVariable_a00318){
    this.omcVariable_a00318 = omcVariable_a00318;
}

public String getOmcVariable_a00319(){
    return omcVariable_a00319;
}

public void setOmcVariable_a00319(String omcVariable_a00319){
    this.omcVariable_a00319 = omcVariable_a00319;
}

public String getOmcVariable_a00320(){
    return omcVariable_a00320;
}

public void setOmcVariable_a00320(String omcVariable_a00320){
    this.omcVariable_a00320 = omcVariable_a00320;
}

public String getOmcVariable_a00321(){
    return omcVariable_a00321;
}

public void setOmcVariable_a00321(String omcVariable_a00321){
    this.omcVariable_a00321 = omcVariable_a00321;
}

public String getOmcVariable_a00322(){
    return omcVariable_a00322;
}

public void setOmcVariable_a00322(String omcVariable_a00322){
    this.omcVariable_a00322 = omcVariable_a00322;
}

public String getOmcVariable_a00323(){
    return omcVariable_a00323;
}

public void setOmcVariable_a00323(String omcVariable_a00323){
    this.omcVariable_a00323 = omcVariable_a00323;
}

public String getOmcVariable_a00324(){
    return omcVariable_a00324;
}

public void setOmcVariable_a00324(String omcVariable_a00324){
    this.omcVariable_a00324 = omcVariable_a00324;
}

public String getOmcVariable_a00325(){
    return omcVariable_a00325;
}

public void setOmcVariable_a00325(String omcVariable_a00325){
    this.omcVariable_a00325 = omcVariable_a00325;
}

public String getOmcVariable_a00326(){
    return omcVariable_a00326;
}

public void setOmcVariable_a00326(String omcVariable_a00326){
    this.omcVariable_a00326 = omcVariable_a00326;
}

public String getOmcVariable_a00327(){
    return omcVariable_a00327;
}

public void setOmcVariable_a00327(String omcVariable_a00327){
    this.omcVariable_a00327 = omcVariable_a00327;
}

public String getOmcVariable_a00328(){
    return omcVariable_a00328;
}

public void setOmcVariable_a00328(String omcVariable_a00328){
    this.omcVariable_a00328 = omcVariable_a00328;
}

public String getOmcVariable_a00329(){
    return omcVariable_a00329;
}

public void setOmcVariable_a00329(String omcVariable_a00329){
    this.omcVariable_a00329 = omcVariable_a00329;
}

public String getOmcVariable_a00330(){
    return omcVariable_a00330;
}

public void setOmcVariable_a00330(String omcVariable_a00330){
    this.omcVariable_a00330 = omcVariable_a00330;
}

public String getOmcVariable_a00331(){
    return omcVariable_a00331;
}

public void setOmcVariable_a00331(String omcVariable_a00331){
    this.omcVariable_a00331 = omcVariable_a00331;
}

public String getOmcVariable_a00332(){
    return omcVariable_a00332;
}

public void setOmcVariable_a00332(String omcVariable_a00332){
    this.omcVariable_a00332 = omcVariable_a00332;
}

public String getOmcVariable_a00333(){
    return omcVariable_a00333;
}

public void setOmcVariable_a00333(String omcVariable_a00333){
    this.omcVariable_a00333 = omcVariable_a00333;
}

public String getOmcVariable_a00334(){
    return omcVariable_a00334;
}

public void setOmcVariable_a00334(String omcVariable_a00334){
    this.omcVariable_a00334 = omcVariable_a00334;
}

public String getOmcVariable_a00335(){
    return omcVariable_a00335;
}

public void setOmcVariable_a00335(String omcVariable_a00335){
    this.omcVariable_a00335 = omcVariable_a00335;
}

public String getOmcVariable_a00336(){
    return omcVariable_a00336;
}

public void setOmcVariable_a00336(String omcVariable_a00336){
    this.omcVariable_a00336 = omcVariable_a00336;
}

public String getOmcVariable_a00337(){
    return omcVariable_a00337;
}

public void setOmcVariable_a00337(String omcVariable_a00337){
    this.omcVariable_a00337 = omcVariable_a00337;
}

public String getOmcVariable_a00338(){
    return omcVariable_a00338;
}

public void setOmcVariable_a00338(String omcVariable_a00338){
    this.omcVariable_a00338 = omcVariable_a00338;
}

public String getOmcVariable_a00339(){
    return omcVariable_a00339;
}

public void setOmcVariable_a00339(String omcVariable_a00339){
    this.omcVariable_a00339 = omcVariable_a00339;
}

public String getOmcVariable_a00340(){
    return omcVariable_a00340;
}

public void setOmcVariable_a00340(String omcVariable_a00340){
    this.omcVariable_a00340 = omcVariable_a00340;
}

public String getOmcVariable_a00341(){
    return omcVariable_a00341;
}

public void setOmcVariable_a00341(String omcVariable_a00341){
    this.omcVariable_a00341 = omcVariable_a00341;
}

public String getOmcVariable_a00342(){
    return omcVariable_a00342;
}

public void setOmcVariable_a00342(String omcVariable_a00342){
    this.omcVariable_a00342 = omcVariable_a00342;
}

public String getOmcVariable_a00343(){
    return omcVariable_a00343;
}

public void setOmcVariable_a00343(String omcVariable_a00343){
    this.omcVariable_a00343 = omcVariable_a00343;
}

public String getOmcVariable_a00344(){
    return omcVariable_a00344;
}

public void setOmcVariable_a00344(String omcVariable_a00344){
    this.omcVariable_a00344 = omcVariable_a00344;
}

public String getOmcVariable_a00345(){
    return omcVariable_a00345;
}

public void setOmcVariable_a00345(String omcVariable_a00345){
    this.omcVariable_a00345 = omcVariable_a00345;
}

public String getOmcVariable_a00346(){
    return omcVariable_a00346;
}

public void setOmcVariable_a00346(String omcVariable_a00346){
    this.omcVariable_a00346 = omcVariable_a00346;
}

public String getOmcVariable_a00347(){
    return omcVariable_a00347;
}

public void setOmcVariable_a00347(String omcVariable_a00347){
    this.omcVariable_a00347 = omcVariable_a00347;
}

public String getOmcVariable_a00348(){
    return omcVariable_a00348;
}

public void setOmcVariable_a00348(String omcVariable_a00348){
    this.omcVariable_a00348 = omcVariable_a00348;
}

public String getOmcVariable_a00349(){
    return omcVariable_a00349;
}

public void setOmcVariable_a00349(String omcVariable_a00349){
    this.omcVariable_a00349 = omcVariable_a00349;
}

public String getOmcVariable_a00350(){
    return omcVariable_a00350;
}

public void setOmcVariable_a00350(String omcVariable_a00350){
    this.omcVariable_a00350 = omcVariable_a00350;
}

public String getOmcVariable_a00351(){
    return omcVariable_a00351;
}

public void setOmcVariable_a00351(String omcVariable_a00351){
    this.omcVariable_a00351 = omcVariable_a00351;
}

public String getOmcVariable_a00352(){
    return omcVariable_a00352;
}

public void setOmcVariable_a00352(String omcVariable_a00352){
    this.omcVariable_a00352 = omcVariable_a00352;
}

public String getOmcVariable_a00353(){
    return omcVariable_a00353;
}

public void setOmcVariable_a00353(String omcVariable_a00353){
    this.omcVariable_a00353 = omcVariable_a00353;
}

public String getOmcVariable_a00354(){
    return omcVariable_a00354;
}

public void setOmcVariable_a00354(String omcVariable_a00354){
    this.omcVariable_a00354 = omcVariable_a00354;
}

public String getOmcVariable_a00355(){
    return omcVariable_a00355;
}

public void setOmcVariable_a00355(String omcVariable_a00355){
    this.omcVariable_a00355 = omcVariable_a00355;
}

public String getOmcVariable_a00356(){
    return omcVariable_a00356;
}

public void setOmcVariable_a00356(String omcVariable_a00356){
    this.omcVariable_a00356 = omcVariable_a00356;
}

public String getOmcVariable_a00357(){
    return omcVariable_a00357;
}

public void setOmcVariable_a00357(String omcVariable_a00357){
    this.omcVariable_a00357 = omcVariable_a00357;
}

public String getOmcVariable_a00358(){
    return omcVariable_a00358;
}

public void setOmcVariable_a00358(String omcVariable_a00358){
    this.omcVariable_a00358 = omcVariable_a00358;
}

public String getOmcVariable_a00359(){
    return omcVariable_a00359;
}

public void setOmcVariable_a00359(String omcVariable_a00359){
    this.omcVariable_a00359 = omcVariable_a00359;
}

public String getOmcVariable_a00360(){
    return omcVariable_a00360;
}

public void setOmcVariable_a00360(String omcVariable_a00360){
    this.omcVariable_a00360 = omcVariable_a00360;
}

public String getOmcVariable_a00361(){
    return omcVariable_a00361;
}

public void setOmcVariable_a00361(String omcVariable_a00361){
    this.omcVariable_a00361 = omcVariable_a00361;
}

public String getOmcVariable_a00362(){
    return omcVariable_a00362;
}

public void setOmcVariable_a00362(String omcVariable_a00362){
    this.omcVariable_a00362 = omcVariable_a00362;
}

public String getOmcVariable_a00363(){
    return omcVariable_a00363;
}

public void setOmcVariable_a00363(String omcVariable_a00363){
    this.omcVariable_a00363 = omcVariable_a00363;
}

public String getOmcVariable_a00364(){
    return omcVariable_a00364;
}

public void setOmcVariable_a00364(String omcVariable_a00364){
    this.omcVariable_a00364 = omcVariable_a00364;
}

public String getOmcVariable_a00365(){
    return omcVariable_a00365;
}

public void setOmcVariable_a00365(String omcVariable_a00365){
    this.omcVariable_a00365 = omcVariable_a00365;
}

public String getOmcVariable_a00366(){
    return omcVariable_a00366;
}

public void setOmcVariable_a00366(String omcVariable_a00366){
    this.omcVariable_a00366 = omcVariable_a00366;
}

public String getOmcVariable_a00367(){
    return omcVariable_a00367;
}

public void setOmcVariable_a00367(String omcVariable_a00367){
    this.omcVariable_a00367 = omcVariable_a00367;
}

public String getOmcVariable_a00368(){
    return omcVariable_a00368;
}

public void setOmcVariable_a00368(String omcVariable_a00368){
    this.omcVariable_a00368 = omcVariable_a00368;
}

public String getOmcVariable_a00369(){
    return omcVariable_a00369;
}

public void setOmcVariable_a00369(String omcVariable_a00369){
    this.omcVariable_a00369 = omcVariable_a00369;
}

public String getOmcVariable_a00370(){
    return omcVariable_a00370;
}

public void setOmcVariable_a00370(String omcVariable_a00370){
    this.omcVariable_a00370 = omcVariable_a00370;
}

public String getOmcVariable_a00371(){
    return omcVariable_a00371;
}

public void setOmcVariable_a00371(String omcVariable_a00371){
    this.omcVariable_a00371 = omcVariable_a00371;
}

public String getOmcVariable_a00372(){
    return omcVariable_a00372;
}

public void setOmcVariable_a00372(String omcVariable_a00372){
    this.omcVariable_a00372 = omcVariable_a00372;
}

public String getOmcVariable_a00373(){
    return omcVariable_a00373;
}

public void setOmcVariable_a00373(String omcVariable_a00373){
    this.omcVariable_a00373 = omcVariable_a00373;
}

public String getOmcVariable_a00374(){
    return omcVariable_a00374;
}

public void setOmcVariable_a00374(String omcVariable_a00374){
    this.omcVariable_a00374 = omcVariable_a00374;
}

public String getOmcVariable_a00375(){
    return omcVariable_a00375;
}

public void setOmcVariable_a00375(String omcVariable_a00375){
    this.omcVariable_a00375 = omcVariable_a00375;
}

public String getOmcVariable_a00376(){
    return omcVariable_a00376;
}

public void setOmcVariable_a00376(String omcVariable_a00376){
    this.omcVariable_a00376 = omcVariable_a00376;
}

public String getOmcVariable_a00377(){
    return omcVariable_a00377;
}

public void setOmcVariable_a00377(String omcVariable_a00377){
    this.omcVariable_a00377 = omcVariable_a00377;
}

public String getOmcVariable_a00378(){
    return omcVariable_a00378;
}

public void setOmcVariable_a00378(String omcVariable_a00378){
    this.omcVariable_a00378 = omcVariable_a00378;
}

public String getOmcVariable_a00379(){
    return omcVariable_a00379;
}

public void setOmcVariable_a00379(String omcVariable_a00379){
    this.omcVariable_a00379 = omcVariable_a00379;
}

public String getOmcVariable_a00380(){
    return omcVariable_a00380;
}

public void setOmcVariable_a00380(String omcVariable_a00380){
    this.omcVariable_a00380 = omcVariable_a00380;
}

public String getOmcVariable_a00381(){
    return omcVariable_a00381;
}

public void setOmcVariable_a00381(String omcVariable_a00381){
    this.omcVariable_a00381 = omcVariable_a00381;
}

public String getOmcVariable_a00382(){
    return omcVariable_a00382;
}

public void setOmcVariable_a00382(String omcVariable_a00382){
    this.omcVariable_a00382 = omcVariable_a00382;
}

public String getOmcVariable_a00383(){
    return omcVariable_a00383;
}

public void setOmcVariable_a00383(String omcVariable_a00383){
    this.omcVariable_a00383 = omcVariable_a00383;
}

public String getOmcVariable_a00384(){
    return omcVariable_a00384;
}

public void setOmcVariable_a00384(String omcVariable_a00384){
    this.omcVariable_a00384 = omcVariable_a00384;
}

public String getOmcVariable_a00385(){
    return omcVariable_a00385;
}

public void setOmcVariable_a00385(String omcVariable_a00385){
    this.omcVariable_a00385 = omcVariable_a00385;
}

public String getOmcVariable_a00386(){
    return omcVariable_a00386;
}

public void setOmcVariable_a00386(String omcVariable_a00386){
    this.omcVariable_a00386 = omcVariable_a00386;
}

public String getOmcVariable_a00387(){
    return omcVariable_a00387;
}

public void setOmcVariable_a00387(String omcVariable_a00387){
    this.omcVariable_a00387 = omcVariable_a00387;
}

public String getOmcVariable_a00388(){
    return omcVariable_a00388;
}

public void setOmcVariable_a00388(String omcVariable_a00388){
    this.omcVariable_a00388 = omcVariable_a00388;
}

public String getOmcVariable_a00389(){
    return omcVariable_a00389;
}

public void setOmcVariable_a00389(String omcVariable_a00389){
    this.omcVariable_a00389 = omcVariable_a00389;
}

public String getOmcVariable_a00390(){
    return omcVariable_a00390;
}

public void setOmcVariable_a00390(String omcVariable_a00390){
    this.omcVariable_a00390 = omcVariable_a00390;
}

public String getOmcVariable_a00391(){
    return omcVariable_a00391;
}

public void setOmcVariable_a00391(String omcVariable_a00391){
    this.omcVariable_a00391 = omcVariable_a00391;
}

public String getOmcVariable_a00392(){
    return omcVariable_a00392;
}

public void setOmcVariable_a00392(String omcVariable_a00392){
    this.omcVariable_a00392 = omcVariable_a00392;
}

public String getOmcVariable_a00393(){
    return omcVariable_a00393;
}

public void setOmcVariable_a00393(String omcVariable_a00393){
    this.omcVariable_a00393 = omcVariable_a00393;
}

public String getOmcVariable_a00394(){
    return omcVariable_a00394;
}

public void setOmcVariable_a00394(String omcVariable_a00394){
    this.omcVariable_a00394 = omcVariable_a00394;
}

public String getOmcVariable_a00395(){
    return omcVariable_a00395;
}

public void setOmcVariable_a00395(String omcVariable_a00395){
    this.omcVariable_a00395 = omcVariable_a00395;
}

public String getOmcVariable_a00396(){
    return omcVariable_a00396;
}

public void setOmcVariable_a00396(String omcVariable_a00396){
    this.omcVariable_a00396 = omcVariable_a00396;
}

public String getOmcVariable_a00397(){
    return omcVariable_a00397;
}

public void setOmcVariable_a00397(String omcVariable_a00397){
    this.omcVariable_a00397 = omcVariable_a00397;
}

public String getOmcVariable_a00398(){
    return omcVariable_a00398;
}

public void setOmcVariable_a00398(String omcVariable_a00398){
    this.omcVariable_a00398 = omcVariable_a00398;
}

public String getOmcVariable_a00399(){
    return omcVariable_a00399;
}

public void setOmcVariable_a00399(String omcVariable_a00399){
    this.omcVariable_a00399 = omcVariable_a00399;
}

public String getOmcVariable_a00400(){
    return omcVariable_a00400;
}

public void setOmcVariable_a00400(String omcVariable_a00400){
    this.omcVariable_a00400 = omcVariable_a00400;
}

public String getOmcVariable_a00401(){
    return omcVariable_a00401;
}

public void setOmcVariable_a00401(String omcVariable_a00401){
    this.omcVariable_a00401 = omcVariable_a00401;
}

public String getOmcVariable_a00402(){
    return omcVariable_a00402;
}

public void setOmcVariable_a00402(String omcVariable_a00402){
    this.omcVariable_a00402 = omcVariable_a00402;
}

public String getOmcVariable_a00403(){
    return omcVariable_a00403;
}

public void setOmcVariable_a00403(String omcVariable_a00403){
    this.omcVariable_a00403 = omcVariable_a00403;
}

public String getOmcVariable_a00404(){
    return omcVariable_a00404;
}

public void setOmcVariable_a00404(String omcVariable_a00404){
    this.omcVariable_a00404 = omcVariable_a00404;
}

public String getOmcVariable_a00405(){
    return omcVariable_a00405;
}

public void setOmcVariable_a00405(String omcVariable_a00405){
    this.omcVariable_a00405 = omcVariable_a00405;
}

public String getOmcVariable_a00406(){
    return omcVariable_a00406;
}

public void setOmcVariable_a00406(String omcVariable_a00406){
    this.omcVariable_a00406 = omcVariable_a00406;
}

public String getOmcVariable_a00407(){
    return omcVariable_a00407;
}

public void setOmcVariable_a00407(String omcVariable_a00407){
    this.omcVariable_a00407 = omcVariable_a00407;
}

public String getOmcVariable_a00408(){
    return omcVariable_a00408;
}

public void setOmcVariable_a00408(String omcVariable_a00408){
    this.omcVariable_a00408 = omcVariable_a00408;
}

public String getOmcVariable_a00409(){
    return omcVariable_a00409;
}

public void setOmcVariable_a00409(String omcVariable_a00409){
    this.omcVariable_a00409 = omcVariable_a00409;
}

public String getOmcVariable_a00410(){
    return omcVariable_a00410;
}

public void setOmcVariable_a00410(String omcVariable_a00410){
    this.omcVariable_a00410 = omcVariable_a00410;
}

public String getOmcVariable_a00411(){
    return omcVariable_a00411;
}

public void setOmcVariable_a00411(String omcVariable_a00411){
    this.omcVariable_a00411 = omcVariable_a00411;
}

public String getOmcVariable_a00412(){
    return omcVariable_a00412;
}

public void setOmcVariable_a00412(String omcVariable_a00412){
    this.omcVariable_a00412 = omcVariable_a00412;
}

public String getOmcVariable_a00413(){
    return omcVariable_a00413;
}

public void setOmcVariable_a00413(String omcVariable_a00413){
    this.omcVariable_a00413 = omcVariable_a00413;
}

public String getOmcVariable_a00414(){
    return omcVariable_a00414;
}

public void setOmcVariable_a00414(String omcVariable_a00414){
    this.omcVariable_a00414 = omcVariable_a00414;
}

public String getOmcVariable_a00415(){
    return omcVariable_a00415;
}

public void setOmcVariable_a00415(String omcVariable_a00415){
    this.omcVariable_a00415 = omcVariable_a00415;
}

public String getOmcVariable_a00416(){
    return omcVariable_a00416;
}

public void setOmcVariable_a00416(String omcVariable_a00416){
    this.omcVariable_a00416 = omcVariable_a00416;
}

public String getOmcVariable_a00417(){
    return omcVariable_a00417;
}

public void setOmcVariable_a00417(String omcVariable_a00417){
    this.omcVariable_a00417 = omcVariable_a00417;
}

public String getOmcVariable_a00418(){
    return omcVariable_a00418;
}

public void setOmcVariable_a00418(String omcVariable_a00418){
    this.omcVariable_a00418 = omcVariable_a00418;
}

public String getOmcVariable_a00419(){
    return omcVariable_a00419;
}

public void setOmcVariable_a00419(String omcVariable_a00419){
    this.omcVariable_a00419 = omcVariable_a00419;
}

public String getOmcVariable_a00420(){
    return omcVariable_a00420;
}

public void setOmcVariable_a00420(String omcVariable_a00420){
    this.omcVariable_a00420 = omcVariable_a00420;
}

public String getOmcVariable_a00421(){
    return omcVariable_a00421;
}

public void setOmcVariable_a00421(String omcVariable_a00421){
    this.omcVariable_a00421 = omcVariable_a00421;
}

public String getOmcVariable_a00422(){
    return omcVariable_a00422;
}

public void setOmcVariable_a00422(String omcVariable_a00422){
    this.omcVariable_a00422 = omcVariable_a00422;
}

public String getOmcVariable_a00423(){
    return omcVariable_a00423;
}

public void setOmcVariable_a00423(String omcVariable_a00423){
    this.omcVariable_a00423 = omcVariable_a00423;
}

public String getOmcVariable_a00424(){
    return omcVariable_a00424;
}

public void setOmcVariable_a00424(String omcVariable_a00424){
    this.omcVariable_a00424 = omcVariable_a00424;
}

public String getOmcVariable_a00425(){
    return omcVariable_a00425;
}

public void setOmcVariable_a00425(String omcVariable_a00425){
    this.omcVariable_a00425 = omcVariable_a00425;
}

public String getOmcVariable_a00426(){
    return omcVariable_a00426;
}

public void setOmcVariable_a00426(String omcVariable_a00426){
    this.omcVariable_a00426 = omcVariable_a00426;
}

public String getOmcVariable_a00427(){
    return omcVariable_a00427;
}

public void setOmcVariable_a00427(String omcVariable_a00427){
    this.omcVariable_a00427 = omcVariable_a00427;
}

public String getOmcVariable_a00428(){
    return omcVariable_a00428;
}

public void setOmcVariable_a00428(String omcVariable_a00428){
    this.omcVariable_a00428 = omcVariable_a00428;
}

public String getOmcVariable_a00429(){
    return omcVariable_a00429;
}

public void setOmcVariable_a00429(String omcVariable_a00429){
    this.omcVariable_a00429 = omcVariable_a00429;
}

public String getOmcVariable_a00430(){
    return omcVariable_a00430;
}

public void setOmcVariable_a00430(String omcVariable_a00430){
    this.omcVariable_a00430 = omcVariable_a00430;
}

public String getOmcVariable_a00431(){
    return omcVariable_a00431;
}

public void setOmcVariable_a00431(String omcVariable_a00431){
    this.omcVariable_a00431 = omcVariable_a00431;
}

public String getOmcVariable_a00432(){
    return omcVariable_a00432;
}

public void setOmcVariable_a00432(String omcVariable_a00432){
    this.omcVariable_a00432 = omcVariable_a00432;
}

public String getOmcVariable_a00433(){
    return omcVariable_a00433;
}

public void setOmcVariable_a00433(String omcVariable_a00433){
    this.omcVariable_a00433 = omcVariable_a00433;
}

public String getOmcVariable_a00434(){
    return omcVariable_a00434;
}

public void setOmcVariable_a00434(String omcVariable_a00434){
    this.omcVariable_a00434 = omcVariable_a00434;
}

public String getOmcVariable_a00435(){
    return omcVariable_a00435;
}

public void setOmcVariable_a00435(String omcVariable_a00435){
    this.omcVariable_a00435 = omcVariable_a00435;
}

public String getOmcVariable_a00436(){
    return omcVariable_a00436;
}

public void setOmcVariable_a00436(String omcVariable_a00436){
    this.omcVariable_a00436 = omcVariable_a00436;
}

public String getOmcVariable_a00437(){
    return omcVariable_a00437;
}

public void setOmcVariable_a00437(String omcVariable_a00437){
    this.omcVariable_a00437 = omcVariable_a00437;
}

public String getOmcVariable_a00438(){
    return omcVariable_a00438;
}

public void setOmcVariable_a00438(String omcVariable_a00438){
    this.omcVariable_a00438 = omcVariable_a00438;
}

public String getOmcVariable_a00439(){
    return omcVariable_a00439;
}

public void setOmcVariable_a00439(String omcVariable_a00439){
    this.omcVariable_a00439 = omcVariable_a00439;
}

public String getOmcVariable_a00440(){
    return omcVariable_a00440;
}

public void setOmcVariable_a00440(String omcVariable_a00440){
    this.omcVariable_a00440 = omcVariable_a00440;
}

public String getOmcVariable_a00441(){
    return omcVariable_a00441;
}

public void setOmcVariable_a00441(String omcVariable_a00441){
    this.omcVariable_a00441 = omcVariable_a00441;
}

public String getOmcVariable_a00442(){
    return omcVariable_a00442;
}

public void setOmcVariable_a00442(String omcVariable_a00442){
    this.omcVariable_a00442 = omcVariable_a00442;
}

public String getOmcVariable_a00443(){
    return omcVariable_a00443;
}

public void setOmcVariable_a00443(String omcVariable_a00443){
    this.omcVariable_a00443 = omcVariable_a00443;
}

public String getOmcVariable_a00444(){
    return omcVariable_a00444;
}

public void setOmcVariable_a00444(String omcVariable_a00444){
    this.omcVariable_a00444 = omcVariable_a00444;
}

public String getOmcVariable_a00445(){
    return omcVariable_a00445;
}

public void setOmcVariable_a00445(String omcVariable_a00445){
    this.omcVariable_a00445 = omcVariable_a00445;
}

public String getOmcVariable_a00446(){
    return omcVariable_a00446;
}

public void setOmcVariable_a00446(String omcVariable_a00446){
    this.omcVariable_a00446 = omcVariable_a00446;
}

public String getOmcVariable_a00447(){
    return omcVariable_a00447;
}

public void setOmcVariable_a00447(String omcVariable_a00447){
    this.omcVariable_a00447 = omcVariable_a00447;
}

public String getOmcVariable_a00448(){
    return omcVariable_a00448;
}

public void setOmcVariable_a00448(String omcVariable_a00448){
    this.omcVariable_a00448 = omcVariable_a00448;
}

public String getOmcVariable_a00449(){
    return omcVariable_a00449;
}

public void setOmcVariable_a00449(String omcVariable_a00449){
    this.omcVariable_a00449 = omcVariable_a00449;
}

public String getOmcVariable_a00450(){
    return omcVariable_a00450;
}

public void setOmcVariable_a00450(String omcVariable_a00450){
    this.omcVariable_a00450 = omcVariable_a00450;
}

public String getOmcVariable_a00451(){
    return omcVariable_a00451;
}

public void setOmcVariable_a00451(String omcVariable_a00451){
    this.omcVariable_a00451 = omcVariable_a00451;
}

public String getOmcVariable_a00452(){
    return omcVariable_a00452;
}

public void setOmcVariable_a00452(String omcVariable_a00452){
    this.omcVariable_a00452 = omcVariable_a00452;
}

public String getOmcVariable_a00453(){
    return omcVariable_a00453;
}

public void setOmcVariable_a00453(String omcVariable_a00453){
    this.omcVariable_a00453 = omcVariable_a00453;
}

public String getOmcVariable_a00454(){
    return omcVariable_a00454;
}

public void setOmcVariable_a00454(String omcVariable_a00454){
    this.omcVariable_a00454 = omcVariable_a00454;
}

public String getOmcVariable_a00455(){
    return omcVariable_a00455;
}

public void setOmcVariable_a00455(String omcVariable_a00455){
    this.omcVariable_a00455 = omcVariable_a00455;
}

public String getOmcVariable_a00456(){
    return omcVariable_a00456;
}

public void setOmcVariable_a00456(String omcVariable_a00456){
    this.omcVariable_a00456 = omcVariable_a00456;
}

public String getOmcVariable_a00457(){
    return omcVariable_a00457;
}

public void setOmcVariable_a00457(String omcVariable_a00457){
    this.omcVariable_a00457 = omcVariable_a00457;
}

public String getOmcVariable_a00458(){
    return omcVariable_a00458;
}

public void setOmcVariable_a00458(String omcVariable_a00458){
    this.omcVariable_a00458 = omcVariable_a00458;
}

public String getOmcVariable_a00459(){
    return omcVariable_a00459;
}

public void setOmcVariable_a00459(String omcVariable_a00459){
    this.omcVariable_a00459 = omcVariable_a00459;
}

public String getOmcVariable_a00460(){
    return omcVariable_a00460;
}

public void setOmcVariable_a00460(String omcVariable_a00460){
    this.omcVariable_a00460 = omcVariable_a00460;
}

public String getOmcVariable_a00461(){
    return omcVariable_a00461;
}

public void setOmcVariable_a00461(String omcVariable_a00461){
    this.omcVariable_a00461 = omcVariable_a00461;
}

public String getOmcVariable_a00462(){
    return omcVariable_a00462;
}

public void setOmcVariable_a00462(String omcVariable_a00462){
    this.omcVariable_a00462 = omcVariable_a00462;
}

public String getOmcVariable_a00463(){
    return omcVariable_a00463;
}

public void setOmcVariable_a00463(String omcVariable_a00463){
    this.omcVariable_a00463 = omcVariable_a00463;
}

public String getOmcVariable_a00464(){
    return omcVariable_a00464;
}

public void setOmcVariable_a00464(String omcVariable_a00464){
    this.omcVariable_a00464 = omcVariable_a00464;
}

public String getOmcVariable_a00465(){
    return omcVariable_a00465;
}

public void setOmcVariable_a00465(String omcVariable_a00465){
    this.omcVariable_a00465 = omcVariable_a00465;
}

public String getOmcVariable_a00466(){
    return omcVariable_a00466;
}

public void setOmcVariable_a00466(String omcVariable_a00466){
    this.omcVariable_a00466 = omcVariable_a00466;
}

public String getOmcVariable_a00467(){
    return omcVariable_a00467;
}

public void setOmcVariable_a00467(String omcVariable_a00467){
    this.omcVariable_a00467 = omcVariable_a00467;
}

public String getOmcVariable_a00468(){
    return omcVariable_a00468;
}

public void setOmcVariable_a00468(String omcVariable_a00468){
    this.omcVariable_a00468 = omcVariable_a00468;
}

public String getOmcVariable_a00469(){
    return omcVariable_a00469;
}

public void setOmcVariable_a00469(String omcVariable_a00469){
    this.omcVariable_a00469 = omcVariable_a00469;
}

public String getOmcVariable_a00470(){
    return omcVariable_a00470;
}

public void setOmcVariable_a00470(String omcVariable_a00470){
    this.omcVariable_a00470 = omcVariable_a00470;
}

public String getOmcVariable_a00471(){
    return omcVariable_a00471;
}

public void setOmcVariable_a00471(String omcVariable_a00471){
    this.omcVariable_a00471 = omcVariable_a00471;
}

public String getOmcVariable_a00472(){
    return omcVariable_a00472;
}

public void setOmcVariable_a00472(String omcVariable_a00472){
    this.omcVariable_a00472 = omcVariable_a00472;
}

public String getOmcVariable_a00473(){
    return omcVariable_a00473;
}

public void setOmcVariable_a00473(String omcVariable_a00473){
    this.omcVariable_a00473 = omcVariable_a00473;
}

public String getOmcVariable_a00474(){
    return omcVariable_a00474;
}

public void setOmcVariable_a00474(String omcVariable_a00474){
    this.omcVariable_a00474 = omcVariable_a00474;
}

public String getOmcVariable_a00475(){
    return omcVariable_a00475;
}

public void setOmcVariable_a00475(String omcVariable_a00475){
    this.omcVariable_a00475 = omcVariable_a00475;
}

public String getOmcVariable_a00476(){
    return omcVariable_a00476;
}

public void setOmcVariable_a00476(String omcVariable_a00476){
    this.omcVariable_a00476 = omcVariable_a00476;
}

public String getOmcVariable_a00477(){
    return omcVariable_a00477;
}

public void setOmcVariable_a00477(String omcVariable_a00477){
    this.omcVariable_a00477 = omcVariable_a00477;
}

public String getOmcVariable_a00478(){
    return omcVariable_a00478;
}

public void setOmcVariable_a00478(String omcVariable_a00478){
    this.omcVariable_a00478 = omcVariable_a00478;
}

public String getOmcVariable_a00479(){
    return omcVariable_a00479;
}

public void setOmcVariable_a00479(String omcVariable_a00479){
    this.omcVariable_a00479 = omcVariable_a00479;
}

public String getOmcVariable_a00480(){
    return omcVariable_a00480;
}

public void setOmcVariable_a00480(String omcVariable_a00480){
    this.omcVariable_a00480 = omcVariable_a00480;
}

public String getOmcVariable_a00481(){
    return omcVariable_a00481;
}

public void setOmcVariable_a00481(String omcVariable_a00481){
    this.omcVariable_a00481 = omcVariable_a00481;
}

public String getOmcVariable_a00482(){
    return omcVariable_a00482;
}

public void setOmcVariable_a00482(String omcVariable_a00482){
    this.omcVariable_a00482 = omcVariable_a00482;
}

public String getOmcVariable_a00483(){
    return omcVariable_a00483;
}

public void setOmcVariable_a00483(String omcVariable_a00483){
    this.omcVariable_a00483 = omcVariable_a00483;
}

public String getOmcVariable_a00484(){
    return omcVariable_a00484;
}

public void setOmcVariable_a00484(String omcVariable_a00484){
    this.omcVariable_a00484 = omcVariable_a00484;
}

public String getOmcVariable_a00485(){
    return omcVariable_a00485;
}

public void setOmcVariable_a00485(String omcVariable_a00485){
    this.omcVariable_a00485 = omcVariable_a00485;
}

public String getOmcVariable_a00486(){
    return omcVariable_a00486;
}

public void setOmcVariable_a00486(String omcVariable_a00486){
    this.omcVariable_a00486 = omcVariable_a00486;
}

public String getOmcVariable_a00487(){
    return omcVariable_a00487;
}

public void setOmcVariable_a00487(String omcVariable_a00487){
    this.omcVariable_a00487 = omcVariable_a00487;
}

public String getOmcVariable_a00488(){
    return omcVariable_a00488;
}

public void setOmcVariable_a00488(String omcVariable_a00488){
    this.omcVariable_a00488 = omcVariable_a00488;
}

public String getOmcVariable_a00489(){
    return omcVariable_a00489;
}

public void setOmcVariable_a00489(String omcVariable_a00489){
    this.omcVariable_a00489 = omcVariable_a00489;
}

public String getOmcVariable_a00490(){
    return omcVariable_a00490;
}

public void setOmcVariable_a00490(String omcVariable_a00490){
    this.omcVariable_a00490 = omcVariable_a00490;
}

public String getOmcVariable_a00491(){
    return omcVariable_a00491;
}

public void setOmcVariable_a00491(String omcVariable_a00491){
    this.omcVariable_a00491 = omcVariable_a00491;
}

public String getOmcVariable_a00492(){
    return omcVariable_a00492;
}

public void setOmcVariable_a00492(String omcVariable_a00492){
    this.omcVariable_a00492 = omcVariable_a00492;
}

public String getOmcVariable_a00493(){
    return omcVariable_a00493;
}

public void setOmcVariable_a00493(String omcVariable_a00493){
    this.omcVariable_a00493 = omcVariable_a00493;
}

public String getOmcVariable_a00494(){
    return omcVariable_a00494;
}

public void setOmcVariable_a00494(String omcVariable_a00494){
    this.omcVariable_a00494 = omcVariable_a00494;
}

public String getOmcVariable_a00495(){
    return omcVariable_a00495;
}

public void setOmcVariable_a00495(String omcVariable_a00495){
    this.omcVariable_a00495 = omcVariable_a00495;
}

public String getOmcVariable_a00496(){
    return omcVariable_a00496;
}

public void setOmcVariable_a00496(String omcVariable_a00496){
    this.omcVariable_a00496 = omcVariable_a00496;
}

public String getOmcVariable_a00497(){
    return omcVariable_a00497;
}

public void setOmcVariable_a00497(String omcVariable_a00497){
    this.omcVariable_a00497 = omcVariable_a00497;
}

public String getOmcVariable_a00498(){
    return omcVariable_a00498;
}

public void setOmcVariable_a00498(String omcVariable_a00498){
    this.omcVariable_a00498 = omcVariable_a00498;
}

public String getOmcVariable_a00499(){
    return omcVariable_a00499;
}

public void setOmcVariable_a00499(String omcVariable_a00499){
    this.omcVariable_a00499 = omcVariable_a00499;
}

public String getOmcVariable_a00500(){
    return omcVariable_a00500;
}

public void setOmcVariable_a00500(String omcVariable_a00500){
    this.omcVariable_a00500 = omcVariable_a00500;
}

}
