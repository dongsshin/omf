package com.rap.omc.core.util.omc;

import java.util.concurrent.ConcurrentHashMap;

public class JwtTokenThreadLocalUtil {

    /**
     * ThreadLocal.
     */
    private static ThreadLocal<ConcurrentHashMap<String, Object>> threadLocal = new ThreadLocal<ConcurrentHashMap<String, Object>>();

    /**
     * ThreadLocal 저장 대상 Key.
     */
    public static enum KEY {Authorization}
    //dataSource: File을 관리하기 위한 것임.
    
    /**
     * ThreadLocal 변수 초기화.
     */
    public static void init(){
        ConcurrentHashMap<String, Object> map = new ConcurrentHashMap<String, Object>();
        threadLocal.set(map);
    }

    /**
     * ThreadLocal 변수 삭제.
     */
    public static void destroy(){
        threadLocal.remove();
    }

    /**
     * ThreadLocal 초기화 여부.
     * 
     * @return isInitialized
     */
    public static boolean isInitialized(){
        return (threadLocal.get() != null);
    }

    /**
     * ThreadLocal에 정보 저장.
     * 
     * @param key
     * @param value
     */
    public static void set(KEY key, Object value){
        if (!JwtTokenThreadLocalUtil.isInitialized()) {
            JwtTokenThreadLocalUtil.init();
        }
        ConcurrentHashMap<String, Object> map = threadLocal.get();
        map.put(key.name(), value);
    }

    /**
     * ThreadLocal Value 취득.
     * 
     * @param key
     * @return
     */
    public static Object get(KEY key){
        ConcurrentHashMap<String, Object> map = threadLocal.get();
        if (map == null) {
            return null;
        }
        return map.get(key.name());
    }

    public static void setAuthorization(String jwt){
        JwtTokenThreadLocalUtil.set(KEY.Authorization,jwt);
    }
    public static String getAuthorization(){
        return (String)JwtTokenThreadLocalUtil.get(KEY.Authorization);
    }
}
