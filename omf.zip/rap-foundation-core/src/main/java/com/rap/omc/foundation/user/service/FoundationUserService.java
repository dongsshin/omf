/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : UserPropertyService.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 3. 9.  hyeyoung.park   Initial
 * ===========================================
 */
package com.rap.omc.foundation.user.service;

import com.event.publish.vo.EventUserVO;
import com.rap.config.datasource.dao.GenericDao;
import com.rap.omc.controller.model.CUserPropertyVO;
import com.rap.omc.foundation.user.model.CommonUserSearchVO;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.foundation.user.model.User2UserResultVO;
import com.rap.omc.foundation.user.model.UserPropertyVO;
import com.rap.omc.schema.object.model.OmcSchemaUserVO;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * Class : UserService
 * Description : TODO
 * </pre>
 * 
 * @author DongSik.Shin
 */
public interface FoundationUserService {
    public List<OmcSchemaUserVO> getCommonUserList(CommonUserSearchVO searchVO);
    public void txnCreateUser(SysUserVO input);
    public void txnCreateUser(String userId, String userName, String site, String departmentCode, String departmentDesc, String departmentDescKor, String mailId);
    public void txnCreateUser(String userId, String userName, String site, String mailId);
    public void txnCreateUser(String userId, String userName);
    public OmcSchemaUserVO txnCreateRole(String role, String roleName);
    public OmcSchemaUserVO txnCreateGroup(String group, String groupName);
    public void txnCreateRoleGroup(String roleGroup, String roleGroupName);
    public void txnSetTimeStampSystemUser(String userId, String timeStamp);
    public void txnSetSynchronizedSystemUser(String userId, String datasourceName);
    public void txnActivate(String userId);
    public void txnInActivate(String userId);
    public void txnChangePassword(String userId, String newPassword);
    public SysUserVO getUserInfo(String userId);
    public SysUserVO getUserInfo(String userId, boolean includePwd);
    public String getTimeStamp(String userId);
    public SysUserVO getCommonUserInfo(String userId);
    public SysUserVO getRoleInfo(String roleId);
    public SysUserVO getGroupInfo(String groupId);
    public List<EventUserVO> getMustBeSynchronizedList(String databaseBeanName);
    public void txnSynchronize(GenericDao genericDao, EventUserVO eventUserVO);
    public void synchronizeUser(GenericDao genericDao, EventUserVO eventUserVO);
    
    public Map<String,String> getPropertyList(String userId);
    public String getPropertyValue(String userId, String propertyName);
    public void txnSetPropertyValue(String userId, String propertyName, String propertyValue);
    public void txnSetPropertyValueList(String userId, Map<String,String> propertyList);
    public void txnSetPropertyValueList(String userId, CUserPropertyVO cUserPropertyVO);
    
    public void txnAddRoleToUser(String userId, String role);
    public void txnAddRoleToUser(String userId, Set<String> roleList);
    public void txnRemoveRoleToUser(String userId, String role);
    public void txnRemoveRoleToUser(String userId, Set<String> roleList);
    
    public void txnAddGroupToUser(String userId, String group);
    public void txnAddGroupToUser(String userId, Set<String> groupList);
    public void txnRemoveGroupToUser(String userId, Set<String> groupList);
    public void txnRemoveGroupToUser(String userId, String group);
    
    public Set<String> getRoleList(String userId);
    public Set<String> getGroupList(String userId);
    public Set<String> getUserListForGroup(String group);
    public Set<String> getUserListForRole(String role);
    
    public List<User2UserResultVO> getUserVOListForRole(String groupId,int wantedLevel, int currentLevel,String uniqueStr);
    public List<User2UserResultVO> getUserVOListForGroup(String groupId,int wantedLevel, int currentLevel,String uniqueStr);
    
    public List<User2UserResultVO> getRoleVOListForUser(String userId,int wantedLevel, int currentLevel,String uniqueStr);
    public List<User2UserResultVO> getRoleVOListForRole(String roleId,int wantedLevel, int currentLevel,String uniqueStr);
    public List<User2UserResultVO> getRoleVOListForGroup(String groupId,int wantedLevel, int currentLevel,String uniqueStr);
    
    public List<User2UserResultVO> getGroupVOListForUser(String userId,int wantedLevel, int currentLevel,String uniqueStr);
    public List<User2UserResultVO> getGroupVOListForGroup(String  groupId,int wantedLevel, int currentLevel,String uniqueStr);
    public List<User2UserResultVO> getGroupVOListForRole(String  roleId,int wantedLevel, int currentLevel,String uniqueStr);
    
    public List<User2UserResultVO> getCommonUserListForUser(String  userId);
    public List<User2UserResultVO> getCommonUserListForRole(String  roleId);
    public List<User2UserResultVO> getCommonUserListForGroup(String  groupId);
    public List<User2UserResultVO> getCommonUserListForCommon(String  commonId);
    
    //public List<User2UserResultVO> getListToUserForUser(String userId, long fromKinds, long scemaKinds, long toKinds);
    //public List<User2UserResultVO> getListFromUserForUser(String userId, long fromKinds, long scemaKinds, long toKinds);
    //public List<User2UserResultVO> getListFromToUserForUser(String userId);
    public List<User2UserResultVO> getCommonUserAllListForUser(String commonUserId);
    
    public List<User2UserResultVO> getCommonToUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds, int wantedLevel);
    public List<User2UserResultVO> getCommonToUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds,int wantedLevel,int currentLevel,String uniqueStr);
    public List<User2UserResultVO> getCommonFromUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds,int wantedLevel);
    public List<User2UserResultVO> getCommonFromUserListForCommonUser(String commonUserName,long fromKinds,long scemaKinds,long toKinds,int wantedLevel,int currentLevel,String uniqueStr);
    
    public void txnAddUserForGroup(String group, String userId);
    public void txnAddUserForGroup(String group, Set<String> userList);
    public void txnRemoveUserForGroup(String group, String userId);
    public void txnRemoveUserForGroup(String group, Set<String> userList);
    
    public void txnAddGroupForGroup(String group, String addedGroup);
    public void txnAddGroupForGroup(String group, Set<String> addedGroupList);
    public void txnAddRoleForGroup(String group, String role);
    public void txnAddRoleForGroup(String group, Set<String> roleList);
    public void txnRemoveGroupForGroup(String group, String addedGroup);
    public void txnRemoveGroupForGroup(String group, Set<String> addedGroupList);
    public void txnRemoveRoleForGroup(String group, String role);
    public void txnRemoveRoleForGroup(String group, Set<String> roleList);
    
    public void txnAddUserForRole(String role, String user);
    public void txnAddUserForRole(String role, Set<String> userList);
    public void txnRemoveUserForRole(String role, String user);
    public void txnRemoveUserForRole(String role, Set<String> userList);
    
    public void txnAddRoleForRole(String role, String addedRole);
    public void txnAddRoleForRole(String role, Set<String> addedRoleList);
    public void txnAddGroupForRole(String role, String group);
    public void txnAddGroupForRole(String role, Set<String> groupList);
    public void txnRemoveRoleForRole(String role, String removeRole);
    public void txnRemoveRoleForRole(String role, Set<String> removedRoleList);
    public void txnRemoveGroupForRole(String role, String group);
    public void txnRemoveGroupForRole(String role, Set<String> groupList);


    public void txnChangeSite(String userId, String site);
    public void txnSetUserDescription(String userId, String descriptions);
    public void txnChangeDepartment(String userId, String departmentCode, String departmentDesc, String departmentDescKr);
    public void txnChangeMailId(String userId, String emailId);
    
    public Date getSessionUserLocalTimeForUser(UserPropertyVO searchInfo);
    public void txnAddCheckItem(String userId, String checkItem);

}
