package com.rap.omc.controller.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CSysRoleVO {
    private String roleName;
    private String roleDescription;
}
