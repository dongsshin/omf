package com.rap.omc.controller.model;

import com.rap.api.object.foundation.model.CPamBaseModel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CFindObjectCondVO extends CPamBaseModel {
    private String className;
    private String wherePattern;
    private String paramPattern;
}
