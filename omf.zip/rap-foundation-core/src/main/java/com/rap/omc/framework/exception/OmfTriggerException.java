package com.rap.omc.framework.exception;

import org.springframework.context.MessageSource;
import org.springframework.http.HttpStatus;

public class OmfTriggerException extends OmfFoundationBaseException {
	private static final long serialVersionUID = -8250874954894572277L;
    public OmfTriggerException(HttpStatus httpStatus, String code) {
        super(httpStatus,code);
    }
    public OmfTriggerException(HttpStatus httpStatus, String code, String message) {
        super(httpStatus,code,message);
    }
    public OmfTriggerException(HttpStatus httpStatus, Throwable cause) {

        super(httpStatus,cause);
    }
    public OmfTriggerException(HttpStatus httpStatus, String code, Throwable cause) {
        super(httpStatus,code, cause);
    }
    public OmfTriggerException(HttpStatus httpStatus, String code, MessageSource messageSource) {
        super(httpStatus,code,messageSource);
    }
    public OmfTriggerException(HttpStatus httpStatus, String code, Object... messageParameters) {
        super(httpStatus,code,messageParameters);
    }
    public OmfTriggerException(HttpStatus httpStatus, String code, Object[] messageParameters, Throwable cause) {
        super(httpStatus,code,messageParameters,cause);
    }
}
