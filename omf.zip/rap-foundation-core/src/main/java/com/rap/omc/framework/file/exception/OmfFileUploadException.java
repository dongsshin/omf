package com.rap.omc.framework.file.exception;

import org.springframework.http.HttpStatus;

public class OmfFileUploadException extends OmfFileBaseException
{
    private static final long serialVersionUID = 1L;
    public OmfFileUploadException(HttpStatus httpStatus, String message)
    {
        super(httpStatus,message);
    }
    public OmfFileUploadException(HttpStatus httpStatus, String code, String message)
    {
        super(httpStatus,code, message);
    }
    public OmfFileUploadException(HttpStatus httpStatus, Throwable cause)
    {
        super(httpStatus,cause);
    }
    public OmfFileUploadException(HttpStatus httpStatus, String code, String message, Throwable cause)
    {
        super(httpStatus,code, message, cause);
    }
    public OmfFileUploadException(HttpStatus httpStatus, String message, Throwable cause)
    {
        super(httpStatus,message, cause);
    }
}
