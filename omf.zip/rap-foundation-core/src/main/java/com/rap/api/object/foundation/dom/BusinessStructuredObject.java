/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : BusinessStructuredObject.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2017. 4. 20.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.api.object.foundation.dom;

import com.rap.api.object.foundation.model.BusinessObjectVO;
import com.rap.api.object.foundation.model.BusinessStructuredObjectVO;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;


/**
 * <pre>
 * Class : BusinessStructuredObject
 * Description : Structured Object에 대한 관리를 위한 Class. 아직 구현되지 않음.
 * </pre>
 * 
 * @author s_dongsshin
 */
@Slf4j
public class BusinessStructuredObject extends BusinessObject {
    public BusinessStructuredObject(String obid, boolean withOutData) {
        super(obid,withOutData);
    }
    /**
     * @param vo
     */
    public BusinessStructuredObject(BusinessObjectVO vo) {
        super(vo);
        // TODO Auto-generated constructor stub
    }
    public BusinessStructuredObject(String obid) {
        super(obid);
    }
    @Override
    public BusinessStructuredObjectVO getVo(){
        return (BusinessStructuredObjectVO)super.getVo();
    }
    @Override
    protected void validateForChangeStates(String newStates, Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/
    }
}
