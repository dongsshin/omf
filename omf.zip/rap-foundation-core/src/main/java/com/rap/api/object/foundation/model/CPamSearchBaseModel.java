/**
 * ===========================================
 * System Name : LGE GPDM
 * Program ID : BaseModel1.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.api.object.foundation.model;

import com.rap.omc.framework.exception.OmfFoundationException;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.lang.reflect.Method;


/**
 * <pre>
 * Class : CPamSearchBaseModel
 * Description : TODO
 * </pre>
 * 
 * @author DongSik.Shin
 */
@Setter
@Getter
public class CPamSearchBaseModel extends CPamBaseModel{
    @Schema(example = "",description = "*를 사용해서 Line검색을 할 수 있음")
    private String names;
    @Schema(example = "")
    private String revision;
    @Schema(example = "")
    private String descriptions;
    @Schema(example = "")
    private String titles;
    @Schema(example = "")
    private String states;
    @Schema(example = "")
    private String lifeCycle;
    @Schema(example = "")
    private String creator;
    @Schema(example = "")
    private String modifier;
    @Schema(example = "")
    private String owner;
    @Schema(example = "")
    private String className;
    @Schema(example = "")
    private String locker;
    @Schema(example = "")
    private String checkouter;
    @Schema(example = "2020-01-01")
    private String createdFrom;
    @Schema(example = "2025-12-31")
    private String createdTo;
    @Schema(example = "2020-01-01")
    private String modifiedFrom;
    @Schema(example = "2025-12-31")
    private String modifiedTo;
}
