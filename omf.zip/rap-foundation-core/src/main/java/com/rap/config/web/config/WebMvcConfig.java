package com.rap.config.web.config;

import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateSerializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.rap.config.web.interceptor.AuthCheckInterceptor;
import com.rap.config.web.interceptor.LoginCheckInterceptor;
import com.rap.config.web.interceptor.SSOLocaleChangeInterceptor;
import com.rap.config.web.interceptor.XssCheckInterceptor;
import com.rap.config.web.resolver.RapMethodArgumentResolver;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.dataaccess.paging.policy.PagingPolicyResolver;
import com.rap.omc.framework.resolver.CollectionMethodArgumentResolver;
import com.rap.omc.framework.resolver.I18nLocaleSessionResolver;
import com.rap.omc.framework.resolver.PagingMethodArgumentResolver;
import com.rap.omc.framework.resolver.exception.AjaxExceptionResolver;
import com.rap.omc.framework.util.HtmlTagValidator;
import com.rap.omc.framework.util.PdmXssValidator;
import com.rap.omc.framework.view.AjaxExceptionView;
import com.rap.omc.framework.view.FoundationMappingJacksonJsonView;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.util.StringUtils;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.servlet.config.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerAdapter;
import org.springframework.web.servlet.view.BeanNameViewResolver;

import java.time.format.DateTimeFormatter;
import java.util.*;


@Configuration
@Slf4j
public class WebMvcConfig implements WebMvcConfigurer {
/*
	private static final String[] CLASSPATH_RESOURCE_LOCATIONS = {"classpath:/static/", "classpath:/public/", "classpath:/",
			"classpath:/resources/", "classpath:/META-INF/resources/", "classpath:/META-INF/resources/webjars/"};
	*/
	@Autowired
	private RequestMappingHandlerAdapter requestMappingHandlerAdapter;

	@Autowired
	AuthCheckInterceptor authCheckInterceptor;
	@Autowired
	LoginCheckInterceptor loginCheckInterceptor;
	@Autowired
	SSOLocaleChangeInterceptor ssoLocaleChangeInterceptor;

	private static final String dateFormat = GlobalConstants.DEFAULT_DATE_FORMAT;
	private static final String dateTimeFormat = GlobalConstants.DEFAULT_DATETIME_FORMAT;

	private final String baseUrl = "";

	/*

<?xml version="1.0" encoding="UTF-8"?>
<Context allowCasualMultipartParsing="true" path="/">
    <Resources cachingAllowed="true" cacheMaxSize="100000" />
</Context>
	 */

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//-----------------------Json Converter를 일관성있게 하지 위한 것임-----------------------------------------
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	@Bean
	public Jackson2ObjectMapperBuilderCustomizer jsonCustomizer() {
		return builder -> {
			builder.simpleDateFormat(dateTimeFormat);
			builder.serializers(new LocalDateSerializer(DateTimeFormatter.ofPattern(dateFormat)));
			builder.serializers(new LocalDateTimeSerializer(DateTimeFormatter.ofPattern(dateTimeFormat)));
		};
	}

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//----------------------- RESTFull이기 때문에 기본적으로 CORS를 허용하도록 설정함------------------------------
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	@Override
	public void addCorsMappings(CorsRegistry registry) {
		registry.addMapping("/**")
				.allowedMethods(HttpMethod.GET.name(), HttpMethod.PUT.name(), HttpMethod.POST.name(), HttpMethod.HEAD.name(), HttpMethod.DELETE.name(), "OPTIONS")
				.allowedOrigins(CorsConfiguration.ALL);
		//.allowedOrigins("http://localhost:8080", "http://localhost:9081");
	}

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//----------------------- Swagger 설정 정보--------------------------------------------------------------
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController(baseUrl + "/swagger-ui/").setViewName("forward:" + baseUrl + "/swagger-ui/index.html");
		/*
		registry.addRedirectViewController("/v2/api-docs", "/api-docs");
		registry.addRedirectViewController("/swagger-resources/configuration/ui", "/swagger-resources/configuration/ui");
		registry.addRedirectViewController("/swagger-resources/configuration/security", "/swagger-resources/configuration/security");
		registry.addRedirectViewController("/swagger-resources", "/swagger-resources");*/
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		String baseUrl = StringUtils.trimTrailingCharacter(this.baseUrl, '/');
		registry.addResourceHandler(baseUrl + "/swagger-ui/**")
				.addResourceLocations("classpath:/META-INF/resources/webjars/springfox-swagger-ui/")
				.resourceChain(false);

		//registry.addResourceHandler("/resources/**").addResourceLocations("/resources/");
		//registry.addResourceHandler("/swagger-ui.html**").addResourceLocations("classpath:/META-INF/resources/swagger-ui.html");
		//registry.addResourceHandler("/webjars/**").addResourceLocations("classpath:/META-INF/resources/webjars/");
	}

	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	//----------------------- Method Argument Resolver 설정 ------------------------------------------------
	// 기본적으로 RESTFull이어서 BODY전체를 받아서 처리해야 하지만 RapMethodArgumentResolver를 이용해 각 Key값을 이용해
	// Value Object로 받을 수 있음
	//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	@Override
	public void addArgumentResolvers(List<HandlerMethodArgumentResolver> resolvers) {
		//가장 우선적으로 Check하여 적용되어지도록 Index를 0으로 지정.
		resolvers.add(0, new RapMethodArgumentResolver());
		resolvers.add(new CollectionMethodArgumentResolver());
		resolvers.add(new PagingMethodArgumentResolver(new PagingPolicyResolver()));
	}

	@Bean
	public AjaxExceptionView ajaxErrorView() {
		return new AjaxExceptionView();
	}

	@Bean
	public FoundationMappingJacksonJsonView ajaxView() {
		return new FoundationMappingJacksonJsonView();
	}

	@Bean
	public I18nLocaleSessionResolver localeResolver() {
		I18nLocaleSessionResolver r = new I18nLocaleSessionResolver();
		r.setDefaultLocale(Locale.US);
		return r;
	}

	@Bean
	public BeanNameViewResolver beanNameViewResolver() {
		BeanNameViewResolver beanNameViewResolver = new BeanNameViewResolver();
		beanNameViewResolver.setOrder(1);
		return beanNameViewResolver;
	}

	@Bean
	public AjaxExceptionResolver ajaxExceptionResolver() {
		AjaxExceptionResolver ajaxExceptionResolver = new AjaxExceptionResolver();
		Properties mappings = new Properties();
		mappings.setProperty("headerName", "X-Requested-With");
		mappings.setProperty("headerValues", "XMLHttpRequest");
		mappings.setProperty("errorView", "ajaxErrorView");
		ajaxExceptionResolver.setOrder(1);
		return ajaxExceptionResolver;
	}

/*
	@Bean
	public RestTemplate restTemplate() {
		return new org.springframework.web.client.RestTemplate();
	}
*/
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		//if (true) return;
		registry.addInterceptor(xssCheckInterceptor());

		/********************************Login Check Interceptor*******************************************/
		//loginCheckInterceptor.setSkipUrls(getLoginCheckSipUrls());
		loginCheckInterceptor.setApplyUrls(getLoginCheckApplyUrls());
		registry.addInterceptor(loginCheckInterceptor);

		/********************************Auth Check Interceptor*******************************************/
		authCheckInterceptor.setSkipUrls(getAuthCheckSipUrls());
		//authCheckInterceptor.setApplyUrls(getAuthCheckApplyUrls());
		registry.addInterceptor(authCheckInterceptor);

		/********************************Invalid URL Check Interceptor*******************************************/
		//inValidUrlCheckInterceptor.setSkipUrls( getInvalidURLCheckSipUrls());
		//inValidUrlCheckInterceptor.setApplyUrls(getInvalidURLCheckApplyUrls());
		//registry.addInterceptor(inValidUrlCheckInterceptor);
		/********************************SSO Locale Change Interceptor*******************************************/
		registry.addInterceptor(ssoLocaleChangeInterceptor);
	}


	private List<String> getLoginCheckSipUrls() {
		List<String> ist = new ArrayList<String>();
		ist.add("/schemaSetup");
		return ist;
	}

	private List<String> getLoginCheckApplyUrls() {
		List<String> ist = new ArrayList<String>();
		return ist;
	}

	private List<String> getAuthCheckSipUrls() {
		List<String> ist = new ArrayList<String>();
		ist.add("/schemaSetup");
		return ist;
	}

	private List<String> getAuthCheckApplyUrls() {
		List<String> ist = new ArrayList<String>();
		return ist;
	}

	private List<String> getTokenCheckSipUrls() {
		List<String> ist = new ArrayList<String>();
		return ist;
	}

	private List<String> getTokenCheckApplyUrls() {
		List<String> ist = new ArrayList<String>();
		return ist;
	}

	private List<String> getInvalidURLCheckSipUrls() {
		List<String> ist = new ArrayList<String>();
		return ist;
	}

	private List<String> getInvalidURLCheckApplyUrls() {
		List<String> ist = new ArrayList<String>();
		return ist;
	}

	@Bean
	public XssCheckInterceptor xssCheckInterceptor() {
		return new XssCheckInterceptor(pdmXssValidator());
	}

	@Bean
	public HtmlTagValidator htmlTagValidator() {
		HtmlTagValidator htmlTagValidator = new HtmlTagValidator();
		Map<String, String> validAttrMap = new HashMap<String, String>();
		validAttrMap.put("img", "align, alt, border, crossorigin, height, hspace, ismap, longdesc, src, usemap, vspace, width");
		htmlTagValidator.setValidAttrMap(validAttrMap);
		Set<String> invalidTags = new HashSet<String>();
		invalidTags.add("script");
		invalidTags.add("applet");
		invalidTags.add("embed");
		htmlTagValidator.setInvalidTags(invalidTags);
		return htmlTagValidator;
	}

	@Bean
	public PdmXssValidator pdmXssValidator() {
		PdmXssValidator pdmXssValidator = new PdmXssValidator();
		pdmXssValidator.setHtmlTagValidator(htmlTagValidator());
		Map<String, String> skipImages = new HashMap<String, String>();
		skipImages.put("/requests/ecad/createECADLibRequestMC.do", "descriptions");
		skipImages.put("/requests/ecad/createElectronicCAERequestMC.do", "descriptions");
		skipImages.put("/common/desktop/saveDesktopMemoAjax.do", "memo");
		pdmXssValidator.setSkipImages(skipImages);
		return pdmXssValidator;
	}
}