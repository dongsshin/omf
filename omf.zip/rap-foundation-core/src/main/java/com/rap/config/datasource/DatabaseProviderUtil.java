package com.rap.config.datasource;

import org.apache.ibatis.mapping.VendorDatabaseIdProvider;

import java.util.Properties;

public class DatabaseProviderUtil {
    public static VendorDatabaseIdProvider databaseIdProvider() {
        VendorDatabaseIdProvider databaseIdProvider = new VendorDatabaseIdProvider();
        Properties properties = new Properties();
        properties.put("SQL Server", "sqlserver");
        properties.put("DB2", "db2");
        properties.put("H2", "h2");
        properties.put("MySQL", "mysql");
        properties.put("MariaDB", "mariadb");
        databaseIdProvider.setProperties(properties);
        return databaseIdProvider;
    }
}
