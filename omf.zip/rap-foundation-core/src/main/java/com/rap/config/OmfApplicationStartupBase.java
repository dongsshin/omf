package com.rap.config;

import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.foundation.startup.OmcLoaderExecuter;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.ClassInfoUtil;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.http.HttpStatus;

public class OmfApplicationStartupBase implements ApplicationListener<ApplicationReadyEvent> {
    private String datasourceName;

    public String getDatasourceName() {
        return datasourceName;
    }
    protected void setDatasourceName(String datasourceName) {
        this.datasourceName = datasourceName;
    }

    @Override
    public void onApplicationEvent(final ApplicationReadyEvent event){
        if(StrUtil.isEmpty(datasourceName)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"System Configuration is invalid(Datasource Name");
        OmcLoaderExecuter.load();
        FoundationUserUtil.synchronizeUser(datasourceName);
        ClassInfoUtil.synchronizeClass(datasourceName);
    };
}