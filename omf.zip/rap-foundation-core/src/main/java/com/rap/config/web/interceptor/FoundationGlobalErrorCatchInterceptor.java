package com.rap.config.web.interceptor;

import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@RestController
@Slf4j
public class FoundationGlobalErrorCatchInterceptor implements ErrorController {
    @RequestMapping(value = "/error")
    public void error(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String errorRequestUri = (String)request.getAttribute(RequestDispatcher.ERROR_REQUEST_URI);
        //Favorite Icon인경우 에러처리 하지 않음.
        if(!StrUtil.isEmpty(errorRequestUri) && errorRequestUri.equals("/favicon.ico")) return ;
        Object errorStatusCode = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        Object obj = request.getAttribute(RequestDispatcher.ERROR_EXCEPTION);
        String errorMessage = "NA";
        Exception ex = null;
        if(!NullUtil.isNull(obj) && obj instanceof Exception){
            ex = (Exception)obj;
            ex.printStackTrace();
            errorMessage = ex.getMessage();
        }
        Map<String,Object> map = new HashMap<String,Object>();
        map.put(StatusConstants.MAP_ERROR_KEY_errorStatusCode,errorStatusCode);
        map.put(StatusConstants.MAP_ERROR_KEY_errorRequestUri,errorRequestUri);
        map.put(StatusConstants.MAP_ERROR_KEY_errorMessage,errorMessage);
        map.put(StatusConstants.MAP_ERROR_KEY_exception,ex);
        request.getSession(true).setAttribute(StatusConstants.MAP_ERROR_SESSION_ATTR,map);
        response.sendRedirect("/exception/invalidrequest");
    }
    @Override
    @Deprecated
    public String getErrorPath() {
        return null;
    }
}