package com.rap.config.web.config;

import com.rap.config.web.filter.ThreadLocalFilter;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@Slf4j
public class FilterConfig {
	/*
	@Bean
	public FilterRegistrationBean<CharacterEncodingFilter> getCharacterEncodingFilteregistrationBean()
	{
		CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
		characterEncodingFilter.setEncoding("utf-8");
		characterEncodingFilter.setForceEncoding(true);
		FilterRegistrationBean<CharacterEncodingFilter> registrationBean = new FilterRegistrationBean<CharacterEncodingFilter>(new CharacterEncodingFilter());
		registrationBean.addUrlPatterns("*.do");
		registrationBean.addUrlPatterns("/rs/");
		registrationBean.addUrlPatterns("/ws/");
		registrationBean.setOrder(2);
		return registrationBean;
	}
	@Bean
	public FilterRegistrationBean<AccessLogFilter> getAccessogFilterRegistrationBean()
	{
		FilterRegistrationBean<AccessLogFilter> registrationBean = new FilterRegistrationBean<AccessLogFilter>(new AccessLogFilter());
		registrationBean.addUrlPatterns("*.do");
		registrationBean.addUrlPatterns("/rs/");
		registrationBean.addUrlPatterns("/ws/");
		registrationBean.setOrder(3);
		return registrationBean;
	}
	*/
	@Bean
	public FilterRegistrationBean<ThreadLocalFilter> getThreadLocalFilterRegistrationBean()
	{
		log.info("Thread Local Filter(ThreadLocalFilter) applied");
		FilterRegistrationBean<ThreadLocalFilter> registrationBean = new FilterRegistrationBean<ThreadLocalFilter>(new ThreadLocalFilter());
		registrationBean.addUrlPatterns("/*");
		//registrationBean.addUrlPatterns("/ws/");
		registrationBean.setOrder(4);
		return registrationBean;
	}
}
