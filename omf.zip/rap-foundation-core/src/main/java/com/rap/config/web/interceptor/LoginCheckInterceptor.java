package com.rap.config.web.interceptor;

import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.util.core.StopWatch;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@Component
@Slf4j
public class LoginCheckInterceptor extends UrlPatternInterceptorAdapter {
	@Autowired
	UserSession userSession;
    public boolean checkHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
    	log.info("*************************************LoginCheckInterceptor.checkHandle*******************************");
    	StopWatch watch = new StopWatch();
//    	HttpSession session = request.getSession();
//    	log.info("\nLoginCheckInterceptor Lap Time-01 : " + watch.getElapsed() + " ms\n");
//        boolean isLogin = false;
//        if (session != null) {
//        	UserSessionVO userSessionVO = (UserSessionVO)HttpSessionUtil.getAttribute(session, GlobalConstants.SESSION_USER_INFO);
//        	
//        	log.info("\nLoginCheckInterceptor Lap Time-02 : " + watch.getElapsed() + " ms\n");
//        	BeanUtils.copyProperties(userSessionVO, userSession);
//        	log.info("\nLoginCheckInterceptor(copyProperties) Lap Time-03 : " + watch.getElapsed() + " ms\n");
//        	if(userSession.getTimeStamp().equals(userSessionVO.getTimeStamp())) {
//            	userSessionVO = UserSessionUtil.getUserSeesionVOFromRedis(userSessionVO.getUserId());
//            	log.info("\nLoginCheckInterceptor(From Redis) Lap Time-04 : " + watch.getElapsed() + " ms\n");
//                session.setAttribute(GlobalConstants.SESSION_USER_INFO, userSessionVO);
//                log.info("\nLoginCheckInterceptor Lap Time-05 : " + watch.getElapsed() + " ms\n");
//                BeanUtils.copyProperties(userSessionVO, userSession);
//                log.info("\nLoginCheckInterceptor Lap Time-06 : " + watch.getElapsed() + " ms\n");
//        	}
//            isLogin = (userSession != null);
//        }
//        if (!isLogin) { throw new NoSessionException("frame.error.session"); }
//        log.info("\nLoginCheckInterceptor Lap Time-end : " + watch.getElapsed() + " ms\n");
        
        return true;
    }
}
