package com.rap.config.web.config;

import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.schema.util.OmcUniqueIDGenerator;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.task.AsyncTaskExecutor;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Callable;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executor;
import java.util.concurrent.Future;

@Configuration
@EnableAsync
@Slf4j
public class AsyncConfig {
    //threadPoolTaskExecutor를 통해서 수행하는 경우 Thread Local정보가 자동으로 Copy되어짐.
    @Bean(name = "threadPoolTaskExecutor", destroyMethod = "destroy")
    public Executor threadPoolTaskExecutor() {
        ThreadPoolTaskExecutor taskExecutor = new ThreadPoolTaskExecutor();
        taskExecutor.setCorePoolSize(10);
        taskExecutor.setMaxPoolSize(30);
        taskExecutor.setQueueCapacity(10);
        taskExecutor.setThreadNamePrefix("Executor-");
        taskExecutor.initialize();
        return new HandlingExecutor(taskExecutor);
    }
    //Thread Local정보가 Copy되지 않기 때문에 문제 발생 소지가 있음으로 주의해서 사용하여야 함.
    @Bean
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(10);
        executor.setMaxPoolSize(30);
        executor.setQueueCapacity(10);
        executor.setThreadNamePrefix("Executor-");
        executor.initialize();
        return new HandlingExecutor(executor);
    }
    public class HandlingExecutor implements AsyncTaskExecutor {
        private AsyncTaskExecutor executor;

        public HandlingExecutor(AsyncTaskExecutor executor) {
            this.executor = executor;
        }
        @Override
        public void execute(Runnable task) {
            if(!ThreadLocalUtil.isInitialized()) ThreadLocalUtil.init();
            if(log.isTraceEnabled()) log.info("====>HandlingExecutor.execute(Runnable task) Started");
            ThreadLocalUtil.print();
            executor.execute(createWrappedRunnable(task));
        }
        @Override
        public void execute(Runnable task, long startTimeout) {
            if(!ThreadLocalUtil.isInitialized()) ThreadLocalUtil.init();
            log.info("====>HandlingExecutor.execute(Runnable task, long startTimeout) Started");
            ThreadLocalUtil.print();
            executor.execute(createWrappedRunnable(task), startTimeout);
        }
        @Override
        public Future<?> submit(Runnable task) {
            if(!ThreadLocalUtil.isInitialized()) ThreadLocalUtil.init();
            if(log.isTraceEnabled()) log.info("====>HandlingExecutor.execute(submit(Runnable task) Started");
            ThreadLocalUtil.print();
            return executor.submit(createWrappedRunnable(task));
        }
        @Override
        public <T> Future<T> submit(final Callable<T> task) {
            if(!ThreadLocalUtil.isInitialized()) ThreadLocalUtil.init();
            if(log.isTraceEnabled()) log.info("====>HandlingExecutor.submit(final Callable<T> task) Started");
            ThreadLocalUtil.print();
            return executor.submit(createCallable(task));
        }
        private <T> Callable<T> createCallable(final Callable<T> task) {
            if(log.isTraceEnabled()) log.info("====>HandlingExecutor.createCallable(final Callable<T> task) Started");
            if(log.isTraceEnabled()) ThreadLocalUtil.print();
            return new Callable<T>() {
                @Override
                public T call() throws Exception {
                    try {
                        return task.call();
                    } catch (Exception ex) {
                        handle(ex);
                        throw ex;
                    }
                }
            };
        }
        private Runnable createWrappedRunnable(final Runnable task) {
            //초기 Start Up시에는 Thread Local의 값이  Null임. Thread Local Filter에서 실제 Setting함으로.
            if(!ThreadLocalUtil.isInitialized()) ThreadLocalUtil.init();
            if(log.isTraceEnabled()) log.info("====>HandlingExecutor.createWrappedRunnable(final Runnable task) Started");
            if(log.isTraceEnabled()) ThreadLocalUtil.print();
            ConcurrentHashMap<String, Object> map = ThreadLocalUtil.copyThreadLocal().get();
            return new AsyncAwareTask(new Runnable() {
                @Override
                public void run() {task.run();}
            }, map);
        }
        private void handle(Exception ex) {
            log.info("Failed to execute task. : {}", ex.getMessage());
            log.error("Failed to execute task. ",ex);
        }
        public void destroy() {
            if(log.isTraceEnabled()) log.info("====>HandlingExecutor.destroy() Started");
            if(executor instanceof ThreadPoolTaskExecutor){
                ((ThreadPoolTaskExecutor) executor).shutdown();
            }
        }
    }
    public class AsyncAwareTask<T> implements Callable<T>, Runnable {
        private Callable<T> callable;
        private Runnable runnable;
        private ConcurrentHashMap<String, Object> threadLocalMap = new ConcurrentHashMap<String, Object>();
        public AsyncAwareTask(Runnable task, ConcurrentHashMap<String, Object> threadLocalMap) {
            if(log.isTraceEnabled()) log.trace("====>AsyncAwareTask(Runnable task, ConcurrentHashMap<String, Object> map) Started");
            this.runnable = task;
            this.threadLocalMap = threadLocalMap;
        }
        @Override
        public void run() {
            if(log.isTraceEnabled()) log.trace("====>AsyncAwareTask.run() Started");
            if(log.isTraceEnabled()) log.trace("AsyncAwareTask.run()-Thread Id" + " : " + ThreadLocalUtil.getThreadId());
            //Main Thread와는 다른 Thread이므로 Thread Local의 정보를 Copy한 "map"를 가지고 Thread Local를 초기화 한 후 Settting해주어야 한다.
            //그렇지 않으면 Thread Local의 정보가 Copy되지 않아 문제가 발생한다.
            //그리고 Sub Thread에 서는 Servlet Context Holder를 가지고 Request를 읽을 수 없다.
            ThreadLocalUtil.init();
            ThreadLocalUtil.setThreadLocal(threadLocalMap);
            ThreadLocalUtil.set(ThreadLocalUtil.KEY.subTransactionId,OmcUniqueIDGenerator.getObid());
            if(log.isTraceEnabled()) ThreadLocalUtil.print();
            try {
                runnable.run();
            } finally {
                ThreadLocalUtil.destroy();
            }
        }
        @Override
        public T call() throws Exception {
            if(log.isTraceEnabled()) log.info("====>AsyncAwareTask,call() Started");
            return null;
        }
    }

}