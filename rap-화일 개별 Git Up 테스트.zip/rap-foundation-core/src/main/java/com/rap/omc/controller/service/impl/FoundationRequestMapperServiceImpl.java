package com.rap.omc.controller.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.omc.controller.model.ControllerParameterVO;
import com.rap.omc.controller.model.ControllerRequestParmOutputVO;
import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.controller.service.FoundationRequestMapperService;
import com.rap.omc.controller.service.FoundationRestService;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.framework.annotation.OmfAuthority;
import com.rap.omc.framework.annotation.OMFCrud;
import com.rap.omc.schema.object.dom.OmcSchemaRequestMapper;
import com.rap.omc.schema.object.model.OmcSchemaRequestMapperVO;
import com.rap.omc.schema.util.OmcSchemaServiceUtils;
import com.rap.omc.schema.util.OmcUniqueIDGenerator;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.util.StrUtil;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import java.lang.annotation.Annotation;
import java.util.*;

@Service("foundationRequestMapperService")
public class FoundationRequestMapperServiceImpl implements FoundationRequestMapperService {
    @Autowired
    private RequestMappingHandlerMapping requestMappingHandlerMapping;
    @Autowired
    private ObjectMapper transactionObjectMapper;
    @Autowired
    private FoundationRestService foundationRestService;
    @Override
    public List<OmcSchemaRequestMapperVO> getRequestMapperListForSource(String serviceName, RestParameterMap restParameterMap) {
        String thisServiceName = "";
        if(StrUtil.isEmpty(serviceName) || serviceName.equals("me")) {
            serviceName = PropertiesUtil.getString("rap.module.service");
            thisServiceName = serviceName;
        }else{
            thisServiceName = PropertiesUtil.getString("rap.module.service");
        }
        List<OmcSchemaRequestMapperVO> returnList = new ArrayList<OmcSchemaRequestMapperVO>();
        if(thisServiceName.equals(serviceName)) {
            returnList.addAll(getEndPointList(serviceName));
        }else {
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            returnList.addAll(DomUtil.convertMap2VO(rtnMapList,OmcSchemaRequestMapperVO.class));
        }
        return returnList;
        //https://since.tistory.com/23
    }
    private List<OmcSchemaRequestMapperVO> convertMap2VO(List<LinkedHashMap<String,Object>> rtnMapList) {
        List<OmcSchemaRequestMapperVO> returnList = new ArrayList<OmcSchemaRequestMapperVO>();
        for(LinkedHashMap<String,Object> map : rtnMapList) returnList.add(DomUtil.convertMap2VO(map,OmcSchemaRequestMapperVO.class));
        return returnList;
    }
    private List<OmcSchemaRequestMapperVO> getEndPointList(String serviceName){
        String timeStamp = OmcUniqueIDGenerator.getObid();
        List<ControllerRequestParmOutputVO> detailList = new ArrayList<ControllerRequestParmOutputVO>();
        Map<RequestMappingInfo, HandlerMethod> map = requestMappingHandlerMapping.getHandlerMethods();
        List<OmcSchemaRequestMapperVO> returnList = new ArrayList<OmcSchemaRequestMapperVO>();
        for (Map.Entry<RequestMappingInfo, HandlerMethod> elem : map.entrySet()) {
            OmcSchemaRequestMapperVO requestMapperVO = new OmcSchemaRequestMapperVO();

            requestMapperVO.setServiceName(serviceName);
            RequestMappingInfo key = elem.getKey();
            HandlerMethod method = elem.getValue();
            Map<String, Object> item = new HashMap<String, Object>();

            requestMapperVO.setRequestPath(getString(key.getPatternsCondition().getPatterns()));
            requestMapperVO.setControllerClass(method.getMethod().getDeclaringClass().getName());
            requestMapperVO.setControllerMethod(method.getMethod().getName());

            RequestMapping requestMapping = method.getMethodAnnotation(RequestMapping.class);
            if(requestMapping != null){
                requestMapperVO.setHttpMethod(getString(requestMapping.method()));
                requestMapperVO.setProduces(getString(requestMapping.produces()));
            }
            Operation operation = method.getMethodAnnotation(Operation.class);
            if (operation != null) {
                requestMapperVO.setSummary(operation.summary());
                requestMapperVO.setDescriptions(operation.description());
            }
            ApiOperation apiOperation = method.getMethodAnnotation(ApiOperation.class);
            if (apiOperation != null) {
                requestMapperVO.setSummary(apiOperation.value());
                requestMapperVO.setDescriptions(apiOperation.notes());
            }
            List<ControllerParameterVO> parameters = getParameters(method);
            String parametersJson = "{}";
            try {
                parametersJson = transactionObjectMapper.writeValueAsString(parameters);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            String parameterTypes = "";
            for(int i = 0; i < parameters.size(); i++){
                if(i !=0) parameterTypes = parameterTypes + ",";
                parameterTypes = parameterTypes + parameters.get(i).getParameterMethodType();
            }
            requestMapperVO.setParameters(parameters);
            requestMapperVO.setParametersJson(parametersJson);//setParameters 다음에 수행하도록 해야 함(성능 때문).
            requestMapperVO.setParametersTypes(parameterTypes);
            OmfAuthority omfAuthority = method.getMethodAnnotation(OmfAuthority.class);
            if (omfAuthority != null) {
                requestMapperVO.setAuthorityCheckItem(omfAuthority.checkItem());
                requestMapperVO.setAuthorityTarget(omfAuthority.target());
                requestMapperVO.setGroups(omfAuthority.groups());
                requestMapperVO.setRoles(omfAuthority.roles());
                requestMapperVO.setUsers(omfAuthority.users());
                OMFCrud.KEY[] keys = omfAuthority.crudTypes();
                if(!NullUtil.isNone(keys)){
                    String crudTypes = "";
                    for(int i = 0; i< keys.length; i++){
                        if(i != 0) crudTypes = crudTypes + ",";
                        crudTypes = keys[i].name();
                    }
                    requestMapperVO.setCrudTypes(crudTypes);
                }
                omfAuthority.crudTypes();
            }
            requestMapperVO.setReturnType(method.getMethod().getReturnType().getSimpleName());
            requestMapperVO.setNames(requestMapperVO.getServiceName() + "." + requestMapperVO.getRequestPath() + "." + requestMapperVO.getHttpMethod());
            requestMapperVO.setTimeStamp(timeStamp);
            returnList.add(requestMapperVO);
            detailList.addAll(makeDetail(requestMapperVO));
        }
        return returnList;
        //https://since.tistory.com/23
    }
    @Override
    public void txnRegisterRequestMappers(List<OmcSchemaRequestMapperVO> list) {
        Set<String> excludeSet = new HashSet<String>();
        excludeSet.add("classKinds");excludeSet.add("obid");excludeSet.add("flags");excludeSet.add("names");
        excludeSet.add("creator");excludeSet.add("created");excludeSet.add("sequences");excludeSet.add("changeComments");
        excludeSet.add("owners");excludeSet.add("remarks");
        for(OmcSchemaRequestMapperVO vo : list){
            OmcSchemaRequestMapperVO dbVO = OmcSchemaServiceUtils.getRequestMapperWithNames(vo.getNames());
            if(NullUtil.isNull(dbVO)){
                OmcSchemaRequestMapper dom = new OmcSchemaRequestMapper(vo);
                dom.createObject(new HashMap<String,Object>());
            }else{
                dbVO = DomUtil.copyAttributesWithExclude(vo,dbVO,excludeSet);
                OmcSchemaRequestMapper dbDom = new OmcSchemaRequestMapper(dbVO);
                dbDom.modifyObject(new HashMap<String,Object>());
            }
        }
    }

    @Override
    public ArrayList<OmcSchemaRequestMapperVO> getRequestMapperList(String serviceName) {
        return null;
    }

    private List<ControllerRequestParmOutputVO> makeDetail(OmcSchemaRequestMapperVO requestOutputVO){
        List<ControllerRequestParmOutputVO> list = new ArrayList<ControllerRequestParmOutputVO>();
        if(NullUtil.isNone(requestOutputVO.getParameters())){
            ControllerRequestParmOutputVO detailVO = new ControllerRequestParmOutputVO();
            detailVO.setAuthorityCheckItem(requestOutputVO.getAuthorityCheckItem());
            detailVO.setAuthorityTarget(requestOutputVO.getAuthorityTarget());
            detailVO.setControllerClass(requestOutputVO.getControllerClass());
            detailVO.setControllerMethod(requestOutputVO.getControllerMethod());
            detailVO.setDescription(requestOutputVO.getDescriptions());
            detailVO.setHttpMethod(requestOutputVO.getHttpMethod());
            detailVO.setProduces(requestOutputVO.getProduces());
            detailVO.setRequestPath(requestOutputVO.getRequestPath());
            detailVO.setSummary(requestOutputVO.getSummary());
            detailVO.setReturnType(requestOutputVO.getReturnType());
            detailVO.setKey(requestOutputVO.getRequestPath() + "." + requestOutputVO.getHttpMethod());

            detailVO.setParameterName("No Parameter");

            list.add(detailVO);
        }else{
            for(ControllerParameterVO parm : requestOutputVO.getParameters()){
                ControllerRequestParmOutputVO detailVO = new ControllerRequestParmOutputVO();
                detailVO.setAuthorityCheckItem(requestOutputVO.getAuthorityCheckItem());
                detailVO.setAuthorityTarget(requestOutputVO.getAuthorityTarget());
                detailVO.setControllerClass(requestOutputVO.getControllerClass());
                detailVO.setControllerMethod(requestOutputVO.getControllerMethod());
                detailVO.setDescription(requestOutputVO.getDescriptions());
                detailVO.setHttpMethod(requestOutputVO.getHttpMethod());
                detailVO.setProduces(requestOutputVO.getProduces());
                detailVO.setRequestPath(requestOutputVO.getRequestPath());
                detailVO.setSummary(requestOutputVO.getSummary());
                detailVO.setReturnType(requestOutputVO.getReturnType());
                detailVO.setKey(requestOutputVO.getRequestPath() + "." + requestOutputVO.getHttpMethod() + "." + parm.getParameterIndex());

                detailVO.setParameterIndex(parm.getParameterIndex());
                detailVO.setParameterAnnotation(parm.getParameterAnnotation());
                detailVO.setParameterDefinedType(parm.getParameterDefinedType());
                detailVO.setParameterDescription(parm.getParameterDescription());
                detailVO.setParameterExample(parm.getParameterExample());
                detailVO.setParameterName(parm.getParameterName());
                detailVO.setParameterMethodType(parm.getParameterMethodType());
                list.add(detailVO);
            }
        }
        return list;
    }
    private List<ControllerParameterVO> getParameters(HandlerMethod method){
        Parameters parameters = method.getMethodAnnotation(Parameters.class);
        List<ControllerParameterVO> list = new ArrayList<ControllerParameterVO>();
        Map<String, Map<String,Object>> parmMap = new HashMap<String,Map<String,Object>>();
        List<Map<String,Object>> parmMapList = new ArrayList<Map<String,Object>>();
        if(!NullUtil.isNull(parameters)){
            Parameter[] parameterArray = parameters.value();
            if(!NullUtil.isNull(parameterArray) && parameterArray.length > 0){
                for(int i = 0; i < parameterArray.length; i++){
                    Map<String,Object> map = new HashMap<String,Object>();
                    map.put("name",parameterArray[i].name());
                    map.put("desc",parameterArray[i].description());
                    map.put("example",parameterArray[i].example());
                    parmMapList.add(map);
                }
            }
        }
        MethodParameter[] methodParameters = method.getMethodParameters();
        List<Map<String,Object>> methodParmMapList = new ArrayList<Map<String,Object>>();
        String parameterTypes = "";
        if(!NullUtil.isNull(methodParameters) && methodParameters.length > 0){
            for(int i = 0; i < methodParameters.length; i++){
                Map<String,Object> map = new HashMap<String,Object>();
                map.put("index",methodParameters[i].getParameterIndex());
                map.put("simpleType",methodParameters[i].getParameterType().getSimpleName());
                map.put("type",methodParameters[i].getParameterType().getName());
                if(i != 0) parameterTypes = parameterTypes + ",";
                parameterTypes = parameterTypes + methodParameters[i].getParameterType().getSimpleName();
                map.put("annotation",getString(methodParameters[i].getParameterAnnotations()));
                methodParmMapList.add(map);
            }
        }
        if(parmMapList.size() == methodParmMapList.size()){
            for(int i = 0; i < methodParmMapList.size(); i++){
                ControllerParameterVO vo = new ControllerParameterVO();
                vo.setParameterName((String)parmMapList.get(i).get("name"));
                vo.setParameterDescription((String)parmMapList.get(i).get("desc"));
                String example = (String)parmMapList.get(i).get("example");
                if(example.indexOf(":")>-1){
                    vo.setParameterExample(example.substring(example.indexOf(":")+1));
                    vo.setParameterDefinedType(example.substring(0,example.indexOf(":")));
                }else{
                    vo.setParameterExample(example);
                }
                vo.setParameterMethodType((String)methodParmMapList.get(i).get("simpleType"));
                vo.setParameterMethodFullType((String)methodParmMapList.get(i).get("type"));
                vo.setParameterAnnotation((String)methodParmMapList.get(i).get("annotation"));
                vo.setParameterIndex((Integer)methodParmMapList.get(i).get("index"));
                list.add(vo);
            }
        }else{
            for(int i = 0; i < methodParmMapList.size(); i++){
                ControllerParameterVO vo = new ControllerParameterVO();
                vo.setParameterMethodType((String)methodParmMapList.get(i).get("simpleType"));
                vo.setParameterMethodFullType((String)methodParmMapList.get(i).get("type"));
                vo.setParameterAnnotation((String)methodParmMapList.get(i).get("annotation"));
                vo.setParameterIndex((Integer)methodParmMapList.get(i).get("index"));
                list.add(vo);
            }
        }
        return list;
    }
    private String getString(Annotation[] in){
        if(NullUtil.isNull(in) || in.length==0) return "";
        StringBuffer strBuf = new StringBuffer();
        for(int i = 0; i < in.length; i++){
            strBuf.append(",").append(in[i].annotationType().getSimpleName());
        }
        return strBuf.toString().substring(1);
    }
    private String getString(RequestMethod[] in){
        if(NullUtil.isNull(in) || in.length==0) return "All";
        StringBuffer strBuf = new StringBuffer();
        for(int i = 0; i < in.length; i++){
            strBuf.append(",").append(in[i].name());
        }
        return strBuf.toString().substring(1);
    }
    private String getString(String[] in){
        if(NullUtil.isNull(in) || in.length==0) return "";
        StringBuffer strBuf = new StringBuffer();
        for(int i = 0; i < in.length; i++){
            strBuf.append(",").append(in[i]);
        }
        return strBuf.toString().substring(1);
    }
    private String getString(MethodParameter[] in){
        if(NullUtil.isNull(in) || in.length==0) return "";
        StringBuffer strBuf = new StringBuffer();
        for(int i = 0; i < in.length; i++){
            strBuf.append(",").append(in[i].getParameterType().getSimpleName());
        }
        return strBuf.toString().substring(1);
    }
    private String getString(Set<String> in){
        if(NullUtil.isNone(in)) return "";
        StringBuffer strBuf = new StringBuffer();
        for(String str : in){
            strBuf.append(",").append(str);
        }
        return strBuf.toString().substring(1);
    }
}
