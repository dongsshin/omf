package com.rap.omc.controller.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CUserPropertyVO {
    private String locale;
    private String privateFolder;
    private String defaultPrivateFolder;
    private String defaultProject;
    private String company;
    private String businessUnit;
    private String divisionUnit;
    private String plantUnit;
    private String timeZone;
    private String userObid;
}
