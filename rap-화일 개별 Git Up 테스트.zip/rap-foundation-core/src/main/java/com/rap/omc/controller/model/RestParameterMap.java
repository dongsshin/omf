package com.rap.omc.controller.model;

import com.rap.config.web.security.TokenUtils;
import com.rap.omc.util.NullUtil;
import org.springframework.http.HttpMethod;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.util.HashMap;
import java.util.Map;

public class RestParameterMap {

    private HttpMethod requestMethod;
    private String uri;
    private String serviceUrl;
    private String token;
    private Object body;
    private Map<String, Object> pathMap  = new HashMap<String, Object>();
    private Map<String, Object> queryMap = new HashMap<String, Object>();

    public Object getBody() {
        return body;
    }

    public void setBody(Object body) {
        this.body = body;
    }

    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }
    public RestParameterMap(HttpMethod requestMethod, String uri, String token) {
        this.uri = uri;
        this.requestMethod = requestMethod;
        this.token = token;
        //this.token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getHeader(TokenUtils.HEADER_STRING);
    }
    public RestParameterMap(HttpMethod requestMethod, String uri) {
        this.uri = uri;
        this.requestMethod = requestMethod;
        this.token = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getHeader(TokenUtils.HEADER_STRING);
    }
    public HttpMethod getRequestMethod() {
        return requestMethod;
    }

    public void setServiceUrl(String serviceUrl) {
        this.serviceUrl = serviceUrl;
    }

    public void addPathParameter(String key, Object value) {
        pathMap.put(key,value);
    }
    public void addQueryParameter(String key, Object value) {
        queryMap.put(key,value);
    }

    public String getURL() {
        return serviceUrl + uri;
    }

    public Map<String, Object> getParameters() {
        Map<String,Object> map = new HashMap<String,Object>();
        map.putAll(pathMap);
        map.putAll(queryMap);
        return map;
    }

    public Map<String, Object> getPathMap() {
        return pathMap;
    }

    public Map<String, Object> getQueryMap() {
        return queryMap;
    }

    public boolean hasBody() {
        return !NullUtil.isNull(body);
    }
}
