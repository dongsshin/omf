package com.rap.omc.foundation.excel;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public abstract class ExcelUploadGeneric {
    private HashMap<String, List<Map<String,Object>>> excelData;

    public HashMap<String, List<Map<String, Object>>> getExcelData() {
        return excelData;
    }
    public ExcelUploadGeneric(HashMap<String, List<Map<String, Object>>> excelData) {
        this.excelData = excelData;
    }
    abstract public void executeProcess();

}
