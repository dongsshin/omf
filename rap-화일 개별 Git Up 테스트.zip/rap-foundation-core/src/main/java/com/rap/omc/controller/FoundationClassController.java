package com.rap.omc.controller;


import com.event.publish.vo.EventClassVO;
import com.rap.omc.controller.service.FoundationClassService;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.foundation.ClassInfoUtil;
import io.swagger.annotations.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
public class FoundationClassController extends RestBaseController {
    private final String ERR_MES_FOUNDATION_GET_CLASS_INFO = "foundation.error.class.get.general";

    @Autowired
    FoundationClassService foundationClassService;
    /**************************************************************************************************/
    @ApiOperation(
            value = "Class에 대한 상세 정보 조회",
            notes = "■Parameter"
                    +"<br>⊙ className        : Class Name"
                    +"<br>■Return            : Class 정보"
                    +"<br>■Example           : className:Company"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "className"          , value = "Class Name"           , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/class/{className}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getClassSchemaDetail(@PathVariable("className") String className) {
        try{
            ClassInfo classInfo = foundationClassService.getClassSchemaDetail(className);
            HashMap<String,Object> returnMap = new HashMap<String,Object>();

            HashMap<String,Object> tempMap = classInfo.makeCreateJsonStr();
            for(String key : tempMap.keySet()) returnMap.put(key,tempMap.get(key));
            returnMap.put("Class Detail Schema Info",classInfo);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,returnMap), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
    @RequestMapping(value = "/foundation/class/synch/{databaseBeanName}",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> synchronizeUsers(@PathVariable("databaseBeanName") String databaseBeanName){
        try{
            ClassInfoUtil.synchronizeClass(databaseBeanName);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
    @RequestMapping(value = "/foundation/class/eventsynch",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> synchronizeClass(@RequestBody EventClassVO eventClassVO){
        try{
            ClassInfoUtil.synchronizeClass(eventClassVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_CLASS_INFO,e);
        }
    }
}