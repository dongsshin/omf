package com.rap.omc.controller.service;

import com.rap.omc.controller.model.RestParameterMap;

public interface FoundationRestService {
    public <T> T callRestService(RestParameterMap restParameterMap,Class<T> valueType);
    public void callRestService(RestParameterMap restParameterMap);
}
