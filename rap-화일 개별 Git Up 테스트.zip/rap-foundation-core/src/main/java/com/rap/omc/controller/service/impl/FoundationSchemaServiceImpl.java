package com.rap.omc.controller.service.impl;

import com.rap.omc.controller.model.CSysServiceVO;
import com.rap.omc.controller.service.FoundationSchemaService;
import com.rap.omc.core.util.omc.CacheUtil;
import com.rap.omc.schema.object.dom.OmcSchemaService;
import com.rap.omc.schema.object.model.OmcSchemaServiceVO;
import com.rap.omc.schema.util.OmcSchemaServiceUtils;
import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.util.StrUtil;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;

@Service("foundationSchemaService")
public class FoundationSchemaServiceImpl implements FoundationSchemaService {

    @Override
    public void txnRegisterService(CSysServiceVO sysServiceVO) {
        OmcSchemaServiceVO parmVO=  new OmcSchemaServiceVO();
        parmVO.setServiceUrl(sysServiceVO.getServiceUrl());
        parmVO.setNames(sysServiceVO.getServiceName());
        OmcSchemaService schemaServiceDom = new OmcSchemaService(parmVO);
        schemaServiceDom.createObject(new HashMap<String,Object>());
    }
    @Override
    public void txnModifyService(CSysServiceVO sysServiceVO) {
        OmcSchemaServiceVO parmVO=  getService(sysServiceVO.getServiceName());
        parmVO.setServiceUrl(sysServiceVO.getServiceUrl());
        OmcSchemaService schemaServiceDom = new OmcSchemaService(parmVO);
        schemaServiceDom.modifyObject(new HashMap<String,Object>());
        CacheUtil.evictCache("moduleServiceCache",sysServiceVO.getServiceName());
    }

    @Override
    public void txnInactivateService(String serviceName) {
        OmcSchemaServiceVO parmVO = OmcSchemaServiceUtils.getServiceWithNames(serviceName);
        OmcSchemaService schemaServiceDom = new OmcSchemaService(parmVO);
        schemaServiceDom.inActiviateObject(new HashMap<String,Object>());
    }
    @Override
    public void txnActivateService(String serviceName) {
        OmcSchemaServiceVO parmVO = OmcSchemaServiceUtils.getServiceWithNames(serviceName);
        OmcSchemaService schemaServiceDom = new OmcSchemaService(parmVO);
        schemaServiceDom.activateObject(new HashMap<String,Object>());
    }

    @Override
    public void txnDeleteService(String serviceName) {
        OmcSchemaServiceVO parmVO=  new OmcSchemaServiceVO();
        parmVO.setNames(serviceName);
        OmcSchemaServiceUtils.deleteSystemService(parmVO);
    }

    @Override
    @Cacheable(value = "moduleServiceCache", key = "#serviceName")
    public OmcSchemaServiceVO getService(String serviceName) {
        //Local에 정의되어진 것이 있으면 해당 Local정보로 Service URL정보를 Return한다.
        String localServiceUrl = PropertiesUtil.getString("local.serviceURL." + serviceName);
        OmcSchemaServiceVO vo = OmcSchemaServiceUtils.getServiceWithNames(serviceName);
        if(!StrUtil.isEmpty(localServiceUrl)){
            vo.setServiceUrl(localServiceUrl);
        }
        return OmcSchemaServiceUtils.getServiceWithNames(serviceName);
    }
    @Override
    public ArrayList<OmcSchemaServiceVO> getServiceList(CSysServiceVO sysServiceVO) {
        return null;
    }
}
