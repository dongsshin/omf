/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CacheInterface.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 18. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service;

import com.rap.config.datasource.dao.GenericDao;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.event.publish.vo.EventClassVO;

import java.util.List;

/**
 * <pre>
 * Class : ClassInfoService
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public interface ClassInfoSubService {
    public ClassInfo getClassInfo(String className);
    public ClassInfo getClassInfo(String sessionFactoryName, String className);
    public List<EventClassVO> getAsyncClassList(String datasourceName);
    public void txnSynchronize(GenericDao genericDao, EventClassVO asynchClassVO);
    public void setSynchronizedSystemClass(EventClassVO asynchClassVO, String datasourceName);
}
