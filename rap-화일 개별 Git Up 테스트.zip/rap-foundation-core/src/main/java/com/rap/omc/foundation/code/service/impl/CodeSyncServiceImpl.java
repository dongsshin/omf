/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : FcsServiceImpl.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 2. 4.  jongjung.kwon   Initial
 * ===========================================
 */
package com.rap.omc.foundation.code.service.impl;

import com.rap.config.datasource.dao.GenericDao;
import com.event.publish.vo.EventCodeVO;
import com.rap.omc.foundation.code.service.CodeSyncService;
import org.springframework.stereotype.Service;

@Service("codeSyncService")
public class CodeSyncServiceImpl implements CodeSyncService {
    public void txnSynchronizeCode(GenericDao genericDao, EventCodeVO eventCodeVO){
        int cnt = genericDao.update("Code.updateCode", eventCodeVO);
        if(cnt==0){
            genericDao.insert("Code.insertCode", eventCodeVO);
        }
    }
}