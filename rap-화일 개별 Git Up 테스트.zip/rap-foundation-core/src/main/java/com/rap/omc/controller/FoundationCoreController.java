package com.rap.omc.controller;

import com.constants.OmfURLConstants;
import com.rap.api.object.foundation.model.*;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.controller.model.CFindObjectCondVO;
import com.rap.omc.controller.model.CWorkflowExecuteMethodVO;
import com.rap.omc.controller.model.OmfPagingReturnVO;
import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.controller.service.FoundationObjectApiService;
import com.rap.omc.controller.service.FoundationRestService;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.CommonCodeSyncUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.StrUtil;
import io.swagger.annotations.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
public class FoundationCoreController extends RestBaseController {
    private static final Logger log = LoggerFactory.getLogger(FoundationCoreController.class);
    @Autowired
    private FoundationObjectApiService foundationObjectApiService;
    @Autowired
    private FoundationRestService foundationRestService;

    private final String ERR_MSG_OBJECT_CREATE = "foundation.error.object.create.general";
    private final String ERR_MSG_OBJECT_MODIFY = "foundation.error.object.modify.general";
    private final String ERR_MSG_OBJECT_DELETE = "foundation.error.object.delete.general";
    private final String INFO_MSG_OBJECT_DELETE = "foundation.info.object.delete.general";
    private final String ERR_MSG_OBJECT_GET = "foundation.error.object.get.general";
    private final String ERR_MSG_OBJECT_FIND = "foundation.error.object.find.general";
    private final String ERR_MSG_OBJECT_ADD_FROM_OBJECT = "foundation.error.object.add.from.general";
    private final String ERR_MSG_OBJECT_ADD_TO_OBJECT = "foundation.error.object.add.to.general";
    private final String ERR_MSG_OBJECT_GET_RELATION_OBJECT = "foundation.error.object.get.relation.general";
    private final String ERR_MSG_OBJECT_GET_RELATED_OBJECT = "foundation.error.object.get.related.general";
    private final String DDDDD = "foundation.error.object.get.related.general";

    /**************************************★★★ createObject ★★★ **********************************************/
    @Operation(
            summary = "Object를 Creation하는 API",
            description = "■Parameter"
                    +"<br>⊙ objVO     : 생성하고자 하는 Object의 VO에 대한 Json을 Parameter로 넘겨주면 된다.<br> VO의 className의 속성에 반드시 해당 Object의 Class명을 넘겨줘야 한다."
                    +"<br>■Return   : 생성되어진 Object에 대한 Value Object"
                    +"<br>■Example : objVO: NA"
    )/*
    @ApiImplicitParams({
            @ApiImplicitParam(name = "className", value = "Class Name", required = true, dataType = "string"),
            @ApiImplicitParam(name = "jsonVOMap", value = "수정하고자 Value Object의 Json String", required = true, dataType = "HashMap<String, Object>")
    })
*/
    @RequestMapping(value = "/foundation/object/{className}",method=RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createObject(@PathVariable(name="className",required = true)
                                                        @Parameter(name = "className",in = ParameterIn.PATH ,description = "Class Name",example = "Users")
                                                                    String className,
                                                        @RequestBody(required = true)
                                                        @Parameter(description = "수정하고자 Value Object의 Json String",example = "dddddddddddddddddd")
                                                        HashMap<String,Object> jsonVOMap) {
        try{
            RestParameterMap RestParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/object/{className}");
            RestParameterMap.addPathParameter("className",className);
            RestParameterMap.setBody(jsonVOMap);
            ObjectRootVO objVO = foundationObjectApiService.txnCreateObject(className,jsonVOMap, RestParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_CREATE,e);
        }
    }
    /**************************************★★★ createObject ★★★ **********************************************/
    @Operation(
            summary = "여러 Object를 Creation하는 API",
            description = "■Parameter"
                    +"<br>⊙ jsonVOMapList : 생성하고자 하는 Object의 VO에 대한 Json을 Parameter로 넘겨주면 된다.<br> VO의 className의 속성에 반드시 해당 Object의 Class명을 넘겨줘야 한다."
                    +"<br>■Return   : 생성되어진 Object에 대한 Value Object List"
                    +"<br>■Example : voJsonStrList: NA"
    )
    @RequestMapping(value = "/foundation/objects",method=RequestMethod.POST,consumes = "application/json; charset=utf-8", produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createObjects(@RequestBody List<HashMap<String, Object>> jsonVOMapList) {
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/objects");
            restParameterMap.setBody(jsonVOMapList);
            List<ObjectRootVO> list = foundationObjectApiService.txnCreateObjects(jsonVOMapList,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_CREATE,e);
        }
    }
    /**************************************★★★ modifyObject ★★★ **********************************************/
    @Operation(
            summary = "Object 정보 수정하는 API",
            description = "■Parameter"
            +"<br>⊙ className : 수정하고자 하는 Object Value Object."
            +"<br>⊙ attributes : 수정하고자 하는 Objec 속성들."
            +"<br>⊙ jsonVOStr : 속성값."
            +"<br>■Return    : 수정되어진 Object에 대한 Value Object"
            +"<br>■Example : className: Company, jsonVOStr: json String, attributes:attr1,attr2"
            +"<br>주의: attributes에서는 사용자 정의 속성만 수정가능하고 시스템에서 관리하는 것은 수정하지 않음. Key정보(className, names, revision)는 수정 불가"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "className", value = "Class Name", required = true, dataType = "string"),
            @ApiImplicitParam(name = "attributes", value = "수정되어야 하는 Attributes", required = true, dataType = "string"),
            @ApiImplicitParam(name = "jsonVOMap", value = "수정하고자 Value Object의 Json String", required = true, dataType = "HashMap<String,Object>")
    })
    @RequestMapping(value = "/foundation/object/{className}/{attributes}",method=RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyObject(@PathVariable("className") String className,
                                                        @PathVariable("attributes") String attributes,
                                                        @RequestBody HashMap<String,Object> jsonVOMap){

        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.PUT,"/foundation/object/{className}/{attributes}");
            restParameterMap.addPathParameter("className",className);restParameterMap.addPathParameter("attributes",attributes);
            restParameterMap.setBody(jsonVOMap);
            ObjectRootVO newObjVO = foundationObjectApiService.txnModifyObject(className,jsonVOMap,attributes,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,newObjVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_MODIFY,e);
        }
    }
    /**************************************★★★ modifyObject ★★★ **********************************************/
    @ApiOperation(
            value = "Object 정보 수정하는 API",
            notes = "■Parameter"
                    +"<br>⊙ jsonVOMapList     : 수정하고자 하는 Object Json String List."
                    +"<br>⊙ attributes        : 수정하고자 속성"
                    +"<br>■Return   : 수정되어진 Object에 대한 Value Object List"
                    +"<br>■Example : jsonVOMapList: json String, attributes:attr1,attr2"
                    +"<br>주의: updateAttrList에서는 사용자 정의 속성만 수정가능하고 시스템에서 관리하는 것은 수정하지 않음. Key정보(className, names, revision)는 수정 불가"
                    +"<br>수정시에는 반드시 obid의 값이 실제 값으로 존재해야함 함. 없으면 Fodundation에서 에러를 발생 시킴."
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "jsonVOMapList" , value = "수정하고자 Value Object의 Json String List", required = true, dataType = "List<HashMap<String, Object>>"),
            @ApiImplicitParam(name = "attributes", value = "수정되어야 하는 Attributes", required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/objects",method=RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyObjects(@RequestBody List<HashMap<String, Object>> jsonVOMapList,
                                                         @PathVariable("attributes") String attributes){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.PUT,"/foundation/objects");
            restParameterMap.addPathParameter("attributes",attributes);
            restParameterMap.setBody(jsonVOMapList);
            List<ObjectRootVO> list = foundationObjectApiService.txnModifyObjects(jsonVOMapList,attributes,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_MODIFY,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "Object를 Delete ",
            notes = "■Parameter"
                    +"<br>⊙ obid     : 해당 Object의 ID"
                    +"<br>■Return           : 삭제되어진 Object의 Value Object"
                    +"<br>■Example : obid: obid1"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid", value = "Object ID", required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = OmfURLConstants.URI_FOUNDATION_PATH_obid,method=RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> deleteObject(@PathVariable("obid") String obid){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.DELETE,OmfURLConstants.URI_FOUNDATION_PATH_obid);
            restParameterMap.addPathParameter("obid",obid);
            ObjectRootVO objVO = foundationObjectApiService.txnDeleteObject(obid,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(INFO_MSG_OBJECT_DELETE,RETURN_KEY,objVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_DELETE,e,obid);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "여러 Object 정보 삭제 ",
            notes = "■Parameter"
                    +"<br>⊙ obidArray     : 삭제하고자 하는 Object ID List"
                    +"<br>■Return           : 삭제되어진 Object ID List"
                    +"<br>■Example          : obid1,obid2,obid3"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obidList", value = "Object ID Array", required = true, dataType = "String")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/objects",method=RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> deleteObjectSet(@RequestBody List<String> obidList){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.DELETE,"/foundation/objects");
            restParameterMap.setBody(obidList);
            List<ObjectRootVO> list = foundationObjectApiService.txnDeleteObjects(obidList,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(INFO_MSG_OBJECT_DELETE,RETURN_KEY,list.size()), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_DELETE,e,obidList);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "Object 정보를 Get",
            notes = "■Parameter"
                    +"<br>⊙ obid: Get하고싶은 Object ID"
                    +"<br>■Return: 해당 Object에 대한 Value Object"
                    +"<br>■Example : obid: MHt6gcGqp133PO~hKxki"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid", value = "Object ID", required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = OmfURLConstants.URI_FOUNDATION_PATH_obid,method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getObject(@PathVariable("obid") String obid){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,OmfURLConstants.URI_FOUNDATION_PATH_obid);
            restParameterMap.addPathParameter("obid",obid);
            ObjectRootVO objVO = foundationObjectApiService.getObject(obid,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET,e);
        }
    }

    @RequestMapping(value = OmfURLConstants.URI_FOUNDATION_executeMethod,method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> executeMethod(@RequestBody CWorkflowExecuteMethodVO executeMethodVO){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.PUT,OmfURLConstants.URI_FOUNDATION_executeMethod);
            restParameterMap.setBody(executeMethodVO);
            foundationObjectApiService.txnExecuteMethod(executeMethodVO,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVO"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET,e);
        }
    }
    @RequestMapping(value = OmfURLConstants.URI_FOUNDATION_targetState,method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getTargetState(@PathVariable("obid") String obid,@PathVariable("direction") String direction, @PathVariable("branchTo") String branchTo){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,OmfURLConstants.URI_FOUNDATION_targetState);
            restParameterMap.addPathParameter("obid",obid);
            restParameterMap.addPathParameter("direction",direction);
            foundationObjectApiService.getTargetState(obid, direction,branchTo,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVO"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET,e);
        }
    }
    @RequestMapping(value = OmfURLConstants.URI_FOUNDATION_promote,method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> promote(@PathVariable("obid") String obid){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.PUT,OmfURLConstants.URI_FOUNDATION_promote);
            restParameterMap.addPathParameter("obid",obid);
            foundationObjectApiService.promote(obid,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVO"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "Revision이 있는 Business Object(BusinessObject에서 상속 받은 것)를 찾아줌 ",
            notes = "■Parameter"
                    +"<br>⊙ className : 찾고자 하는 Object의 Class Name"
                    +"<br>⊙ name      : 찾고자 하는 Object의 Name"
                    +"<br>⊙ revision  : 찾고자 하는 Object의 Revision"
                    +"<br>■Return      : 해당 Object에 대한 Value Object"
                    +"<br>■Example     : className:Company, name:LGE, revision: 1"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "className"    , value = "Object Class Name"         , required = true, dataType = "string"),
            @ApiImplicitParam(name = "name"         , value = "Object Name"               , required = true, dataType = "string"),
            @ApiImplicitParam(name = "revision"     , value = "Object Revision"           , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                     @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )

    @RequestMapping(value = "/foundation/object/{className}/{name}/{revision}",method=RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> findBusinessObject(@PathVariable("className") String className,
                                                              @PathVariable("name") String name,
                                                              @PathVariable("revision") String revision){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/object/{className}/{name}/{revision}");
            restParameterMap.addPathParameter("className",className);restParameterMap.addPathParameter("name",name);restParameterMap.addPathParameter("revision",revision);
            BusinessObjectVO businessObjectVO = foundationObjectApiService.findBusinessObject(className,name,revision,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,businessObjectVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_FIND,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "Revision이 있는 최신 혹은 최초 Business Object(BusinessObject에서 상속 받은 것)를 찾아줌 ",
            notes = "■Parameter"
                    +"<br>⊙ className     : 찾고자 하는 Object의 Class Name"
                    +"<br>⊙ name          : 찾고자 하는 Object의 Name"
                    +"<br>⊙ latestOrFirst : Latest : Y, First : N"
                    +"<br>■Return      : 해당 Object에 대한 Value Object"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "className"    , value = "Object Class Name"         , required = true, dataType = "string"),
            @ApiImplicitParam(name = "name"         , value = "Object Name"               , required = true, dataType = "string"),
            @ApiImplicitParam(name = "latestOrFirst", value = "Latest: Y,First: N"        , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/object/revision/{className}/{name}/{latestOrFirst}",method=RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> findObject(@PathVariable("className") String className,
                                                      @PathVariable("name") String name,
                                                      @PathVariable("latestOrFirst") String latestOrFirst){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/object/revision/{className}/{name}/{latestOrFirst}");
            restParameterMap.addPathParameter("className",className);restParameterMap.addPathParameter("name",name);restParameterMap.addPathParameter("latestOrFirst",latestOrFirst);
            BusinessObjectVO businessObjectVO= foundationObjectApiService.findObject(className,name,latestOrFirst,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,businessObjectVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_FIND,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "Revision이 없는 Business Object(BusinessObjectMaster에서 상속 받은 것)를 찾아줌 ",
            notes = "■Parameter"
                    +"<br>⊙ className     : 찾고자 하는 Object의 Class Name"
                    +"<br>⊙ name          : 찾고자 하는 Object의 Name"
                    +"<br>■Return      : 해당 Object에 대한 Value Object"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "className"    , value = "Object Class Name"         , required = true, dataType = "string"),
            @ApiImplicitParam(name = "name"         , value = "Object Name"               , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/object/{className}/{name}",method=RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> findBusinessObjectMaster(@PathVariable("className") String className,
                                                                    @PathVariable("name") String name){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/object/{className}/{name}");
            restParameterMap.addPathParameter("className",className);restParameterMap.addPathParameter("name",name);
            BusinessObjectMasterVO businessObjectMasterVO = foundationObjectApiService.findBusinessObjectMaster(className,name,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,businessObjectMasterVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_FIND,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "Revision이 없는 Business Object(BusinessObjectMaster에서 상속 받은 것)를 찾아줌 ",
            notes = "■Parameter"
                    +"<br>⊙ className     : 찾고자 하는 Object의 Class Name"
                    +"<br>⊙ namePattern   : 찾고자 하는 Object의 Name의 Pattern"
                    +"<br>■Return       : 해당 조건에 맞는 Value Object List"
                    +"<br>■Example      : className:Company, namePattern:LG*"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "className"    , value = "Object Class Name"         , required = true, dataType = "string"),
            @ApiImplicitParam(name = "namePattern"  , value = "Object Name Pattern"       , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                     @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/objects/{className}/{namePattern}",method=RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> findObjects(@PathVariable("className") String className,
                                                       @PathVariable("namePattern") String namePattern) {
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/objects/{className}/{namePattern}");
            restParameterMap.addPathParameter("className",className);restParameterMap.addPathParameter("namePattern",namePattern);

            List<BusinessObjectRootVO> list = foundationObjectApiService.findObjects(className,namePattern,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_FIND,e);
        }
    }
    @RequestMapping(value = "/foundation/objects/find",method=RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> findObjects(@RequestBody CFindObjectCondVO cFindObjectCondVO) {
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/objects/find");
            restParameterMap.setBody(cFindObjectCondVO);
            List<BusinessObjectRootVO> list = foundationObjectApiService.findObjects(cFindObjectCondVO,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_FIND,e);
        }
    }

    /**************************************************************************************************/
    @ApiOperation(
            value = "해당 Object(obid)의 From Object로 Reation을 생성함.",
            notes = "■Parameter"
                    +"<br>⊙ obid                : 기준이 되는 Object ID"
                    +"<br>⊙ relationClassName   : Relation Name"
                    +"<br>⊙ jsonVOMap           : 추가할 Object"
                    +"<br>■Return              : 생성되어진 Relation Object의 Value Object"
                    +"<br>■Example             : obid:MHt6gcGqp133PO~hKxki, relationClassName: SubOrganization, jsonVOMap: json"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid"               , value = "Object ID"            , required = true, dataType = "string"),
            @ApiImplicitParam(name = "relationClassName"  , value = "Relation Class Name"  , required = true, dataType = "string"),
            @ApiImplicitParam(name = "jsonVOMap"          , value = "추가할 ObjectVO" , required = true, dataType = "ObjectRootVO")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )

    @RequestMapping(value = "/foundation/object/{obid}/relation/from/{relationClassName}",method=RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> addFromObject(@PathVariable("obid") String obid,
                                                         @PathVariable("relationClassName") String relationClassName,
                                                         @RequestBody HashMap<String,Object> jsonVOMap){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/object/{obid}/relation/from/{relationClassName}");
            restParameterMap.addPathParameter("obid",obid);restParameterMap.addPathParameter("relationClassName",relationClassName);
            restParameterMap.setBody(jsonVOMap);
            BusinessRelationObjectVO relVO = foundationObjectApiService.tnxCreateRelation(obid,relationClassName, GlobalConstants.FLAG_TYPE_FROM,jsonVOMap,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,relVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_ADD_FROM_OBJECT,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "해당 Object(obid)의 From Object로 Reation을 생성함.",
            notes = "■Parameter"
                    +"<br>⊙ obid                : 기준이 되는 Object ID"
                    +"<br>⊙ relationClassName   : Relation Name"
                    +"<br>⊙ jsonVOMapList       : 추가할 Object List"
                    +"<br>■Return              : 생성되어진 Relation Object의 Value Object List"
                    +"<br>■Example             : obid:MHt6gcGqp133PO~hKxki, relationClassName: SubOrganization, jsonVOMapList: json List"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid"               , value = "Object ID"            , required = true, dataType = "string"),
            @ApiImplicitParam(name = "relationClassName"  , value = "Relation Class Name"  , required = true, dataType = "string"),
            @ApiImplicitParam(name = "jsonVOMapList"      , value = "추가할 ObjectVO List"  , required = true, dataType = "List<ObjectRootVO>")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/objects/{obid}/relation/from/{relationClassName}",method=RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> addFromObjects(@PathVariable("obid") String obid,
                                                          @PathVariable("relationClassName") String relationClassName,
                                                          @RequestBody List<HashMap<String,Object>> jsonVOMapList){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/objects/{obid}/relation/from/{relationClassName}");
            restParameterMap.addPathParameter("obid",obid);restParameterMap.addPathParameter("relationClassName",relationClassName);
            restParameterMap.setBody(jsonVOMapList);
            List<BusinessRelationObjectVO> relVOList = foundationObjectApiService.tnxCreateRelations(obid,relationClassName, GlobalConstants.FLAG_TYPE_FROM,jsonVOMapList,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,relVOList), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_ADD_FROM_OBJECT,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "해당 Object(obid)의 To Object로 Reation을 생성함.",
            notes = "■Parameter"
                    +"<br>⊙ obid                : 기준이 되는 Object ID"
                    +"<br>⊙ relationClassName   : Relation Name"
                    +"<br>⊙ jsonVOMap           : 추가할 Object"
                    +"<br>■Return              : 생성되어진 Relation Object의 Value Object"
                    +"<br>■Example             : obid:MHt6gcGqp133PO~hKxki, relationClassName: SubOrganization, jsonVOMap: json"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid"               , value = "Object ID"            , required = true, dataType = "string"),
            @ApiImplicitParam(name = "relationClassName"  , value = "Relation Class Name"  , required = true, dataType = "string"),
            @ApiImplicitParam(name = "jsonVOMap"          , value = "추가할 ObjectVO" , required = true, dataType = "ObjectRootVO")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                    @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/object/{obid}/relation/to/{relationClassName}",method=RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> addToObject(@PathVariable("obid") String obid,
                                                       @PathVariable("relationClassName") String relationClassName,
                                                       @RequestBody HashMap<String,Object> jsonVOMap){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/object/{obid}/relation/to/{relationClassName}");
            restParameterMap.addPathParameter("obid",obid);restParameterMap.addPathParameter("relationClassName",relationClassName);
            restParameterMap.setBody(jsonVOMap);
            BusinessRelationObjectVO relVO = foundationObjectApiService.tnxCreateRelation(obid,relationClassName, GlobalConstants.FLAG_TYPE_TO,jsonVOMap,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,relVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_ADD_TO_OBJECT,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "해당 Object(obid)의 To Object로 Reation을 생성함.",
            notes = "■Parameter"
                    +"<br>⊙ obid                : 기준이 되는 Object ID"
                    +"<br>⊙ relationClassName   : Relation Name"
                    +"<br>⊙ jsonVOMapList       : 추가할 Object List"
                    +"<br>■Return              : 생성되어진 Relation Object의 Value Object List"
                    +"<br>■Example             : obid:MHt6gcGqp133PO~hKxki, relationClassName: SubOrganization, jsonVOMapList: json List"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid"               , value = "Object ID"            , required = true, dataType = "string"),
            @ApiImplicitParam(name = "relationClassName"  , value = "Relation Class Name"  , required = true, dataType = "string"),
            @ApiImplicitParam(name = "jsonVOMapList"      , value = "추가할 ObjectVO List"  , required = true, dataType = "List<ObjectRootVO>")
    })
    @RequestMapping(value = "/foundation/objects/{obid}/relation/to/{relationClassName}",method=RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> addToObjects(@PathVariable("obid") String obid,
                                                        @PathVariable("relationClassName") String relationClassName,
                                                        @RequestBody List<HashMap<String,Object>> jsonVOMapList){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/objects/{obid}/relation/to/{relationClassName}");
            restParameterMap.addPathParameter("obid",obid);restParameterMap.addPathParameter("relationClassName",relationClassName);
            restParameterMap.setBody(jsonVOMapList);
            List<BusinessRelationObjectVO> relVOList = foundationObjectApiService.tnxCreateRelations(obid,relationClassName, GlobalConstants.FLAG_TYPE_TO,jsonVOMapList,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,relVOList), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_ADD_TO_OBJECT,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "해당 Object에 대한 Relation Object를 찾아줌(getRelationship) ",
            notes = "■Parameter"
                    +"<br>⊙ obid                : 기준이 되는 Object ID"
                    +"<br>⊙ relationClassName   : Relation Name"
                    +"<br>⊙ fromOrTo            : From 혹은 To(찾고자 하는 방향)"
                    +"<br>⊙ targetFilter        : Related Object의 Class Filter"
                    +"<br>■Return             : 해당 Object(obid)의 Relation Object의 Value Object List"
                    +"<br>■Example           : obid:MHt6gcGqp133PO~hKxki, relationClassName: SubOrganization, fromOrTo: To, targetFilter: Organizations"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid"               , value = "Object ID"            , required = true, dataType = "string"),
            @ApiImplicitParam(name = "relationClassName"  , value = "Relation Class Name"  , required = true, dataType = "string"),
            @ApiImplicitParam(name = "fromOrTo"           , value = "From, To"             , required = true, dataType = "string"),
            @ApiImplicitParam(name = "targetFilter"       , value = "Related Class Filter" , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                     @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/objects/{obid}/relation/{relationClassName}/{fromOrTo}/{targetFilter}",method=RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getRelationObjects(@PathVariable("obid") String obid,
                                                              @PathVariable("relationClassName") String relationClassName,
                                                              @PathVariable("fromOrTo") String fromOrTo,
                                                              @PathVariable("targetFilter") String targetFilter){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/objects/{obid}/relation/{relationClassName}/{fromOrTo}/{targetFilter}");
            restParameterMap.addPathParameter("obid",obid);restParameterMap.addPathParameter("relationClassName",relationClassName);
            ;restParameterMap.addPathParameter("fromOrTo",fromOrTo);restParameterMap.addPathParameter("targetFilter",targetFilter);
            List<BusinessRelationObjectVO> list = foundationObjectApiService.getRelationObjects(obid,relationClassName,fromOrTo,targetFilter,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET_RELATION_OBJECT,e);
        }
    }

    /**************************************************************************************************/
    @ApiOperation(
            value = "해당 Object에 대한 Related Object를 찾아줌(getRelatedObjects) ",
            notes = "■Parameter"
                    +"<br>⊙ obid                : 기준이 되는 Object ID"
                    +"<br>⊙ relationClassName   : Relation Name"
                    +"<br>⊙ fromOrTo            : From 혹은 To(찾고자 하는 방향)"
                    +"<br>⊙ targetFilter        : Related Object의 Class Filter"
                    +"<br>■Return            : 해당 Object(obid)의 Related Object의 Value Object List"
                    +"<br>■Example           : obid:MHt6gcGqp133PO~hKxki, relationClassName: SubOrganization, fromOrTo: To, targetFilter: Organizations"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid"               , value = "Object ID"            , required = true, dataType = "string"),
            @ApiImplicitParam(name = "relationClassName"  , value = "Relation Class Name"  , required = true, dataType = "string"),
            @ApiImplicitParam(name = "fromOrTo"           , value = "From, To"             , required = true, dataType = "string"),
            @ApiImplicitParam(name = "targetFilter"       , value = "Related Class Filter" , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                     @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/objects/{obid}/related/{relationClassName}/{fromOrTo}/{targetFilter}",method=RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getRelatedObjects(@PathVariable("obid") String obid,
                                                             @PathVariable("relationClassName") String relationClassName,
                                                             @PathVariable("fromOrTo") String fromOrTo,
                                                             @PathVariable("targetFilter") String targetFilter){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/objects/{obid}/related/{relationClassName}/{fromOrTo}/{targetFilter}");
            restParameterMap.addPathParameter("obid",obid);restParameterMap.addPathParameter("relationClassName",relationClassName);
            ;restParameterMap.addPathParameter("fromOrTo",fromOrTo);restParameterMap.addPathParameter("targetFilter",targetFilter);
            List<ObjectRootVO> list = foundationObjectApiService.getRelatedObjects(obid,relationClassName,fromOrTo,targetFilter,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET_RELATED_OBJECT,e);
        }
    }
    /**************************************************************************************************/
    @ApiOperation(
            value = "해당 Object에 대한 Related Object를 찾아줌(getRelatedObjects), 원하는 Depth까지 ",
            notes = "■Parameter"
                    +"<br>⊙ obid                : 기준이 되는 Object ID"
                    +"<br>⊙ relationClassName   : Relation Name"
                    +"<br>⊙ fromOrTo            : From 혹은 To(찾고자 하는 방향)"
                    +"<br>⊙ targetFilter        : Related Object의 Class Filter"
                    +"<br>⊙ depth               : 찾고자 하는 Depth"
                    +"<br>■Return            : 해당 Object(obid)의 Related Object의 Value Object List"
                    +"<br>■Example           : obid:MHt6gcGqp133PO~hKxki, relationClassName: SubOrganization, fromOrTo: To, targetFilter: Organizations"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "obid"               , value = "Object ID"            , required = true, dataType = "string"),
            @ApiImplicitParam(name = "relationClassName"  , value = "Relation Class Name"  , required = true, dataType = "string"),
            @ApiImplicitParam(name = "fromOrTo"           , value = "From, To"             , required = true, dataType = "string"),
            @ApiImplicitParam(name = "targetFilter"       , value = "Related Class Filter" , required = true, dataType = "string"),
            @ApiImplicitParam(name = "depth"              , value = "찾고자하는 Depth"       , required = true, dataType = "string")
    })
    @ApiResponses(
            value = {@ApiResponse(code = 200, message = "Success"),
                     @ApiResponse(code = 404, message = "자원을 찾을 수 없음")
            }
    )
    @RequestMapping(value = "/foundation/objects/{obid}/related/{relationClassName}/{fromOrTo}/{targetFilter}/{depth}",method=RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getRelatedObjects(@PathVariable("obid") String obid,
                                                             @PathVariable("relationClassName") String relationClassName,
                                                             @PathVariable("fromOrTo") String fromOrTo,
                                                             @PathVariable("targetFilter") String targetFilter,
                                                             @PathVariable("depth") Integer depth){
        try{
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/objects/{obid}/related/{relationClassName}/{fromOrTo}/{targetFilter}/{depth}");
            restParameterMap.addPathParameter("obid",obid);restParameterMap.addPathParameter("relationClassName",relationClassName);
            restParameterMap.addPathParameter("fromOrTo",fromOrTo);restParameterMap.addPathParameter("targetFilter",targetFilter);
            restParameterMap.addPathParameter("depth",depth);

            List<BusinessObjectRootVO> list = foundationObjectApiService.getRelatedObjects(obid,relationClassName,fromOrTo,targetFilter,depth,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET_RELATED_OBJECT,e);
        }
    }
    @RequestMapping(value = "/foundation/objects/paging",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> findObjectsPaging(@RequestParam(name="className"           ,required = true ,defaultValue = "Users") String className,
                                                             @RequestParam(name="namePattern"         ,required = false,defaultValue = "XP*") String namePattern,
                                                             @RequestParam(name="createdFrom"         ,required = false,defaultValue = "2020-01-01") String createdFrom,
                                                             @RequestParam(name="createdTo"           ,required = false,defaultValue = "2020-12-31") String createdTo,
                                                             @RequestParam(name="modifiedFrom"        ,required = false,defaultValue = "2020-01-01") String modifiedFrom,
                                                             @RequestParam(name="modifiedTo"          ,required = false,defaultValue = "2020-12-31") String modifiedTo,
                                                             @RequestParam(name="states"              ,required = false,defaultValue = "Active") String states,
                                                             @RequestParam(name="zz1_targetRow"       ,required = true ,defaultValue = "1") String targetRow,
                                                             @RequestParam(name="zz2_rowSize"         ,required = true ,defaultValue = "30") String rowSize,
                                                             @RequestParam(name="zz3_currentPage"     ,required = true ,defaultValue = "1") String currentPage,
                                                             @RequestParam(name="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{

            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/objects/paging");
            //sortByPattern = URLDecoder.decode(sortByPattern,"UTF-8");
            restParameterMap.addQueryParameter("className",className);restParameterMap.addQueryParameter("namePattern",namePattern);
            restParameterMap.addQueryParameter("createdFrom",createdFrom);restParameterMap.addQueryParameter("createdTo",createdTo);
            restParameterMap.addQueryParameter("modifiedFrom",modifiedFrom);restParameterMap.addQueryParameter("modifiedTo",modifiedTo);
            restParameterMap.addQueryParameter("states",states);

            restParameterMap.addQueryParameter("zz1_targetRow",targetRow);restParameterMap.addQueryParameter("zz2_rowSize",String.valueOf(rowSize));
            restParameterMap.addQueryParameter("zz3_currentPage",currentPage);restParameterMap.addQueryParameter("zz4_sortByPattern",sortByPattern);

            OmfPagingReturnVO pagingReturnVO = foundationObjectApiService.finddObjectsPaging(className, namePattern, createdFrom, createdTo, modifiedFrom, modifiedTo, states,
                                                                                             Integer.parseInt(targetRow), Integer.parseInt(rowSize), Integer.parseInt(currentPage), sortByPattern, restParameterMap);

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,pagingReturnVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_GET_RELATED_OBJECT,e);
        }
    }
    private void makeOQL(String createdFrom,String createdTo,String modifiedFrom,String modifiedTo,String states,StringBuffer wherePatternBuf,StringBuffer paramPatternBuf){
        if(!StrUtil.isEmpty(createdFrom)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[created]",GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN,createdFrom);
        if(!StrUtil.isEmpty(createdTo)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[created]",GlobalConstants.OQL_OPERATOR_LESS_EQTHAN,createdTo);

        if(!StrUtil.isEmpty(modifiedFrom)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[modified]",GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN,modifiedFrom);
        if(!StrUtil.isEmpty(modifiedTo)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[modified]",GlobalConstants.OQL_OPERATOR_LESS_EQTHAN,modifiedTo);

        if(!StrUtil.isEmpty(states)) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[states]",GlobalConstants.OQL_OPERATOR_EQUAL, states);
    }
    @RequestMapping(value = "/foundation/codes/sync",method=RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> findObjects() {
        try{
            CommonCodeSyncUtil.synchronizeCodes();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"list"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_OBJECT_FIND,e);
        }
    }
}
