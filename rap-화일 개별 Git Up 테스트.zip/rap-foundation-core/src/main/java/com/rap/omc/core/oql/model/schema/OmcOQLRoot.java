/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : OmcOQLRoot.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2016. 7. 25.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.omc.core.oql.model.schema;

import com.rap.omc.dataaccess.paging.model.PagingEntity;

import java.lang.reflect.Method;


/**
 * <pre>
 * Class : OmcOQLRoot
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public class OmcOQLRoot extends PagingEntity {

    public Object getAttribute(String attribute){
        StringBuffer methodBufStr = new StringBuffer();
        methodBufStr.append("get").append(attribute.substring(0, 1).toUpperCase()).append(attribute.substring(1));
        try {
            Method method = this.getClass().getMethod(methodBufStr.toString());
            return(method.invoke(this));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return(null);
    }
}
