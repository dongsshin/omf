package com.rap.omc.dataaccess.mybatis;

import com.rap.omc.framework.exception.OmfDaoException;
import org.apache.ibatis.session.RowBounds;
import org.springframework.http.HttpStatus;

public class OmfLimitCountRowBounds extends RowBounds
{
    private final boolean dataCut;
    public OmfLimitCountRowBounds(int limitCount, boolean dataCut)
    {
        super(0, limitCount);
        if (limitCount < 1) throw new OmfDaoException(HttpStatus.INTERNAL_SERVER_ERROR,"LimitCount must be greater than 0.");
        this.dataCut = dataCut;
    }

    public boolean isDataCut()
    {
        return this.dataCut;
    }
}