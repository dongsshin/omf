package com.rap.omc.controller.service;

import com.rap.omc.controller.model.ExcelFormatVO;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface FoundationExcelUploadService {
    public HashMap<String, List<Map<String,Object>>> convertExcelToMapLList(File file, Map<String, ExcelFormatVO> excelFormat) throws IOException, InvalidFormatException;
}
