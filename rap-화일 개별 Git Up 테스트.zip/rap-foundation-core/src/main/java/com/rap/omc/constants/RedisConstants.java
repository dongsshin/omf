package com.rap.omc.constants;

public class RedisConstants {
	public static final String REDIS_USER_ID_PARAMETER = "@USER_ID";
	public static final String REDIS_USER_SESSION_KEY_FROMAT = "_" + REDIS_USER_ID_PARAMETER + ":userSessionVO" + "_";
	public static final String REDIS_USER_CHANGE_MESSAGE     = "UserChange";
}
