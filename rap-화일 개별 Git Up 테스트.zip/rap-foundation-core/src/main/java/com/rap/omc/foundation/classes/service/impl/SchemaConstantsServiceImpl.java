/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CacheInterfaceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 18. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service.impl;

import com.rap.config.datasource.dao.SchemaDao;
import com.rap.omc.dataaccess.OmfSQL;
import com.rap.omc.foundation.classes.service.SchemaConstantsService;
import com.rap.omc.schema.object.dom.OmcSchemaProperty;
import com.rap.omc.schema.object.model.OmcSchemaPropertyVO;
import com.rap.omc.schema.util.OmcSchemaUtil;
import com.rap.omc.schema.util.OmcSystemConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * <pre>
 * Class : SchemaConstantsServiceImpl
 * Description : TODO
 * </pre>
 *
 */ 
@Service("schemaConstantsService")
public class SchemaConstantsServiceImpl implements SchemaConstantsService {
    @Autowired
    private SchemaDao schemaDao;
    @Override
    public List<OmcSchemaPropertyVO> getSystemConstantsList(){
        OmfSQL sql = OmcSchemaProperty.getCommonSelectSql();
        sql.INNER_JOIN("psysconstants b on a.psys_object = b.obid");
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{SYSPTY_KIND_Constants}"     ,"#{SYSPTY_KIND_Constants}"     ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pflags", "#{SYSPTY_FLAG_Active}"        ,"#{SYSPTY_FLAG_Active}"        ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("b.pflags", "#{SYSCONSTANTS_FLAG_Active}"  ,"#{SYSCONSTANTS_FLAG_Active}"  ,false));
        sql.PARAMETER("SYSPTY_KIND_Constants"   ,OmcSystemConstants.SYSPTY_KIND_Constants);
        sql.PARAMETER("SYSPTY_FLAG_Active"      ,OmcSystemConstants.SYSPTY_FLAG_Active);
        sql.PARAMETER("SYSCONSTANTS_FLAG_Active",OmcSystemConstants.SYSCONSTANTS_FLAG_Active);
        List<OmcSchemaPropertyVO> propertyList = sql.END().selectList(schemaDao,"SchemaNew.dynamicRetrieveProperty");
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getLifeCycleConstantsList(String moduleName){
        OmfSQL sql = OmcSchemaProperty.getCommonSelectSql();
        sql.INNER_JOIN("psyslifecycle b on a.psys_object = b.obid");

        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{SYSPTY_KIND_LifeCycle}"     ,"#{SYSPTY_KIND_LifeCycle}"     ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pflags", "#{SYSPTY_FLAG_Active}"        ,"#{SYSPTY_FLAG_Active}"        ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("b.pflags", "#{SYSLCYCLE_FLAG_Active}"  ,"#{SYSLCYCLE_FLAG_Active}"  ,false));

        sql.PARAMETER("SYSPTY_KIND_LifeCycle"   ,OmcSystemConstants.SYSPTY_KIND_LifeCycle);
        sql.PARAMETER("SYSPTY_FLAG_Active"      ,OmcSystemConstants.SYSPTY_FLAG_Active);
        sql.PARAMETER("SYSLCYCLE_FLAG_Active",OmcSystemConstants.SYSCONSTANTS_FLAG_Active);

        if(!moduleName.equals("All")) {
            sql.WHERE("(b.pmodule_list like #{funVariable_00004} or b.pmodule_list like  #{funVariable_00005})");
            sql.PARAMETER("funVariable_00004","%#" + moduleName + "#%");
            sql.PARAMETER("funVariable_00005","%#" + "All" + "#%");
        }
        List<OmcSchemaPropertyVO> propertyList = sql.END().selectList(schemaDao,"SchemaNew.dynamicRetrieveProperty");
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getStateConstantsList(String moduleName){
        OmfSQL sql = OmcSchemaProperty.getCommonSelectSql();
        sql.INNER_JOIN("psysstate     b on a.psys_object = b.obid");
        sql.INNER_JOIN("psyslifecycle c on b.plife_cycle = c.obid");
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{SYSPTY_KIND_State}"     , "#{SYSPTY_KIND_State}"    ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pflags", "#{SYSPTY_FLAG_Active}"    , "#{SYSPTY_FLAG_Active}"   ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("b.pflags", "#{SYSSTATE_FLAG_Active}"  , "#{SYSSTATE_FLAG_Active}" ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("c.pflags", "#{SYSLCYCLE_FLAG_Active}" , "#{SYSLCYCLE_FLAG_Active}",false));
        sql.PARAMETER("SYSPTY_KIND_State"       ,OmcSystemConstants.SYSPTY_KIND_State       );
        sql.PARAMETER("SYSPTY_FLAG_Active"      ,OmcSystemConstants.SYSPTY_FLAG_Active      );
        sql.PARAMETER("SYSSTATE_FLAG_Active"    ,OmcSystemConstants.SYSSTATE_FLAG_Active    );
        sql.PARAMETER("SYSLCYCLE_FLAG_Active"   ,OmcSystemConstants.SYSLCYCLE_FLAG_Active   );

        if(!moduleName.equals("All")) {
            sql.WHERE("(c.pmodule_list like #{funVariable_00005} or c.pmodule_list like  #{funVariable_00006})");
            sql.PARAMETER("funVariable_00005","%#" + moduleName + "#%");
            sql.PARAMETER("funVariable_00006","%#" + "All" + "#%");
        }
        List<OmcSchemaPropertyVO> propertyList = sql.END().selectList(schemaDao,"SchemaNew.dynamicRetrieveProperty");
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getClassBizConstantsList(String moduleName){
        OmfSQL sql = OmcSchemaProperty.getCommonSelectSql();
        sql.INNER_JOIN("psysbizobjectclassinfo b on a.psys_object = b.obid");
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{SYSPTY_KIND_Class}"     , "#{SYSPTY_KIND_Class}"   ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pflags", "#{SYSPTY_FLAG_Active}"    , "#{SYSPTY_FLAG_Active}"  ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("b.pflags", "#{BUSINESS_FLAG_Active}"  , "#{BUSINESS_FLAG_Active}",false));
        sql.PARAMETER("SYSPTY_KIND_Class"   ,OmcSystemConstants.SYSPTY_KIND_Class);
        sql.PARAMETER("SYSPTY_FLAG_Active"  ,OmcSystemConstants.SYSPTY_FLAG_Active);
        sql.PARAMETER("BUSINESS_FLAG_Active",OmcSystemConstants.BUSINESS_FLAG_Active);
        if(!moduleName.equals("All")) {
            sql.WHERE_AND_PARAMETER("b.pmodule_name","moduleName",moduleName);
        }
        List<OmcSchemaPropertyVO> propertyList = sql.END().selectList(schemaDao,"SchemaNew.dynamicRetrieveProperty");
        return(propertyList);
    }
    @Override
    public List<OmcSchemaPropertyVO> getClassRelConstantsList(String moduleName){
        OmfSQL sql = OmcSchemaProperty.getCommonSelectSql();
        sql.INNER_JOIN("psysrelobjectclassinfo b on a.psys_object = b.obid");
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pkinds", "#{SYSPTY_KIND_Class}"     , "#{SYSPTY_KIND_Class}"   ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("a.pflags", "#{SYSPTY_FLAG_Active}"    , "#{SYSPTY_FLAG_Active}"  ,false));
        sql.WHERE(OmcSchemaUtil.getBitAndStr("b.pflags", "#{RELATION_FLAG_Active}"  , "#{RELATION_FLAG_Active}",false));
        sql.PARAMETER("SYSPTY_KIND_Class"   ,OmcSystemConstants.SYSPTY_KIND_Class);
        sql.PARAMETER("SYSPTY_FLAG_Active"  ,OmcSystemConstants.SYSPTY_FLAG_Active);
        sql.PARAMETER("RELATION_FLAG_Active",OmcSystemConstants.RELATION_FLAG_Active);
        if(!moduleName.equals("All")) {
            sql.WHERE_AND_PARAMETER("b.pmodule_name","moduleName",moduleName);
        }
        List<OmcSchemaPropertyVO> propertyList = sql.END().selectList(schemaDao,"SchemaNew.dynamicRetrieveProperty");
        return(propertyList);
    }

}
