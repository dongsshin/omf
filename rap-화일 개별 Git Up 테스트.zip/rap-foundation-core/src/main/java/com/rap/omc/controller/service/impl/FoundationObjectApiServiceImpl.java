package com.rap.omc.controller.service.impl;

import com.constants.GlobalCommonConstants;
import com.constants.OmfURLConstants;
import com.constants.ServiceConstants;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.BusinessObjectRoot;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.*;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.controller.model.*;
import com.rap.omc.controller.service.FoundationObjectApiService;
import com.rap.omc.controller.service.FoundationRestService;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.common.model.KeyInfo;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.object.model.OmcSchemaServiceVO;
import com.rap.omc.util.BaseFoundationUtil;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.StrUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.*;

@Service("foundationObjectApiService")
@SuppressWarnings("unchecked")
public class FoundationObjectApiServiceImpl implements FoundationObjectApiService {
    @Autowired
    private FoundationRestService foundationRestService;
    @Autowired
    private ObjectMapper objectMapper;

    @Override
    public <T extends ObjectRootVO> T txnCreateObject(String className, HashMap<String, Object> jsonVOMap, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        ObjectRootVO objVO = null;
        if(serviceVO.isSameService()) {
            objVO = DomUtil.makeVO(className,jsonVOMap);
            ObjectRoot obj = DomUtil.toDom(objVO);
            obj.createObject();
            return (T)obj.getVo();
        }
        else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            return (T)DomUtil.makeVO((String)map.get("className"),map);
        }
    }
    @Override
    public <T extends ObjectRootVO> List<T> txnCreateObjects(List<HashMap<String, Object>> mapList, RestParameterMap restParameterMap) {
        List<T> list = new ArrayList<>();
        if(NullUtil.isNone(mapList)) return list;
        String className = (String)mapList.get(0).get("className");
        if(StrUtil.isEmpty(className) ) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Class Name is Empty.");
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()) {
            for(HashMap<String,Object> voMap : mapList){
                ObjectRootVO objVO = DomUtil.makeVO(voMap);
                ObjectRoot obj = DomUtil.toDom(objVO);
                obj.createObject();
                list.add((T)obj.getVo());
            }
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            list = DomUtil.makeVO(rtnMapList);
        }
        return list;
    }
    @Override
    public <T extends ObjectRootVO> T txnModifyObject(String className, HashMap<String,Object> voJsonStr, String updateAttrList, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()) {
            ObjectRootVO newObjVO = DomUtil.makeVO(className,voJsonStr);
            if(StrUtil.isEmpty(newObjVO.getClassName())) newObjVO.setClassName(className);
            ObjectRootVO dbObjVO = DomUtil.toDom(newObjVO.getObid()).getVo();
            Set<String> strSet = StrUtil.convertArrayToSet(updateAttrList.split(","));
            DomUtil.copyAttribute(newObjVO,dbObjVO,strSet);
            ObjectRoot obj = DomUtil.toDom(dbObjVO);
            obj.modifyObject();
            return (T)obj.getVo();
        }else{
            LinkedHashMap<String,Object> rtnMap = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            return DomUtil.makeVO((String)rtnMap.get("className"),rtnMap);
        }
    }
    @Override
    public <T extends ObjectRootVO> List<T> txnModifyObjects(List<HashMap<String, Object>> mapList, String updateAttrList, RestParameterMap restParameterMap) {
        List<T> list = new ArrayList<>();
        if(NullUtil.isNone(mapList)) return list;
        String className = (String)mapList.get(0).get("className");
        if(StrUtil.isEmpty(className) ) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Class Name is Empty.");

        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());

        if(serviceVO.isSameService()) {
            Set<String> strSet = StrUtil.convertArrayToSet(updateAttrList.split(","));
            for(HashMap<String,Object> voMap : mapList){
                ObjectRootVO newObjVO = DomUtil.makeVO(voMap);
                if(StrUtil.isEmpty(newObjVO.getObid())) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object Id is Empty.");
                ObjectRootVO dbObjVO = DomUtil.toDom(newObjVO.getObid()).getVo();
                DomUtil.copyAttribute(newObjVO,dbObjVO,strSet);
                ObjectRoot objDom = DomUtil.toDom(dbObjVO);
                objDom.modifyObject();
                list.add((T)objDom.getVo());
            }
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            list = DomUtil.makeVO(rtnMapList);
        }
        return list;
    }
    @Override
    public <T extends ObjectRootVO> T txnDeleteObject(String obid, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        KeyInfo keyInfo = BaseFoundationUtil.getKeyInfo(obid);
        if(serviceVO.isSameService()) {
            ObjectRoot obj = DomUtil.toDom(obid);
            obj.deleteObject();
            return (T)obj.getVo();
        }else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            return DomUtil.makeVO(keyInfo.getClassName(),map);
        }
    }

    @Override
    public <T extends ObjectRootVO> List<T> txnDeleteObjects(List<String> obidList,RestParameterMap restParameterMap) {
        List<T> list = new ArrayList<>();
        if(StrUtil.isDuplicated(obidList)) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Exist Duplicated Object ID.");
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obidList.get(0));
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        KeyInfo keyInfo = BaseFoundationUtil.getKeyInfo(obidList.get(0));
        if(serviceVO.isSameService()) {
            ObjectRoot obj;
            for(String obid : obidList){
                obj = DomUtil.toDom(obid);
                obj.deleteObject();
                list.add((T)obj.getVo());
            }
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            list = DomUtil.makeVO(rtnMapList);
        }
        return list;
    }
    @Override
    public <T extends ObjectRootVO> T getObject(String obid, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());

        ObjectRootVO objVO = null;
        if(serviceVO.isSameService()) {
            objVO = DomUtil.getObjectVO(obid,true);
        }else{
            KeyInfo keyInfo = BaseFoundationUtil.getKeyInfo(obid);
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            objVO = DomUtil.makeVO(keyInfo.getClassName(),map);
        }
        return (T)objVO;
    }

    @Override
    public StateInfo getTargetState(String obid, String direction, String branchTo, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()) {
            BusinessObjectRoot obj = DomUtil.toDom(obid);
            obj.getVo().setBranchTo(branchTo);
            StateInfo stateInfo = obj.getTargetState(direction);
            return stateInfo;
        }else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            //TODO
            return null;
        }
    }
    @Override
    public void promote(String obid, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()) {
            BusinessObjectRoot obj = DomUtil.toDom(obid);
            obj.promote();
        }else{
            foundationRestService.callRestService(restParameterMap);
        }
    }

    @Override
    public <T extends BusinessObjectRootVO> T txnExecuteMethod(CWorkflowExecuteMethodVO executeMethodVO, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(executeMethodVO.getObid());
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        BusinessObjectRoot obj = null;
        if(serviceVO.isSameService()) {
            obj = DomUtil.toDom(executeMethodVO.getObid(),false);
            try {
                Method method = obj.getClass().getMethod(executeMethodVO.getMethodName(),executeMethodVO.getParmMap().getClass());
                method.invoke(obj,executeMethodVO.getParmMap());
            } catch (Exception e) {
                throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Execute(" + executeMethodVO.getMethodName() + ") Error!",e);
            }
        }else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            KeyInfo keyInfo = BaseFoundationUtil.getKeyInfo(executeMethodVO.getObid());
            BusinessObjectRootVO objVO = DomUtil.makeVO(keyInfo.getClassName(),map);
        }
        return (T) obj.getVo();
    }
    @Override
    public <T extends BusinessObjectVO> T findBusinessObject(String className, String name, String revision,RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        BusinessObjectVO businessObjectVO = null;
        if(serviceVO.isSameService()){
            businessObjectVO = BusinessObject.findBusinessObject(className,name,revision);
        }else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            businessObjectVO = DomUtil.makeVO((String)map.get("className"),map);
        }
        return (T)businessObjectVO;
    }

    @Override
    public <T extends BusinessObjectVO> T findObject(String className, String name, String latestOrFirst,RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        BusinessObjectVO businessObjectVO = null;
        if(serviceVO.isSameService()){
            if(latestOrFirst.equalsIgnoreCase("Y")){
                businessObjectVO = BusinessObject.findLatestObject(className,name);
            }else{
                businessObjectVO = BusinessObject.findFirstObject(className,name);
            }
        }else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            businessObjectVO = DomUtil.makeVO((String)map.get("className"),map);
        }
        return (T)businessObjectVO;
    }

    @Override
    public <T extends BusinessObjectMasterVO> T findBusinessObjectMaster(String className, String name,RestParameterMap restParameterMap) {
        BusinessObjectMasterVO businessObjectMasterVO = null;
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            businessObjectMasterVO = BusinessObjectMaster.findBusinessObjectMaster(className,name);
        }else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            businessObjectMasterVO = DomUtil.makeVO(className,map);
        }
        return (T)businessObjectMasterVO;
    }

    @Override
    public <T extends BusinessObjectRootVO> List<T> findObjects(String className, String namePattern, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(className);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            return ObjectRoot.findObjects(className, namePattern);
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            return DomUtil.makeVO(rtnMapList);
        }
    }

    @Override
    public <T extends BusinessRelationObjectVO> List<T> getRelationObjects(String obid, String relationClassName, String fromOrTo, String targetFilter, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            ObjectRoot obj = DomUtil.toDom(obid);
            return obj.getRelationships(relationClassName,targetFilter,fromOrTo);
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            return DomUtil.makeVO(rtnMapList);
        }
    }

    @Override
    public <T extends ObjectRootVO> List<T> getRelatedObjects(String obid, String relationClassName, String fromOrTo, String targetFilter, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            ObjectRoot obj = DomUtil.toDom(obid);
            return obj.getRelatedObjects(relationClassName,targetFilter,fromOrTo);
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            return DomUtil.makeVO(rtnMapList);
        }
    }

    @Override
    public <T extends ObjectRootVO> List<T> getRelatedObjects(String obid, String relationClassName, String fromOrTo, String targetFilter, Integer depth, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            ObjectRoot obj = DomUtil.toDom(obid);
            return obj.getRelatedObjects(relationClassName,targetFilter,fromOrTo,depth);
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            return DomUtil.makeVO(rtnMapList);
        }
    }
    @Override
    public OmfPagingReturnVO finddObjectsPaging(String className, String namePattern, String createdFrom, String createdTo, String modifiedFrom, String modifiedTo, String states, int targetRow, int rowSize, int currentPage, String sortByPattern, RestParameterMap restParameterMap) {

        String[] classNameArray = className.split(",");
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(classNameArray[0]);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            StringBuffer wherePatternBuf = new StringBuffer();
            StringBuffer paramPatternBuf = new StringBuffer();
            StringBuffer selectPatternBuf = new StringBuffer();

            PagingEntity pagingEntity = new PagingEntity(targetRow,rowSize,currentPage,sortByPattern);
            if(!StrUtil.isEmpty(pagingEntity.getOrderBy())) OqlBuilderUtil.addSortByPattern(selectPatternBuf,pagingEntity.getOrderBy());

            makeOQL(createdFrom,createdTo,modifiedFrom,modifiedTo,states,wherePatternBuf,paramPatternBuf);
            List<ObjectRootVO > objVOList = ObjectRoot.findObjectPagingList(className, namePattern, "",selectPatternBuf.toString(), wherePatternBuf.toString(), paramPatternBuf.toString(), pagingEntity);

            OmfPagingList<ObjectRootVO> pagingList = (OmfPagingList<ObjectRootVO>)objVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            OmfPagingReturnVO pagingReturnVO = new OmfPagingReturnVO();pagingReturnVO.setPagingEntity(pagingList.getPagingEntity());pagingReturnVO.setPagingList(pagingList);
            return pagingReturnVO;
        }else{
            Object obj = foundationRestService.callRestService(restParameterMap,OmfPagingReturnVO.class);
            if(obj instanceof LinkedHashMap){
                LinkedHashMap<String,Object> map= (LinkedHashMap<String,Object>)obj;
                OmfPagingReturnVO pagingReturnVO = new OmfPagingReturnVO();
                OmfPagingList<ObjectRootVO> pagingList = new OmfPagingList<ObjectRootVO>();
                ArrayList<LinkedHashMap<String,Object>> hashMapList = (ArrayList<LinkedHashMap<String,Object>>)map.get(GlobalCommonConstants.PAGING_MAP_KEY_LIST);
                for(LinkedHashMap<String,Object> eachMap : hashMapList){
                    pagingList.add(DomUtil.makeVO(eachMap));
                }
                LinkedHashMap<String,Object> pagingEntityMap = (LinkedHashMap<String,Object>)map.get(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY);
                ObjectMapper objectMapper = new ObjectMapper();
                PagingEntity pagingEntity = (PagingEntity)objectMapper.convertValue(pagingEntityMap,PagingEntity.class);
                pagingList.setPagingEntity(pagingEntity);
                pagingReturnVO.setPagingList(pagingList);
                pagingReturnVO.setPagingEntity(pagingEntity);
                return pagingReturnVO;
            }else{
                throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Paging return Object is invalid!");
            }
        }
    }
    @Override
    public <T extends BusinessRelationObjectVO> List<T> tnxCreateRelations(String obid, String relationClassName, String fromOrTo, List<HashMap<String, Object>> mapList, RestParameterMap restParameterMap) {
        List<T> list = new ArrayList<T>();
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            ObjectRoot objDom = DomUtil.toDom(obid);
            for(HashMap<String, Object> map : mapList){
                BusinessRelationObjectVO relVO = createRelationSub(objDom,relationClassName,fromOrTo,map);
                list.add((T)relVO);
            }
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            list = DomUtil.makeVO(rtnMapList);
        }
        return list;
    }
    @Override
    public <T extends BusinessRelationObjectVO> T tnxCreateRelation(String obid, String relationClassName, String fromOrTo, HashMap<String, Object> map, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithObject(obid);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            ObjectRoot objDom = DomUtil.toDom(obid);
            return (T)createRelationSub(objDom,relationClassName,fromOrTo,map);
        }else{
            LinkedHashMap<String,Object> rtnMap = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
            return DomUtil.makeVO((String)rtnMap.get("className"),rtnMap);
        }

    }
    private final <T extends BusinessRelationObjectVO> T createRelationSub(ObjectRoot objDom, String relationClassName, String fromOrTo, HashMap<String, Object> map) {
        BusinessRelationObjectVO relationVO = DomUtil.makeVO(relationClassName,map);
        String relatedObjectId = "";
        ObjectRootVO relatedObjVO;
        boolean bFromTo = true;
        if(GlobalConstants.FLAG_TYPE_FROM.equals(fromOrTo)){
            relatedObjVO = new ObjectRoot(relationVO.getFromObid()).getVo();

        }else if(GlobalConstants.FLAG_TYPE_TO.equals(fromOrTo)){
            relatedObjVO = new ObjectRoot(relationVO.getToObid()).getVo();
            bFromTo = false;
        }else{
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Create Relation parameter(fromOrTo:" + fromOrTo + ") Error. Valid value is From or To.");
        }
        return (T)objDom.addRelatedObject(relationClassName,relatedObjVO,map,bFromTo);
    }
    private void makeOQL(String createdFrom,String createdTo,String modifiedFrom,String modifiedTo,String states,StringBuffer wherePatternBuf,StringBuffer paramPatternBuf){
        if(!StrUtil.isEmpty(createdFrom)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[created]",GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN,createdFrom);
        if(!StrUtil.isEmpty(createdTo)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[created]",GlobalConstants.OQL_OPERATOR_LESS_EQTHAN,createdTo);

        if(!StrUtil.isEmpty(modifiedFrom)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[modified]",GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN,modifiedFrom);
        if(!StrUtil.isEmpty(modifiedTo)) OqlBuilderUtil.constructDateWherePattern(wherePatternBuf,paramPatternBuf,"@this.[modified]",GlobalConstants.OQL_OPERATOR_LESS_EQTHAN,modifiedTo);

        if(!StrUtil.isEmpty(states)) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[states]",GlobalConstants.OQL_OPERATOR_EQUAL, states);
    }
    @Override
    public <T extends BusinessObjectRootVO> List<T> findObjects(CFindObjectCondVO cFindObjectCondVO, RestParameterMap restParameterMap) {
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(cFindObjectCondVO.getClassName());
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()){
            return ObjectRoot.findObjects(cFindObjectCondVO.getClassName(), cFindObjectCondVO.getWherePattern(),cFindObjectCondVO.getParamPattern());
        }else{
            List<LinkedHashMap<String,Object>> rtnMapList = foundationRestService.callRestService(restParameterMap,ArrayList.class);
            return DomUtil.makeVO(rtnMapList);
        }
    }
    @Override
    public WorkflowHeaderVO createWorkflowHeader(CParmHeaderVO cParmHeaderVO) {
        RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST, OmfURLConstants.URI_FOUNDATION_wfHeader);
        restParameterMap.setBody(cParmHeaderVO);
        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithServiceName(ServiceConstants.SERVICE_COMMON);
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        LinkedHashMap<String,Object> headerMap = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
        WorkflowHeaderVO headerVO = DomUtil.makeVO(headerMap);
        return headerVO;
    }
}
