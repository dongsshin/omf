package com.rap.omc.controller.service;

import com.rap.omc.foundation.classes.model.ClassInfo;

import java.util.HashMap;

public interface FoundationClassService {
    public HashMap<String,Object> getClassSchemaInfo();
    public HashMap<String,Object> getClassSchemaForJson();
    public ClassInfo getClassSchemaDetail(String className);
}
