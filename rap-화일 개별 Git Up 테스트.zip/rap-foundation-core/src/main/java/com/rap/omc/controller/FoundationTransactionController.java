package com.rap.omc.controller;


import com.constants.GlobalCommonConstants;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.omc.controller.model.CParmTranVO;
import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.controller.service.FoundationTransactionService;
import com.rap.omc.core.util.general.FoundationDbProxy;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class FoundationTransactionController extends RestBaseController {
    private final String ERR_MES_FOUNDATION_GET_TRANS_INFO = "foundation.error.transaction.get.general";
    @Autowired
    private FoundationTransactionService foundationTransactionService;
    /**************************************************************************************************/
    @Operation(summary  = "Transaction Log에 대한 List를 조회한다.(Paging)",
            description  = "Sample 제작을 위한 Request를 생성 한다.<br>" +
                    "■CParmTranVO(cParmTranVO):<br>" +
                    "{<br>\"className\":\"SampleRequest\"" +
                    "<br>,\"beforeHours\":3" +
                    "<br>,\"transactionType\":\"Modify*\"" +
                    "<br>,\"globalTransactionId\":\"Global Transaction Id\"" +
                    "<br>,\"obid\":\"obid\"" +
                    "<br>,\"transactionSeq\":0" +
                    "<br>,\"creator\":\"XP3866\"" +
                    "<br>,\"uri\":\"sample\"" +
                    "<br>,\"currentPage\":1" +
                    "<br>,\"rowSize\":30" +
                    "<br>,\"targetRow\":1" +
                    "<br>,\"orderBy\":\"order by transaction_seq desc\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/foundation/transactions/paging",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getTransactionLinkListPaging(@RequestBody CParmTranVO cParmTranVO) {
        try{
            //조회 조건에 맞는 Paging되어진 List를 조회한다.
            List<TransactionLinkVO> transactionLinkVOList = foundationTransactionService.getTransactionLinkListPaging(cParmTranVO);
            //결과를 가지고 리스트와 Paging Entity를 분리하여 Return한다.
            OmfPagingList<TransactionLinkVO> pagingList = (OmfPagingList<TransactionLinkVO>)transactionLinkVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingList.getPagingEntity());
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,pagingList);

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,cParmTranVO);
        }
    }
    @Operation(summary  = "Object Id를 이용한 리스트 조회")
    @RequestMapping(value = "/foundation/transactions/obid/{obid}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getTransactionLinkListForObject(@PathVariable String obid) {
        try{
            List<TransactionLinkVO> transactionLinkVOList = foundationTransactionService.getTransactionLinkListForObject(obid);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,transactionLinkVOList), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,obid);
        }
    }
    @Operation(summary  = "Global TransactionId Id를 이용한 리스트 조회")
    @RequestMapping(value = "/foundation/transactions/transactionid/{globalTransactionId}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getTransactionLinkListForTransactionId(@PathVariable String globalTransactionId) {
        try{
            List<TransactionLinkVO> transactionLinkVOList = foundationTransactionService.getTransactionLinkListForTransactionId(globalTransactionId);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,transactionLinkVOList), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,globalTransactionId);
        }
    }
    @Operation(summary  = "Transaction Sequence를 이용한 리스트 조회")
    @RequestMapping(value = "/foundation/transactions/transactionseq/{transactionSeq}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getRelatedTranLinkListForTranSeq(@PathVariable int transactionSeq) {
        try{
            List<TransactionLinkVO> transactionLinkVOList = foundationTransactionService.getRelatedTranLinkListForTranSeq(transactionSeq);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,transactionLinkVOList), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,transactionSeq);
        }
    }
    @Operation(summary  = "Object에 대해서 일어난 TransactionId 리스트 조회")
    @RequestMapping(value = "/foundation/transactions/ids/{obid}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getGlobalTransactionIdListForObject(@PathVariable String obid) {
        try{
            List<String> transactionLinkVOList = foundationTransactionService.getGlobalTransactionIdListForObject(obid);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,transactionLinkVOList), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,obid);
        }
    }
    @Operation(summary  = "Transaction에 대한 정보 조회")
    @RequestMapping(value = "/foundation/transaction/{transactionSeq}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getTransactionLink(@PathVariable int transactionSeq) {
        try{
            TransactionLinkVO transactionLinkVO = foundationTransactionService.getTransactionLink(transactionSeq);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,transactionLinkVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,transactionSeq);
        }
    }
    @Operation(summary  = "특정 Transaction Sequence에 대한 Rollback을 수행함")
    @RequestMapping(value = "/foundation/transaction/rollbackseq/{transactionSeq}",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> txnRollbackForTransactionSeq(@PathVariable(name = "transactionSeq") int transactionSeq) {
        try{
            //Rollback에 대해서는 Transaction Log를 남기지 않는다.
            FoundationDbProxy.setNoTransactionLog();
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.POST,"/foundation/transaction/rollback/{transactionSeq}");
            restParameterMap.addPathParameter("transactionSeq",transactionSeq);
            foundationTransactionService.txnRollbackForTransactionSeq(transactionSeq,restParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"transactionLinkVO"), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,transactionSeq);
        }
    }
    @Operation(summary  = "Global Transaction ID에 대해서 Rollback을 수행함.")
    @RequestMapping(value = "/foundation/transaction/rollbackid/{globalTransactionId}",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> txnRollbackForTransactionId(@PathVariable(name = "globalTransactionId") String globalTransactionId) {
        try{
            //Rollback에 대해서는 Transaction Log를 남기지 않는다.
            FoundationDbProxy.setNoTransactionLog();
            foundationTransactionService.txnRollbackForTransactionId(globalTransactionId);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"transactionLinkVO"), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MES_FOUNDATION_GET_TRANS_INFO,e,globalTransactionId);
        }
    }
}