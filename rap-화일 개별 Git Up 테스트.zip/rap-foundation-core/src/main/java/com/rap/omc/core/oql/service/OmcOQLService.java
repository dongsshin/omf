/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CommonServiceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.core.oql.service;

import com.rap.omc.dataaccess.paging.model.PagingEntity;
import org.apache.ibatis.session.RowBounds;

import java.util.List;
import java.util.Map;

/**
 * 
 * <pre>
 * Class : OmcOQLService
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public interface OmcOQLService{
    //public List<String> getChildClassList(OmcSQLVariableParameter variableParameter);
    //public List<String> getStringList(OmcSQLVariableParameter variableParameter);
    //public List<OmcOQLTableAndClass> getTableAndClassList(OmcSQLVariableParameter variableParameter);
    //public List<OmcOQLClassAttribute> getClassAttributeList(OmcSQLVariableParameter variableParameter);
    //public List<OmcOQLApiLogVO> getAPILlogByKeyValue(OmcOQLApiLogVO apiLogVO);
    //public OmcOQLApiRelatedLogVO getAPIRelateLogByKeyValue(OmcOQLApiRelatedLogVO apiLogVO);
    //public <T> List<T> getObjects(OmcSQLVariableParameter sqlVariableParameter, boolean isPaging);
    //public <T> List<T> getObjects(OmcSQLVariableParameter sqlVariableParameter, String countSql, String executingSql, boolean isPaging);
    //public <T> List<T> getObjects(OmcSQLVariableParameter sqlVariableParameter, String countSql, String executingSql, boolean isPaging, RowBounds paramRowBounds);
    public <T> List<T> getObjects(Map<String,Object> attributeMap, PagingEntity pagingEntity, String countSql, String executingSql, boolean isPaging, RowBounds paramRowBounds);
    //public List<String> getClassNameList(List<String> obidList);
    //public List<OmcOQLBusinessClass> getBusinessClassList(OmcSQLVariableParameter variableParameter);
    //public List<OmcOQLRelationClass> getRelationClassList(OmcSQLVariableParameter variableParameter);
    //public List<OmcOQLRelationShipInfo> getRelationShipInfoList(OmcSQLVariableParameter variableParameter);
    //public List<OmcOQLRelatedClassInfo> getRelatedInfoList(OmcSQLVariableParameter variableParameter);
}
