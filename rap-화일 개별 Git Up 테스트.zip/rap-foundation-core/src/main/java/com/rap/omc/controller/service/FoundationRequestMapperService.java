package com.rap.omc.controller.service;

import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.schema.object.model.OmcSchemaRequestMapperVO;

import java.util.ArrayList;
import java.util.List;

public interface FoundationRequestMapperService {
    public List<OmcSchemaRequestMapperVO> getRequestMapperListForSource(String serviceName, RestParameterMap restParameterMap);
    public void txnRegisterRequestMappers(List<OmcSchemaRequestMapperVO> list);
    public ArrayList<OmcSchemaRequestMapperVO> getRequestMapperList(String serviceName);
}
