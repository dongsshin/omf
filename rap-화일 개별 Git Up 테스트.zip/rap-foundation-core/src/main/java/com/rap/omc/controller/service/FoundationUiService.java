package com.rap.omc.controller.service;

public interface FoundationUiService {
}
