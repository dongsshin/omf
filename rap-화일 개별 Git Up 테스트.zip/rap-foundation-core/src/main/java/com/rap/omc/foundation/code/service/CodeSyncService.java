/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : FcsService.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 2. 4.  jongjung.kwon   Initial
 * ===========================================
 */
package com.rap.omc.foundation.code.service;

import com.rap.config.datasource.dao.GenericDao;
import com.event.publish.vo.EventCodeVO;

/**
 * <pre>
 * Class : FcsService
 * Description : TODO
 * </pre>
 * 
 * @author jongjung.kwon
 */
public interface CodeSyncService {
    public void txnSynchronizeCode(GenericDao genericDao, EventCodeVO eventCodeVO);
}
