package com.rap.omc.dataaccess.trace;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.rap.omc.core.oql.utility.OmcFoundationConstant;
import com.rap.omc.dataaccess.mybatis.interceptor.OmfTraceContext;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.ParameterMapping;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

@Intercepts({
        @Signature(type = Executor.class, method = "update"  ,args = { MappedStatement.class, Object.class }),
        @Signature(type = Executor.class, method = "query"   ,args = { MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class }),
        @Signature(type = Executor.class, method = "query"   ,args = { MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class, CacheKey.class, BoundSql.class }) })

public class OmfQueryLoggingInterceptor implements Interceptor {
    private static final Logger log = LoggerFactory.getLogger(OmfQueryLoggingInterceptor.class);
    @Autowired
    private ObjectMapper objectMapper;
	@SuppressWarnings("rawtypes")
	@Override
    public Object intercept(Invocation invocation) throws Exception{
	    if(log.isTraceEnabled()){
	        boolean onlyOne = false;
            log.trace("********************************QueryLoggingInterceptor intercepted*******************************");
            Object[] args = invocation.getArgs();
            Object param = args[1];
            MappedStatement mappedStatement = (MappedStatement)args[0];
            BoundSql boundSql = mappedStatement.getBoundSql(param);
            String sql = boundSql.getSql();
            StringBuffer sb = new StringBuffer();
            if (param != null) {
                if (param instanceof Integer || param instanceof Long || param instanceof Float || param instanceof Double) {
                    sb.append(param.toString());
                    onlyOne = true;
                } else if (param instanceof String) {
                    sb.append(param);
                    onlyOne = true;
                } else if (param instanceof Map) {
                    List<ParameterMapping> paramMapping = boundSql.getParameterMappings();
                    String objectIndexName = "";
                    String objectIndexNameSaved = "";
                    StringBuffer adBuf = new StringBuffer();
                    for (int inx = 0; inx < paramMapping.size(); inx++) {
                        objectIndexName = "";
                        ParameterMapping mapping = paramMapping.get(inx);
                        String propValue = mapping.getProperty();
                        if (propValue != null && propValue.startsWith("__frch")) {
                            if (propValue.indexOf(".") >= 0){
                                objectIndexName = propValue.substring(0, propValue.indexOf("."));
                            }else{
                                objectIndexName = propValue;
                            }
                            if (!StrUtil.isEmpty(objectIndexName) && !objectIndexName.equals(objectIndexNameSaved) & !StrUtil.isEmpty(objectIndexNameSaved)) {
                                sb.append(",").append("(").append(adBuf.toString().substring(1)).append(")").append(OmcFoundationConstant.newline);
                                adBuf.setLength(0);
                            }
                            Object value = boundSql.getAdditionalParameter(propValue);
                            if (!NullUtil.isNull(value)) {
                                adBuf.append(",").append(value);
                            } else {
                                adBuf.append(",").append("");
                            }
                        } else {
                            if(!StrUtil.isEmpty(adBuf)){
                                sb.append(",").append("(").append(adBuf.toString().substring(1)).append(")").append(OmcFoundationConstant.newline);
                                adBuf.setLength(0);
                            }
                            Object value = ((Map<?, ?>) param).get(propValue);
                            if (NullUtil.isNull(value)) {
                                sb.append(",").append("");
                            } else if (value instanceof String) {
                                sb.append(",").append(value);
                            } else {
                                sb.append(",").append(value.toString());
                            }
                        }
                        objectIndexNameSaved = objectIndexName;
                    }
                    if(!StrUtil.isEmpty(adBuf)){
                        sb.append(",").append("(").append(adBuf.toString().substring(1)).append(")").append(OmcFoundationConstant.newline);
                        adBuf.setLength(0);
                    }
                }
                else {
                    List<ParameterMapping> paramMapping = boundSql.getParameterMappings();
                    try {
                        Gson gson = new Gson();
                        JsonElement jsonElement = gson.toJsonTree(param);
                        JsonObject jsonObject = jsonElement.getAsJsonObject();
                        for (int inx = 0; inx < paramMapping.size(); inx++) {
                            ParameterMapping mapping = paramMapping.get(inx);
                            String propValue = mapping.getProperty();
                            if (!NullUtil.isNull(jsonObject.get(propValue))) {
                                String paramValue = jsonObject.get(propValue).toString();
                                sb.append(",").append(paramValue.replace("\"", ""));
                            } else {
                                sb.append(",").append("");
                            }
                        }
                    } catch (java.lang.IllegalArgumentException e) {
                        sb.append("JSON Converting Error!! " + e.getMessage());
                    }
                }
            }
            Map<String, String> map = new HashMap<String, String>();
            map.put("sql", sql);
            if(StrUtil.isEmpty(sb)){
                map.put("paramInfo", "[]");
            }else{
                if(onlyOne){
                    map.put("paramInfo", "[" + sb.toString() + "]");
                }else{
                    map.put("paramInfo", "[" + sb.toString().substring(1) + "]");
                }
            }
            OmfTraceContext.local.set(map);
        }
        return invocation.proceed();
    }
    /**
     * MyBatis의 Interceptor 를 implements할 때 override해야 하는 기본 메소드
     * 현재 Interceptor를 MyBatis Plugin으로 등록한다.
     *
     * @param target MyBatis의 Plugin Context
     */
    @Override
    public Object plugin(Object target){
        return Plugin.wrap(target, this);
    }

    /**
     * MyBatis의 Interceptor 를 implements할 때 override해야 하는 기본 메소드
     * Interceptor를 Configuration파일에 설정시 지정 가능한 property값을 처리하는 callback 메소드
     *
     * @param properties Intercepor를 Configuration파일에 설정시 지정 가능한 property값
     */
    @Override
    public void setProperties(Properties properties){
        // no properties required.
    }

}
