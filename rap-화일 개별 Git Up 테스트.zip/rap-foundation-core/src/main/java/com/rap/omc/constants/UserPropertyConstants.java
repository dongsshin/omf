/**
 * ===========================================
 * System Name : LGE PLM Project
 * Program ID : UserPropertyConstants.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2017. 6. 19.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.omc.constants;


/**
 * <pre>
 * Class : UserPropertyConstants
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public class UserPropertyConstants {
    public static final String USER_PROPERTY_TIME_ZONE = "Time Zone";
    public static final String USER_PROPERTY_LOCALE = "Locale";
    public static final String USER_PROPERTY_PRIVATE_FOLDER = "Private Folder";
    public static final String USER_PROPERTY_DEFAULT_PRIVATE_FOLDER = "Default Private Folder";
    public static final String USER_PROPERTY_DEFAULT_PROJECT = "Default Project";

    public static final String USER_PROPERTY_COMPANY = "Company Responsibility";
    public static final String USER_PROPERTY_BUSINESS_UNIT = "Business Unit Responsibility";
    public static final String USER_PROPERTY_DR = "Design Responsibility";
    public static final String USER_PROPERTY_MR = "Manufacturing Responsibility";

    public static final String USER_PROPERTY_USER_OBID = "User OBID";
}
