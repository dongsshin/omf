package com.rap.omc.controller.model;

import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.CPamBaseModel;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;

@Setter
@Getter
public class CParmHeaderVO extends CPamBaseModel {
    private HashMap<String,Object> bizObjMap;
    private CParmWorkflowHeader cParmWorkflowHeader;
}
