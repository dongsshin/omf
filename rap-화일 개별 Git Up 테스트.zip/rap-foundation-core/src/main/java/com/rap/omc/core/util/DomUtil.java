/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : DomUtil.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2020. 08. 01. DongSik.Shin Initial
 * ===========================================
 */
package com.rap.omc.core.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.CPamBaseModel;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.foundation.classes.model.ColumnInfo;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.ClassInfoUtil;
import com.rap.omc.util.foundation.CommonServiceUtil;
import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.io.*;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.*;
// import org.springframework.beans.BeanUtils;


/**
 * <pre>
 * Class : DomUtil
 * Description : TODO
 * </pre>
 * 
 * @author DongSik.Shin
 */

public class DomUtil {
    private static final Logger log = LoggerFactory.getLogger(DomUtil.class);
    public static final Set<String> NOT_UPDATE_ATTRS = OmcSystemConstants.FOUNDATION_ATTRIBUTE_SET;

    private ObjectMapper objectMapper;
    private static DomUtil sInstance;

    private synchronized static DomUtil getInstance(){
        if (sInstance == null) {
            sInstance = new DomUtil();
            sInstance.objectMapper    = (ObjectMapper) SpringFactoryUtil.getBean("objectMapper");
        }
        return sInstance;
    }


    /**
     * Dom이나 VO 클래스를 복제한다.
     * 
     * @param from
     * @return
     */
    public static Object cloneBean(Object from){
        Object to = null;
        try {
            to = BeanUtils.cloneBean(from);
        } catch (IllegalAccessException | InstantiationException | InvocationTargetException | NoSuchMethodException e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.util.domNotCreated",e);
        }

        return to;
    }
    public static <T> T cloneObject(T from){
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(bos);
            out.writeObject(from);
            out.flush();
            out.close();
            ObjectInputStream in = new ObjectInputStream(new ByteArrayInputStream(bos.toByteArray()));
            T to = (T)in.readObject();
            return to;
        }
        catch(Exception e) {
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Copy object Error",e);
        }
    }
    /**
     * VO를 기반으로 Dom Class를 생성한다.
     *
     * @param vo
     * @return
     */
    public static <T extends ObjectRoot> T toDom(ObjectRootVO vo){
        return makeDom(vo);
    }

    /**
     * obid에 해당하는 VO 정보를 DB에서 조회하여, VO를 생성한 뒤 생성된 VO를 기반으로 Dom Class를 생성한다.
     * (outData에 locker, owner 등의 추가 정보를 같이 조회함)
     *
     * @param obid
     * @return
     */
    public static <T extends ObjectRoot> T toDom(String obid){
        return toDom(obid,false);
    }
    
    /**
     * obid에 해당하는 VO 정보를 DB에서 조회하여, VO를 생성한 뒤
     * 생성된 VO를 기반으로 Dom Class를 생성한다.
     *
     * @param obid
     * @param bWithOutData outData에 locker, owner 등의 추가 정보를 같이 조회한다.
     * @return
     */
    public static <T extends ObjectRoot> T toDom(String obid, boolean bWithOutData){
        if (NullUtil.isNone(obid)) { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.warn.obid"); }
        
        ObjectRootVO vo = null;
        if (bWithOutData) {
            vo = CommonServiceUtil.getObjectWithOutData(obid);
        } else {
            vo = CommonServiceUtil.getObject(obid);
        }
        
        if (NullUtil.isNull(vo)) { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.warn.obid"); }

        return makeDom(vo);
    }
    public static <T extends ObjectRootVO> T getObjectVO(String obid){
        return getObjectVO(obid,false);
    }
    public static <T extends ObjectRootVO> T getObjectVO(String obid,boolean withOutData){
        if(withOutData) return CommonServiceUtil.getObjectWithOutData(obid);
        return CommonServiceUtil.getObject(obid);
    }
    @SuppressWarnings("unchecked")
    private static <T extends ObjectRoot> T makeDom(ObjectRootVO vo){
        Class<? extends ObjectRootVO> clazz = vo.getClass();
        String packageName = clazz.getPackage().getName();
        int index = packageName.lastIndexOf('.');
        String domName = packageName.substring(0, index) + ".dom." + clazz.getSimpleName().replace("VO", "");

        Class<T> domClass = null;
        try {
            domClass = (Class<T>)Class.forName(domName);
        } catch (ClassNotFoundException e1) {
            e1.printStackTrace();
        }

        Constructor<T> ctor = null;
        try {
            ctor = domClass.getDeclaredConstructor(clazz);
        } catch (NoSuchMethodException | SecurityException e1) {
            e1.printStackTrace();
        }

        T obj = null;
        try {
            obj = ctor.newInstance(vo);
        } catch (InstantiationException | IllegalAccessException | IllegalArgumentException | InvocationTargetException e1) {
            e1.printStackTrace();
        }

        return obj;
    }
    
    public static Object copy(Object orig) {
        Object obj = null;
        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ObjectOutputStream out = new ObjectOutputStream(bos);
            out.writeObject(orig);
            out.flush();
            out.close();
            ObjectInputStream in = new ObjectInputStream(
                new ByteArrayInputStream(bos.toByteArray()));
            obj = in.readObject();
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        catch(ClassNotFoundException cnfe) {
            cnfe.printStackTrace();
        }
        return obj;
    }
    public static void copyPagingEntity(PagingEntity from, PagingEntity to){
        to.setCurrentPage(from.getCurrentPage());
        to.setOrderBy(from.getOrderBy());
        to.setRowSize(from.getRowSize());
        to.setTotalCount(from.getTotalCount());
        if(from.getTargetRow() == 0 ){
            to.setTargetRow(1);
            from.setTargetRow(1);
        }else{
            to.setTargetRow(from.getTargetRow());
        }
    }
    public static <T> List<T> convertMap2VO(List<? extends Map<String,Object>> voMapList, Class<T> cls) {
        List<T> list = new ArrayList<>();
        for(Map<String,Object> map: voMapList){
            list.add(convertMap2VO(map,cls));
        }
        return list;
    }
    public static <T> T convertMap2VO(Map<String,Object> voMap, Class<T> cls) {
        try {
            Object objVO = getInstance().objectMapper.convertValue(voMap,cls);
            return (T) objVO;
        } catch (Exception e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
        }
    }
    public static <T extends ObjectRootVO> T makeVO(String className, String voJsonStr) {
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
        ObjectRootVO objVO = null;
        try {
            Class<?> cls = Class.forName(classInfo.getJavaPackage() + "." + className + "VO");
            objVO = (ObjectRootVO)getInstance().objectMapper.readValue(voJsonStr, cls);
            return (T) objVO;
        } catch (Exception e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
        }
    }
    public static <T> T makeObject(String voJsonStr,Class<T> valueType) {
        try{
            return getInstance().objectMapper.readValue(voJsonStr, valueType);
        } catch (Exception e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
        }
    }
    public static <T extends ObjectRootVO> T makeVO(String voJsonStr) {
        JsonNode node = null;
        ObjectRootVO objVO = null;
        try {
            node = getInstance().objectMapper.readTree(voJsonStr);
            if(NullUtil.isNull(node)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Invalid Json Data");
            String className = node.get("className").asText();
            if(StrUtil.isEmpty(className)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Class Name(className) attribute Not found!");
            ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
            Class<?> cls = Class.forName(classInfo.getJavaPackage() + "." + className + "VO");
            objVO = (ObjectRootVO)getInstance().objectMapper.convertValue(node, cls);
            return (T) objVO;
        } catch (JsonProcessingException | ClassNotFoundException e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
        }
        /*
        ObjectMapper objectMapper = new ObjectMapper();
        String className = "";
        try{
            ObjectRootVO vo = (ObjectRootVO)objectMapper.readValue(voJsonStr, ObjectRootVO.class);
            className = vo.getClassName();
        } catch (Exception e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
        }
        return makeVO(className,voJsonStr);
        */
    }

    public static <T extends ObjectRootVO> T makeVO(HashMap<String,Object> voMap) {
        return map2ObjctVO(voMap);
    }
    public static <T extends ObjectRootVO> T makeVO(String className, HashMap<String,Object> voMap) {
        voMap.put("className",className);
        return map2ObjctVO(voMap);
    }
    public static <T extends ObjectRootVO> T map2ObjctVO(HashMap<String,Object> voMap) {
        String className = (String) voMap.get("className");
        if(StrUtil.isEmpty(className)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Class Name is empty");
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
        if(NullUtil.isNull(classInfo)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Class(" + className + ") is not Found.");
        Set<String> attributeSet = classInfo.getAttributeSet(true);
        ObjectRootVO objVO = null;
        try {
            Class<? extends ObjectRootVO> cls = (Class<? extends ObjectRootVO>) Class.forName(classInfo.getJavaPackage() + "." + className + "VO");
            ObjectRootVO objectRootVO = cls.getDeclaredConstructor().newInstance();
            for(String attribute : voMap.keySet()){
                if(attributeSet.contains(attribute)) {
                    Object value = voMap.get(attribute);
                    if(!NullUtil.isNull(value)) objectRootVO.setAttributeValue(attribute,voMap.get(attribute));
                }
            }
            return (T)objectRootVO;
        } catch (Exception e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
        }
    }
    public static <T extends CPamBaseModel> T copyAttribute(CPamBaseModel fromObj,CPamBaseModel toObj){
        return copyAttribute(fromObj,toObj,null);
    }
    public static <T extends CPamBaseModel> T copyAttribute(CPamBaseModel fromObj,CPamBaseModel toObj,Set<String> updateAttrSet){
        return copyAttributeSub(fromObj,toObj,updateAttrSet);
    }
    public static <T> T copyAttribute(CPamBaseModel fromObj,ObjectRootVO toObj,Set<String> updateAttrSet){
        return copyAttributeSub(fromObj,toObj,updateAttrSet);
    }
    public static <T> T copyAttributeAll(CPamBaseModel fromObj,ObjectRootVO toObj){
        return copyAttributeSub(fromObj,toObj,null);
    }
    public static ObjectRootVO copyAttribute(ObjectRootVO fromObj,ObjectRootVO toObj,Set<String> updateAttrSet){
        return copyAttributeSub(fromObj,toObj,updateAttrSet,false,false);
    }
    public static ObjectRootVO copyAttributeAll(ObjectRootVO fromObj,ObjectRootVO toObj){
        return copyAttributeSub(fromObj,toObj,null,true,true);
    }
    private static ObjectRootVO copyAttributeSub(ObjectRootVO fromObj,ObjectRootVO toObj,Set<String> updateAttrSet,boolean includeFoundationAttr, boolean kindDiffAllow){
        Set<String> toObjAttrSet = updateAttrSet;

        if(StrUtil.isEmpty(fromObj.getClassName())) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"From Object Class Name is empty");
        if(StrUtil.isEmpty(toObj.getClassName())) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"To Object Class Name is empty");
        if(!kindDiffAllow && !fromObj.getClassName().equals(toObj.getClassName())) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Object kind is different.");
        ClassInfo fromClassInfo     = ClassInfoUtil.getClassInfo(fromObj.getClassName());
        ClassInfo toClassInfo     = ClassInfoUtil.getClassInfo(toObj.getClassName());

        if(NullUtil.isNull(fromClassInfo)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"To Object Class Name is empty");
        if(NullUtil.isNone(updateAttrSet)) updateAttrSet = fromClassInfo.getAttributeSet(includeFoundationAttr);
        if(NullUtil.isNone(toObjAttrSet))  toObjAttrSet = toClassInfo.getAttributeSet(includeFoundationAttr);

        int executedCnt = 0;
        for(ColumnInfo col : fromClassInfo.getColumnList()){
            if(executedCnt >= updateAttrSet.size()) break;
            if(!NOT_UPDATE_ATTRS.contains(col.getAttributeName()) && updateAttrSet.contains(col.getAttributeName()) && toObjAttrSet.contains(col.getAttributeName())){
                String setMethodString = "set" + col.getAttributeName().substring(0, 1).toUpperCase() + col.getAttributeName().substring(1);
                String getMethodString = "get" + col.getAttributeName().substring(0, 1).toUpperCase() + col.getAttributeName().substring(1);
                try{
                    Method getMethod = fromObj.getClass().getMethod(getMethodString);
                    if(!NullUtil.isNull(getMethod)){
                        Method setMethod = toObj.getClass().getMethod(setMethodString,getMethod.getReturnType());
                        if(!NullUtil.isNull(setMethod)){
                            setMethod.invoke(toObj,getMethod.invoke(fromObj));
                            executedCnt++;
                        }
                    }
                }catch(Exception e){
                    throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
                }
            }
        }
        return toObj;
    }
    public static List<Field> getAllFields(Class clazz) {
        if (clazz == null) return Collections.emptyList();
        List<Field> result = new ArrayList<>(getAllFields(clazz.getSuperclass()));
        /*
        List<Field> filteredFields = Arrays.stream(clazz.getDeclaredFields())
                .filter(f -> Modifier.isPublic(f.getModifiers()) || Modifier.isProtected(f.getModifiers()))
                .collect(Collectors.toList());
         */
        Field[] fields = clazz.getDeclaredFields();
        for(int i = 0; i < fields.length; i++) result.add(fields[i]);
        return result;
    }
    private static <T extends CPamBaseModel> T copyAttributeSub(CPamBaseModel fromObj,CPamBaseModel toObj,Set<String> updateAttrSet){
        boolean all = false;
        if(NullUtil.isNone(updateAttrSet)) all = true;
        List<Field> allFields = getAllFields(fromObj.getClass());
        for(int i = 0; i < allFields.size(); i++){
            String attribute = allFields.get(i).getName();
            if(all || (NullUtil.isNone(updateAttrSet) || updateAttrSet.contains(attribute))){
                String setMethodString = "set" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
                String getMethodString = "get" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
                try{
                    Method getMethod = null;
                    try{
                        getMethod = fromObj.getClass().getMethod(getMethodString);
                    }catch(NoSuchMethodException e){
                        ;
                    }catch (SecurityException e){
                        ;
                    }catch (Exception e){
                        throw e;
                    }
                    if(!NullUtil.isNull(getMethod)){
                        Method setMethod = null;
                        try {
                            setMethod = toObj.getClass().getMethod(setMethodString, getMethod.getReturnType());
                        }catch(NoSuchMethodException e){
                            ;
                        }catch (SecurityException e){
                            ;
                        }catch (Exception e){
                            throw e;
                        }
                        if(!NullUtil.isNull(setMethod)){
                            setMethod.invoke(toObj,getMethod.invoke(fromObj));
                        }
                    }
                }catch(Exception e){
                    throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
                }
            }
        }
        return (T)toObj;
    }
    private static <T> T copyAttributeSub(CPamBaseModel fromObj,ObjectRootVO toObj,Set<String> updateAttrSet){
        List<Field> fields = getAllFields(fromObj.getClass());
        Method[] methods = fromObj.getClass().getMethods();
        for(int i = 0; i < fields.size(); i++){
            String attribute = fields.get(i).getName();
            if(NullUtil.isNone(updateAttrSet) || updateAttrSet.contains(attribute)){
                String getMethodString = "get" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
                String setMethodString = "set" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
                if(fields.get(i).getGenericType().toString().endsWith("boolean")) {
                    if(attribute.startsWith("is") || attribute.startsWith("has") || attribute.startsWith("can")){
                        getMethodString = attribute;

                    }else{
                        getMethodString = "is" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
                    }
                }
                try{
                    Method getMethod = fromObj.getClass().getMethod(getMethodString);
                    if(!NullUtil.isNull(getMethod)){
                        Method setMethod = toObj.getClass().getMethod(setMethodString,getMethod.getReturnType());
                        if(!NullUtil.isNull(setMethod)){
                            setMethod.invoke(toObj,getMethod.invoke(fromObj));
                        }
                    }
                }catch(Exception e){
                    //e.printStackTrace();
                    log.info("Attribute({}) copy fail(skipped)",attribute);
                    //throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
                }
            }
        }
        return (T)toObj;
    }
    public static <T> T makeVO(String className, LinkedHashMap<String,Object> map){
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
        String classPath = classInfo.getJavaPackage() + "." + className + "VO";
        try {
            Class<T> voClass = (Class<T>)Class.forName(classPath);
            Object obj = getInstance().objectMapper.convertValue(map,voClass);
            return (T)obj;
        } catch (ClassNotFoundException e) {
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "ERR_MSG_OBJECT_FIND",e);
        }
    }
    public static <T> List<T> makeVO(List<LinkedHashMap<String,Object>> mapList){
        Map<String,Object> classMap = new HashMap<String,Object>();
        List<T> list = new ArrayList<>();
        for(LinkedHashMap<String,Object> map : mapList){
            list.add(makeVO((String)map.get("className"),map));
        }
        return list;
    }
    public static <T> T copyAttributesWithExclude(Object fromObj, Object toObj, Set<String> excludeAttrSet){
        return copyAttributeSub(fromObj,toObj,null,excludeAttrSet);
    }
    public static <T> T copyAttributesWithInclude(Object fromObj, Object toObj, Set<String> updateAttrSet){
        return copyAttributeSub(fromObj,toObj,updateAttrSet,null);
    }
    private static <T> T copyAttributeSub(Object fromObj, Object toObj, Set<String> updateAttrSet, Set<String> excludeAttrSet){
        boolean all = false;
        if(NullUtil.isNull(updateAttrSet)) updateAttrSet = new HashSet<String>();
        if(NullUtil.isNull(excludeAttrSet)) excludeAttrSet = new HashSet<String>();
        if(NullUtil.isNone(updateAttrSet)) all = true;
        List<Field> allFields = getAllFields(fromObj.getClass());
        for(int i = 0; i < allFields.size(); i++){
            String attribute = allFields.get(i).getName();
            if((all || updateAttrSet.contains(attribute)) && !excludeAttrSet.contains(attribute)){
                String setMethodString = "set" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
                String getMethodString = "get" + attribute.substring(0, 1).toUpperCase() + attribute.substring(1);
                try{
                    Method getMethod = null;
                    try{
                        getMethod = fromObj.getClass().getMethod(getMethodString);
                    }catch(NoSuchMethodException e){
                        ;
                    }catch (SecurityException e){
                        ;
                    }catch (Exception e){
                        throw e;
                    }
                    if(!NullUtil.isNull(getMethod)){
                        Method setMethod = null;
                        try {
                            setMethod = toObj.getClass().getMethod(setMethodString, getMethod.getReturnType());
                        }catch(NoSuchMethodException e){
                            ;
                        }catch (SecurityException e){
                            ;
                        }catch (Exception e){
                            throw e;
                        }
                        if(!NullUtil.isNull(setMethod)){
                            setMethod.invoke(toObj,getMethod.invoke(fromObj));
                        }
                    }
                }catch(Exception e){
                    throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
                }
            }
        }
        return (T)toObj;
    }


}
