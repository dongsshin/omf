package com.rap.omc.controller.model;

import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;

import java.util.Date;

public class CParmTranVO extends PagingEntity{
    private TransactionLinkVO transactionLinkVO = new TransactionLinkVO();
    private Double beforeHours = 4.0;

    public Double getBeforeHours() {
        return beforeHours;
    }

    public void setBeforeHours(Double beforeHours) {
        this.beforeHours = beforeHours;
    }

    public Integer getTransactionSeq(){
        return this.transactionLinkVO.getTransactionSeq();
    }
    public void setTransactionSeq(Integer transactionSeq){
        this.transactionLinkVO.setTransactionSeq(transactionSeq);
    }
    public String getGlobalTransactionId(){
        return this.transactionLinkVO.getGlobalTransactionId();
    }
    public void setGlobalTransactionId(String globalTransactionId){
        this.transactionLinkVO.setGlobalTransactionId(globalTransactionId);
    }
    public String getTransactionType(){
        return this.transactionLinkVO.getTransactionType();
    }
    public void setTransactionType(String transactionType){
        this.transactionLinkVO.setTransactionType(transactionType);
    }
    public String getUri(){
        return this.transactionLinkVO.getUri();
    }
    public void setUri(String uri){
        this.transactionLinkVO.setUri(uri);
    }
    public String getObid(){
        return this.transactionLinkVO.getObid();
    }
    public void setObid(String obid){
        this.transactionLinkVO.setObid(obid);
    }
    public String getClassName(){
        return this.transactionLinkVO.getClassName();
    }
    public void setClassName(String className){
        this.transactionLinkVO.setClassName(className);
    }
    public String getCreator(){
        return this.transactionLinkVO.getCreator();
    }
    public void setCreator(String creator){
        this.transactionLinkVO.setCreator(creator);
    }
    public Date getCreated(){
        return this.transactionLinkVO.getCreated();
    }
    public void setCreated(Date created){
        this.transactionLinkVO.setCreated(created);
    }
    public String getJsonBefore(){
        return this.transactionLinkVO.getJsonBefore();
    }
    public void setJsonBefore(String jsonBefore){
        this.transactionLinkVO.setJsonBefore(jsonBefore);
    }
    public String getJsonAfter(){
        return this.transactionLinkVO.getJsonAfter();
    }
    public void setJsonAfter(String jsonAfter){
        this.transactionLinkVO.setJsonAfter(jsonAfter);
    }
}