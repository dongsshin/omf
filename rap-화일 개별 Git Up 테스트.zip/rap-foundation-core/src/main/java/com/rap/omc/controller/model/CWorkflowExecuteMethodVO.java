package com.rap.omc.controller.model;

import com.rap.api.object.foundation.model.CPamBaseModel;
import lombok.Getter;
import lombok.Setter;

import java.util.HashMap;
import java.util.Map;

@Setter
@Getter
public class CWorkflowExecuteMethodVO extends CPamBaseModel {
    private String obid;
    private Map<String,Object> parmMap = new HashMap<String,Object>();
    private String methodName;
    public void addParameter(String attribute, Object value){
        parmMap.put(attribute,value);
    }
}
