package com.rap.omc.controller.service;

import com.rap.omc.controller.model.CSysServiceVO;
import com.rap.omc.schema.object.model.OmcSchemaServiceVO;

import java.util.ArrayList;

public interface FoundationSchemaService {
    public void txnRegisterService(CSysServiceVO sysServiceVO);
    public void txnModifyService(CSysServiceVO sysServiceVO);
    public void txnInactivateService(String serviceName);
    public void txnActivateService(String serviceName);
    public void txnDeleteService(String serviceName);
    public OmcSchemaServiceVO getService(String serviceName);
    public ArrayList<OmcSchemaServiceVO> getServiceList(CSysServiceVO sysServiceVO);

}
