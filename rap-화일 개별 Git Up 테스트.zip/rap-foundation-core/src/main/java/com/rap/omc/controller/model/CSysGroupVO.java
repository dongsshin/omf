package com.rap.omc.controller.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CSysGroupVO {
    private String groupName;
    private String groupDescription;
}
