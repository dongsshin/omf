package com.rap.omc.controller;

import com.event.publish.vo.EventUserVO;
import com.rap.config.datasource.dao.GenericDao;
import com.rap.config.web.security.OmfAuthenticationToken;
import com.rap.config.web.security.OmfAuthenticationVO;
import com.rap.config.web.security.TokenUtils;
import com.rap.omc.controller.model.CSysChangePasswordVO;
import com.rap.omc.controller.model.CSysUserVO;
import com.rap.omc.controller.model.CUserPropertyVO;
import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.core.util.omc.CacheUtil;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.foundation.user.model.CommonUserSearchVO;
import com.rap.omc.foundation.user.model.OmfSecurityMember;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.foundation.user.service.FoundationUserDetailsService;
import com.rap.omc.foundation.user.service.FoundationUserService;
import com.rap.omc.framework.annotation.OmfAuthority;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.exception.model.OmfNotFoundException;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.schema.object.model.OmcSchemaUserVO;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.util.StrUtil;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class FoundationUserController extends RestBaseController {
    @Autowired
    private FoundationUserDetailsService foundationUserDetailsService;
    @Autowired
    private FoundationUserService foundationUserService;
    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    UserSession userSession;

    private final String ERR_MSG_FOUNDATION_TOKEN = "foundation.error.token.general";
    private final String ERR_MSG_FOUNDATION_USER_CREATE = "foundation.error.user.create.general";
    private final String ERR_MSG_FOUNDATION_USER_GET = "foundation.error.user.get.general";
    private final String ERR_MSG_FOUNDATION_USER_MODIFY = "foundation.error.user.modify.general";
    private final String ERR_MSG_FOUNDATION_USER_INACTIVE = "foundation.error.user.inactive.general";
    private final String ERR_MSG_FOUNDATION_USER_LIST = "foundation.error.user.list.general";
    private final String ERR_MSG_FOUNDATION_NOT_FOUND = "foundation.error.object.notfound";
    private final String ERR_MSG_FOUNDATION_ALREADY_EXIST = "foundation.error.object.alreadyexists";

    @Operation(summary  = "Token 생성",
            description  = "사용자에 대한 Token을 생성한다.<br>" +
                    "■authenticationRequest:<br>" +
                    "{<br>" +
                    "\"expiredDaysAfter\":100" +
                    ",<br>\"username\":\"UserID\"" +
                    ",<br>\"password\":\"password\"" +
                    "<br>}"
    )
    @Parameters({
        @Parameter(name = "authenticationRequest",
                   description = "authenticationRequest Desc",
                   example = "AuthenticationVO authenticationRequest:{" +
                "\"expiredDaysAfter\":100" +
                ",\"username\":\"UserID\"" +
                ",\"password\":\"password\"" +
                "}")
    })
    @OmfAuthority(target = true,checkItem = "foundation.token.check.no")
    @RequestMapping(value = "/foundation/token",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getAPIToken(@RequestBody OmfAuthenticationVO authenticationRequest){
        try{
            //User정보가 Cache되어져 있을 수 있으므로 해당 User에 대한 Cache를 Clear한다.
            FoundationUserUtil.evictCacheForUser(authenticationRequest.getUsername());
            UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword());
            Authentication authentication = authenticationManager.authenticate(token);
            OmfSecurityMember omfSecurityMember = (OmfSecurityMember)authentication.getPrincipal();
            OmfAuthenticationToken authToken = new OmfAuthenticationToken(omfSecurityMember.getUsername(), omfSecurityMember.getAuthorities());
            String tokenStr = TokenUtils.generateJwtToken(authToken,authenticationRequest.getExpiredDaysAfter());
            Map<String,String> map = new HashMap<String,String>();
            map.put("header",TokenUtils.HEADER_STRING);
            map.put("token",TokenUtils.TOKEN_PREFIX + tokenStr);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_FOUNDATION_TOKEN,e);
        }
    }
    /**************************************★★★ Foundation User ★★★ **********************************************/

    @ApiOperation(
            value = "Foundation User를 Creation하는 API",
            notes = "■Parameter"
                    +"<br>⊙ sysUserVO : Foundation user Value Object"
                    +"<br>■Return     : 생성되어진  Foundation user"
                    +"<br>■Example : objVO: NA"
    )
    @ApiImplicitParams({
            @ApiImplicitParam(name = "cSysUserVO", value = "Foundation user", required = true, dataType = "CSysUserVO")
    })
    @OmfAuthority(target = true,checkItem = "test.ddkdkd.ddd")
    @RequestMapping(value = "/foundation/user",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createUser(@RequestBody CSysUserVO cSysUserVO){
        try{
            SysUserVO sysUserVO = new SysUserVO(cSysUserVO);
            foundationUserService.txnCreateUser(sysUserVO);
            SysUserVO dbUserVo = foundationUserService.getUserInfo(sysUserVO.getUserId());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,dbUserVo), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_CREATE,e);
        }
    }

    @RequestMapping(value = "/foundation/user/{userId}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getUserInfo(@PathVariable String userId){
        try{
            SysUserVO sysUserVO = foundationUserService.getUserInfo(userId);
            if(NullUtil.isNull(sysUserVO)) throw new OmfNotFoundException(ERR_MSG_FOUNDATION_NOT_FOUND,new Object[]{userId});
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,sysUserVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_GET,e);
        }
    }
    @RequestMapping(value = "/foundation/user",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyUser(@RequestBody SysUserVO sysUserVO){
        try{
            SysUserVO dbUserVo = foundationUserService.getUserInfo(sysUserVO.getUserId());
            if(NullUtil.isNull(dbUserVo)) throw new OmfNotFoundException(ERR_MSG_FOUNDATION_NOT_FOUND,new Object[]{sysUserVO.getUserId()});
            if(!StrUtil.defaultIfEmpty(sysUserVO.getSite(),"").equals(StrUtil.defaultIfEmpty(dbUserVo.getSite(),""))){
                foundationUserService.txnChangeSite(sysUserVO.getUserId(),sysUserVO.getSite());
            }
            if(!StrUtil.defaultIfEmpty(sysUserVO.getDescriptions(),"").equals(StrUtil.defaultIfEmpty(dbUserVo.getDescriptions(),""))){
                foundationUserService.txnSetUserDescription(sysUserVO.getUserId(),sysUserVO.getDescriptions());
            }
            dbUserVo = foundationUserService.getUserInfo(sysUserVO.getUserId());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,dbUserVo), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_MODIFY,e);
        }
    }
    @RequestMapping(value = "/foundation/user/password",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> changePassword(@RequestBody CSysChangePasswordVO cSysChangePasswordVO){
        try{
            foundationUserService.txnChangePassword(cSysChangePasswordVO.getUserId(), cSysChangePasswordVO.getNewPassword());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_CREATE,e);
        }
    }
    @RequestMapping(value = "/foundation/user",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> inActivate(@RequestBody String userId){
        try{
            foundationUserService.txnInActivate(userId);
            SysUserVO sysUserVO = foundationUserService.getUserInfo(userId);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,sysUserVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_INACTIVE,e);
        }
    }
    @RequestMapping(value = "/foundation/commonusers",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCommonUserList(@RequestBody CommonUserSearchVO searchVO){
        try{
            List<OmcSchemaUserVO> userList = foundationUserService.getCommonUserList(searchVO);
            List<String> list = new ArrayList<String>();
            for(OmcSchemaUserVO vo : userList) list.add(vo.getNames());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
    @RequestMapping(value = "/foundation/users",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getUserList(@RequestParam(name = "userNamePattern",required = false) String userNamePattern){
        try{
            CommonUserSearchVO searchVO = new CommonUserSearchVO();
            searchVO.setNames(userNamePattern);
            searchVO.setUserInclude(true);
            List<OmcSchemaUserVO> userList = foundationUserService.getCommonUserList(searchVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,userList), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
    @RequestMapping(value = "/foundation/user/property",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> setProperty(@RequestBody CUserPropertyVO cUserPropertyVO){
        try{
            foundationUserService.txnSetPropertyValueList(userSession.getUserId(),cUserPropertyVO);
            Map<String,String> map = FoundationUserUtil.getPropertyList(userSession.getUserId());
            //Ehcache에 있는 사용자 정보를 Clear한다.
            CacheUtil.evictCache("sysUserInfoCache",userSession.getUserId());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_CREATE,e);
        }
    }
    @RequestMapping(value = "/foundation/users/synch/{databaseBeanName}",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> synchronizeUsers(@PathVariable("databaseBeanName") String databaseBeanName){
        try{
            FoundationUserUtil.synchronizeUser(databaseBeanName);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_CREATE,e);
        }
    }
    @RequestMapping(value = "/foundation/user/eventsynch",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> synchronizeUsers(@RequestBody EventUserVO eventUserVO){
        try{
            String databaseBeanName = PropertiesUtil.getString("rap.module.dao");
            GenericDao genericDao = (GenericDao) SpringFactoryUtil.getBean(databaseBeanName);
            foundationUserService.synchronizeUser(genericDao,eventUserVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_CREATE,e);
        }
    }
}