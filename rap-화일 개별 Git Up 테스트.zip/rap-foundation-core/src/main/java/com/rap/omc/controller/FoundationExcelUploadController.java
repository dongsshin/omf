package com.rap.omc.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.rap.omc.controller.model.ExcelFormatVO;
import com.rap.omc.controller.service.FoundationExcelUploadService;
import com.rap.omc.foundation.excel.ExcelUploadGeneric;
import com.rap.omc.framework.annotation.OmfAuthority;
import com.rap.omc.framework.annotation.OMFCrud;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import io.swagger.annotations.Api;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Constructor;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;


@RestController

@Api(value="Schema Excel API")
public class FoundationExcelUploadController extends RestBaseController {
	@Autowired
	private FoundationExcelUploadService foundationExcelUploadService;
	@Operation(summary  = "Excel Upload",
			   description  = "<br>Excel 자료를 HashMap<String, List<Map<String,Object>>>형식으로 Convert 해준다."
					   + "<br>Sheet별 Start Row와 Valid한 Row인지 Check하기 위한 Column 위치를 넘겨주면 해당 Excel자료를 Converting 해준다.."
					   + "<br>com.rap.omc.foundation.excel.ExcelUploadTest을 Copy 참조하여 개발하면 됨."
					   + "<br>■excelFormatJson:<br>"
					   + "{"
			           + "<br>\"Sheet1\":{"
					   + "<br>\"endCheckColumn\":2,"
					   + "<br>\"startRow\":3"
					   + "<br>},"
					   + "<br>\"Sheet2\":{"
					   + "<br>\"endCheckColumn\":2,"
					   + "<br>\"startRow\":1"
					   + "<br>}<br><br>"
					   + "<br>■program: com.rap.omc.foundation.excel.ExcelUploadTest"
			           + "<br>■excelFile: Upload Excel File"
			)
	@Parameters({
			@Parameter(name = "excelFormatJson",
					description = "Upload File Format 정의, Sheet당 정의함(Start Row: Data Start Row로서 이전 Row가 Header Row로 인식함, "
					+ "End Check Column: 데이터의 End를 Check하는 Column으로서 Empty이면 데이터의 End로 인식함. )",
					example = "String masterCode:"
					+ "<br>\"Sheet1\":{"
							+ "<br>\"endCheckColumn\":2,"
							+ "<br>\"startRow\":3"
							+ "<br>},"
							+ "<br>\"Sheet2\":{"
							+ "<br>\"endCheckColumn\":2,"
							+ "<br>\"startRow\":1"
							+ "<br>}"),
			@Parameter(name = "program",
					description = "실제 수행할 프로그램",
					example = "String masterCode:com.rap.omc.foundation.excel.ExcelUploadTest"),
			@Parameter(name = "excelFile",
					description = "Upload 할 Excel화일",
					example = "MultipartFile excelFile :N/A")
	})
	@OmfAuthority(
			target = false,
			checkItem = "common.code.management",
			crudTypes = {OMFCrud.KEY.Create,OMFCrud.KEY.Read,OMFCrud.KEY.Modify,OMFCrud.KEY.Delete},
			users = {"XP3866"},
			roles = {"System Administration Role"},
			groups = {"Administration Group"}
	)
	@RequestMapping(value="/foundation/excel/upload",consumes = { "multipart/form-data" },method = RequestMethod.POST,produces = "application/json; charset=utf-8")
	public ResponseEntity<?> loadFoundationExcelUpload(@RequestParam(name = "excelFormatJson",required = true) String excelFormatJson,
													   @RequestParam(name = "program"        ,required = true) String program,
			                                           @RequestPart(value = "excelFile"      ,required = false) MultipartFile excelFile){
		try{
			JsonNode jsonNode = objectMapper.readTree(excelFormatJson);
			Iterator<String> iterator = jsonNode.fieldNames();
			Map<String, ExcelFormatVO> excelFormat = new HashMap<String, ExcelFormatVO>();
			while (iterator.hasNext()) {
				String nodeName = iterator.next();
				ExcelFormatVO excelFormatVO = objectMapper.convertValue(jsonNode.get(nodeName), ExcelFormatVO.class);
				excelFormat.put(nodeName,excelFormatVO);
			}
			HashMap<String, List<Map<String,Object>>> excelData = foundationExcelUploadService.convertExcelToMapLList(storeFile(excelFile),excelFormat);
			Constructor constructor = Class.forName(program).getConstructor(HashMap.class);
			ExcelUploadGeneric excelUploadGeneric = (ExcelUploadGeneric)constructor.newInstance(excelData);
			excelUploadGeneric.executeProcess();
			return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,excelData), StatusConstants.OK);
		}catch (Exception e){
			throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"ERR_MSG_EXCEL_UPLOAD",e);
		}
	}
	private File storeFile(MultipartFile file) throws IOException {
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		String str = "C:/root/uploaded";
		File destinationFile = new File(str + File.separator + fileName);
		file.transferTo(destinationFile);
		return destinationFile;
	}
}
