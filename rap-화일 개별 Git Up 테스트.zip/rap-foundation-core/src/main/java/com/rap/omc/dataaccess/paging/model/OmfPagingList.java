package com.rap.omc.dataaccess.paging.model;

/**
 * ===========================================
 * System Name : Foundation
 * Program ID : OmfPagingList.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2020. 09. 17. DongSik.Shin Initial
 * ===========================================
 */
import java.util.ArrayList;

/**
 * <pre>
 * Class : OmfPagingList
 * Description : TODO
 * </pre>
 *
 * @author DongSik.Shin
 */
@SuppressWarnings("serial")
public class OmfPagingList<E> extends ArrayList<E> {

    private PagingEntity pagingEntity = new PagingEntity();

    public PagingEntity getPagingEntity() {
        return pagingEntity;
    }

    public void setPagingEntity(PagingEntity pagingEntity) {
        this.pagingEntity = pagingEntity;
    }
    public String getOrderBy() {
        return pagingEntity.getOrderBy();
    }

    public void setOrderBy(String orderBy) {
        this.pagingEntity.setOrderBy(orderBy);
    }

    /**
     *
     *
     * @return the totalCount
     */
    public int getTotalCount(){
        return this.pagingEntity.getTotalCount();
    }

    /**
     *
     *
     * @param totalCount the totalCount to set
     */
    public void setTotalCount(int totalCount){
        this.pagingEntity.setTotalCount(totalCount);
    }

    /**
     *
     *
     * @return the targetRow
     */
    public int getTargetRow(){
        return this.pagingEntity.getTargetRow();
    }

    /**
     *
     *
     * @param targetRow the targetRow to set
     */
    public void setTargetRow(int targetRow){
        this.pagingEntity.setTargetRow(targetRow);
    }

    /**
     *
     *
     * @return the rowSize
     */
    public int getRowSize(){
        return this.pagingEntity.getRowSize();
    }

    /**
     *
     *
     * @param rowSize the rowSize to set
     */
    public void setRowSize(int rowSize){
        this.pagingEntity.setRowSize(rowSize);
    }

    /**
     *
     *
     * @return the currentPage
     */
    public int getCurrentPage(){
        return this.pagingEntity.getCurrentPage();
    }

    /**
     *
     *
     * @param currentPage the currentPage to set
     */
    public void setCurrentPage(int currentPage){
        this.pagingEntity.setCurrentPage(currentPage);
    }

    public void setCurrentPage(int targetRow, int rowSize){
        this.pagingEntity.setCurrentPage((int)Math.ceil((float)targetRow / rowSize));
    }
}
