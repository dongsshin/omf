package com.rap.omc.controller.service;

import com.rap.api.object.foundation.model.*;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.omc.controller.model.*;
import com.rap.omc.foundation.lifecycle.model.StateInfo;

import java.util.HashMap;
import java.util.List;

public interface FoundationObjectApiService {
    public <T extends ObjectRootVO> T txnCreateObject(String className, HashMap<String, Object> jsonVOMap, RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> List<T> txnCreateObjects(List<HashMap<String, Object>> mapList, RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> T txnModifyObject(String className, HashMap<String,Object> voJsonStr, String updateAttrList, RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> List<T> txnModifyObjects(List<HashMap<String, Object>> mapList, String updateAttrList, RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> T txnDeleteObject(String obid, RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> List<T> txnDeleteObjects(List<String> obidList,RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> T getObject(String obid, RestParameterMap restParameterMap);
    public StateInfo getTargetState(String obid, String direction, String branchTo,RestParameterMap restParameterMap);
    public void promote(String obid, RestParameterMap restParameterMap);
    public <T extends BusinessObjectRootVO> T txnExecuteMethod(CWorkflowExecuteMethodVO executeMethodVO, RestParameterMap restParameterMap);
    public <T extends BusinessObjectVO> T findBusinessObject(String className, String name, String revision,RestParameterMap restParameterMap);
    public <T extends BusinessObjectVO> T findObject(String className, String name, String latestOrFirst,RestParameterMap restParameterMap);
    public <T extends BusinessObjectMasterVO> T findBusinessObjectMaster(String className, String name,RestParameterMap restParameterMap);
    public <T extends BusinessObjectRootVO> List<T> findObjects(String className, String namePattern, RestParameterMap restParameterMap);
    public <T extends BusinessRelationObjectVO> List<T> getRelationObjects(String obid, String relationClassName, String fromOrTo, String targetFilter, RestParameterMap restParameterMap);
    public OmfPagingReturnVO finddObjectsPaging(String className, String namePattern, String createdFrom, String createdTo, String modifiedFrom, String modifiedTo, String states,
                                                int targetRow, int rowSize, int currentPage, String sortByPattern, RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> List<T> getRelatedObjects(String obid,String relationClassName,String fromOrTo,String targetFilter, RestParameterMap restParameterMap);
    public <T extends ObjectRootVO> List<T> getRelatedObjects(String obid,String relationClassName,String fromOrTo,String targetFilter,Integer depth, RestParameterMap restParameterMap);
    public <T extends BusinessRelationObjectVO> List<T> tnxCreateRelations(String obid,String relationClassName,String fromOrTo,List<HashMap<String, Object>> mapList, RestParameterMap restParameterMap);
    public <T extends BusinessRelationObjectVO> T tnxCreateRelation(String obid,String relationClassName,String fromOrTo,HashMap<String, Object> map, RestParameterMap restParameterMap);
    public <T extends BusinessObjectRootVO> List<T> findObjects(CFindObjectCondVO cFindObjectCondVO, RestParameterMap restParameterMap);
    public WorkflowHeaderVO createWorkflowHeader(CParmHeaderVO cParmHeaderVO);
}