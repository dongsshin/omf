/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CommonServiceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service.impl;

import com.rap.api.object.foundation.model.*;
import com.rap.config.datasource.dao.GenericDao;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.TransactionTypeConstants;
import com.rap.omc.core.util.general.FoundationDbProxy;
import com.rap.omc.core.util.general.NameGeneratorUtil;
import com.rap.omc.core.util.omc.DatasourceThreadLocalUtil;
import com.rap.omc.core.util.omc.SortUtil;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.foundation.classes.model.ObjectTableVO;
import com.rap.omc.foundation.classes.model.RelationTableInfo;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;
import com.rap.omc.foundation.classes.service.CommonService;
import com.rap.omc.foundation.classes.service.SchemaConstantsService;
import com.rap.omc.foundation.common.model.KeyInfo;
import com.rap.omc.foundation.common.model.ObjectTableKeyVO;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.object.model.OmcSchemaPropertyVO;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.schema.util.OmcUniqueIDGenerator;
import com.rap.omc.util.BaseFoundationUtil;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.ClassInfoUtil;
import com.rap.omc.util.foundation.CommonServiceUtil;
import com.rap.omc.util.foundation.FoundationValidationUtil;
import com.rap.omc.util.foundation.QueryStringUtil;
import org.apache.ibatis.session.RowBounds;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service("commonService")
public class CommonServiceImpl implements CommonService {

    @Autowired
    private SchemaConstantsService schemaConstantsService;

    //getDataSourceBean은 Schema Module의 Bean생성시 에러발생을 방지하기 위해서 Bean이 없는 경우 Null을 Return하게 함.
    //private GenericDao moduleDao = (GenericDao)SpringFactoryUtil.getBean(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_NAME));
    private GenericDao moduleDao = (GenericDao)SpringFactoryUtil.getDataSourceBean(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_DATASOURCE_NAME));

    private String getGlobalTransactionId(){
        return ThreadLocalUtil.getString(ThreadLocalUtil.KEY.globalTransactionId, OmcUniqueIDGenerator.getObid());
    }
    /**
     *
     *
     * @param inputList 생성할 Object VO List
     * @return 생성되어진 Object List(Business Object/Business Object Master/Relation Object를 구분해서 Return함.
     * @see com.rap.omc.foundation.classes.service.CommonService#createObjectSet(java.util.List)
     */
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public Map<String,Object> createObjectSet(List<? extends ObjectRootVO> inputList){

        List<ObjectRootVO> relObjList      = new ArrayList<ObjectRootVO>();
        List<ObjectRootVO> bizMasterObjList= new ArrayList<ObjectRootVO>();
        List<ObjectRootVO> bizObjList      = new ArrayList<ObjectRootVO>();
        Set<String> objectSet = new HashSet<String>();
        Map<String,Object> returnMap = new HashMap<String,Object>();
        
        injectTargetSet(inputList,relObjList,bizMasterObjList,bizObjList,objectSet);
        
        Map<String,Object> map = new HashMap<String,Object>();
        //Relation Type별 Flag Setting작업 필요
        if(!NullUtil.isNone(relObjList)) {
            Map<String, ObjectTableKeyVO> objectKeyMap = new HashMap<String, ObjectTableKeyVO>();

            Map<String,Object> parmMap = new HashMap<String,Object>();
            parmMap.put(GlobalConstants.MAP_KEY_OBID_LIST, objectSet);
            
            RowBounds unlimitedRowBounds = new RowBounds(OmcSystemConstants.NO_ROW_OFFSET, OmcSystemConstants.OMC_DBMS_UNLIIMITED_COUNT);
            List<ObjectTableKeyVO> objectTableKeyVOList = moduleDao.selectList("Common.getObjectTableKeys", parmMap);
            for(ObjectTableKeyVO keyVO : objectTableKeyVOList ){
                objectKeyMap.put(keyVO.getObid(), keyVO);
            }
            String fromObid = "";
            String toObid   = "";
            ObjectTableKeyVO fromKeyVO;
            ObjectTableKeyVO toKeyVO;

            long flags = 0;
            boolean isValid = false;
            Set<String> relationList = new HashSet<String>();
            Set<String> relationShipList = new HashSet<String>();
            for(ObjectRootVO vo : relObjList){
                isValid = false;
                fromObid  = ((BusinessRelationObjectVO)vo).getFromObid();
                if(StrUtil.isEmpty(fromObid)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.fromobidempty");
                toObid    = ((BusinessRelationObjectVO)vo).getToObid();
                if(StrUtil.isEmpty(toObid)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.toobidempty");
                
                fromKeyVO = objectKeyMap.get(fromObid);
                if(fromKeyVO == null) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.fromobjectnotfound");
                toKeyVO   = objectKeyMap.get(toObid);
                if(toKeyVO == null) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.toobjectnotfound");

                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_B2B));
                    isValid = true;
                }
                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_B2R));
                    isValid = true;
                }
                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_R2B));
                    isValid = true;
                }
                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_R2R));
                    isValid = true;
                }
                if(!isValid) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.objectkeyinfoinvalid");
                relationList.add(vo.getClassName() + "," + fromKeyVO.getClassName() + "," + toKeyVO.getClassName() + "," + vo.getFlags());
                relationShipList.add(vo.getClassName());
            }
            for(String relationName : relationShipList){
            	FoundationValidationUtil.checkInstantiable(relationName);
            }
            for(String str : relationList){
                String[] classArray = str.split(",");
                FoundationValidationUtil.checkValidationFromToType(classArray[0],classArray[1],classArray[2], Long.parseLong(classArray[3]));
            }
        }
        if(!NullUtil.isNone(relObjList)) {
            createObjectSetSub(relObjList, GlobalConstants.OBJECT_CREATE_SET_REL,"Common.insertRelationObjectSet");
        }
        if(!NullUtil.isNone(bizMasterObjList)) {
            for(ObjectRootVO vo : bizMasterObjList){
                vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO));
            }
            createObjectSetSub(bizMasterObjList, GlobalConstants.OBJECT_CREATE_SET_BIZ_MSTR,"Common.insertBusinessObjectMasterSet");
        }
        if(!NullUtil.isNone(bizObjList)) {
            for(ObjectRootVO vo : bizObjList){
                vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO,OmcSystemConstants.OBJROOT_FLAG_Revisible));
            }
            createObjectSetSub(bizObjList, GlobalConstants.OBJECT_CREATE_SET_BIZ,"Common.insertBusinessObjectSet");
        }
        returnMap.put(GlobalConstants.OBJECT_CREATE_SET_BIZ, bizObjList);
        returnMap.put(GlobalConstants.OBJECT_CREATE_SET_BIZ_MSTR, bizMasterObjList);
        returnMap.put(GlobalConstants.OBJECT_CREATE_SET_REL, relObjList);

        return returnMap;
    }
    /**
     * Object List에 대해서 일괄 Modify작업을 한다.
     *
     * @param inputList
     * @return
     */
    @Transactional(propagation = Propagation.REQUIRED)
    @Deprecated
    private Map<String,Object> modifyObjectSet(List<? extends ObjectRootVO> inputList){

        List<ObjectRootVO> relObjList      = new ArrayList<ObjectRootVO>();
        List<ObjectRootVO> bizMasterObjList= new ArrayList<ObjectRootVO>();
        List<ObjectRootVO> bizObjList      = new ArrayList<ObjectRootVO>();
        Set<String> objectSet = new HashSet<String>();
        Map<String,Object> returnMap = new HashMap<String,Object>();
        
        injectTargetSet(inputList,relObjList,bizMasterObjList,bizObjList,objectSet);
        
        Map<String,Object> map = new HashMap<String,Object>();
        //Relation Type별 Flag Setting작업 필요
        if(!NullUtil.isNone(relObjList)) {
            Map<String, ObjectTableKeyVO> objectKeyMap = new HashMap<String, ObjectTableKeyVO>();

            Map<String,Object> parmMap = new HashMap<String,Object>();
            parmMap.put(GlobalConstants.MAP_KEY_OBID_LIST, objectSet);
            
            List<ObjectTableKeyVO> objectTableKeyVOList = moduleDao.selectList("Common.getObjectTableKeys", parmMap);
            for(ObjectTableKeyVO keyVO : objectTableKeyVOList ){
                objectKeyMap.put(keyVO.getObid(), keyVO);
            }
            String fromObid = "";
            String toObid   = "";
            ObjectTableKeyVO fromKeyVO;
            ObjectTableKeyVO toKeyVO;

            long flags = 0;
            boolean isValid = false;
            Set<String> relationList = new HashSet<String>();
            Set<String> relationShipList = new HashSet<String>();
            for(ObjectRootVO vo : relObjList){
                isValid = false;
                fromObid  = ((BusinessRelationObjectVO)vo).getFromObid();
                if(StrUtil.isEmpty(fromObid)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.fromobidempty");
                toObid    = ((BusinessRelationObjectVO)vo).getToObid();
                if(StrUtil.isEmpty(toObid)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.toobidempty");
                
                fromKeyVO = objectKeyMap.get(fromObid);
                if(fromKeyVO == null) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.fromobjectnotfound");
                toKeyVO   = objectKeyMap.get(toObid);
                if(toKeyVO == null) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.toobjectnotfound");

                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_B2B));
                    isValid = true;
                }
                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_B2R));
                    isValid = true;
                }
                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_R2B));
                    isValid = true;
                }
                if(Bit.isInclude(fromKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO) && Bit.isInclude(toKeyVO.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO)){
                    vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_RO,OmcSystemConstants.OBJROOT_FLAG_RO_R2R));
                    isValid = true;
                }
                if(!isValid) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.objectkeyinfoinvalid");
                relationList.add(vo.getClassName() + "," + fromKeyVO.getClassName() + "," + toKeyVO.getClassName() + "," + vo.getFlags());
                relationShipList.add(vo.getClassName());
            }
            for(String relationName : relationShipList){
            	FoundationValidationUtil.checkInstantiable(relationName);
            }
            for(String str : relationList){
                String[] classArray = str.split(",");
                FoundationValidationUtil.checkValidationFromToType(classArray[0],classArray[1],classArray[2], Long.parseLong(classArray[3]));
            }
        }
        if(!NullUtil.isNone(relObjList)) {
                createObjectSetSub(relObjList, GlobalConstants.OBJECT_CREATE_SET_REL,"Common.insertRelationObjectSet");
        }
        if(!NullUtil.isNone(bizMasterObjList)) {
            for(ObjectRootVO vo : bizMasterObjList){
                vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO));
            }
            createObjectSetSub(bizObjList, GlobalConstants.OBJECT_CREATE_SET_BIZ_MSTR,"Common.insertBusinessObjectMasterSet");
        }
        if(!NullUtil.isNone(bizObjList)) {
            for(ObjectRootVO vo : bizObjList){
                vo.setFlags(Bit.or(vo.getFlags(),OmcSystemConstants.OBJROOT_FLAG_BO,OmcSystemConstants.OBJROOT_FLAG_Revisible));
            }
            createObjectSetSub(bizObjList, GlobalConstants.OBJECT_CREATE_SET_BIZ,"Common.insertBusinessObjectSet");
        }
        returnMap.put(GlobalConstants.OBJECT_CREATE_SET_BIZ, bizObjList);
        returnMap.put(GlobalConstants.OBJECT_CREATE_SET_BIZ_MSTR, bizMasterObjList);
        returnMap.put(GlobalConstants.OBJECT_CREATE_SET_REL, relObjList);
        return returnMap;
    }
    /**
     * Object List에 대해서 일괄 삭제
     * 
     * @param inputList
     * @see com.rap.omc.foundation.classes.service.CommonService#deleteObjectSet(java.util.List)
     */
    
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void deleteObjectSet(List<? extends ObjectRootVO> inputList){
        Map<String, ArrayList<ObjectRootVO>> inputListMap = classifyClassList(inputList);
        validateForDeleteObjectSet(inputListMap);
        for(String className : inputListMap.keySet()){
            ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
            if(NullUtil.isNull(classInfo)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Critical Error. Not Found Class(" + className + ")");
            if(Bit.isInclude(classInfo.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_Relation)){
                deleteObjectSetSub(inputListMap.get(className),className,classInfo.getDbmsTable(),"Common.deleteRelationObjectSet");
            }else if(Bit.isInclude(classInfo.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_Business)){
                deleteObjectSetSub(inputListMap.get(className),className,classInfo.getDbmsTable(),"Common.deleteBusinessObjectSet");
            }else{
                throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Schema Info Error. Class is '" + className + "'");
            }
        }
    }

    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void createObject(ObjectRootVO input){
        input.setGlobalTransactionId(getGlobalTransactionId());
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        Date now = new Date();
        input.setModifier(userId);
        input.setCreator(userId);
        input.setCreated(now);input.setModified(now);
        injectSelectSql(input);
        input.setSql(QueryStringUtil.convert2InsertValues(input));
        if (input instanceof BusinessRelationObjectVO) {
            moduleDao.insert("Common.insertRelationObject", input);
        }else {
            if (input instanceof BusinessObjectVO) {
                moduleDao.insert("Common.insertBusinessObject", input);
            } else {
                moduleDao.insert("Common.insertBusinessObjectMaster", input);
            }
        }
        FoundationDbProxy.createFoundationTable(input);
        //생성되어진 데이터 기준으로 Log를 관리함.
        FoundationDbProxy.createTransactionLink(input,getCurrentDatabaseObject(input.getObid(),TransactionTypeConstants.TYPE.Create),TransactionTypeConstants.TYPE.Create);

    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void modifyObjectBatch(List<? extends ObjectRootVO> inputList,Set<String> attributes){
        if(NullUtil.isNone(inputList)) return;
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        String globalTransactionId = getGlobalTransactionId();
        for(ObjectRootVO vo : inputList){
            vo.setModifier(userId);
            vo.setGlobalTransactionId(globalTransactionId);
            if(StrUtil.isEmpty(vo.getObid())) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Critical There is null Ojbect ID.");
            if(StrUtil.isEmpty(vo.getClassName())) {
                KeyInfo keyInfo = BaseFoundationUtil.getKeyInfo(vo.getObid());
                if (NullUtil.isNull(keyInfo)) {
                    throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.nodata");
                } else {
                    vo.setClassName(keyInfo.getClassName());
                }
            }
            ClassInfo classInfo = ClassInfoUtil.getClassInfo(vo.getClassName());
            if (NullUtil.isNull(classInfo)) { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata"); }
            vo.setDbmsTable(classInfo.getDbmsTable());
            vo.setModifier(userId);
            attributes.add("modified");attributes.add("modifier");
            vo.setSql(QueryStringUtil.convert2UpdateValues(classInfo,vo,attributes,true));
        }
        Map<String,Object> map = new HashMap<String,Object>();
        map.put(GlobalConstants.MAP_KEY_VO_LIST, inputList);
        FoundationDbProxy.createTransactionLink(inputList,getCurrentDatabaseObject(map,TransactionTypeConstants.TYPE.ModifySet),TransactionTypeConstants.TYPE.ModifySet);

        moduleDao.update("Common.modifyObjectSet",map);
    }
    /**
     * foundation 영역의 항목만 update
     *
     * @param input
     */
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void updateObject(ObjectRootVO input, boolean bIncludeAll){
        input.setGlobalTransactionId(getGlobalTransactionId());
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        input.setModifier(userId);

        injectSelectSql(input);
        if (bIncludeAll) {
            input.setSql(QueryStringUtil.convert2UpdateValues(input, true));
        } else {
            input.setSql(QueryStringUtil.convert2UpdateSpecificValues(input));
        }
        FoundationDbProxy.createTransactionLink(input,getCurrentDatabaseObject(input.getObid(),TransactionTypeConstants.TYPE.Modify),TransactionTypeConstants.TYPE.Modify);
        GenericDao specialDao = (GenericDao)ThreadLocalUtil.get(ThreadLocalUtil.KEY.dataSource);
        if(specialDao != null) {
            specialDao.update("Common.updateObject", input);
        }else {
            moduleDao.update("Common.updateObject", input);
        }
    }
    /**
     * base 영역의 항목만 update
     *
     * @param input
     */
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void modifyObject(ObjectRootVO input){
        GenericDao specialDao = DatasourceThreadLocalUtil.getDatasource(DatasourceThreadLocalUtil.KEY.fileDataSource);
        _changeObject_(input,specialDao,QueryStringUtil.convert2UpdateValues(input, false),TransactionTypeConstants.TYPE.Modify);
    }
    /**
     * change 대상 항목만 update
     *
     * @param input
     */
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObject(ObjectRootVO input){
        changeObject(input,false);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObject(ObjectRootVO input, boolean isOwner){
        String sql = "";
        if (!isOwner) {
            sql = QueryStringUtil.convert2ChangeValues(input, false);
        } else {
            sql = QueryStringUtil.convert2ChangeValues(input, true);
        }
        _changeObject_(input,sql,TransactionTypeConstants.TYPE.ModifyChange);
        updateKeyInfo(input);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObjectClassName(ObjectRootVO input){
        _changeObject_(input,QueryStringUtil.convert2ClassName(input),TransactionTypeConstants.TYPE.ModifyChange);
        updateKeyInfo(input);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObjectNames(ObjectRootVO input) {
        _changeObject_(input,QueryStringUtil.convert2Names(input),TransactionTypeConstants.TYPE.ModifyChange);
        updateKeyInfo(input);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObjectNamesAndRevision(ObjectRootVO input){
        _changeObject_(input,QueryStringUtil.convert2NamesRevision(input),TransactionTypeConstants.TYPE.ModifyChange);
        updateKeyInfo(input);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObjectStates(ObjectRootVO input){
        _changeObject_(input,QueryStringUtil.convert2States(input),TransactionTypeConstants.TYPE.ModifyChange);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObjectLifeCycleAndStates(ObjectRootVO input){
        _changeObject_(input,QueryStringUtil.convert2LifeCycleAdnState(input),TransactionTypeConstants.TYPE.ModifyChange);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeObjectWithKeyTableForDefloat(ObjectRootVO input){
        _changeObject_(input,QueryStringUtil.convert2DefloatValues(input),TransactionTypeConstants.TYPE.ModifyChange);
        updateKeyInfoForDefloat(input);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeRelationObject(ObjectRootVO input){
        input.setGlobalTransactionId(getGlobalTransactionId());
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        input.setModifier(userId);
        injectSelectSql(input);
        input.setSql(QueryStringUtil.convert2UpdateValues(input,true));

        FoundationDbProxy.createTransactionLink(input,getCurrentDatabaseObject(input.getObid(),TransactionTypeConstants.TYPE.ModifyChangeRel),TransactionTypeConstants.TYPE.ModifyChangeRel);
        moduleDao.update("Common.updateRelationObjectWithKeyTable", input);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void changeRelationObjectWithKeyTable(BusinessRelationObjectVO input){
        input.setGlobalTransactionId(getGlobalTransactionId());

        FoundationDbProxy.createTransactionLink(input,getCurrentDatabaseObject(input.getObid(),TransactionTypeConstants.TYPE.ModifyChangeRelAll),TransactionTypeConstants.TYPE.ModifyChangeRelAll);
        moduleDao.update("Common.updateRelationKeyInfoAll", input);
    }
    @Transactional(propagation = Propagation.REQUIRED)
    @Override
    public void deleteObject(ObjectRootVO input){
        input.setGlobalTransactionId(getGlobalTransactionId());
        injectSelectSql(input);
        //Delete 인경우 삭제전에 Transaction Log 관리를 Call하도록 함.
        FoundationDbProxy.createTransactionLink(input,getCurrentDatabaseObject(input.getObid(),TransactionTypeConstants.TYPE.Delete),TransactionTypeConstants.TYPE.Delete);
        if (input instanceof BusinessRelationObjectVO) {
            moduleDao.delete("Common.deleteRelationObject", input);
        } else {
            moduleDao.delete("Common.deleteBusinessObject", input);
        }
        FoundationDbProxy.deleteFoundationTable(input);
    }
    @Override
    public void deleteObject(String obid){
        ObjectRootVO input = new ObjectRootVO();
        input.setObid(obid);
        deleteObject(input);
    }
    @Override
    public <T> List<T> getSimpleObjects(String className, List<? extends ObjectRootVO> inputList, Set<String> attributes){
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
        String selectStr = classInfo.getSelectStr(true);
        String whereStr = classInfo.makeWhereString(attributes);
        Map<String,Object> map = new HashMap<String,Object>();
        map.put(GlobalConstants.MAP_KEY_SQL, selectStr);
        map.put("whereStr", whereStr);
        map.put(GlobalConstants.MAP_KEY_VO_LIST, inputList);
        map.put(GlobalConstants.MAP_KEY_DBMS_TABLE, classInfo.getDbmsTable());
        List<T> result = moduleDao.selectList("Common.getSimpleObjects", map);
        return result;
    }
    @Override
    public <T> T getObject(ObjectRootVO searchInfo){
        return getObject(searchInfo,true);
    }
    private <T> T getObject(ObjectRootVO searchInfo, boolean withOutData){
        injectSelectSql(searchInfo,withOutData);
        T result = moduleDao.select("Common.getObject",searchInfo);
        return result;
    }
    @Override
    public <T> T getObject(String obid,boolean withOutData){
        ObjectRootVO searchInfo = new ObjectRootVO();
        searchInfo.setObid(obid);
        return(getObject(searchInfo,withOutData));
    }
    @Override
    public <T> T getObject(String obid){
        return getObject(obid,true);
    }
    @Override
    public <T> T getRawObject(String obid){
        ObjectRootVO searchInfo = new ObjectRootVO();
        searchInfo.setObid(obid);
        injectSelectSql(searchInfo,false);
        T result = moduleDao.select("Common.getRawObject", searchInfo);
        return result;
    }
    @Override
    public <T> T getObject(String queryId, String obid){
        ObjectRootVO searchInfo = new ObjectRootVO();
        searchInfo.setObid(obid);

        injectSelectSql(searchInfo);
        T result = moduleDao.select(queryId, searchInfo);
        return result;
    }
    @Override
    public <T> List<T> getRevisionObjects(String queryId, String className, String names){
        BusinessObjectVO searchInfo = new BusinessObjectVO();
        searchInfo.setClassName(className);
        searchInfo.setNames(names);
        injectSelectSql(searchInfo);
        List<T> result = moduleDao.selectList(queryId, searchInfo);
        return result;
    }
    @Override
    public <T> T getObjectWithOutData(String obid){
        ObjectRootVO searchInfo = new ObjectRootVO();
        searchInfo.setObid(obid);
        this.injectSelectSql(searchInfo);
        searchInfo.setSql(QueryStringUtil.appendSelectValues(searchInfo));
        T result = moduleDao.select("Common.getObject", searchInfo);
        return result;
    }
    @SuppressWarnings({"unchecked","rawtypes"})
    @Override
    public <T> List<T> getObjectsWithOutData(List<String> obidList, String className){
        ObjectRootVO searchInfo = new ObjectRootVO();
        searchInfo.setClassName(className);
        this.injectSelectSql(searchInfo);
        Map map = new HashMap();
        map.put(GlobalConstants.MAP_KEY_SQL, QueryStringUtil.appendSelectValues(searchInfo));
        map.put(GlobalConstants.MAP_KEY_OBID_LIST, obidList);
        map.put(GlobalConstants.MAP_KEY_DBMS_TABLE, searchInfo.getDbmsTable());
        List<T> result = moduleDao.selectList("Common.getObjects", map);
        return result;
    }
    //voList에는 같은 Class Name이 와야 한다.
    @Override
    public <T> List<T> getRawObjects(List<ObjectRootVO> voList, String className){
        ObjectRootVO vo = new ObjectRootVO();
        vo.setClassName(className);
        this.injectSelectSql(vo);
        Map map = new HashMap();
        map.put(GlobalConstants.MAP_KEY_SQL       , QueryStringUtil.appendSelectValues(vo));
        map.put(GlobalConstants.MAP_KEY_VO_LIST   , voList);
        map.put(GlobalConstants.MAP_KEY_DBMS_TABLE, vo.getDbmsTable());
        List<T> result = moduleDao.selectList("Common.getRawObjects", map);
        return result;
    }
    @Override
    public <T> List<T> getObjectList(String queryId, String obid){
        ObjectRootVO searchInfo = new ObjectRootVO();
        searchInfo.setObid(obid);

        injectSelectSql(searchInfo);
        List<T> result = moduleDao.selectList(queryId, searchInfo);
        return result;
    }
    @SuppressWarnings({ "rawtypes", "unchecked" })
    @Override
    public List<RelationTableInfo> getRelationTableObjList(String obid, String direction, String classFilter, String fromClassFilter, String toClassFilter){
        Map map = new HashMap<String,String>();
        map.put("obid", obid);
        map.put("direction", direction);
        if(!NullUtil.isNone(classFilter) && !classFilter.equals(GlobalConstants.FLAG_TYPE_ALL)){
            String classListStr = ClassInfoUtil.getChildClassListStr(classFilter);
            List<String> strList = StrUtil.convertArrayToList(classListStr.split(","));
            map.put("relationList", strList);
        }
        if(!NullUtil.isNone(fromClassFilter) && !fromClassFilter.equals(GlobalConstants.FLAG_TYPE_ALL)){
            String classListStr = ClassInfoUtil.getChildClassListStr(fromClassFilter);
            List<String> strList = StrUtil.convertArrayToList(classListStr.split(","));
            map.put("fromFilterList", strList);
        }
        if(!NullUtil.isNone(toClassFilter) && !toClassFilter.equals(GlobalConstants.FLAG_TYPE_ALL)){
            String classListStr = ClassInfoUtil.getChildClassListStr(toClassFilter);
            List<String> strList = StrUtil.convertArrayToList(classListStr.split(","));
            map.put("toFilterList", strList);
        }
        List<RelationTableInfo> result = moduleDao.selectList("SchemaNew.getRelationObjectTable", map);
        return(result);
    }
    @Override
    public List<FilesVO> getFileObjectList(FilesVO file){

        List<FilesVO> result = moduleDao.selectList("file.getFileObject", file);
        return result;
    }
    private void _changeObject_(ObjectRootVO input, String sql, TransactionTypeConstants.TYPE transactionType){
        _changeObject_(input,null, sql,transactionType);
    }
    private void _changeObject_(ObjectRootVO input, GenericDao specialDao, String sql, TransactionTypeConstants.TYPE transactionType){
        input.setGlobalTransactionId(getGlobalTransactionId());
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        input.setModifier(userId);
        if (NullUtil.isNone(input.getClassName())) {
            KeyInfo keyInfo = BaseFoundationUtil.getKeyInfo(input.getObid());
            if (NullUtil.isNull(keyInfo)) {
                throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.nodata");
            } else {
                input.setClassName(keyInfo.getClassName());
            }
        }
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(input.getClassName());
        if (NullUtil.isNull(classInfo)) { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata"); }
        input.setDbmsTable(classInfo.getDbmsTable());
        input.setSql(sql);
        ObjectRootVO preVo = getCurrentDatabaseObject(input.getObid(),transactionType);
        ObjectRootVO preVoddd = new ObjectRootVO();
        FoundationDbProxy.createTransactionLink(input,preVo,transactionType);
        if(!NullUtil.isNull(specialDao)){
            specialDao.update("Common.updateObject", input);
        }else{
            moduleDao.update("Common.updateObject", input);
        }

    }
    private void injectSelectSql(ObjectRootVO bizObj){
        injectSelectSql(bizObj,true);
    }
    private void injectSelectSql(ObjectRootVO bizObj, boolean withOutData){
        if (NullUtil.isNone(bizObj.getClassName())) {
            KeyInfo keyInfo = BaseFoundationUtil.getKeyInfo(bizObj.getObid());
            if (NullUtil.isNull(keyInfo))  throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.keyInfo.nodata");
            bizObj.setClassName(keyInfo.getClassName());
        }
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(bizObj.getClassName());
        if (NullUtil.isNull(classInfo)) { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata"); }
        bizObj.setDbmsTable(classInfo.getDbmsTable());
        bizObj.setSql(classInfo.getSelectStr(withOutData));
    }
    private void injectTargetSet(List<? extends ObjectRootVO> allObjList, List<ObjectRootVO> relObjList, List<ObjectRootVO> bizMasterObjList, List<ObjectRootVO> bizObjList,Set<String> objectSet){

        String globalTransactionId = getGlobalTransactionId();
        String[] obid = NameGeneratorUtil.generateUniqueNameSet(allObjList.size());
        if(obid.length != allObjList.size()) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Object Id Generator Error!");
        int i = 0;
        Date now = new Date();
        for(ObjectRootVO bizObj : allObjList){
            bizObj.setCreated(now);bizObj.setModified(now);
            bizObj.setObid(obid[i++]);
            bizObj.setGlobalTransactionId(globalTransactionId);
            if (NullUtil.isNone(bizObj.getClassName())) {
                String tempClassName = bizObj.getClass().toString();
                tempClassName = tempClassName.substring(tempClassName.lastIndexOf('.') + 1);
                tempClassName = tempClassName.replace("VO", "");
                bizObj.setClassName(tempClassName);
            }
        }
        SortUtil.sort(allObjList, "className", false);
        int RELATION_CLASS         = 1;
        int BUSINESS_OBJECT_MASTER = 2;
        int BUSINESS_OBJECT        = 3;
        boolean isFirst       = true;
        String classNameSaved = "";
        String dbmsTable      = "";
        String insertValus    = "";
        String insertColumns  = "";

        int objectType = 0;
        
        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
        Date date = null;
        for(ObjectRootVO bizObj : allObjList){
            bizObj.setGlobalTransactionId(globalTransactionId);
            bizObj.setModifier(userId);
            bizObj.setCreator(userId);
            if(isFirst){
                classNameSaved = bizObj.getClassName();
                ClassInfo classInfo = ClassInfoUtil.getClassInfo(classNameSaved);
                if (NullUtil.isNull(classInfo)) { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata"); }
                if(!Bit.isInclude(classInfo.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_Instantiable))  { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Cannot instantiate. Class Name is '" + classNameSaved + "'"); }
                dbmsTable     = classInfo.getDbmsTable();
                insertValus   = QueryStringUtil.convert2InsertValues(bizObj,true);
                insertColumns = bizObj.getColumns();
                if(Bit.isInclude(classInfo.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_Relation)){
                    objectType = RELATION_CLASS;
                }else if(Bit.isInclude(classInfo.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_Business)){
                    if(Bit.isInclude(classInfo.getFlags(), OmcSystemConstants.BUSINESS_FLAG_Revisible)){
                        objectType = BUSINESS_OBJECT;
                    }else{
                        objectType = BUSINESS_OBJECT_MASTER;
                    }
                }else{
                    throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata");
                }
            }
            if(classNameSaved.equals(bizObj.getClassName())){
                bizObj.setDbmsTable(dbmsTable);
                insertValus   = QueryStringUtil.convert2InsertValues(bizObj,true);
                bizObj.setSql(insertValus);
                bizObj.setColumns(insertColumns);
            }else{
                classNameSaved = bizObj.getClassName();
                ClassInfo classInfo = ClassInfoUtil.getClassInfo(classNameSaved);
                if (NullUtil.isNull(classInfo)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata");
                if(!Bit.isInclude(classInfo.getClassInfoFlags() ,OmcSystemConstants.CLASSINFO_FLAG_Instantiable))  { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Cannot instantiate. Class Name is '" + classNameSaved + "'"); }
                if(Bit.isInclude(classInfo.getClassInfoFlags()  ,OmcSystemConstants.CLASSINFO_FLAG_Relation)){
                    objectType = RELATION_CLASS;
                }else if(Bit.isInclude(classInfo.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_Business)){
                    if(Bit.isInclude(classInfo.getFlags(), OmcSystemConstants.BUSINESS_FLAG_Revisible)){
                        objectType = BUSINESS_OBJECT;
                    }else{
                        objectType = BUSINESS_OBJECT_MASTER;
                    }
                }else{
                    throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata");
                }
                dbmsTable     = classInfo.getDbmsTable();
                insertValus   = QueryStringUtil.convert2InsertValues(bizObj,true);
                insertColumns = bizObj.getColumns();
                bizObj.setDbmsTable(dbmsTable);
                bizObj.setSql(insertValus);
                bizObj.setColumns(insertColumns);
            }
            bizObj.setFlags(OmcSystemConstants.OBJROOT_FLAG_Default);
            bizObj.setLocker("1");
            bizObj.setCheckouter("1");
            bizObj.setCheckouted(date);
            bizObj.setOwner("1");
            
            isFirst = false;
            if(objectType == RELATION_CLASS){
                relObjList.add(bizObj);
                objectSet.add(bizObj.getObid());
                objectSet.add(((BusinessRelationObjectVO)bizObj).getFromObid());
                objectSet.add(((BusinessRelationObjectVO)bizObj).getToObid());
            }else if(objectType == BUSINESS_OBJECT_MASTER){
                bizMasterObjList.add(bizObj);
                objectSet.add(bizObj.getObid());
            }else if(objectType == BUSINESS_OBJECT){
                bizObjList.add(bizObj);
                objectSet.add(bizObj.getObid());
            }
        }
    }
    @Transactional(propagation = Propagation.REQUIRED)
    private void updateKeyInfo(ObjectRootVO input){
        input.setGlobalTransactionId(getGlobalTransactionId());
        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setObid(input.getObid());
        if (!NullUtil.isNone(input.getClassName())) {
            keyInfo.setClassName(input.getClassName());
        }
        if (input instanceof BusinessObjectRootVO && !NullUtil.isNone(((BusinessObjectRootVO)input).getNames())) {
            keyInfo.setNames(((BusinessObjectRootVO)input).getNames());
        }
        if (input instanceof BusinessObjectVO && !NullUtil.isNone(((BusinessObjectVO)input).getRevision())) {
            keyInfo.setRevision(((BusinessObjectVO)input).getRevision());
        }
        if (input instanceof BusinessRelationObjectVO) {
            moduleDao.update("Common.updateRelationObjetKeyInfo", keyInfo);
        } else {
            moduleDao.update("Common.updateBusinessObjectKeyInfo", keyInfo);
        }
        FoundationDbProxy.modifyFoundationTable(keyInfo);
    }
    @Override
    public List<KeyInfo> getClassNameWithObidList(List<String> obidList){
        return moduleDao.selectList("Common.getClassNameWithObidList", obidList);
        
    }
    @Override
    public List<KeyInfo> getClassNameWithObidSet(Set<String> obidSet){
        List<String> obidList = new ArrayList<String>();
        for(String obid : obidSet) obidList.add(obid);
        return moduleDao.selectList("Common.getClassNameWithObidList", obidList);
        
    }
    private void updateKeyInfoForDefloat(ObjectRootVO input){
        input.setGlobalTransactionId(getGlobalTransactionId());
        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setObid(input.getObid());
        if (!NullUtil.isNull(input.getFlags())) {
            keyInfo.setFlags(input.getFlags());
        }
        if (input instanceof BusinessRelationObjectVO) {
            moduleDao.update("Common.updateObjectFlagKeyInfo", keyInfo);            
        } 
    }
    @Override
    public List<RelationTableInfo> getAllRelationShipForDeleteObject(String obid){
        KeyInfo keyInfo = new KeyInfo();
        keyInfo.setObid(obid);
        List<RelationTableInfo> result = moduleDao.selectList("Common.selectRelationShipAllList", keyInfo);
        return result;
    }
    @Override
    public List<OmcSchemaPropertyVO> getVariableList(){
        return getVariableList("All");
    }
    @Override
    public List<OmcSchemaPropertyVO> getVariableList(String moduleName){
        List<OmcSchemaPropertyVO> allList = new ArrayList<OmcSchemaPropertyVO>();
        List<OmcSchemaPropertyVO> tempList = new ArrayList<OmcSchemaPropertyVO>();
        
        tempList = schemaConstantsService.getSystemConstantsList();allList.addAll(tempList);
        tempList = schemaConstantsService.getLifeCycleConstantsList(moduleName);allList.addAll(tempList);
        tempList = schemaConstantsService.getStateConstantsList(moduleName);allList.addAll(tempList);
        tempList = schemaConstantsService.getClassBizConstantsList(moduleName);allList.addAll(tempList);
        tempList = schemaConstantsService.getClassRelConstantsList(moduleName);allList.addAll(tempList);
        return(allList); 
    }
    @Override
    public List<FilesVO> getFileObjects(FilesVO vo){
        this.injectSelectSql(vo);
        vo.setSql(QueryStringUtil.appendSelectValues(vo));
        return FoundationDbProxy.getFileObjects(vo);
    }
    @Override
    public List<ObjectTableVO> getObjectTableForClassChange(BusinessObjectRootVO vo){
        List<ObjectTableVO> result = moduleDao.selectList("ClassInfo.getObjectClassForChange", vo);
        return result;
    }
    @Override
    public void updateRelationForClassChangeFrom(Map<String,Object> map){
        moduleDao.update("ClassInfo.updateRelationFromClass", map);
    }
    @Override
    public void updateRelationForClassChangeTo(Map<String,Object> map){
        moduleDao.update("ClassInfo.updateRelationToClass", map);
    }

    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public int txnDeleteObjectForRollback(TransactionLinkVO linkVO, ObjectRootVO objVO){
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(objVO.getClassName());
        if (NullUtil.isNull(classInfo)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata");
        objVO.setDbmsTable(classInfo.getDbmsTable());
        FoundationDbProxy.createTransactionLink(objVO,getCurrentDatabaseObject(objVO.getObid(),TransactionTypeConstants.TYPE.Delete),TransactionTypeConstants.TYPE.Delete);
        int count = 0;
        if (objVO instanceof BusinessRelationObjectVO) {
            count = moduleDao.delete("Rollback.deleteRelationRollback", objVO);
        } else {
            count = moduleDao.delete("Rollback.deleteBusinessRollback", objVO);
        }
        objVO.setDbmsTable(null);objVO.setSql(null);objVO.setColumns(null);
        FoundationDbProxy.deleteFoundationTable(objVO);
        FoundationDbProxy.setRollbackTransactionLink(linkVO);
        return count;
    }
    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public int txnModifyObjectForRollback(TransactionLinkVO linkVO, ObjectRootVO objVO){
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(objVO.getClassName());
        if (NullUtil.isNull(classInfo)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata");
        objVO.setDbmsTable(classInfo.getDbmsTable());
        objVO.setSql(classInfo.makeUpdateSqlForRollback());
        objVO.setDbmsTable(classInfo.getDbmsTable());
        int count = 0;
        if (objVO instanceof BusinessRelationObjectVO) {
            count = moduleDao.update("Rollback.updateRelationRollback", objVO);
        } else {
            count = moduleDao.update("Rollback.updateBusinessRollback", objVO);
        }
        objVO.setDbmsTable(null);objVO.setSql(null);objVO.setColumns(null);
        FoundationDbProxy.modifyFoundationTable(objVO);
        FoundationDbProxy.setRollbackTransactionLink(linkVO);
        return count;
    }
    @Override
    @Transactional(propagation = Propagation.REQUIRED)
    public int txnCreateObjectForRollback(TransactionLinkVO linkVO, ObjectRootVO objVO){
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(objVO.getClassName());
        if (NullUtil.isNull(classInfo)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata");
        Map<String,String> map = classInfo.makeInsertSqlForRollback();
        objVO.setDbmsTable(classInfo.getDbmsTable());
        objVO.setSql(map.get("values"));
        objVO.setColumns(map.get("columns"));
        int count = 0;
        if (objVO instanceof BusinessRelationObjectVO) {
            count = moduleDao.insert("Rollback.insertRelationRollback", objVO);
        }else {
            if (objVO instanceof BusinessObjectVO) {
                count = moduleDao.insert("Rollback.insertBusinessRollback", objVO);
            } else {
                count = moduleDao.insert("Rollback.insertBusinessMasterRollback", objVO);
            }
        }
        objVO.setDbmsTable(null);objVO.setSql(null);objVO.setColumns(null);
        FoundationDbProxy.createFoundationTable(objVO);
        FoundationDbProxy.setRollbackTransactionLink(linkVO);
        return count;
    }
    /**
     *
     *
     * @param inputList
     * @return
     */
    private Map<String, ArrayList<ObjectRootVO>> classifyClassList(List<? extends ObjectRootVO> inputList){
        String globalTransactionId = getGlobalTransactionId();
        Map<String, ArrayList<ObjectRootVO>> inputListMap = new HashMap<String, ArrayList<ObjectRootVO>>();
        SortUtil.sort(inputList, "className", false);
        boolean isFirst = true;
        ArrayList<ObjectRootVO> tempList = new ArrayList<ObjectRootVO>();
        String classNameSaved = "";
        for(ObjectRootVO vo : inputList){
            vo.setGlobalTransactionId(globalTransactionId);
            if(isFirst){
                tempList.add(vo);
            }else{
                if(!classNameSaved.equals(vo.getClassName())){
                    inputListMap.put(classNameSaved, tempList);
                    tempList = new ArrayList<ObjectRootVO>();
                }
                tempList.add(vo);
            }
            classNameSaved = vo.getClassName();
            isFirst = false;
        }
        if(!NullUtil.isNone(tempList)) inputListMap.put(classNameSaved, tempList);
        return(inputListMap);
    }
    /**
     * Object List에 대한 삭제전Validation을 수행한다.
     *
     * @param inputListMap 삭제되어질 Object List
     */
    private void validateForDeleteObjectSet(Map<String, ArrayList<ObjectRootVO>> inputListMap){
        for(String className : inputListMap.keySet()){
            ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
            if(Bit.isInclude(classInfo.getClassInfoFlags(), OmcSystemConstants.CLASSINFO_FLAG_IsReferenced)){

                List<ObjectRootVO> list = inputListMap.get(className);
                List<ObjectRootVO> newList = new ArrayList<ObjectRootVO>();
                if(list.size() > OmcSystemConstants.OMC_OBJECT_SQL_DML_UNIT){
                    int seq = 0;
                    for(ObjectRootVO vo : list){
                        if(seq > 0 && seq%OmcSystemConstants.OMC_OBJECT_SQL_DML_UNIT == 0){
                            Map<String,Object> map = new HashMap<String,Object>();
                            map.put(GlobalConstants.MAP_KEY_VO_LIST, newList);
                            Integer exists = moduleDao.select("Common.referencedObjectCheck", map);
                            if(exists > 0) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Referenced Object Exits.Cannot delete with 'DeleteObjectSet'. Class Name is '" + className + "'.");
                            newList = new ArrayList<ObjectRootVO>();
                        }
                        newList.add(vo);
                        seq++;
                    }
                    if(!NullUtil.isNone(newList)){
                        Map<String,Object> map = new HashMap<String,Object>();
                        map.put(GlobalConstants.MAP_KEY_VO_LIST, newList);
                        Integer exists = moduleDao.select("Common.referencedObjectCheck", map);
                        if(exists > 0) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Referenced Object Exits.Cannot delete with 'DeleteObjectSet'. Class Name is '" + className + "'.");
                    }
                }else{
                    Map<String,Object> map = new HashMap<String,Object>();
                    map.put(GlobalConstants.MAP_KEY_VO_LIST, inputListMap.get(className));
                    Integer exists = moduleDao.select("Common.referencedObjectCheck", map);
                    if(exists > 0) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Foundation]Referenced Object Exits.Cannot delete with 'DeleteObjectSet'. Class Name is '" + className + "'.");
                }
            }
        }
    }
    /**
     *
     *
     * @param inputList
     * @param className
     * @param dbmsTable
     * @param queryId
     */
    private void deleteObjectSetSub(List<? extends ObjectRootVO> inputList, String className, String dbmsTable, String queryId){
        int i = 0;
        List<ObjectRootVO> newList = new ArrayList<ObjectRootVO>();
        Map<String,Object> map = new HashMap<String,Object>();
        for(ObjectRootVO vo : inputList){
            if(i > 0 && i%OmcSystemConstants.OMC_OBJECT_SQL_DML_UNIT == 0) {
                map.put(GlobalConstants.MAP_KEY_VO_LIST, newList);
                map.put(GlobalConstants.MAP_KEY_DBMS_TABLE, dbmsTable);
                FoundationDbProxy.createTransactionLink(newList,getCurrentDatabaseObject(map,TransactionTypeConstants.TYPE.DeleteSet),TransactionTypeConstants.TYPE.DeleteSet);
                moduleDao.delete(queryId, map);
                FoundationDbProxy.deleteFoundationTableSet(map);
                newList = new ArrayList<ObjectRootVO>();
            }
            newList.add(vo);
            i++;
        }
        if(!NullUtil.isNone(newList)){
            map.put(GlobalConstants.MAP_KEY_VO_LIST, newList);
            map.put(GlobalConstants.MAP_KEY_DBMS_TABLE, dbmsTable);
            FoundationDbProxy.createTransactionLink(newList,getCurrentDatabaseObject(map,TransactionTypeConstants.TYPE.DeleteSet),TransactionTypeConstants.TYPE.DeleteSet);
            moduleDao.delete(queryId, map);
            FoundationDbProxy.deleteFoundationTableSet(map);
        }
    }
    private void createObjectSetSub(List<? extends ObjectRootVO> inputList, String mapKey, String queryId){
        List<ObjectRootVO> newList = new ArrayList<ObjectRootVO>();
        List<ObjectRootVO> rtnList = new ArrayList<ObjectRootVO>();
        int i = 0;
        Map<String,Object> map = new HashMap<String,Object>();
        for(ObjectRootVO vo : inputList){
            if(i > 0 && i%OmcSystemConstants.OMC_OBJECT_SQL_DML_UNIT == 0) {
                map.put(GlobalConstants.MAP_KEY_VO_LIST, newList);
                moduleDao.insert(queryId, map);
                FoundationDbProxy.createFoundationTableSet(map);
                FoundationDbProxy.createTransactionLink(newList,getCurrentDatabaseObject(map,TransactionTypeConstants.TYPE.CreateSet),TransactionTypeConstants.TYPE.CreateSet);
                rtnList.addAll(newList);
                newList = new ArrayList<ObjectRootVO>();
            }
            newList.add(vo);
            i++;
        }
        if(!NullUtil.isNone(newList)){
            map.put(GlobalConstants.MAP_KEY_VO_LIST, newList);
            moduleDao.insert(queryId, map);
            FoundationDbProxy.createFoundationTableSet(map);
            FoundationDbProxy.createTransactionLink(newList,getCurrentDatabaseObject(map,TransactionTypeConstants.TYPE.CreateSet),TransactionTypeConstants.TYPE.CreateSet);
            rtnList.addAll(newList);
        }
    }
    private ObjectRootVO getCurrentDatabaseObject(String obid,TransactionTypeConstants.TYPE transactionType){
        if(transactionType.name().startsWith("Modify") || transactionType.name().startsWith("Delete")){
            return CommonServiceUtil.getRawObject(obid);
        }else{
            return null;
        }
    }
    private List<ObjectRootVO> getCurrentDatabaseObject(Map<String,Object> map, TransactionTypeConstants.TYPE transactionType){
        List<ObjectRootVO> returnList = new ArrayList<ObjectRootVO>();
        List<ObjectRootVO> voList = (List<ObjectRootVO>)map.get(GlobalConstants.MAP_KEY_VO_LIST);
        if(transactionType.name().startsWith("Modify") || transactionType.name().startsWith("Delete")){
            Map<String,ObjectRootVO> dbObjectMap = new HashMap<String,ObjectRootVO>();
            Map<String,List<ObjectRootVO>> classifiedMap = classifyWithClassName(voList);
            for(String className : classifiedMap.keySet()) {
                List<ObjectRootVO> tempList = getRawObjects(classifiedMap.get(className), className);
                for (ObjectRootVO vo : tempList) returnList.addAll(tempList);
            }
        }else{
            return voList;
        }
        return returnList;
    }
    private Map<String,List<ObjectRootVO>> classifyWithClassName(List<ObjectRootVO> voList){
        Map<String,List<ObjectRootVO>> map = new HashMap<String,List<ObjectRootVO>>();
        for(ObjectRootVO vo : voList){
            if(map.containsKey(vo.getClassName())){
                map.get(vo.getClassName()).add(vo);
            }else{
                ArrayList<ObjectRootVO> tempList = new ArrayList<ObjectRootVO>();
                tempList.add(vo);
                map.put(vo.getClassName(),tempList);
            }
        }
        return map;
    }
}
