package com.rap.omc.controller.model;

import com.rap.api.object.foundation.model.CPamBaseModel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CParmWorkflowHeader extends CPamBaseModel {
    private String        objectDetailUrl                                    = "None";
    private String        organizations                                      = "None";
    private Boolean       mailSendFlagApproval                               = (Boolean)true;
    private Boolean       mailSendFlagDistribution                           = (Boolean)true;
    private Boolean       allowDelegation                                    = (Boolean)true;
    private String        parallelNodeProcessionRule                         = "All";
    private String        requestComments                                   ;
}
