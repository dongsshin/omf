/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CommonService.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service;

/**
 * <pre>
 * Class : CommonCoreService
 * Description : TODO
 * </pre>a
 * 
 * @author s_dongsshin
 */
public interface CommonCoreService {
    public String getClassNameWithObid(String obid);
}
