package com.rap.omc.dataaccess;

import com.rap.config.datasource.dao.GenericDao;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.util.OmcDBMSConstants;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.Map;


public class OmfSQL extends  OmfAbstractSQL<OmfSQL> {
    private Map<String,Object> omfParms = new HashMap<String,Object>();
    private Object parmObj;
    private boolean isEnded = false;
    private boolean withParmObj = false;

    public void OBJECT_PARAMETER(Object parmObj) {
        this.parmObj = parmObj;
        withParmObj = true;
    }

    @Override
    public OmfSQL getSelf() {
        return this;
    }

    public void PARAMETER(String key, Object val){
        omfParms.put(key,val);
    }
    @Override
    public String toString(){
        return super.toString();
    }
    public OmfSQL END(){
        omfParms.put("sql",toString());
        isEnded = true;
        return this;
    }
    public <T> int insert(GenericDao dao, String sqlId)  {
        if(!isEnded) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Not completed Sql!");
        if(withParmObj){
            return dao.insert(sqlId,parmObj);
        }else{
            return dao.insert(sqlId,omfParms);
        }
    }
    public <T> int insert(GenericDao dao, String sqlId, T params)  {
        return dao.insert(sqlId,params);
    }
    public int update(GenericDao dao, String sqlId){
        if(!isEnded) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Not completed Sql!");
        if(withParmObj){
            return dao.update(sqlId,parmObj);
        }else{
            return dao.update(sqlId,omfParms);
        }
    }
    public <T> int update(GenericDao dao, String sqlId, T param){
        return dao.update(sqlId,param);
    }
    public <T, V> T selectList(GenericDao dao, String sqlId)  {
        if(!isEnded) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Not completed Sql!");
        if(withParmObj){
            return dao.selectList(sqlId,parmObj);
        }else{
            return dao.selectList(sqlId,omfParms);
        }
    }
    public <T, V> T selectList(GenericDao dao, String sqlId, V param)  {
        return dao.selectList(sqlId,param);
    }
    public <T, V> T select(GenericDao dao,String sqlId, V param)  {
        return dao.select(sqlId, param);
    }
    public <T, V> T select(GenericDao dao,String sqlId)  {
        if(!isEnded) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Not completed Sql!");
        if(withParmObj){
            return dao.select(sqlId,parmObj);
        }else{
            return dao.select(sqlId,omfParms);
        }
    }
    public <T> int delete(GenericDao dao,String sqlId, T params)  {
        return dao.delete(sqlId, params);
    }
    public <T> int delete(GenericDao dao,String sqlId)  {
        if(!isEnded) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Not completed Sql!");
        if(withParmObj){
            return dao.delete(sqlId,parmObj);
        }else{
            return dao.delete(sqlId,omfParms);
        }
    }
    public OmfSQL SET_AND_PARAMETER(String col, String attr, Object val){
        SET(col + " = #{" + attr + "}");
        PARAMETER(attr,val);
        return getSelf();
    }
    public OmfSQL WHERE_AND_PARAMETER(String col, String attr, Object val){
        WHERE(col + " = #{" + attr + "}");
        PARAMETER(attr,val);
        return getSelf();
    }
    public OmfSQL WHERE_IN(String col, String attr, Object val){
        WHERE(col + " IN(#{" + attr + "})");
        PARAMETER(attr,val);
        return getSelf();
    }
    public OmfSQL WHERE_NOT_IN(String col, String attr, Object val){
        WHERE(col + " NOT IN(#{" + attr + "})");
        PARAMETER(attr,val);
        return getSelf();
    }
    public void DEFAULT_VALUES_FIRST(){
        VALUES("obid"  ,"#{obid}");
        VALUES("pflags","#{flags}");
        VALUES("pnames","#{names}");
    }
    public void DEFAULT_VALUES_LAST(){
        VALUES("pcreator" ,"#{creator}");
        VALUES("pcreated" , OmcDBMSConstants.DBMS_SYSTEM_DATE);
        VALUES("pmodifier","#{modifier}");
        VALUES("pmodified",OmcDBMSConstants.DBMS_SYSTEM_DATE);
    }
}
