package com.rap.omc.controller.service.impl;

import com.rap.omc.controller.model.ExcelFormatVO;
import com.rap.omc.controller.service.FoundationExcelUploadService;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.*;

@Service("foundationExcelUploadService")
public class FoundationExcelUploadServiceImpl implements FoundationExcelUploadService {
    @Override
    public HashMap<String, List<Map<String, Object>>> convertExcelToMapLList(File file, Map<String, ExcelFormatVO> excelFormat) throws IOException, InvalidFormatException {
        OPCPackage opcPackage = OPCPackage.open(file, PackageAccess.READ);
        XSSFWorkbook workbook = new XSSFWorkbook(opcPackage);
        Iterator<Sheet> itr = workbook.sheetIterator();
        HashMap<String, List<Map<String, Object>>> listMap = new HashMap<String, List<Map<String, Object>>>();
        while(itr.hasNext()){
            List<Map<String, Object>> subList = new ArrayList<Map<String, Object>> ();
            XSSFSheet workSheet = (XSSFSheet) itr.next();
            String str = workSheet.getSheetName();
            ExcelFormatVO excelFormatVO = excelFormat.get(str);
            Set<String> headerSet = new HashSet<String>();
            Map<Integer,String> headerMap = new HashMap<Integer,String>();
            int endColumn = 0;
            if(!NullUtil.isNull(excelFormatVO)){
                for(int idx = excelFormatVO.getStartRow(); idx <= workSheet.getLastRowNum(); idx++){
                    if(idx == excelFormatVO.getStartRow()){
                        XSSFRow headerRow = workSheet.getRow(idx-1);
                        int i = 0;
                        while(true){
                            String value = getExcelCellValue(headerRow.getCell(i)).trim();
                            if(StrUtil.isEmpty(value)) {
                                endColumn = i - 1;
                                break;
                            }
                            if(headerSet.contains(value)) break;//Error
                            headerMap.put(i,value);
                            headerSet.add(value);
                            i = i+ 1;
                        }
                    }
                    XSSFRow row = workSheet.getRow(idx);
                    if(row == null) break;
                    if(StrUtil.isEmpty(getExcelCellValue(row.getCell(excelFormatVO.getEndCheckColumn())).trim())) break;
                    Map<String,Object> dataMap = new HashMap<String,Object>();
                    for(int i = 0; i <= endColumn; i++ ){
                        dataMap.put(headerMap.get(i),getExcelCellValue(row.getCell(excelFormatVO.getEndCheckColumn())).trim());
                    }
                    subList.add(dataMap);
                }
                listMap.put(workSheet.getSheetName(),subList);
            }
        }
        return listMap;
    }
    private String getExcelCellValue(XSSFCell cell){
        String cellValue = "";
        try{
            cellValue = cell == null ? "" : cell.getStringCellValue().trim();
        }
        catch( IllegalStateException e ){
            try{
                cellValue = String.valueOf( ((Double)cell.getNumericCellValue()).intValue() );
            }
            catch( IllegalStateException ed ){
                try{
                    cellValue = String.valueOf((cell.getBooleanCellValue()));
                }
                catch(Exception ee){
                    cellValue = "";
                }
            }
        }
        return cellValue;
    }
}
