package com.rap.omc.controller;


import com.rap.omc.foundation.workflow.WorkflowMethodCallParameter;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FoundationWorkflowController extends RestBaseController {
    /**************************************************************************************************/
    @Operation(
            summary = "Class에 대한 상세 정보 조회",
            description = "■Parameter"
                    +"<br>⊙ workflowMethodCallParameter        : Parameter"
    )
    @RequestMapping(value = "/foundation/workflow",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> executeWorkflowCheckMethod(@RequestBody WorkflowMethodCallParameter workflowMethodCallParameter) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,true), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_EXECUTE,e);
        }
    }
    @RequestMapping(value = "/foundation/workflow/promote",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> promote(@RequestBody WorkflowMethodCallParameter workflowMethodCallParameter) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,true), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_EXECUTE,e);
        }
    }
    @RequestMapping(value = "/foundation/workflow/demote",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> demote(@RequestBody WorkflowMethodCallParameter workflowMethodCallParameter) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,true), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_EXECUTE,e);
        }
    }
    @RequestMapping(value = "/foundation/workflow/withdrawal",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> withdrawal(@RequestBody WorkflowMethodCallParameter workflowMethodCallParameter) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,true), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_EXECUTE,e);
        }
    }
}