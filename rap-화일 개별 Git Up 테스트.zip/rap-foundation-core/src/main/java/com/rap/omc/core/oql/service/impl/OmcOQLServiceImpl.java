/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CommonServiceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.core.oql.service.impl;

import com.rap.config.datasource.dao.GenericDao;
import com.rap.config.datasource.dao.SchemaDao;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.oql.service.OmcOQLService;
import com.rap.omc.core.util.omc.DatasourceThreadLocalUtil;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.PropertiesUtil;
import org.apache.ibatis.session.RowBounds;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

/**
 * 
 * <pre>
 * Class : OmcOQLServiceImpl
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
@Service("omcOQLService")
public class OmcOQLServiceImpl implements OmcOQLService {
    
	@Resource(name = "schemaDao")
    private SchemaDao schemaDao;
	/*
    public List<String> getChildClassList(OmcSQLVariableParameter variableParameter){
        List<String> result = schemaDao.selectList("OmcOql.omcOqlDynamicSelectForString", variableParameter);
        return result;
    }

    public List<String> getStringList(OmcSQLVariableParameter variableParameter){
        List<String> result = schemaDao.selectList("OmcOql.getStringList", variableParameter);
        return result;
    }
    public List<OmcOQLTableAndClass> getTableAndClassList(OmcSQLVariableParameter variableParameter){
        List<OmcOQLTableAndClass> result = schemaDao.selectList("OmcOql.getTableAndClassList", variableParameter);
        return result;
    }
    public List<OmcOQLClassAttribute> getClassAttributeList(OmcSQLVariableParameter variableParameter){
        List<OmcOQLClassAttribute> result = schemaDao.selectList("OmcOql.getClassAttributeList", variableParameter);
        return result;
    }
    public List<OmcOQLApiLogVO> getAPILlogByKeyValue(OmcOQLApiLogVO apiLogVO){
        List<OmcOQLApiLogVO> result = schemaDao.selectList("OmcOql.getAPILogByKeyValue", apiLogVO);
        return result;
    }
    
    public List<String> getClassNameList(List<String> obidList){
    	GenericDao moduleDao = (GenericDao)SpringFactoryUtil.getBean(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_DATASOURCE_NAME));
        Map<String, Object> map = new HashMap<String,Object>();
        map.put("obidList", obidList);
        List<String> result = moduleDao.selectList("OmcOql.omcOqlUniqueClassName", map);
        return result;
    }
    
    public OmcOQLApiRelatedLogVO getAPIRelateLogByKeyValue(OmcOQLApiRelatedLogVO apiLogVO){
        OmcOQLApiRelatedLogVO result = schemaDao.select("OmcOql.getAPIRelateLogByKeyValue", apiLogVO);
        return result;
    }
    public <T> List<T> getObjects(OmcSQLVariableParameter sqlVariableParameter, String countSql, String executingSql, boolean isPaging){
        return getObjects(sqlVariableParameter, countSql, executingSql, isPaging,null);
    }

	 */
    @Override
    public <T> List<T> getObjects(Map<String,Object> attributeMap, PagingEntity pagingEntity, String countSql, String executingSql, boolean isPaging, RowBounds paramRowBounds){
        List<T> result;
        GenericDao moduleDao = (GenericDao)DatasourceThreadLocalUtil.getDatasource(DatasourceThreadLocalUtil.KEY.fileDataSource);
        if(moduleDao == null) moduleDao = (GenericDao)SpringFactoryUtil.getBean(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_DATASOURCE_NAME));
        if(isPaging){
            attributeMap.put("sql", countSql);
            Integer totalCount = moduleDao.select("OmcOql.getTotalCount", attributeMap);
            attributeMap.put("sql", executingSql);
            OmfPagingList<T> pagedList = new OmfPagingList<T>();
            result = moduleDao.selectList("OmcOql.getObject", attributeMap);
            pagedList.addAll(result);

            pagedList.setRowSize(pagingEntity.getRowSize());
            pagedList.setTargetRow(pagingEntity.getTargetRow());
            pagedList.setCurrentPage(pagingEntity.getTargetRow(), pagingEntity.getRowSize());
            pagedList.setTotalCount(totalCount);
            pagedList.setOrderBy(pagingEntity.getOrderBy());
            result = pagedList;
        }else{
            attributeMap.put("sql", executingSql);
            if(NullUtil.isNull(paramRowBounds)){
                result = moduleDao.selectList("OmcOql.getObject", attributeMap);
            }else{
                result = moduleDao.selectList("OmcOql.getObject", attributeMap, paramRowBounds);
            }
        }
        return result;
    }
    /*
    @Override
    public <T> List<T> getObjects(OmcSQLVariableParameter sqlVariableParameter, String countSql, String executingSql, boolean isPaging, RowBounds paramRowBounds){
        List<T> result;
        Map<String,Object> attributeMap = sqlVariableParameter.getAttributeMap();
        GenericDao moduleDao = (GenericDao)DatasourceThreadLocalUtil.getDatasource(DatasourceThreadLocalUtil.KEY.fileDataSource);
        if(moduleDao == null) moduleDao = (GenericDao)SpringFactoryUtil.getBean(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_DATASOURCE_NAME));
        if(isPaging){
            attributeMap.put("sql", countSql);
            Integer totalCount = moduleDao.select("OmcOql.getTotalCount", attributeMap);
            attributeMap.put("sql", executingSql);
            OmfPagingList<T> pagedList = new OmfPagingList<T>();
            result = moduleDao.selectList("OmcOql.getObject", attributeMap);
            pagedList.addAll(result);

            pagedList.setRowSize(sqlVariableParameter.getRowSize());
            pagedList.setTargetRow(sqlVariableParameter.getTargetRow());
            pagedList.setCurrentPage(sqlVariableParameter.getTargetRow(), sqlVariableParameter.getRowSize());
            pagedList.setTotalCount(totalCount);
            pagedList.setOrderBy(sqlVariableParameter.getOrderBy());
            result = pagedList;
        }else{
            attributeMap.put("sql", executingSql);
            if(NullUtil.isNull(paramRowBounds)){
                result = moduleDao.selectList("OmcOql.getObject", attributeMap);
            }else{
                result = moduleDao.selectList("OmcOql.getObject", attributeMap, paramRowBounds);
            }
        }
        return result;
    }
    */
    /*
    public <T> List<T> getObjects(OmcSQLVariableParameter sqlVariableParameter, boolean isPaging){
        List<T> result;
        GenericDao moduleDao = (GenericDao)DatasourceThreadLocalUtil.getDatasource(DatasourceThreadLocalUtil.KEY.fileDataSource);
        if(isPaging){
            result = moduleDao.selectPagedList("OmcOql.getObject", sqlVariableParameter);
        }else{
            result = moduleDao.selectList("OmcOql.getObject", sqlVariableParameter);
        }
        return result;
    }
    public List<OmcOQLBusinessClass> getBusinessClassList(OmcSQLVariableParameter variableParameter){
        List<OmcOQLBusinessClass> result = schemaDao.selectList("OmcOql.getBusinessClassList", variableParameter);
        return result;
    }

    public List<OmcOQLRelationClass> getRelationClassList(OmcSQLVariableParameter variableParameter){
        List<OmcOQLRelationClass> result = schemaDao.selectList("OmcOql.getRelationClassList", variableParameter);
        return result;
    }

    public List<OmcOQLRelationShipInfo> getRelationShipInfoList(OmcSQLVariableParameter variableParameter){
        List<OmcOQLRelationShipInfo> result = schemaDao.selectList("OmcOql.getRelationShipInfoList", variableParameter);
        return result;
    }
    public List<OmcOQLRelatedClassInfo> getRelatedInfoList(OmcSQLVariableParameter variableParameter){
        List<OmcOQLRelatedClassInfo> result = schemaDao.selectList("OmcOql.getRelatedInfoList", variableParameter);
        return result;
    }

     */

}