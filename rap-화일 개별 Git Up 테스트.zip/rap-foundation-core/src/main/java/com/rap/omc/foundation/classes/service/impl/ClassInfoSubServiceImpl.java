/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CacheInterfaceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 18. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service.impl;

import com.event.publish.vo.EventClassVO;
import com.rap.config.datasource.dao.GenericDao;
import com.rap.config.datasource.dao.SchemaDao;
import com.rap.omc.core.oql.utility.OmcComUtility;
import com.rap.omc.core.oql.utility.OmcFoundationConstant;
import com.rap.omc.dataaccess.OmfSQL;
import com.rap.omc.foundation.classes.model.*;
import com.rap.omc.foundation.classes.service.ClassInfoSubService;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSchemaUtil;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;
import java.util.regex.Pattern;

/**
 * <pre>
 * Class : ClassInfoServiceImpl
 * Description : TODO
 * </pre>
 *
 * @author hyeyoung.park
 */
@Service("classInfoSubService")
public class ClassInfoSubServiceImpl implements ClassInfoSubService {
    @Resource(name = "schemaDao")
    private SchemaDao schemaDao;
    
    @Cacheable(value = "classInfoCache", key = "#className")
    @Override
    public ClassInfo getClassInfo(String className){
        return getClassInfo("sqlSessionFactory", className);
    }
    @Override
    public List<EventClassVO> getAsyncClassList(String datasourceName) {
        return (new OmfSQL(){{
            SELECT("b.pclass_name        as class_name"       );
            SELECT("b.pdisplayed_name    as displayed_name"   );
            SELECT("b.pdisplayed_name_kr as displayed_name_kr");
            FROM("psysschemasync a","psysclassinfo b");
            WHERE_AND_PARAMETER("a.pis_synchronized","isSynchronized","N");
            WHERE("a.pclass_name = b.pclass_name");
            WHERE("instr(a.psynchronized_list,#{datasourceName}) = 0");
            PARAMETER("datasourceName","@" + datasourceName + "@");
        }}.END().selectList(schemaDao,"ClassInfo.getAsyncClassList"));
    }

    @Override
    public void txnSynchronize(GenericDao genericDao, EventClassVO asynchClassVO){
        if(genericDao instanceof SchemaDao) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Schema Database cannot be synchronized!");

        int count = (new OmfSQL(){{
            UPDATE("psysclassinfo a");
            SET_AND_PARAMETER("a.pdisplayed_name"   ,"displayedName"    ,asynchClassVO.getDisplayedName());
            SET_AND_PARAMETER("a.pdisplayed_name_kr","displayedNameKr"  ,asynchClassVO.getDisplayedNameKr());
            WHERE_AND_PARAMETER("a.pclass_name"     ,"className"    ,asynchClassVO.getClassName());
        }}.END().update(genericDao,"SchemaNew.dynamicModify"));
        if(count == 0){
            new OmfSQL(){{
                INSERT_INTO("psysclassinfo");
                VALUES("pclass_name"         ,"#{className}");
                VALUES("pdisplayed_name"     ,"#{displayedName}");
                VALUES("pdisplayed_name_kr"  ,"#{displayedNameKr}");

                PARAMETER("className"           ,asynchClassVO.getClassName());
                PARAMETER("displayedName"       ,asynchClassVO.getDisplayedName());
                PARAMETER("displayedNameKr"     ,asynchClassVO.getDisplayedNameKr());
            }}.END().insert(genericDao,"SchemaNew.dynamicCreate");
        }
    }
    @Override
    public void setSynchronizedSystemClass(EventClassVO asynchClassVO, String datasourceName) {
        new OmfSQL(){{
            UPDATE("psysschemasync a");
            SET("a.psynchronized_list  = concat(a.psynchronized_list,#{datasourceName})");
            PARAMETER("datasourceName","@" + datasourceName + "@");
            WHERE_AND_PARAMETER("a.pclass_name","className",asynchClassVO.getClassName());
            WHERE("instr(a.psynchronized_list,#{datasourceName})=0");
        }}.END().update(schemaDao,"SchemaNew.dynamicModify");
    }
    @Cacheable(value = "classInfoCache", key = "#className")
    @Override
    public ClassInfo getClassInfo(String sessionFactoryName, String className){
        StringBuffer sqlStrBuff = new StringBuffer(); 
        ClassInfo keyInfo = new OmfSQL(){{
            SELECT("a.pnames               as class_name"        );
            SELECT("(select x.pnames from psysbizobjectclassinfo x where x.obid = a.pparent_obid)    as class_name_parent");
            SELECT("a.pdbms_table          as dbms_table"        );
            SELECT("a.pjava_package        as java_package"      );
            SELECT("(select x.pjava_package from psysbizobjectclassinfo x where x.obid = a.pparent_obid)    as java_package_parent");
            SELECT("a.obid                 as obid"              );
            SELECT("a.pflags               as flags"             );
            SELECT("a.pparent_obid         as parent_obid"       );
            SELECT("a.pdisplayed_name      as displayed_name"    );
            SELECT("a.pdisplayed_name_kr   as displayed_name_kr" );
            SELECT("a.pdefault_policy      as default_policy"    );
            SELECT("a.pworkflow_url        as workflow_url"      );
            SELECT("a.pclass_icon          as class_icon"        );
            SELECT("a.pclass_icon_small    as class_icon_small"  );
            SELECT("a.pmodule_name         as module_name"       );
            SELECT("b.pupper_class_list    as upper_class_list_str"  );
            SELECT("b.plower_class_list    as lower_class_list_str"  );
            SELECT("b.pflags               as class_info_flags"  );
            FROM("psysbizobjectclassinfo a", "psysclassinfo b");
            WHERE_AND_PARAMETER("a.pnames","className",className);
            WHERE("a.obid = b.pclass_obid");
            WHERE(OmcSchemaUtil.getBitAndStr("a.pflags", "#{BUSINESS_FLAG_Active}", "#{BUSINESS_FLAG_Active}",false));
            PARAMETER("BUSINESS_FLAG_Active",OmcSystemConstants.BUSINESS_FLAG_Active);
        }}.END().select(schemaDao,"ClassInfo.getDynamicBizClassInfo");
        if (NullUtil.isNull(keyInfo)) {
            keyInfo = new OmfSQL(){{
                SELECT("a.pnames               as class_name"         );
                SELECT("(select x.pnames from psysrelobjectclassinfo x where x.obid = a.pparent_obid)    as class_name_parent");
                SELECT("a.pdbms_table          as dbms_table"         );
                SELECT("a.pjava_package        as java_package"       );
                SELECT("(select x.pjava_package from psysrelobjectclassinfo x where x.obid = a.pparent_obid)    as java_package_parent");
                SELECT("a.obid                 as obid"               );
                SELECT("a.pflags               as flags"              );
                SELECT("a.pparent_obid         as parent_obid"        );
                SELECT("a.pdisplayed_name      as displayed_name"     );
                SELECT("a.pdisplayed_name_kr   as displayed_name_kr"  );
                SELECT("a.pcardinality_from    as cardinality_from"   );
                SELECT("a.pcardinality_to      as cardinality_to"     );
                SELECT("a.prevision_rule_from  as revision_rule_from" );
                SELECT("a.prevision_rule_to    as revision_rule_to"   );
                SELECT("a.pmodule_name         as module_name"        );
                SELECT("b.pupper_class_list    as upper_class_list_str"   );
                SELECT("b.plower_class_list    as lower_class_list_str"   );
                SELECT("b.pflags               as class_info_flags"   );
                FROM("psysrelobjectclassinfo a","psysclassinfo b");
                WHERE_AND_PARAMETER("a.pnames","className",className);
                WHERE("a.obid = b.pclass_obid");
                WHERE(OmcSchemaUtil.getBitAndStr("a.pflags", "#{RELATION_FLAG_Active}", "#{RELATION_FLAG_Active}",false));
                PARAMETER("RELATION_FLAG_Active",OmcSystemConstants.RELATION_FLAG_Active);
            }}.END().select(schemaDao,"ClassInfo.getDynamicRelClassInfo");
            if(NullUtil.isNull(keyInfo)) {
                OmcComUtility.error("Cannot Find Class(" + className + ").");
            }
            if (!NullUtil.isNull(keyInfo)){
                List<AllowedClassInfo> allowedClassInfo = new OmfSQL(){{
                    SELECT("a.pflags      as flags"     );
                    SELECT("a.pclass_obid as class_obid");
                    SELECT("(select concat(x.pclass_name,'.',x.pdbms_table)  from psysclassinfo x where a.pclass_obid        = x.pclass_obid) as class_name");
                    SELECT("(select concat(y.pclass_name,'.',y.pdbms_table)  from psysclassinfo y where a.prelationship_obid = y.pclass_obid) as relation_name");
                    FROM("psysallowedclassforrel a","psysrelobjectclassinfo b", "psysclassinfo c");
                    WHERE("a.prelationship_obid = b.obid");
                    WHERE("a.pclass_obid        = c.pclass_obid");
                    WHERE(OmcSchemaUtil.getBitAndStr("b.pflags", "#{RELATION_FLAG_Active}", "#{RELATION_FLAG_Active}",false));
                    PARAMETER("RELATION_FLAG_Active",OmcSystemConstants.RELATION_FLAG_Active);
                }}
                .WHERE_AND_PARAMETER("a.prelationship_obid","relationshipObid",keyInfo.getObid())
                        .END().selectList(schemaDao,"ClassInfo.getDynamicAllowedClassInfo");

                keyInfo.setAllowedClassInfo(allowedClassInfo);
                
                Set<String> allowedFromClassSet = new HashSet<String>();
                Set<String> allowedToClassSet   = new HashSet<String>();
                if(!NullUtil.isNone(allowedClassInfo)){
                    for(AllowedClassInfo allowedVo : allowedClassInfo){
                        String[] strArray = allowedVo.getClassName().split(Pattern.quote("."));
                        if(Bit.isInclude(allowedVo.getFlags(),OmcSystemConstants.FLAG_ALLOWEDRELATION_FROM)){
                            allowedFromClassSet.add(strArray[0]);
                        }
                        if(Bit.isInclude(allowedVo.getFlags(),OmcSystemConstants.FLAG_ALLOWEDRELATION_TO)){
                            allowedToClassSet.add(strArray[0]);
                        }
                    }
                    //if(allowedFromClassSet.size() < 1 && Bit.isInclude(keyInfo.getFlags(), OmcSystemConstants.RELATION_FLAG_Instantiable)) OmcComUtility.error("Relation Definition Error(" + className + "). From class not defined.");
                    keyInfo.setAllowedFromClassSet(allowedFromClassSet);
                    //if(allowedToClassSet.size() < 1 && Bit.isInclude(keyInfo.getFlags(), OmcSystemConstants.RELATION_FLAG_Instantiable)) OmcComUtility.error("Relation Definition Error(" + className + "). To class not defined.");
                    keyInfo.setAllowedToClassSet(allowedToClassSet);
                }else{
                    //if(Bit.isInclude(keyInfo.getFlags(), OmcSystemConstants.RELATION_FLAG_Instantiable)) OmcComUtility.error("Relation Definition Error(" + className + "). From To Class not defined. ");
                }
            }
        }
        if (!NullUtil.isNull(keyInfo)){
            List<AllowedClassInfo> allowedClassInfo  =
                    new OmfSQL(){{
                        SELECT_DISTINCT("b.pflags      as flags");
                        SELECT_DISTINCT("b.pclass_obid as class_obid");
                        SELECT_DISTINCT("(select concat(x.pclass_name,'.',x.pdbms_table)  from psysclassinfo x where b.pclass_obid        = x.pclass_obid) as class_name");
                        SELECT_DISTINCT("(select concat(y.pclass_name,'.',y.pdbms_table)  from psysclassinfo y where b.prelationship_obid = y.pclass_obid) as relation_name");
                        FROM("psysallowedclassforrel a","psysallowedclassforrel b");
                        WHERE("a.prelationship_obid = b.prelationship_obid");
                        sqlStrBuff.setLength(0);
                        sqlStrBuff.append(OmcFoundationConstant.newline).append("((");
                        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pflags", "#{FLAG_ALLOWEDRELATION_FROM}", "#{FLAG_ALLOWEDRELATION_FROM}",false));
                        sqlStrBuff.append(OmcFoundationConstant.newline).append("and ");
                        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("b.pflags", "#{FLAG_ALLOWEDRELATION_TO}", "#{FLAG_ALLOWEDRELATION_TO}",false));
                        sqlStrBuff.append(OmcFoundationConstant.newline).append(")");
                        sqlStrBuff.append(OmcFoundationConstant.newline).append("or");
                        sqlStrBuff.append(OmcFoundationConstant.newline).append("(");
                        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("a.pflags", "#{FLAG_ALLOWEDRELATION_FROM}", "#{FLAG_ALLOWEDRELATION_FROM}",false));
                        sqlStrBuff.append(OmcFoundationConstant.newline).append("and ");
                        sqlStrBuff.append(OmcFoundationConstant.newline).append(OmcSchemaUtil.getBitAndStr("b.pflags", "#{FLAG_ALLOWEDRELATION_TO}", "#{FLAG_ALLOWEDRELATION_TO}",false));
                        sqlStrBuff.append(OmcFoundationConstant.newline).append("))");
                        WHERE(sqlStrBuff.toString());
                        PARAMETER("FLAG_ALLOWEDRELATION_FROM",OmcSystemConstants.FLAG_ALLOWEDRELATION_FROM);
                        PARAMETER("FLAG_ALLOWEDRELATION_TO",OmcSystemConstants.FLAG_ALLOWEDRELATION_TO);
                    }}.WHERE_AND_PARAMETER("a.pclass_obid","classObid",keyInfo.getObid()).END().selectList(schemaDao,"ClassInfo.getDynamicAllowedClassInfo");
            keyInfo.setRelatedClassInfo(allowedClassInfo);
        }
        if (!NullUtil.isNull(keyInfo)) {
            Map<String, Object> map = new HashMap<String, Object>();
            map.put("namesList", keyInfo.getLowerClassList());
            map.put("flags", OmcSystemConstants.CLASSINFO_FLAG_Instantiable);
            List<ClassDbmsTableVO> result = schemaDao.selectList("ClassInfo.getInstantiableClassList", map);
            keyInfo.setInstantiableClassList(result);
        
            map.put("flags", OmcSystemConstants.BUSINESS_FLAG_ComboDisplay);
            List<ClassNameForDisplayVO> result1 = schemaDao.selectList("ClassInfo.getChildClassListForDisplay", map);
            keyInfo.setChildClassListForCombo(result1);
            
            map = new HashMap<String, Object>();
            map.put("flagsClass", OmcSystemConstants.BUSINESS_FLAG_Active);
            map.put("flagsRelation", OmcSystemConstants.SYSLIFEINFO_FLAG_Active);
            map.put("kindsRelation", OmcSystemConstants.SYSLIFEINFO_KIND_Class);
            map.put("flagsLifeCycle", OmcSystemConstants.SYSLCYCLE_FLAG_Active);
            map.put("namesList", keyInfo.getUpperClassList());
            List<String> result2 = schemaDao.selectList("ClassInfo.getLifeCycleListForClass", map);
            keyInfo.setAllowedLifeCycleList(result2);
        }
        
        if (!NullUtil.isNull(keyInfo)) {
            //Column 정보 Setting
            List<ColumnInfo> columnList = schemaDao.selectList("ClassInfo.getColumnList", keyInfo.getClassName());
            keyInfo.setColumnList(columnList);
            //============================Class Menu 정보 Setting===========================================
            List<String> upperClassList = keyInfo.getUpperClassList();
            List<String> strList = null;
            if(!NullUtil.isNone(upperClassList)){
                Map<String,Object> map = new HashMap<String,Object>();
                String[] strArray = new String[upperClassList.size()];
                for(int i = 0; i < upperClassList.size(); i++){
                    strArray[i] = "mnu_" + upperClassList.get(i); 
                }
                map.put("namesList", strArray);
                map.put("flags", OmcSystemConstants.SYSMNU_FLAG_Active);
                map.put("objectKind", OmcSystemConstants.SYSMNU_KIND_ClassMenu);
                strList = schemaDao.selectList("MenuInfo.getMenuNameWithKind", map);
            }
            
            boolean isFound = false;
            if(!NullUtil.isNone(strList)){
                for(int i = 0; i < upperClassList.size(); i++){
                    if(isFound) break;
                    for(int j = 0; j < strList.size(); j++ ){
                        if(("mnu_" + upperClassList.get(i)).equals(strList.get(j))){
                            keyInfo.setClassMenu(strList.get(j));isFound =true; break;
                        }
                    }
                }
            }
           //=================================Structure Menu 정보 Setting=========================================
            strList = null;
            if(!NullUtil.isNone(upperClassList)){
                Map<String,Object> map = new HashMap<String,Object>();
                String[] strArray = new String[upperClassList.size()];
                for(int i = 0; i < upperClassList.size(); i++){
                    strArray[i] = "structure_" + upperClassList.get(i); 
                }
                map.put("namesList", strArray);
                map.put("flags", OmcSystemConstants.SYSMNU_FLAG_Active);
                map.put("objectKind", OmcSystemConstants.SYSMNU_KIND_StructureMenu);
                strList = schemaDao.selectList("MenuInfo.getMenuNameWithKind", map);
            }
            isFound = false;
            if(!NullUtil.isNone(strList)){
                for(int i = 0; i < upperClassList.size(); i++){
                    if(isFound) break;
                    for(int j = 0; j < strList.size(); j++ ){
                        if(("structure_" + upperClassList.get(i)).equals(strList.get(j))){
                            keyInfo.setStructureMenu(strList.get(j));isFound =true; break;
                        }
                    }
                }
            }
            //=================================Class Icon 정보 Setting==========================================
            strList = null;
            List<ClassInfo> classList = null;
            if(!NullUtil.isNone(upperClassList)){
                Map<String,Object> map = new HashMap<String,Object>();
                String[] strArray = new String[upperClassList.size()];
                for(int i = 0; i < upperClassList.size(); i++){
                    strArray[i] = upperClassList.get(i); 
                }
                map.put("namesList", strArray);
                classList = schemaDao.selectList("ClassInfo.getBizClassName", map);
            }
            isFound = false;
            if(!NullUtil.isNone(classList)){
                for(int i = 0; i < upperClassList.size(); i++){
                    if(isFound) break;
                    for(int j = 0; j < classList.size(); j++ ){
                        if((upperClassList.get(i)).equals(classList.get(j).getClassName()) && !StrUtil.isEmpty(classList.get(j).getClassIcon())){
                            keyInfo.setClassIconReal(classList.get(j).getClassIcon());
                            keyInfo.setClassIconSmallReal(classList.get(j).getClassIconSmall());
                            isFound =true; break;
                        }
                    }
                }
            }
        }
        return keyInfo;
    }
}
