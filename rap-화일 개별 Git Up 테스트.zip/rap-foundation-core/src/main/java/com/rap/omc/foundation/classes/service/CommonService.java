/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CommonService.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service;

import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.BusinessRelationObjectVO;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.omc.foundation.classes.model.ObjectTableVO;
import com.rap.omc.foundation.classes.model.RelationTableInfo;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;
import com.rap.omc.foundation.common.model.KeyInfo;
import com.rap.omc.schema.object.model.OmcSchemaPropertyVO;

import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * <pre>
 * Class : CommonService
 * Description : TODO
 * </pre>
 * 
 */
public interface CommonService {
    public Map<String,Object> createObjectSet(List<? extends ObjectRootVO> inputList);
    
    public void deleteObjectSet(List<? extends ObjectRootVO> inputList);
    
    public void modifyObjectBatch(List<? extends ObjectRootVO> inputList,Set<String> attributes);
    
    public <T> List<T> getSimpleObjects(String className, List<? extends ObjectRootVO> inputList, Set<String> attributes);
    
    public <T> T getObject(ObjectRootVO searchInfo);

    public <T> T getObject(String obid);

    public <T> T getRawObject(String obid);
    
    public <T> T getObject(String obid,boolean withOutData);

    public <T> T getObject(String queryId, String obid);
    
    public <T> List<T> getRevisionObjects(String queryId, String className, String names);

    public <T> T getObjectWithOutData(String obid);
    
    public <T> List<T> getObjectsWithOutData(List<String> obidList, String className);
    public <T> List<T> getRawObjects(List<ObjectRootVO> voList, String className);
    
    public List<RelationTableInfo> getRelationTableObjList(String obid, String direction, String classFilter, String fromClassFilter, String toClassFilter);
    
    public List<RelationTableInfo> getAllRelationShipForDeleteObject(String obid);
        
    public <T> List<T> getObjectList(String queryId, String obid);

    public List<FilesVO> getFileObjectList(FilesVO file);

    public void createObject(ObjectRootVO input);

    public void modifyObject(ObjectRootVO input);

    public void updateObject(ObjectRootVO input, boolean bIncludeAll);

    public void changeObject(ObjectRootVO input, boolean isOwner);

    public void changeObject(ObjectRootVO input);

    public void changeObjectClassName(ObjectRootVO input);
    public void changeObjectNames(ObjectRootVO input);
    public void changeObjectNamesAndRevision(ObjectRootVO input);
    public void changeObjectStates(ObjectRootVO input);
    public void changeObjectLifeCycleAndStates(ObjectRootVO input);

    public void changeObjectWithKeyTableForDefloat(ObjectRootVO input);
    
    public void changeRelationObjectWithKeyTable(BusinessRelationObjectVO input);
    
    public void deleteObject(ObjectRootVO input);

    public void deleteObject(String obid);

    public List<OmcSchemaPropertyVO> getVariableList(String moduleName);
    public List<OmcSchemaPropertyVO> getVariableList();
    
    public List<FilesVO> getFileObjects(FilesVO vo);
    
    public List<ObjectTableVO> getObjectTableForClassChange(BusinessObjectRootVO vo);
    
    public void updateRelationForClassChangeFrom(Map<String,Object> map);

    public void updateRelationForClassChangeTo(Map<String,Object> map);
    
    public void changeRelationObject(ObjectRootVO input);
    
    public List<KeyInfo> getClassNameWithObidList(List<String> obidList);

    public List<KeyInfo> getClassNameWithObidSet(Set<String> obidSet);
    public int txnDeleteObjectForRollback(TransactionLinkVO linkVO, ObjectRootVO objVO);
    public int txnModifyObjectForRollback(TransactionLinkVO linkVO, ObjectRootVO objVO);
    public int txnCreateObjectForRollback(TransactionLinkVO linkVO, ObjectRootVO objVO);
}
