package com.rap.omc.dataaccess.paging.executer;

import com.rap.omc.dataaccess.paging.PagingConstants;
import com.rap.omc.dataaccess.paging.PagingHelper;
import com.rap.omc.dataaccess.paging.exception.OmfPagingException;
import com.rap.omc.dataaccess.paging.handler.PagingCountHandler;
import com.rap.omc.dataaccess.paging.handler.PagingResultHandler;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.dataaccess.paging.model.PagingParameterUtil;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.SqlSession;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;

import java.util.List;
@Component("myBatisPagingExecutor")
@SuppressWarnings({ "rawtypes", "unchecked" })
public class MyBatisPagingExecutor implements PagingExecutor{

    private String sqlInjectionSieve = "'\";:#\\/*"; 
    public <E> List<E> execute(Object sqlSession, String queryId, Object parameter)
    {
        return execute(sqlSession, queryId, parameter, true);
    }
	public <E> List<E> execute(Object sqlSession, String queryId, Object parameter, boolean isExecuteCountQuery){
        SqlSession template = (SqlSession)sqlSession;
        PagingEntity pagingEntity = null;
        if (!(parameter instanceof PagingEntity)) {
            throw new OmfPagingException(HttpStatus.INTERNAL_SERVER_ERROR,"To use CommonDao.selectPagedList(String queryId, Object parameter), parameter must be type of '" + PagingEntity.class.getName() + "'.");
        }
        pagingEntity = (PagingEntity)parameter;
        
        PagingHelper.checkSortingOrderBySQL(pagingEntity.getOrderBy(), this.sqlInjectionSieve);
        String databaseUrl = DatabaseUrlHolder.getInstance().getDatabaseUrl(template.getConfiguration().getEnvironment().getDataSource());
        PagingParameterUtil.setPagingParameter(pagingEntity, PagingConstants.DATABASE_URL, databaseUrl);
        
        int totalRows = 0;
        if (isExecuteCountQuery) {
			ResultHandler countHandler = new PagingCountHandler();
            template.select(queryId, pagingEntity, countHandler);
            totalRows = ((PagingCountHandler)countHandler).getTotalCount();
            PagingParameterUtil.setPagingParameter(pagingEntity, "rows", Integer.valueOf(totalRows));
        }
		ResultHandler pagingResultHandler = new PagingResultHandler();
        template.select(queryId, pagingEntity, pagingResultHandler);
        OmfPagingList pagedList = ((PagingResultHandler)pagingResultHandler).getResultList();
        if (isExecuteCountQuery){
            pagingEntity.setTotalCount(totalRows);
        }
        else {
            pagingEntity.setTotalCount(pagedList.size());
        }
        pagedList.setPagingEntity(pagingEntity);
        return pagedList;
    }
    public void setSqlInjectionSieve(String sqlInjectionSieve)
    {
        this.sqlInjectionSieve = sqlInjectionSieve;
    }
}