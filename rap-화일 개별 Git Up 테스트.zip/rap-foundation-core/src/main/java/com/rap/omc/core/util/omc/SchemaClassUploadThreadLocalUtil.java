package com.rap.omc.core.util.omc;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
//Excel에서 Class 관련정보 Read할 때 Setting함.
public class SchemaClassUploadThreadLocalUtil {

    private static ThreadLocal<ConcurrentHashMap<String, Set<String>>> threadLocal = new ThreadLocal<ConcurrentHashMap<String, Set<String>>>();
    public static enum KEY {oldAllClass,currentAllClass,oldModuleClass,oldModuleClassObid, currentModuleClass,targetModule}
    public static void init(){
        ConcurrentHashMap<String, Set<String>> map = new ConcurrentHashMap<String, Set<String>>();
        threadLocal.set(map);
    }
    public static void destroy(){
        threadLocal.remove();
    }
    public static boolean isInitialized(){
        return (threadLocal.get() != null);
    }
    public static void setValue(KEY key, Set<String> value){
        if (!SchemaClassUploadThreadLocalUtil.isInitialized()) {
            SchemaClassUploadThreadLocalUtil.init();
        }
        ConcurrentHashMap<String, Set<String>> map = threadLocal.get();
        map.put(key.name(), value);
    }
    public static Set<String> getValue(KEY key){
        ConcurrentHashMap<String, Set<String>> map = threadLocal.get();
        if (map == null) {
            return null;
        }
        return map.get(key.name());
    }
}
