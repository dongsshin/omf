/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : NameGeneratorUtil.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 22. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.core.util.general;

import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.omc.constants.TransactionTypeConstants;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;
import com.rap.omc.foundation.classes.service.CommonCoreFoundationService;
import com.rap.omc.foundation.common.model.KeyInfo;

import java.util.List;
import java.util.Map;

/**
 * 
 * <pre>
 * Class : TransactionLinkUtil
 * Description : Foundation Database의 Global Object 정보와 Transaction 정보 반영을 위한 Utility
 * </pre>
 * 
 * @author s_dongsshin
 */
public class FoundationDbProxy {
    private static FoundationDbProxy nInstance;
    private CommonCoreFoundationService commonCoreFoundationService;

    private synchronized static FoundationDbProxy getInstance(){
        if (nInstance == null) {
            nInstance = new FoundationDbProxy();
            nInstance.commonCoreFoundationService = (CommonCoreFoundationService)SpringFactoryUtil.getBean("commonCoreFoundationService");
        }
        return nInstance;
    }
    public static void createFoundationTableSet(Map<String, Object> map){
        getInstance().commonCoreFoundationService.createFoundationTableSet(map);
    }
    public static void createFoundationTable(ObjectRootVO input){
        getInstance().commonCoreFoundationService.createFoundationTable(input);
    }
    public static void deleteFoundationTableSet(Map<String, Object> map){
        getInstance().commonCoreFoundationService.deleteFoundationTableSet(map);
    }
    public static void deleteFoundationTable(ObjectRootVO input){
        getInstance().commonCoreFoundationService.deleteFoundationTable(input);
    }
    public static void modifyFoundationTable(KeyInfo keyInfo){
        getInstance().commonCoreFoundationService.modifyFoundationTable(keyInfo);
    }
    public static void modifyFoundationTable(ObjectRootVO objVO){
        getInstance().commonCoreFoundationService.modifyFoundationTable(objVO);
    }
    public static void createTransactionLink(ObjectRootVO currentVO, ObjectRootVO previousVO, TransactionTypeConstants.TYPE transactionType){
        getInstance().commonCoreFoundationService.createTransactionLink(currentVO,previousVO,transactionType);
    }
    public static void createTransactionLink(List<? extends ObjectRootVO> currentVOList, List<? extends ObjectRootVO> previousVOList, TransactionTypeConstants.TYPE transactionType){
        getInstance().commonCoreFoundationService.createTransactionLink(currentVOList,previousVOList,transactionType);
    }
    public static void setRollbackTransactionLink(TransactionLinkVO linkVO){
        getInstance().commonCoreFoundationService.setRollbackTransactionLink(linkVO);
    }

    public static KeyInfo getFoundationKeyInfo(String obid){
        return getInstance().commonCoreFoundationService.getFoundationKeyInfo(obid);
    }
    public static List<FilesVO> getFileObjects(FilesVO vo){
        return getInstance().commonCoreFoundationService.getFileObjects(vo);
    }
    public static void setNoTransactionLog(){
        ThreadLocalUtil.setTransactionLog(false);
    }
    public static void setTransactionLog(){
        ThreadLocalUtil.setTransactionLog(true);
    }
    public static boolean getTransactionLogFlag(){
        return ThreadLocalUtil.getTransactionLog();
    }
}
