package com.rap.omc.controller;

import com.rap.omc.controller.model.*;
import com.rap.omc.foundation.user.model.CommonUserSearchVO;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.foundation.user.service.FoundationUserService;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.schema.object.model.OmcSchemaUserVO;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class FoundationRoleGroupController extends RestBaseController {
    @Autowired
    private FoundationUserService foundationUserService;

    private final String ERR_MSG_FOUNDATION_TOKEN = "foundation.error.token.general";
    private final String ERR_MSG_FOUNDATION_USER_CREATE = "foundation.error.user.create.general";
    private final String ERR_MSG_FOUNDATION_USER_GET = "foundation.error.user.get.general";
    private final String ERR_MSG_FOUNDATION_USER_MODIFY = "foundation.error.user.modify.general";
    private final String ERR_MSG_FOUNDATION_USER_INACTIVE = "foundation.error.user.inactive.general";
    private final String ERR_MSG_FOUNDATION_USER_LIST = "foundation.error.user.list.general";
    private final String ERR_MSG_FOUNDATION_NOT_FOUND = "foundation.error.object.notfound";
    private final String ERR_MSG_FOUNDATION_ALREADY_EXIST = "foundation.error.object.alreadyexists";

    @Operation(summary  = "Role 생성",
                description  = "Role을 생성한다..<br>" +
                        "■authenticationRequest:<br>" +
                        "{" +
                        ",<br>\"roleName\":\"roleName\"" +
                        ",<br>\"roleDescription\":\"roleDescription\"" +
                        "<br>}"
        )
    @RequestMapping(value = "/foundation/role",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createRole(@RequestBody CSysRoleVO cSysRoleVO){
        try{
            OmcSchemaUserVO groupVO = foundationUserService.txnCreateRole(cSysRoleVO.getRoleName(),cSysRoleVO.getRoleDescription());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,groupVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
    @RequestMapping(value = "/foundation/role/{roleName}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getRoleInfo(@PathVariable(name = "roleName") String roleName){
        try{
            SysUserVO roleVO = foundationUserService.getRoleInfo(roleName);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,roleVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
    @RequestMapping(value = "/foundation/roles",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getRoleList(@RequestParam(name="roleNamePattern", required = true,defaultValue = "*Role") String roleNamePattern){
        try{
            CommonUserSearchVO searchVO = new CommonUserSearchVO();
            searchVO.setNames(roleNamePattern);
            searchVO.setRoleInclude(true);
            List<OmcSchemaUserVO> userList = foundationUserService.getCommonUserList(searchVO);
            List<String> list = new ArrayList<String>();
            for(OmcSchemaUserVO vo : userList) list.add(vo.getNames());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
    @RequestMapping(value = "/foundation/group",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createGroup(@RequestBody CSysGroupVO cSysGroupVO){
        try{
            OmcSchemaUserVO groupVO = foundationUserService.txnCreateGroup(cSysGroupVO.getGroupName(),cSysGroupVO.getGroupDescription());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,groupVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
    @RequestMapping(value = "/foundation/group/{groupName}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getGroupInfo(@PathVariable(name = "groupName", required = true) String groupName){
        try{
            SysUserVO roleVO = foundationUserService.getGroupInfo(groupName);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,roleVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
    @RequestMapping(value = "/foundation/groups",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getGroupList(@RequestParam(value = "groupNamePattern",required = true,defaultValue = "Group") String groupNamePattern){
        try{
            CommonUserSearchVO searchVO = new CommonUserSearchVO();
            searchVO.setNames(groupNamePattern);
            searchVO.setGroupInclude(true);
            List<OmcSchemaUserVO> userList = foundationUserService.getCommonUserList(searchVO);
            List<String> list = new ArrayList<String>();
            for(OmcSchemaUserVO vo : userList) list.add(vo.getNames());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_FOUNDATION_USER_LIST,e);
        }
    }
}
