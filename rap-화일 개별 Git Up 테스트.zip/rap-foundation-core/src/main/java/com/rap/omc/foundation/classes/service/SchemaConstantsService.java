/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CacheInterface.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 18. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service;

import com.rap.omc.schema.object.model.OmcSchemaPropertyVO;

import java.util.List;

/**
 * <pre>
 * Class : ClassInfoService
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public interface SchemaConstantsService {
    public List<OmcSchemaPropertyVO> getSystemConstantsList();
    public List<OmcSchemaPropertyVO> getLifeCycleConstantsList(String moduleName);
    public List<OmcSchemaPropertyVO> getStateConstantsList(String moduleName);
    public List<OmcSchemaPropertyVO> getClassBizConstantsList(String moduleName);
    public List<OmcSchemaPropertyVO> getClassRelConstantsList(String moduleName);
}
