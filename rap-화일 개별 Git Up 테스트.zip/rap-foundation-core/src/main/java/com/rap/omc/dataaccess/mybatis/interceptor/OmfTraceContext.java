package com.rap.omc.dataaccess.mybatis.interceptor;

import java.util.Map;

public class OmfTraceContext
{
    @SuppressWarnings({ "unchecked", "rawtypes" })
	public static ThreadLocal<Map<String, String>> local = new ThreadLocal();
}
