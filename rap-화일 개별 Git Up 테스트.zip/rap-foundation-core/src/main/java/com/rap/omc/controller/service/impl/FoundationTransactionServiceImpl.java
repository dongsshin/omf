package com.rap.omc.controller.service.impl;

import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.config.datasource.dao.FoundationDao;
import com.rap.omc.controller.model.CParmTranVO;
import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.controller.service.FoundationRestService;
import com.rap.omc.controller.service.FoundationTransactionService;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.schema.object.model.OmcSchemaServiceVO;
import com.rap.omc.schema.util.Bit;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.BaseFoundationUtil;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.RollbackCoreServiceUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.LinkedHashMap;
import java.util.List;

@Service("foundationTransactionService")
public class FoundationTransactionServiceImpl implements FoundationTransactionService {

    @Resource(name = "foundationDao")
    private FoundationDao foundationDao;

    @Autowired
    private FoundationRestService foundationRestService;
    @Override
    public List<TransactionLinkVO> getTransactionLinkListPaging(CParmTranVO cParmTranVO) {
        if(StrUtil.isEmpty(cParmTranVO.getOrderBy())) cParmTranVO.setOrderBy( "order by transaction_seq desc");
        if(NullUtil.isNull(cParmTranVO.getBeforeHours())) cParmTranVO.setBeforeHours(24*365.0);
        if(!StrUtil.isEmpty(cParmTranVO.getTransactionType()) && cParmTranVO.getTransactionType().indexOf("*")>=0) cParmTranVO.setTransactionType(cParmTranVO.getTransactionType().replace("*","%"));
        if(!StrUtil.isEmpty(cParmTranVO.getUri()) && cParmTranVO.getUri().indexOf("*")>=0) cParmTranVO.setUri(cParmTranVO.getUri().replace("*","%"));
        return foundationDao.selectPagedList("Transaction.selectTransactionLinkList",cParmTranVO);
    }
    @Override
    public List<TransactionLinkVO> getTransactionLinkListForObject(String obid) {
        CParmTranVO cParmTranVO = new CParmTranVO();
        cParmTranVO.setObid(obid);
        cParmTranVO.setBeforeHours(24*365.0);
        return foundationDao.selectList("Transaction.selectTransactionLinkList",cParmTranVO);
    }

    @Override
    public List<TransactionLinkVO> getTransactionLinkListForTransactionId(String globalTransactionId) {
        CParmTranVO cParmTranVO = new CParmTranVO();
        cParmTranVO.setGlobalTransactionId(globalTransactionId);
        cParmTranVO.setBeforeHours(24*365.0);
        return foundationDao.selectList("Transaction.selectTransactionLinkList",cParmTranVO);
    }

    @Override
    public List<TransactionLinkVO> getRelatedTranLinkListForTranSeq(int transactionSeq) {
        CParmTranVO cParmTranVO = new CParmTranVO();
        cParmTranVO.setTransactionSeq(transactionSeq);
//        cParmTranVO.setBeforeHours(24*365.0);
        return foundationDao.selectList("Transaction.selectRelatedTransactionLinkList",cParmTranVO);
    }

    @Override
    public List<String> getGlobalTransactionIdListForObject(String obid) {
        CParmTranVO cParmTranVO = new CParmTranVO();
        cParmTranVO.setObid(obid);
        cParmTranVO.setBeforeHours(24*365.0);
        return foundationDao.selectList("Transaction.selectTransactionLinkList",cParmTranVO);
    }
    @Override
    public TransactionLinkVO getTransactionLink(int transactionSeq) {
        CParmTranVO cParmTranVO = new CParmTranVO();
        cParmTranVO.setTransactionSeq(transactionSeq);
        cParmTranVO.setBeforeHours(24*365.0);
        List<TransactionLinkVO> list = foundationDao.selectList("Transaction.selectTransactionLinkList",cParmTranVO);
        if(NullUtil.isNone(list)) return null;
        return list.get(0);
    }
    private List<TransactionLinkVO> getTransactionLinkForRollback(String globalTransactionId) {
        CParmTranVO cParmTranVO = new CParmTranVO();
        cParmTranVO.setGlobalTransactionId(globalTransactionId);
        return foundationDao.selectList("Transaction.selectTransactionLinkListForRollback",cParmTranVO);
    }
    @Override
    public void txnRollbackForTransactionSeq(int transactionSeq, RestParameterMap restParameterMap) {
        TransactionLinkVO linkVO = getTransactionLink(transactionSeq);
        if(NullUtil.isNull(linkVO)) return;

        String json = "";
        if(linkVO.getTransactionType().startsWith("Create")) json = linkVO.getJsonAfter();
        if(linkVO.getTransactionType().startsWith("Delete")) json = linkVO.getJsonBefore();
        if(linkVO.getTransactionType().startsWith("Modify")) json = linkVO.getJsonBefore();

        ObjectRootVO objVO = DomUtil.makeVO(json);

        OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(objVO.getClassName());
        restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
        if(serviceVO.isSameService()) {
            rollbackForTransaction(linkVO,objVO);
        }else{
            LinkedHashMap<String,Object> map = foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
        }
    }
    @Override
    public void txnRollbackForTransactionId(String globalTransactionId) {
        List<TransactionLinkVO> list = getTransactionLinkForRollback(globalTransactionId);
        for(TransactionLinkVO linkVO : list){
            //rollbackForTransaction(linkVO);
            if(Bit.isInclude(linkVO.getFlags(), OmcSystemConstants.TRANSACTION_FLAG_Rollback))
                throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Already Rollback!(Global Transaction Id:" + linkVO.getGlobalTransactionId() + "/Transaction Sequence: " + linkVO.getTransactionSeq() + ")");
            RestParameterMap restParameterMap = new RestParameterMap(HttpMethod.PUT, "/foundation/transaction/rollbackseq/{transactionSeq}");
            restParameterMap.addPathParameter("transactionSeq",linkVO.getTransactionSeq());
            OmcSchemaServiceVO serviceVO = BaseFoundationUtil.getServiceInfoWithClass(linkVO.getClassName());
            restParameterMap.setServiceUrl(serviceVO.getServiceUrl());
            foundationRestService.callRestService(restParameterMap,LinkedHashMap.class);
        }
    }
    private void rollbackForTransaction(TransactionLinkVO linkVO, ObjectRootVO objVO) {
        if(linkVO.getTransactionType().startsWith("Create")){
            RollbackCoreServiceUtil.deleteObjectForRollback(linkVO,objVO);
            return;
        }else if(linkVO.getTransactionType().startsWith("Delete")){
            RollbackCoreServiceUtil.createObjectForRollback(linkVO,objVO);
            return;
        }else if(linkVO.getTransactionType().startsWith("Modify")){
            RollbackCoreServiceUtil.modifyObjectForRollback(linkVO,objVO);
            return;
        }
    }
}