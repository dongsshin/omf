package com.rap.omc.controller.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CSysChangePasswordVO {
    private String userId;
    private String newPassword;

}
