package com.rap.omc.controller;

import com.rap.omc.controller.model.CSysServiceVO;
import com.rap.omc.controller.service.FoundationSchemaService;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.schema.object.model.OmcSchemaServiceVO;
import com.rap.omc.schema.service.OmcSchemaManagementService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class FoundationSchemaController extends RestBaseController {
    @Autowired
    private FoundationSchemaService foundationSchemaService;

    @RequestMapping(value = "/foundation/schema/service",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<?> registerService(@RequestBody CSysServiceVO sysServiceVO) {
        try{
            foundationSchemaService.txnRegisterService(sysServiceVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error",e);
        }
    }
    @RequestMapping(value = "/foundation/schema/service",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<?> modifyService(@RequestBody CSysServiceVO sysServiceVO) {
        try{
            foundationSchemaService.txnModifyService(sysServiceVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error",e);
        }
    }
    @RequestMapping(value = "/foundation/schema/service",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<?> deleteService(@RequestBody CSysServiceVO sysServiceVO) {
        try{
            foundationSchemaService.txnDeleteService(sysServiceVO.getServiceName());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error",e);
        }
    }
    @RequestMapping(value = "/foundation/schema/service",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<?> getService(@RequestBody CSysServiceVO sysServiceVO) {
        try{
            OmcSchemaServiceVO serviceVO = foundationSchemaService.getService(sysServiceVO.getServiceName());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,serviceVO), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error",e);
        }
    }
    @RequestMapping(value = "/foundation/schema/services",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody
    ResponseEntity<?> getServiceList(@RequestBody CSysServiceVO sysServiceVO) {
        try{
            List<OmcSchemaServiceVO> serviceVOList = foundationSchemaService.getServiceList(sysServiceVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,serviceVOList), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error",e);
        }
    }
}
