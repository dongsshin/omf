/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : FoundationServiceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 15. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service.impl;

import com.rap.api.object.foundation.model.BusinessRelationObjectVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.config.datasource.dao.GenericDao;
import com.rap.config.datasource.dao.SchemaDao;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.general.FoundationDbProxy;
import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.foundation.classes.service.CommonService;
import com.rap.omc.foundation.classes.service.FoundationService;
import com.rap.omc.foundation.common.model.KeyInfo;
import com.rap.omc.foundation.common.model.search.SearchTargetInfo;
import com.rap.omc.foundation.model.VariableAttribute;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.util.foundation.ClassInfoUtil;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <pre>
 * Class : FoundationServiceImpl
 * Description : TODO
 * </pre>
 * 
 * @author hyeyoung.park
 */
@Service("foundationService")
public class FoundationServiceImpl implements FoundationService {

    @Resource(name = "schemaDao")
    private SchemaDao schemaDao;

    @Resource(name = "commonService")
    private CommonService commonService;

    //getDataSourceBean은 Schema Module의 Bean생성시 에러발생을 방지하기 위해서 Bean이 없는 경우 Null을 Return하게 함.
    //private GenericDao moduleDao = (GenericDao)SpringFactoryUtil.getBean(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_NAME));
    private GenericDao moduleDao = (GenericDao)SpringFactoryUtil.getDataSourceBean(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_DATASOURCE_NAME));
    
    @Override
    public KeyInfo getFoundationKeyInfo(ObjectRootVO searchInfo){
        return(getFoundationKeyInfo(searchInfo.getObid()));
    }
    @Override
    public KeyInfo getFoundationKeyInfo(String obid){
        return FoundationDbProxy.getFoundationKeyInfo(obid);
    }
    @Override
    public List<String> getBusinessLatestObjectList(String className,List<String> nameList){
        Map<String, Object> map = new HashMap<String, Object>(); 
        List<String> chileList = ClassInfoUtil.getInstantiableChildList(className);
        map.put("classNameList", chileList);
        map.put("nameList", nameList);
        List<String> result = moduleDao.selectList("Common.getLatestBusinessObjectObidList", map);
        return result;
    }
    @Override
    public List<String> getBusinessObjectMasters(String className,String names){
        return(getBusinessObjects(className,names,"-"));
    }
    @Override
    public List<String> getBusinessObjects(String className,String names, String revision){
        Map<String, Object> map = new HashMap<String, Object>(); 
        List<String> chileList = ClassInfoUtil.getInstantiableChildList(className);
        map.put("classNameList", chileList);
        map.put("revision", revision);
        map.put("names", names);
        List<String> result = new ArrayList<String>();
        //result = schemaDao.selectList("Common.getBusinessObjectObidList", map);
        if(chileList.size() == 1){
            map.put("className", chileList.get(0));
            result = moduleDao.selectList("Common.getBusinessObjectObid", map);
        }else{
            result = moduleDao.selectList("Common.getBusinessObjectObidList", map);
        }
        if(result.size() == 0) result = null;
        return result;
    }
    @Override
    public List<String> getBusinessObjectMasterList(String className,List<String> nameList){
        Map<String, Object> map = new HashMap<String, Object>(); 
        List<String> chileClassList = ClassInfoUtil.getInstantiableChildList(className);
        map.put("chileClassList", chileClassList);
        map.put("nameList", nameList);
        map.put("revision", "-");
        List<String> result = moduleDao.selectList("Common.getBusinessObjectMasterObidList", map);
        return result;
    }
    @Override
    public <T> List<T> getRelatedObjectList(SearchTargetInfo searchInfo){
        List<T> resultList = null;
        List<String> relatedObidList = moduleDao.selectList("Relation.getRelatedObjectList", searchInfo);
        if (!NullUtil.isNone(relatedObidList)) {
            resultList = new ArrayList<T>();
            for (String relatedObid : relatedObidList) {
                T result = commonService.getObject(relatedObid);
                resultList.add(result);
            }
        }
        return resultList;
    }
    @Override
    public List<BusinessRelationObjectVO> getRelationList(SearchTargetInfo searchInfo){
        injectTarget(searchInfo);
        List<BusinessRelationObjectVO> resultList = moduleDao.selectList("Relation.getRelationList", searchInfo);
        return resultList;
    }

    private void injectTarget(SearchTargetInfo searchInfo){
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(searchInfo.getClassName());
        if (NullUtil.isNull(classInfo)) { throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"omc.error.classInfo.nodata"); }
        searchInfo.setDbmsTable(classInfo.getDbmsTable());
        searchInfo.setSql(classInfo.getSelectStr());
    }
    @Override
    public List<VariableAttribute> getDynamicAttributeList(String dynamicAttributeGroup){
        List<VariableAttribute> result = schemaDao.selectList("DynamicAttribute.getDynamicAttributeList",
                dynamicAttributeGroup);
        return result;
    }
}
