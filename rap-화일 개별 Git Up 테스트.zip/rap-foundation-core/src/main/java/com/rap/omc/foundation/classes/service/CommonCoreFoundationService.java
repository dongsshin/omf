/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : CommonService.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.omc.foundation.classes.service;

import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.omc.constants.TransactionTypeConstants;
import com.rap.omc.foundation.classes.model.TransactionLinkVO;
import com.rap.omc.foundation.common.model.KeyInfo;

import java.util.List;
import java.util.Map;

/**
 * <pre>
 * Class : CommonCoreFoundationService
 * Description : TODO
 * </pre>a
 * 
 * @author s_dongsshin
 */
public interface CommonCoreFoundationService {
    public void createTransactionLink(ObjectRootVO currentVO, ObjectRootVO previousVO, TransactionTypeConstants.TYPE transactionType);
    public void createTransactionLink(List<? extends ObjectRootVO> currentVOList, List<? extends ObjectRootVO>  previousVOList, TransactionTypeConstants.TYPE transactionType);
    public void setRollbackTransactionLink(TransactionLinkVO linkVO);
    public void createFoundationTableSet(Map<String,Object> map);
    public void createFoundationTable(ObjectRootVO input);
    public void deleteFoundationTableSet(Map<String,Object> map);
    public void deleteFoundationTable(ObjectRootVO input);
    public void modifyFoundationTable(KeyInfo keyInfo);
    public void modifyFoundationTable(ObjectRootVO objVO);
    public KeyInfo getFoundationKeyInfo(String obid);
    public List<FilesVO> getFileObjects(FilesVO vo);
}
