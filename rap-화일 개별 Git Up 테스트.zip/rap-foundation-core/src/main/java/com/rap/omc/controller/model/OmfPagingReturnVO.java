package com.rap.omc.controller.model;

import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import lombok.Getter;
import lombok.Setter;


@Setter
@Getter
public class OmfPagingReturnVO {
    private OmfPagingList pagingList;
    private PagingEntity  pagingEntity;
}
