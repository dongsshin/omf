/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : FcsServiceImpl.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 2. 4.  jongjung.kwon   Initial
 * ===========================================
 */
package com.rap.omc.foundation.file.service.impl;

import com.rap.config.datasource.dao.SchemaDao;
import com.rap.omc.foundation.file.model.FcsLocationVO;
import com.rap.omc.foundation.file.service.FcsService;
import com.rap.omc.schema.util.OmcSystemConstants;
import com.rap.omc.util.NullUtil;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * <pre>
 * Class : FcsServiceImpl
 * Description : TODO
 * </pre>
 * 
 * @author jongjung.kwon
 */
@Service("fcsService")
public class FcsServiceImpl implements FcsService{

    @Resource(name = "schemaDao")
    private SchemaDao schemaDao;

    @Cacheable(value = "locationInfoCache", key = "#names")
    public FcsLocationVO getFileLocationOrStore(String names){
        Map<String,Object> map = new HashMap<>();
        map.put("funVariable_00001",names);
        map.put("funVariable_00002",OmcSystemConstants.SYSFILELOCATION_FLAG_Active);
        map.put("funVariable_00003",OmcSystemConstants.SYSFILESTORE_FLAG_Active);
        return schemaDao.select("FcsInfo.getLocationOrStore", map);
    }
    @Cacheable(value = "locationInfoCache", key="T(java.lang.String).valueOf('L-').concat(#lifeCycle)")
    public FcsLocationVO getCurrentStoreForLifeCycle(String lifeCycle){
        Map<String,Object> map = new HashMap<>();
        map.put("funVariable_00001",lifeCycle);
        map.put("funVariable_00002",OmcSystemConstants.SYSREL_KIND_PolicyStore);
        map.put("funVariable_00003",OmcSystemConstants.SYSLIFEINFO_FLAG_Active);
        map.put("funVariable_00004",OmcSystemConstants.SYSREL_FLAG_Active);
        map.put("funVariable_00005",OmcSystemConstants.SYSFILESTORE_FLAG_Active);
        FcsLocationVO fcsLocationVO = schemaDao.select("FcsInfo.getStoreByLifeCycle", map);
       return fcsLocationVO;
    }
    @Override
    @Cacheable(value = "locationInfoCache", key="T(java.lang.String).valueOf('S-').concat(#site).concat(#storeName)")
    public FcsLocationVO getFcsLocationForSite(String site, String storeName){
        Map<String,Object> map = new HashMap<>();
        map.put("funVariable_00001",site);
        map.put("funVariable_00002",storeName);
        map.put("funVariable_00003",OmcSystemConstants.SYSFILESTORE_FLAG_Active);
        map.put("funVariable_00004",OmcSystemConstants.SYSREL_FLAG_Active);
        map.put("funVariable_00005",OmcSystemConstants.SYSREL_KIND_StoreIncludeLoc);
        map.put("funVariable_00006",OmcSystemConstants.SYSFILELOCATION_FLAG_Active);
        map.put("funVariable_00007",OmcSystemConstants.SYSREL_FLAG_Active);
        map.put("funVariable_00008",OmcSystemConstants.SYSREL_KIND_SiteHasLoc);
        map.put("funVariable_00009",OmcSystemConstants.SYSSITE_FLAG_Active);

        List<FcsLocationVO> list = schemaDao.selectList("FcsInfo.getStoreLocationBySite", map);
        if(!NullUtil.isNone(list)) return list.get(0);
        map.clear();
        map.put("funVariable_00001",storeName);
        map.put("funVariable_00002",OmcSystemConstants.SYSFILESTORE_FLAG_Active);
        map.put("funVariable_00003",OmcSystemConstants.SYSREL_FLAG_Active);
        map.put("funVariable_00004",OmcSystemConstants.SYSREL_KIND_StoreIncludeLoc);
        map.put("funVariable_00005",OmcSystemConstants.SYSFILELOCATION_FLAG_Active);
        list = schemaDao.selectList("FcsInfo.getLocationWithStore", map);
        if(!NullUtil.isNone(list)) return list.get(0);
        map.clear();
        map.put("funVariable_00001",storeName);
        map.put("funVariable_00002",OmcSystemConstants.SYSFILESTORE_FLAG_Active);
        list = schemaDao.selectList("FcsInfo.getStoreWithStore", map);
        if(!NullUtil.isNone(list)) return list.get(0);
        return null;
    }
}
