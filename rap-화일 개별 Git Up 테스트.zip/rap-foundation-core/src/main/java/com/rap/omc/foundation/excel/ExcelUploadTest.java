package com.rap.omc.foundation.excel;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ExcelUploadTest extends ExcelUploadGeneric {
    private static final Logger log = LoggerFactory.getLogger(ExcelUploadTest.class);
    public ExcelUploadTest(HashMap<String, List<Map<String, Object>>> excelData) {
        super(excelData);
    }
    //Convert 되어진 정보를 바탕으로 각 응용에서는 아래와 같이 원하는 작업을 수행할 수 있다.
    //Database Transaction이 필요한 경우 문의 필요
    //반드시 ExcelUploadGeneric를 상속 받아서 사용해야 함.
    @Override
    public void executeProcess(){
        HashMap<String, List<Map<String, Object>>> excelData = this.getExcelData();
        for(String key : excelData.keySet()){
            log.info("(Sheet Name)" + key + ":" + excelData.get(key).size());
            List<Map<String, Object>> sheetList = excelData.get(key);
            int i = 0;
            for(Map<String, Object> map : sheetList){
                StringBuffer strBuf = new StringBuffer();
                for(String attr : map.keySet()){
                    strBuf.append(",[").append(attr).append("]:").append(map.get(attr));
                }
                System.out.println("sheetList[" + i++ + "] == " + strBuf.toString().substring(1));
            }
        }
    }
}
