package com.rap.omc.controller;

import com.rap.omc.controller.model.RestParameterMap;
import com.rap.omc.controller.service.FoundationRequestMapperService;
import com.rap.omc.framework.annotation.OmfAuthority;
import com.rap.omc.framework.annotation.OMFCrud;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.schema.object.model.OmcSchemaRequestMapperVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class FoundationRequestMapperController extends RestBaseController {
    @Autowired
    private FoundationRequestMapperService foundationRequestMapperService;

    private final String ERR_MSG_FOUNDATION_MAPPER = "foundation.error.mapper.general";
    /**************************************★★★ Foundation Request Mapper ★★★ **********************************************/

    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Rest Controller Endpoint Indexing",
            description  = "■Parameter" +
                    "<br>\"serviceName\":\"Common\""
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "serviceName",
                    description = "Service Name, me인경우 현재 Module을 의미함.",
                    example = "String serviceName:Common,me")
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = true,//Check대상인지
            checkItem = "system.schema.authority",//권한 Check를 관리할 대상 정의, checkItem을 대해서 사용자/Group/Role을 할당할 수 있음
            crudTypes = {OMFCrud.KEY.Create, OMFCrud.KEY.Modify, OMFCrud.KEY.Delete},//본 기능이 어떠한 작업(CRUD 관점)을 하는 지 정의
            users = {"XP3866"},//Optional, 초기 정의시 항상 권한을 줄 사용자를 정의할 수 있다.
            roles = {"System Administration Role"},//Optional, 초기 정의시 항상 권한을 줄 Role을 정의할 수 있다.
            groups = {"Administration Group"}//Optional, 초기 정의시 항상 권한을 줄 Group을 정의할 수 있다.
            //users,roles,groups은 Online에서 추가 관리할 수 있음. 여기에 정의하는 것은 실제 자동으로 Database에 저장되어짐(Online에서 관리되어지는 것과 동일), 삭제는 관리하지 않고
            //추가만 되어지는 형식임. 삭제가 필요한 경우 Online 프로그램에서 삭제하면 됨.
    )
    @RequestMapping(value = "/foundation/endpoints/{serviceName}",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public ResponseEntity<?> refreshEndPointListFor(@PathVariable(name = "serviceName",required = true) String serviceName) {
        try{
            RestParameterMap RestParameterMap = new RestParameterMap(HttpMethod.PUT,"/foundation/endpoints/{serviceName}");
            RestParameterMap.addPathParameter("serviceName",serviceName);
            List<OmcSchemaRequestMapperVO> list = foundationRequestMapperService.getRequestMapperListForSource(serviceName,RestParameterMap);
            foundationRequestMapperService.txnRegisterRequestMappers(list);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_FOUNDATION_MAPPER,e);
        }
    }
    @Operation(summary  = "Rest Controller Endpoint 리스트 조회",
            description  = "■Parameter" +
                    "<br>\"serviceName\":\"Common\""
    )
    @Parameters({
            @Parameter(name = "serviceName",
                       description = "Service Name, me인경우 현재 Module을 의미함.",
                       example = "String serviceName:Common,me")
    })
    @OmfAuthority(target = true,
                  checkItem = "system.schema.authority",
                  crudTypes = {OMFCrud.KEY.Read},
                  users = {"XP3866"},
                  roles = {"System Administration Role"},
                  groups = {"Administration Group"})
    @RequestMapping(value = "/foundation/endpoints/{serviceName}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getEndPointList(@PathVariable(name = "serviceName",required = true) String serviceName) {
        try{
            RestParameterMap RestParameterMap = new RestParameterMap(HttpMethod.GET,"/foundation/endpoints/{serviceName}");
            RestParameterMap.addPathParameter("serviceName",serviceName);
            List<OmcSchemaRequestMapperVO> list = foundationRequestMapperService.getRequestMapperListForSource(serviceName,RestParameterMap);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), StatusConstants.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_FOUNDATION_MAPPER,e);
        }
    }

}