package com.rap.config.web.config;

import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.util.StrUtil;
import net.sf.ehcache.Cache;
import net.sf.ehcache.config.CacheConfiguration;
import net.sf.ehcache.config.DiskStoreConfiguration;
import net.sf.ehcache.store.MemoryStoreEvictionPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.ehcache.EhCacheCacheManager;
import org.springframework.cache.support.CompositeCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;

import java.util.Collections;

@Configuration
@EnableCaching
public class OmfCacheConfig implements CommandLineRunner {
    private static final Logger log = LoggerFactory.getLogger(OmfCacheConfig.class);
	@Autowired
    private CacheManager cacheManager;
/*
    @Bean
    public CacheManager cacheManager() {
        CacheManager cacheManager =  new EhCacheCacheManager(ehCacheCacheManager().getObject());
        return cacheManager;
    }
    @Bean
    public EhCacheManagerFactoryBean ehCacheCacheManager() {
        EhCacheManagerFactoryBean cmfb = new EhCacheManagerFactoryBean();
        cmfb.setConfigLocation(new ClassPathResource("ehcache.xml"));
        cmfb.setCacheManagerName("cacheManager");
        cmfb.setShared(true);
        return cmfb;
    }
*/
    @Primary
    @Bean("cacheManager")
    public CompositeCacheManager cacheManager() {
        CompositeCacheManager compositeCacheManager = new CompositeCacheManager();
        compositeCacheManager.setFallbackToNoOpCache(true);
        compositeCacheManager.setCacheManagers(Collections.singleton(ehCacheManager()));
        return compositeCacheManager;
    }
    @Bean("ehCacheManager")
    public EhCacheCacheManager ehCacheManager() {
        EhCacheCacheManager ehCacheCacheManager = new EhCacheCacheManager();
        net.sf.ehcache.CacheManager cacheManager = net.sf.ehcache.CacheManager.create(new net.sf.ehcache.config.Configuration());
        addFoundationCache(cacheManager);
        //addModuleCache(cacheManager,"rap.foundation.ehcache.list","rap.foundation.ehcache.");
        addModuleCache(cacheManager,"rap.module.ehcache.list","rap.module.ehcache.");
        ehCacheCacheManager.setCacheManager(cacheManager);
        return ehCacheCacheManager;
    }
    private  void addModuleCache(net.sf.ehcache.CacheManager cacheManager, String propertyCacheList, String propertySuffix) {
        //cacheManager.addCache(createCache("commonCodeMasterCache",MemoryStoreEvictionPolicy.LRU,500 ,0,600));
        //cacheManager.addCache(createCache("commonCodeCache"      ,MemoryStoreEvictionPolicy.LRU,500 ,0,600));
        String cacheList = PropertiesUtil.getString(propertyCacheList);
        if(StrUtil.isEmpty(cacheList) || StrUtil.isEmpty(cacheList.trim())) return;
        String[] cacheArray = cacheList.split(",");
        for(int i = 0; i < cacheArray.length; i++){
            if(!StrUtil.isEmpty(cacheArray[i]) && !StrUtil.isEmpty(cacheArray[i].trim())){
                String cacheEachName = cacheArray[i].trim();
                String cacheProperty = PropertiesUtil.getString("rap.module.ehcache." + cacheEachName);
                if(StrUtil.isEmpty(cacheProperty) || StrUtil.isEmpty(cacheProperty.trim())) new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cache definition for '" +  cacheEachName + "' is empty.");
                cacheManager.addCache(createCache(cacheEachName,cacheProperty));
            }
        }
    }
    private Cache createCache(String cacheName, String cacheProperty) {
        log.trace(cacheName + ":" + cacheProperty);
        String[] cachePropertyArray = cacheProperty.split(",");
        MemoryStoreEvictionPolicy policy = null;
        int maxEntriesLocalHeap = 0;
        int timeToIdleSeconds = 0;
        int timeToLiveSeconds = 0;


        if(cachePropertyArray.length != 4) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cache definition format is invalid.");
        if(StrUtil.isEmpty(cachePropertyArray[0]) || StrUtil.isEmpty(cachePropertyArray[0].trim())) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cache definition format is invalid. Policy is empty.");
        if(StrUtil.isEmpty(cachePropertyArray[1]) || StrUtil.isEmpty(cachePropertyArray[1].trim())) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cache definition format is invalid. maxEntriesLocalHeap is empty.");
        if(StrUtil.isEmpty(cachePropertyArray[2]) || StrUtil.isEmpty(cachePropertyArray[2].trim())) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cache definition format is invalid. timeToIdleSeconds is empty.");
        if(StrUtil.isEmpty(cachePropertyArray[3]) || StrUtil.isEmpty(cachePropertyArray[3].trim())) throw  new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cache definition format is invalid. timeToLiveSeconds is empty.");

        cachePropertyArray[0] = cachePropertyArray[0].trim().toUpperCase();
        switch (cachePropertyArray[0]) {
            case "LRU":
                policy = MemoryStoreEvictionPolicy.LRU;
                break;
            case "LFU":
                policy = MemoryStoreEvictionPolicy.LFU;
                break;
            case "FIFO":
                policy = MemoryStoreEvictionPolicy.FIFO;
                break;
            case "CLOCK":
                policy = MemoryStoreEvictionPolicy.CLOCK;
                break;
            default:
                policy = MemoryStoreEvictionPolicy.LRU;
                break;
        }
        maxEntriesLocalHeap = Integer.parseInt(cachePropertyArray[1].trim());
        timeToIdleSeconds = Integer.parseInt(cachePropertyArray[2].trim());
        timeToLiveSeconds = Integer.parseInt(cachePropertyArray[3].trim());
        return createCache(cacheName,policy,maxEntriesLocalHeap,timeToIdleSeconds,timeToLiveSeconds);
    }
    private void addFoundationCache(net.sf.ehcache.CacheManager cacheManager) {
        //cacheManager.addCache(createCache("valueCache"           ,MemoryStoreEvictionPolicy.LRU,1000,0,600));
        cacheManager.addCache(createCache("sysUserInfoCache"     ,MemoryStoreEvictionPolicy.LRU,500 ,0,60*10  ));//10분
        cacheManager.addCache(createCache("locationInfoCache"    ,MemoryStoreEvictionPolicy.LRU,50  ,0,0  ));
        cacheManager.addCache(createCache("classInfoCache"       ,MemoryStoreEvictionPolicy.LRU,1000,0,0  ));
        cacheManager.addCache(createCache("apiQueryCache"        ,MemoryStoreEvictionPolicy.LFU,1000,0,60*10));
        cacheManager.addCache(createCache("layoutInfoCache"      ,MemoryStoreEvictionPolicy.LRU,100 ,0,0  ));//5초
        cacheManager.addCache(createCache("objectKeyTable"       ,MemoryStoreEvictionPolicy.LRU,500 ,0,5  ));
        cacheManager.addCache(createCache("menuInfoCache"        ,MemoryStoreEvictionPolicy.LRU,500 ,0,0  ));
        cacheManager.addCache(createCache("lifeCycleInfoCache"   ,MemoryStoreEvictionPolicy.LRU,300 ,0,0  ));
        cacheManager.addCache(createCache("propertiesCache"      ,MemoryStoreEvictionPolicy.LRU,100 ,0,60 ));
        cacheManager.addCache(createCache("moduleServiceCache"   ,MemoryStoreEvictionPolicy.LRU,100 ,0,60 ));
    }
    private Cache createCache(String cacheName, MemoryStoreEvictionPolicy policy, int maxEntriesLocalHeap, int timeToIdleSeconds,int timeToLiveSeconds) {
        CacheConfiguration cacheConfig = new CacheConfiguration(cacheName, maxEntriesLocalHeap)
                .memoryStoreEvictionPolicy(policy)
                .eternal(false)
                .timeToLiveSeconds(timeToLiveSeconds)
                .timeToIdleSeconds(timeToIdleSeconds);
        return new Cache(cacheConfig);
    }

    private net.sf.ehcache.config.Configuration getEhCacheConfiguration() {
        net.sf.ehcache.config.Configuration configuration = new net.sf.ehcache.config.Configuration();
        DiskStoreConfiguration diskStoreConfiguration = new DiskStoreConfiguration();
        diskStoreConfiguration.setPath("java.io.tmpdir");
        configuration.addDiskStore(diskStoreConfiguration);
        return configuration;
    }
/*
    @Bean(name = "redisCacheManager")
    public RedisCacheManager cacheManager(RedisConnectionFactory connectionFactory) {

        RedisCacheConfiguration configuration = RedisCacheConfiguration.defaultCacheConfig()
                .disableCachingNullValues() // null value 캐시안함
                //.entryTtl(Duration.ofSeconds(CacheKey.DEFAULT_EXPIRE_SEC)) // 캐시의 기본 유효시간 설정
                .entryTtl(Duration.ofSeconds(60)) // 캐시의 기본 유효시간 설정
                .computePrefixWith(CacheKeyPrefix.simple())
                .serializeKeysWith(RedisSerializationContext.SerializationPair.fromSerializer(new StringRedisSerializer())); // redis 캐시 데이터 저장방식을 StringSeriallizer로 지정

        // 캐시키별 default 유효시간 설정
        Map<String, RedisCacheConfiguration> cacheConfigurations = new HashMap<>();
        cacheConfigurations.put("classInfoCache", RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofSeconds(60)));
        return RedisCacheManager.RedisCacheManagerBuilder.fromConnectionFactory(connectionFactory).cacheDefaults(configuration)
                .withInitialCacheConfigurations(cacheConfigurations).build();
    }
*/
    @Override
    public void run(String... args) throws Exception {
    	log.info("\n\n" + "=========================================================\n"
                + "Using cache manager: " + this.cacheManager.getClass().getName() + "\n"
                + "=========================================================\n\n");
    }
}