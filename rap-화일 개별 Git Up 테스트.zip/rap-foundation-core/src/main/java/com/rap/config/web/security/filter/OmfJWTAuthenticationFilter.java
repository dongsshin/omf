package com.rap.config.web.security.filter;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.config.web.security.OmfAuthenticationToken;
import com.rap.config.web.security.OmfAuthenticationVO;
import com.rap.config.web.security.TokenUtils;
import com.rap.omc.foundation.user.model.OmfSecurityMember;
import com.rap.omc.framework.exception.OmfBaseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

public class OmfJWTAuthenticationFilter extends UsernamePasswordAuthenticationFilter {
    private static final Logger log = LoggerFactory.getLogger(OmfJWTAuthenticationFilter.class);
    public OmfJWTAuthenticationFilter(AuthenticationManager authenticationManager, AuthenticationFailureHandler authenticationFailureHandler) {
        super.setAuthenticationManager(authenticationManager);
        this.setAuthenticationFailureHandler(authenticationFailureHandler);
    }
    @Override
    public Authentication attemptAuthentication(HttpServletRequest request, HttpServletResponse response) {
        OmfAuthenticationVO authRequestVO = null;
        try{
            authRequestVO = new ObjectMapper().readValue(request.getInputStream(), OmfAuthenticationVO.class);
        } catch (IOException e) {
            e.printStackTrace();
            throw new AuthenticationServiceException("Cannot Read User Login Info.",e);
        }
        Authentication auth = null;
        UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(authRequestVO.getUsername(),authRequestVO.getPassword());
        try{
            auth = this.getAuthenticationManager().authenticate(authenticationToken);
        }catch (Exception e) {
            e.printStackTrace();
            if(e instanceof AuthenticationException){
                throw new AuthenticationServiceException("User Name or Password is invalid(" + e.getMessage() + ").",e);// + e.getClass() + ")",e);
            }else if(e instanceof OmfBaseException){
                throw new AuthenticationServiceException(e.getMessage(),e);
            }else{
                throw new AuthenticationServiceException("Unexpected Error in Login(" + e.getMessage() + ").",e);
            }
        }
        return auth;
    }
    @Override
    protected void successfulAuthentication(HttpServletRequest request, HttpServletResponse response, FilterChain chain, Authentication authentication) {
        OmfSecurityMember omfSecurityMember = (OmfSecurityMember)authentication.getPrincipal();
        HttpSession session = request.getSession();
        OmfAuthenticationToken authToken = new OmfAuthenticationToken(omfSecurityMember.getUsername(), omfSecurityMember.getAuthorities());
        String token = TokenUtils.generateJwtToken(authToken,30);
        response.addHeader(TokenUtils.HEADER_STRING, TokenUtils.TOKEN_PREFIX + token);
    }
}