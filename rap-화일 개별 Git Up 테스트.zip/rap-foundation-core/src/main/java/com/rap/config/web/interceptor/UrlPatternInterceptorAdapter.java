package com.rap.config.web.interceptor;

import com.rap.omc.util.core.PatternCoreUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.List;
import java.util.regex.Pattern;

public abstract class UrlPatternInterceptorAdapter extends HandlerInterceptorAdapter
{
    private Pattern[] skipUrlPatterns;
    private Pattern[] applyUrlPatterns;
    
    public void setSkipUrls(List<String> skipUrls)
    {
        this.skipUrlPatterns = PatternCoreUtil.compileWildcardPattern(skipUrls);
    }
    public void setApplyUrls(List<String> applyUrls){
        this.applyUrlPatterns = PatternCoreUtil.compileWildcardPattern(applyUrls);
    }
    public final boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)throws Exception{
        if ((this.skipUrlPatterns != null) && (this.applyUrlPatterns != null)) throw new IllegalArgumentException("skipUrl and applyUrl in interceptor property cannot be used at the same time");
        if (((this.skipUrlPatterns != null)&& (PatternCoreUtil.matches(this.skipUrlPatterns, request.getServletPath()))) || (
            (this.applyUrlPatterns != null)&& (!(PatternCoreUtil.matches(this.applyUrlPatterns, request.getServletPath()))))) {
            return true;
        }
        return checkHandle(request, response, handler);
    }

    public abstract boolean checkHandle(HttpServletRequest paramHttpServletRequest,HttpServletResponse paramHttpServletResponse, Object paramObject) throws Exception;
}