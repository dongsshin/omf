package com.rap.config.web.security;

import lombok.extern.slf4j.Slf4j;


public class OmfAuthenticationVO {
    private String username;
    private String password;
    private int expiredDaysAfter = 30;

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public String getPassword() {
        return password;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    public int getExpiredDaysAfter() {
        return expiredDaysAfter;
    }

    public void setExpiredDaysAfter(int expiredDaysAfter) {
        this.expiredDaysAfter = expiredDaysAfter;
    }
}
