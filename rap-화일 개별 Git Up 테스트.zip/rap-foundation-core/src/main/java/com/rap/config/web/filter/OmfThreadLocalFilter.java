package com.rap.config.web.filter;

import com.rap.config.web.security.TokenUtils;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.foundation.user.ThreadLocalSessionUtil;
import com.rap.omc.foundation.user.model.UserSessionVO;
import com.rap.omc.schema.util.OmcUniqueIDGenerator;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.*;
import javax.servlet.http.HttpServletRequest;
import java.io.IOException;


public class OmfThreadLocalFilter implements Filter {

	@Override
	public void init(FilterConfig arg0) throws ServletException{
    }
    @Override
    public void destroy(){
    }
    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException{
        try {
            HttpServletRequest httpReq = (HttpServletRequest)req;
            //HttpSession session = httpReq.getSession();
            String userIp = httpReq.getRemoteAddr();
            String uri    = httpReq.getRequestURI();
            ThreadLocalUtil.init();
            ThreadLocalUtil.set(ThreadLocalUtil.KEY.remoteAddr, userIp);
            ThreadLocalUtil.set(ThreadLocalUtil.KEY.requestUri, httpReq.getRequestURI());

            setGlobalTransactionInfo(httpReq);
            //Http Session정보를 활용하지 않으므로 항상 Mull값이다.(JWT로 변경되었기 때문)
            //UserSessionVO userSessionVO = (UserSessionVO) HttpSessionUtil.getAttribute(session, GlobalConstants.SESSION_USER_INFO);
            //RapJWTAuthorizationFilter에서 Thread Local에 Setting되어지더라고 DispatchServerlet은 다른 Thread에서 수행되어지므로 Thread Local에서
            // 데이터를 읽어 올수 없다. 그래서 userSession를 이용해서 Threade Local정보를 다시 Setting해야 한다.
            //RapJWTAuthorizationFilter에서 UserSessionVO을 Request에 담는다.
            UserSessionVO userSessionVO = (UserSessionVO)req.getAttribute(GlobalConstants.SESSION_VO_USER_INFO);
            //if(NullUtil.isNull(userSessionVO)) throw new OmfFoundationException(HttpStatus.FORBIDDEN,"User info is empty.");
            if (!NullUtil.isNull(userSessionVO)) {
            	ThreadLocalSessionUtil.refreshThreadLocalFromSession(userSessionVO);
            }
            chain.doFilter(req, res);
        } finally {
            ThreadLocalUtil.destroy();
        }
    }
    private void setGlobalTransactionInfo(HttpServletRequest httpReq){
        //globalTransactionId는 전체 시스템 관점의 Transaction Id로서 Object 생성시 항상 Object의 globalTransactionId에 Setting되어진다.
        //대상은 Business Object에 대한 대상으로 한정한다.
        //에러 발생시 해당 Id에 대한 데이터 처리를 해야한다.
        //데이터에 대한 상세 Handling은 업무 영역으로 맡김. 단지 Foundation에서는 Transaction 발생시 해당 Attribute를 관리해줄 뿐임.
        String globalTransactionId = httpReq.getHeader(TokenUtils.HEADER_GLOBAL_TRANSACTION_ID);
        String globalTransactionFlag = httpReq.getHeader(TokenUtils.HEADER_GLOBAL_TRANSACTION_FLAG);
        if(StrUtil.isEmpty(globalTransactionId)) globalTransactionId = OmcUniqueIDGenerator.getObid();
        if(StrUtil.isEmpty(globalTransactionFlag)) globalTransactionFlag = "Y";
        boolean bTransactionFlag = true;
        if(globalTransactionFlag.equals("N")) bTransactionFlag = false;
        ThreadLocalUtil.set(ThreadLocalUtil.KEY.globalTransactionId, globalTransactionId);
        ThreadLocalUtil.set(ThreadLocalUtil.KEY.transactionLogFlag , bTransactionFlag);
        // Rest call로 다시 Request되어지면 Transaction이 분리되어지므로 새로운 Sub Transaction Id를 Set한다.
        ThreadLocalUtil.set(ThreadLocalUtil.KEY.subTransactionId,OmcUniqueIDGenerator.getObid());
    }
}
