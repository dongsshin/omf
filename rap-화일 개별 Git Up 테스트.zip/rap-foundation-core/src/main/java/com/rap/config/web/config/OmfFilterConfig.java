package com.rap.config.web.config;

import com.rap.config.web.filter.OmfThreadLocalFilter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OmfFilterConfig {
	private static final Logger log = LoggerFactory.getLogger(OmfFilterConfig.class);
	/*
	@Bean
	public FilterRegistrationBean<CharacterEncodingFilter> getCharacterEncodingFilteregistrationBean()
	{
		CharacterEncodingFilter characterEncodingFilter = new CharacterEncodingFilter();
		characterEncodingFilter.setEncoding("utf-8");
		characterEncodingFilter.setForceEncoding(true);
		FilterRegistrationBean<CharacterEncodingFilter> registrationBean = new FilterRegistrationBean<CharacterEncodingFilter>(new CharacterEncodingFilter());
		registrationBean.addUrlPatterns("*.do");
		registrationBean.addUrlPatterns("/rs/");
		registrationBean.addUrlPatterns("/ws/");
		registrationBean.setOrder(2);
		return registrationBean;
	}
	@Bean
	public FilterRegistrationBean<AccessLogFilter> getAccessogFilterRegistrationBean()
	{
		FilterRegistrationBean<AccessLogFilter> registrationBean = new FilterRegistrationBean<AccessLogFilter>(new AccessLogFilter());
		registrationBean.addUrlPatterns("*.do");
		registrationBean.addUrlPatterns("/rs/");
		registrationBean.addUrlPatterns("/ws/");
		registrationBean.setOrder(3);
		return registrationBean;
	}
	*/
	@Bean
	public FilterRegistrationBean<OmfThreadLocalFilter> getThreadLocalFilterRegistrationBean()
	{
		log.info("Thread Local Filter(ThreadLocalFilter) applied");
		FilterRegistrationBean<OmfThreadLocalFilter> registrationBean = new FilterRegistrationBean<OmfThreadLocalFilter>(new OmfThreadLocalFilter());
		registrationBean.addUrlPatterns("/*");
		//registrationBean.addUrlPatterns("/ws/");
		registrationBean.setOrder(4);
		return registrationBean;
	}
}
