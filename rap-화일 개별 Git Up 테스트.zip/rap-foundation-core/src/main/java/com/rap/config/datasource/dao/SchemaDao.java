package com.rap.config.datasource.dao;


import com.rap.omc.dataaccess.paging.executer.MyBatisPagingExecutor;
import lombok.extern.slf4j.Slf4j;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
@Repository

public class SchemaDao extends GenericDao implements InitializingBean{
	@Autowired
	SqlSession schemaSqlSession;
	@Autowired
	MyBatisPagingExecutor myBatisPagingExecutor;
	
	@Override
	public void afterPropertiesSet() throws Exception{
		if (super.genricSqlSession == null) super.genricSqlSession = schemaSqlSession;
		if (super.pagingExecutor == null) super.pagingExecutor = myBatisPagingExecutor;
	}
}