package com.rap.config.web.security;

import lombok.extern.slf4j.Slf4j;

import java.util.Collection;


public class OmfAuthenticationToken {

    private String username;
    private Collection authorities;
    //private String token;
/*
    private SysUserVO sysUserVO;

    public SysUserVO getSysUserVO() {
        return sysUserVO;
    }

    public void setSysUserVO(SysUserVO sysUserVO) {
        this.sysUserVO = sysUserVO;
    }
*/
    public OmfAuthenticationToken(String username, Collection collection) {
        this.username = username;
        this.authorities = collection;
        //this.token = token;
        //this.sysUserVO = sysUserVO;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }
    public Collection getAuthorities() {
        return authorities;
    }
    public void setAuthorities(Collection authorities) {
        this.authorities = authorities;
    }
    /*
    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }
    */
}
