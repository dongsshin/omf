package com.rap.config.web.interceptor;

import com.rap.omc.util.NullUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.http.client.support.HttpRequestWrapper;
import org.springframework.util.StreamUtils;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.net.URI;
import java.nio.charset.Charset;
import java.util.List;


public class HttpRequestResponseInterceptor implements ClientHttpRequestInterceptor {
    private static final Logger log = LoggerFactory.getLogger(HttpRequestResponseInterceptor.class);
    @Override
    public ClientHttpResponse intercept(HttpRequest request, byte[] body, ClientHttpRequestExecution execution) throws IOException
    {
        List<String> list = request.getHeaders().get("Authorization");
        if(NullUtil.isNone(list)){
            request.getHeaders().add("Authorization", "Bearer eyJyZWdEYXRlIjoxNTk5NDQyODk5Njc1LCJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJyb2xlIjpbeyJhdXRob3JpdHkiOiJST0xFXzNEIExpYnJhcmlhbiBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX0FjY2VzcyBHcmFudG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfQ29tcG9uZW50IERldmVsb3BtZW50IEVuZ2luZWVyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfR2VuZXJhbCBNYW5hZ2VyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfR2VuZXJhbCBVc2VyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfSGFyZHdhcmUgQWRtaW5pc3RyYXRvciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX0hhcmR3YXJlIEVuZ2luZWVyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfSGFyZHdhcmUgTGlicmFyaWFuIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfTWVjaGFuaWNhbCBFbmdpbmVlciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX01lY2huaWNhbCBBZG1pbmlzdHJhdG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfUENCIEVuZ2luZWVyIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfUHJvY2VzcyBBZG1pbmlzdHJhdG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfUHVyY2hhc2UgRW5naW5lZXIgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9RdWFsaXR5IEFkbWluaXN0cmF0b3IgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9SZXF1aXJlbWVudCBFbmdpbmVlciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX1JlcXVpcmVtZW50IE1hbmFnZXIgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9Tb2Z0d2FyZSBBZG1pbmlzdHJhdG9yIFJvbGUifSx7ImF1dGhvcml0eSI6IlJPTEVfU29mdHdhcmUgRW5naW5lZXIgUm9sZSJ9LHsiYXV0aG9yaXR5IjoiUk9MRV9TdXBwbGllciBFbmdpbmVlciBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX1N5c3RlbSBBZG1pbmlzdHJhdGlvbiBSb2xlIn0seyJhdXRob3JpdHkiOiJST0xFX1VTRVIifV0sImlkIjoiWFAzODY2IiwiZXhwIjoxNjAyMDM0ODk5fQ._2kkTpqulWoKfyuGD9wiGSwMxjdKUOJ-RcH0DzXn8AE");
        }
        logRequest(request, body);
        ClientHttpResponse response = execution.execute(new HttpRequestWrapper(request) {
            @Override
            public URI getURI() {
                URI u = super.getURI();
                String strictlyEscapedQuery = u.getRawQuery();
                return UriComponentsBuilder.fromUri(u)
                        .replaceQuery(strictlyEscapedQuery)
                        .build(true).toUri();
            }
        }, body);
        logResponse(response);
        return response;
    }
    private void logRequest(HttpRequest request, byte[] body) throws IOException
    {
        if (log.isTraceEnabled())
        {
            log.trace("===========================request begin================================================");
            log.trace("URI         : {}", request.getURI());
            log.trace("Method      : {}", request.getMethod());
            log.trace("Headers     : {}", request.getHeaders());
            log.trace("Request body: {}", new String(body, "UTF-8"));
            log.trace("==========================request end================================================");
        }
    }

    private void logResponse(ClientHttpResponse response) throws IOException
    {
        if (log.isTraceEnabled())
        {
            log.trace("============================response begin==========================================");
            log.trace("Status code  : {}", response.getStatusCode());
            log.trace("Status text  : {}", response.getStatusText());
            log.trace("Headers      : {}", response.getHeaders());
            log.trace("Response body: {}", StreamUtils.copyToString(response.getBody(), Charset.defaultCharset()));
            log.trace("=======================response end=================================================");
        }
    }
}