package com.rap.config.web.config;


import com.fasterxml.classmate.TypeResolver;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.ResponseEntity;
import org.springframework.web.context.request.async.DeferredResult;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.oas.annotations.EnableOpenApi;
import springfox.documentation.schema.WildcardType;
import springfox.documentation.service.*;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spi.service.contexts.SecurityContext;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger.web.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static java.util.Collections.singletonList;
import static springfox.documentation.schema.AlternateTypeRules.newRule;

@Configuration
@EnableOpenApi

public class OmfSwaggerConfig {
    @Autowired
    private TypeResolver typeResolver;
    /*
    @Bean
    public Docket swaggerSpringfoxDocket() {
        Docket docket = new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiEndPointsInfo())
                .pathMapping("/")
                .forCodeGeneration(true)
                .genericModelSubstitutes(ResponseEntity.class)
                .ignoredParameterTypes(java.sql.Date.class)
                .directModelSubstitute(java.time.LocalDate.class, java.sql.Date.class)
                .directModelSubstitute(java.time.ZonedDateTime.class, Date.class)
                .directModelSubstitute(java.time.LocalDateTime.class, Date.class)
                .securityContexts(securityContext())
                .securitySchemes(apiKey())
                .useDefaultResponseMessages(false);
                //ResultVO<Map<String, List<DicBase>>>, the ResultVO,DicBase are custom object
                //.alternateTypeRules(
                //        AlternateTypeRules.newRule(
                //                typeResolver.resolve(ObjectRootVO.class,
                //                        typeResolver.resolve(Map.class, String.class, typeResolver.resolve(List.class, DicBase.class))),
                 //               typeResolver.resolve(ObjectRootVO.class, WildcardType.class), Ordered.HIGHEST_PRECEDENCE));
        docket = docket.select().paths(PathSelectors.any()).build();
        //docket = docket.select().apis(Predicate.not(RequestHandlerSelectors.basePackage("org.springframework.boot"))).paths(PathSelectors.any()).build();
        //docket = docket.select().apis(Predicate.not(RequestHandlerSelectors.basePackage("com.rap"))).paths(PathSelectors.any()).build();

        //.apis(Predicates.not(RequestHandlerSelectors.
        //        basePackage("org.springframework.boot"))).paths(PathSelectors.any()).build();

        return docket;
    }
    */
    @Bean
    public Docket swaggerSpringfoxDocket() {
        return new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiEndPointsInfo())
                .select()
                .apis(RequestHandlerSelectors.any())
                .paths(PathSelectors.any())
                .build()
                .pathMapping("/")
                .forCodeGeneration(true)
                .directModelSubstitute(LocalDate.class, String.class)
                .genericModelSubstitutes(ResponseEntity.class)
                .alternateTypeRules(
                        newRule(typeResolver.resolve(DeferredResult.class,
                                typeResolver.resolve(ResponseEntity.class, WildcardType.class)),
                                typeResolver.resolve(WildcardType.class)))
                .useDefaultResponseMessages(false)
                .securitySchemes(singletonList(apiKey()))
                .securityContexts(singletonList(securityContext()))
                .enableUrlTemplating(false)//URL에 "}"가 %7B Encode 되어서 URL에 Attach되어져 false 수정
                .tags(new Tag("API Service", "All apis relating to RAP"));
                //.additionalModels(typeResolver.resolve(AdditionalModel.class));
    }

    private ApiInfo apiEndPointsInfo() {
        return new ApiInfoBuilder()
                .title("Decide REST API")
                .description("This documents describes about decide version 7 REST API")
                .contact(new Contact("DongSik.Shin", "???", "dongsshin@lgcns.com"))
                .license("Apache 2.0")
                .version("v1")
                .build();
    }
    private SecurityContext securityContext() {
        return SecurityContext.builder()
                .securityReferences(defaultAuth())
                //.forPaths(PathSelectors.regex("/anyPath.*"))
                .forPaths(PathSelectors.any())
                .build();
    }
    private SecurityScheme apiKey() {
        List<SecurityScheme> securitySchemes = new ArrayList<SecurityScheme>();
        return new ApiKey("JWT", "Authorization", "header");
    }
    List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope
                = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return singletonList(new SecurityReference("JWT", authorizationScopes));
    }
    @Bean
    SecurityConfiguration security() {
        return SecurityConfigurationBuilder.builder()
                .clientId("test-app-client-id")
                .clientSecret("test-app-client-secret")
                .realm("test-app-realm")
                .appName("test-app")
                .scopeSeparator(",")
                .additionalQueryStringParams(null)
                .useBasicAuthenticationWithAccessCodeGrant(false)
                .enableCsrfSupport(false)
                .build();
    }
    @Bean
    UiConfiguration uiConfig() {
        return UiConfigurationBuilder.builder()
                .deepLinking(true)
                .displayOperationId(false)
                .defaultModelsExpandDepth(1)
                .defaultModelExpandDepth(1)
                .defaultModelRendering(ModelRendering.MODEL)
                .displayRequestDuration(false)
                .docExpansion(DocExpansion.NONE)
                .filter(false)
                .maxDisplayedTags(null)
                .operationsSorter(OperationsSorter.ALPHA)
                .showExtensions(false)
                .showCommonExtensions(false)
                .tagsSorter(TagsSorter.ALPHA)
                .supportedSubmitMethods(UiConfiguration.Constants.DEFAULT_SUBMIT_METHODS)
                .validatorUrl(null)
                .build();
    }
    /*
    private List<springfox.documentation.spi.service.contexts.SecurityContext> securityContext() {
        List<springfox.documentation.spi.service.contexts.SecurityContext> list = new ArrayList<springfox.documentation.spi.service.contexts.SecurityContext>();
        list.add(springfox.documentation.spi.service.contexts.SecurityContext.builder()
                .securityReferences(defaultAuth()) .forPaths(PathSelectors.any()) .build());
        return list;
    }
    private List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        List<SecurityReference> list = new ArrayList<SecurityReference>();
        list.add(new SecurityReference("JWT", authorizationScopes));
        return list;
    }
*/

    /*
    private SecurityContext securityContext() {
        Predicate<OperationContext> selector = new Predicate<OperationContext>();
        return springfox.documentation.spi.service.contexts.SecurityContext.builder()
                .securityReferences(defaultAuth()).operationSelector()
                .forPaths(PathSelectors.any()) .build();
    }
    */
    /*
    List<SecurityReference> defaultAuth() {
        AuthorizationScope authorizationScope = new AuthorizationScope("global", "accessEverything");
        AuthorizationScope[] authorizationScopes = new AuthorizationScope[1];
        authorizationScopes[0] = authorizationScope;
        return Lists.newArrayList(new SecurityReference("JWT", authorizationScopes));
    }
    */
}