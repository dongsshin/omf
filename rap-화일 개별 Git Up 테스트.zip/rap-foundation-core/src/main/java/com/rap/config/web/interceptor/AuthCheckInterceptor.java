package com.rap.config.web.interceptor;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.net.URI;
import java.util.Map;

@Component
public class AuthCheckInterceptor extends UrlPatternInterceptorAdapter {
    private static final Logger log = LoggerFactory.getLogger(AuthCheckInterceptor.class);
    public boolean checkHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception{
    	log.info("*************************************AuthCheckInterceptor********************************************");
        //HttpSession session = request.getSession(false);
        //UserSessionVO userSessionVO = (UserSessionVO)HttpSessionUtil.getAttribute(session, GlobalConstants.SESSION_USER_INFO);
        ///if (userSessionVO != null && userSessionVO != null) {
            String url = request.getRequestURI();
        String dd = request.getQueryString();
            String method = request.getMethod();
            String contextPath = request.getContextPath();
            String name = HandlerMapping.URI_TEMPLATE_VARIABLES_ATTRIBUTE;
        ServletUriComponentsBuilder builder = ServletUriComponentsBuilder.fromCurrentRequestUri();
        URI newUri = builder.build().toUri();

        Map<String, String> uriVars = (Map<String, String>) request.getAttribute(name);
            String action = url.substring(contextPath.length());
            action = action.substring(action.lastIndexOf("/") + 1,action.lastIndexOf("?") > 0 ? action.lastIndexOf("?") - 1 : action.length());
            //if (action != null) {
            //    boolean isAuth = true;
            //    if (!isAuth) throw new OmfNoAuthorityException(HttpStatus.INTERNAL_SERVER_ERROR,"frame.error.notauthorized", new Object[] { request.getServletPath() });
            //}
        //}
        return true;
    }
}
