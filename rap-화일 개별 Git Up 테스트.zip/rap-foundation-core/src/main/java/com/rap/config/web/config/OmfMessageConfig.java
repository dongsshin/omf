package com.rap.config.web.config;

import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.framework.message.file.FileMessageSource;
import com.rap.omc.util.StrUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.MessageSourceAccessor;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

import java.util.Locale;

@Configuration

public class OmfMessageConfig {
	
//	@Autowired
//	DataSource schemaDataSource;
//	@Bean
//	public DatabaseMessageSource messageSource() {
//		DatabaseMessageSource databaseMessageSource = new DatabaseMessageSource();
//		databaseMessageSource.setDataSource(schemaDataSource);
//		databaseMessageSource.setDefaultQuery("SELECT PMSG MESSAGE, PLOCALE LOCALE, PCODE CODE FROM PSYSMESSAGE");
//		databaseMessageSource.setLoadType("preLoad");
//		databaseMessageSource.setTableName("PSYSMESSAGE");
//		databaseMessageSource.setCodeColumn("CODE");
//		databaseMessageSource.setMessageColumn("MESSAGE");
//		databaseMessageSource.setLocaleColumn("LOCALE");
//		databaseMessageSource.setParentMessageSource(fileMessageSource());
//		return databaseMessageSource;
//		
//	}
	@Bean
	public MessageSource messageSource() {
		FileMessageSource fileMessageSource = new FileMessageSource();

		String foundationMessage = PropertiesUtil.getString("message.foundation");
		if(StrUtil.isEmpty(foundationMessage)) throw new RuntimeException("message.foundation is not Define in System Property");
		String attributeMessage = "classpath:/messages/attribute";
		String moduleMessage = PropertiesUtil.getString("message.module");
		if(StrUtil.isEmpty(moduleMessage)) throw new RuntimeException("message.module is not Define in System Property");

		fileMessageSource.setBasenames(foundationMessage,
				                       attributeMessage,
				                       moduleMessage);
		/*
		fileMessageSource.setBasenames(//"classpath:/messages/message-foundation",
				                       "file:C:/root/nxrap/workspace/rap/rap-foundation-core/src/main/resources/messages/message-foundation",
				                       "classpath:/messages/message-project",
				                       "classpath:/messages/message-validator",
				                       "classpath:/messages/attribute");
        */
		//"file:C:/root/nxrap/workspace/rap/rap-foundation-core/src/main/resources/messages");

		fileMessageSource.setCacheSeconds(60);
		fileMessageSource.setLoadType("preLoad");
		fileMessageSource.setDefaultEncoding("UTF-8");
		fileMessageSource.setDefaultLocale(Locale.US);
		fileMessageSource.setUseCodeAsDefaultMessage(true);
		return fileMessageSource;
	}
	@Bean
	public LocalValidatorFactoryBean beanValidator() {
        LocalValidatorFactoryBean bean = new LocalValidatorFactoryBean();
        bean.setValidationMessageSource(messageSource());
        return bean;
	}
	@Bean
	public MessageSourceAccessor messageSourceAccessor(){
	    return new MessageSourceAccessor(messageSource());
	}

}
