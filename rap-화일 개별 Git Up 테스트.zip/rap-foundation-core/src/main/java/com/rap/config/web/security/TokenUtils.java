package com.rap.config.web.security;

import com.rap.omc.core.util.spring.SpringFactoryUtil;
import com.rap.omc.foundation.user.service.FoundationUserDetailsService;
import io.jsonwebtoken.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;

import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;
import java.security.Key;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
//@Component
//@RequiredArgsConstructor

public class TokenUtils {
    private static final String secretKey = "ThisIsA_SecretKeyForJwtExample";
    public static final int EXPIRATION_TIME_DAYS = 30; // 30 days
    public static final String TOKEN_PREFIX = "Bearer ";
    public static final String HEADER_STRING = "Authorization";
    public static final String HEADER_GLOBAL_TRANSACTION_ID = "_GlobalTransactionId_";
    public static final String HEADER_GLOBAL_TRANSACTION_FLAG = "_GlobalTransactionFlag_";

    public static final String MAP_KEY_MESSAGE = "message";
    public static final String MAP_KEY_RESULT = "checkResult";
    public static final String MAP_KEY_ERROR = "error";

    private FoundationUserDetailsService foundationUserDetailsService;
    private static TokenUtils sInstance;

    private synchronized static TokenUtils getInstance(){
        if (sInstance == null) {
            sInstance = new TokenUtils();
            sInstance.foundationUserDetailsService = (FoundationUserDetailsService) SpringFactoryUtil.getBean("foundationUserDetailsService");
        }
        return sInstance;
    }
    public static String generateJwtToken(OmfAuthenticationToken token, int expiredDaysAfter) {
        JwtBuilder builder = Jwts.builder()
                .setSubject(token.getUsername())
                .setHeader(createHeader())
                .setClaims(createClaims(token))
                .setExpiration(createExpireDateForOneYear(expiredDaysAfter))
                .signWith(SignatureAlgorithm.HS256, createSigningKey());
        return builder.compact();
    }
    public static HashMap<String, Object> checkValidToken(String token) {
        HashMap<String,Object> map = new HashMap<String,Object>();
        try {
            Claims claims = getClaimsFormToken(token);
            if(claims.getExpiration().before(new Date())) {
                map.put(MAP_KEY_MESSAGE,"Token Expired");
                map.put(MAP_KEY_RESULT,false);
            }else{
                map.put(MAP_KEY_MESSAGE,"Success");
                map.put(MAP_KEY_RESULT,true);
            }
        } catch (ExpiredJwtException exception) {
            map.put(MAP_KEY_MESSAGE,"Token Expired");
            map.put(MAP_KEY_RESULT,false);
            map.put(MAP_KEY_ERROR,exception);
        } catch (JwtException exception) {
            map.put(MAP_KEY_MESSAGE,"Token Tampered");
            map.put(MAP_KEY_RESULT,false);
            map.put(MAP_KEY_ERROR,exception);
        } catch (NullPointerException exception) {
            map.put(MAP_KEY_MESSAGE,"Token null");
            map.put(MAP_KEY_RESULT,false);
            map.put(MAP_KEY_ERROR,exception);
        }
        return map;
    }
    public static Authentication createAuthenticationFromToken(String token) {
        UserDetails userDetails = getInstance().foundationUserDetailsService.loadUserByUsername(getUserIdFromToken(token));
        return new UsernamePasswordAuthenticationToken(userDetails, null, userDetails.getAuthorities());
    }
    public static String getTokenFromHeader(String header) {
        return header.split(" ")[1];
    }

    private static Date createExpireDateForOneYear(int expiredDaysAfter) {
        Calendar c= Calendar.getInstance();
        c.add(Calendar.DATE, expiredDaysAfter);
        //c.add(Calendar.DATE, EXPIRATION_TIME_DAYS);
        return c.getTime();
    }
    private static Map<String, Object> createHeader() {
        Map<String, Object> header = new HashMap<>();
        header.put("typ", "JWT");
        header.put("alg", "HS256");
        header.put("regDate", System.currentTimeMillis());
        return header;
    }
    private static Map<String, Object> createClaims(OmfAuthenticationToken token) {
        Map<String, Object> claims = new HashMap<>();
        claims.put("id", token.getUsername());
        claims.put("role", token.getAuthorities());
        return claims;
    }

    private static Key createSigningKey() {
        byte[] apiKeySecretBytes = DatatypeConverter.parseBase64Binary(secretKey);
        return new SecretKeySpec(apiKeySecretBytes, SignatureAlgorithm.HS256.getJcaName());
    }

    public static Claims getClaimsFormToken(String token) {
        return Jwts.parser().setSigningKey(DatatypeConverter.parseBase64Binary(secretKey))
                .parseClaimsJws(token).getBody();
    }

    public static String getUserIdFromToken(String token) {
        Claims claims = getClaimsFormToken(token);
        return (String) claims.get("id");
    }

}