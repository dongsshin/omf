package com.rap.config.web.resolver;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.omc.core.util.omc.RequestBodyThreadLocalUtil;
import com.rap.omc.framework.annotation.OmfJsonResolver;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import net.sf.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.MethodParameter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;

import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.lang.annotation.Annotation;

public class OmfMethodArgumentResolver implements HandlerMethodArgumentResolver{
    private static final Logger log = LoggerFactory.getLogger(OmfMethodArgumentResolver.class);
    private static final String JSON_REQUEST_BODY = "JSON_REQUEST_BODY";

    @Override
    public boolean supportsParameter(MethodParameter parameter){
        log.info("RapMethodArgumentResolver supportsParameter : " + parameter.getParameterName());
        return parameter.hasParameterAnnotation(OmfJsonResolver.class);
    }
    @Override
    public Object resolveArgument(MethodParameter methodParameter, ModelAndViewContainer mavContainer,
                                  NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception{
        String jsonBody = this.getRequestBody(webRequest);
        if(StrUtil.isEmpty(jsonBody)){
            jsonBody = RequestBodyThreadLocalUtil.get(RequestBodyThreadLocalUtil.KEY.jsonBody);
        }
        JSONObject jsonObj = JSONObject.fromObject(jsonBody);
        if(!NullUtil.isNull(jsonObj.getJSONObject(JSON_REQUEST_BODY))){
            jsonObj = jsonObj.getJSONObject(JSON_REQUEST_BODY);
        }
        for (Annotation annotation : methodParameter.getParameterAnnotations()) {
            if (annotation.annotationType().equals(OmfJsonResolver.class)) {
                ObjectMapper om = new ObjectMapper();
                OmfJsonResolver requestDataset = (OmfJsonResolver)annotation;
                String dataSetId = requestDataset.value();
                if(StrUtil.isEmpty(dataSetId)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Request Parameter Mapping Error!");
                Object dataSetObj = jsonObj.get(dataSetId);
                return om.readValue(dataSetObj.toString(), methodParameter.getParameterType());
            }
        }
        return new Object();
    }
    private String getRequestBody(NativeWebRequest webRequest){
        HttpServletRequest servletRequest = webRequest.getNativeRequest(HttpServletRequest.class);
        String jsonBodyStr = (String) webRequest.getAttribute(JSON_REQUEST_BODY, NativeWebRequest.SCOPE_REQUEST);
        if (jsonBodyStr==null){
            try {
                BufferedReader reader = servletRequest.getReader();
                String line = null;
                StringBuffer strBuf = new StringBuffer();
                while((line = reader.readLine()) != null) strBuf.append(line);
                jsonBodyStr = strBuf.toString();
                if(!StrUtil.isEmpty(jsonBodyStr)) RequestBodyThreadLocalUtil.set(RequestBodyThreadLocalUtil.KEY.jsonBody,jsonBodyStr);
            } catch (IOException e) {
                throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,e);
            }
        }
        return jsonBodyStr;
    }
}