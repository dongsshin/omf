package com.rap.config.web.security.filter;

import com.rap.config.web.security.TokenUtils;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.core.util.omc.UserSessionUtil;
import com.rap.omc.foundation.user.model.UserSessionVO;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.core.StopWatch;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;

public class OmfJWTAuthorizationFilter extends BasicAuthenticationFilter {
    private static final Logger log = LoggerFactory.getLogger(OmfJWTAuthorizationFilter.class);
    public OmfJWTAuthorizationFilter(AuthenticationManager authenticationManager) {
        super(authenticationManager);
    }
    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws IOException, ServletException {
        String header = request.getHeader(TokenUtils.HEADER_STRING);
        String url = request.getRequestURL().toString();
        String uri = request.getRequestURI();
        //Token 없이 수행되어지는 것 Check
        if(!(noFoundationURICheck(uri) || noModuleURICheck(uri))){
            log.trace("url:" + url);
            if(StrUtil.isEmpty(header)) throw new OmfFoundationException(HttpStatus.FORBIDDEN,"[Access Error]Header(Token) empty.");
            if(!header.startsWith(TokenUtils.TOKEN_PREFIX)) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"[Access Error]Invalid Token.");
            Authentication authentication = getUsernamePasswordAuthentication(request);
            SecurityContextHolder.getContext().setAuthentication(authentication);
        }else{
            log.trace("Token Check Skipped:" + uri);
        }
        chain.doFilter(request, response);
    }
    private boolean noModuleURICheck(String uri){
        String uriList = PropertiesUtil.getString("module.token.no.uri");
        if(StrUtil.isEmpty(uriList)) return false;
        return noURICheck(uriList,uri);
    }
    private boolean noFoundationURICheck(String uri){
        String uriList = PropertiesUtil.getString("foundation.token.no.uri");
        if(StrUtil.isEmpty(uriList)) return false;
        return noURICheck(uriList,uri);
    }
    private boolean noURICheck(String uriList,String uri){
        if(StrUtil.isEmpty(uriList)) return false;
        String[] uriArray = uriList.split(",");
        boolean no = false;
        for(int i = 0; i < uriArray.length; i++){
            if(!StrUtil.isEmpty(uriArray[i])){
                if(uriArray[i].endsWith("**")){
                    String tempUri = uriArray[i].substring(0,uriArray[i].length()-2);
                    if(uri.indexOf(tempUri) >= 0) return true;
                }else {
                    if(uri.endsWith(uriArray[i])) return true;
                }
            }
        }
        return false;
    }
    private Authentication getUsernamePasswordAuthentication(HttpServletRequest request) {
        UsernamePasswordAuthenticationToken authToken = null;
        String tokenString = request.getHeader(TokenUtils.HEADER_STRING);
        StopWatch stopWatch = new StopWatch();
        boolean trace = log.isTraceEnabled();
        if(!StrUtil.isEmpty(tokenString)){
            if(trace) log.trace("Session Auto Refresh Elapsed1: " + stopWatch.getElapsed() + " ms");
            String token = TokenUtils.getTokenFromHeader(tokenString);
            HashMap<String,Object> map = TokenUtils.checkValidToken(token);
            if(trace) log.trace("Session Auto Refresh Elapsed2: " + stopWatch.getElapsed() + " ms");
            if((boolean)map.get(TokenUtils.MAP_KEY_RESULT)){
                String userId = TokenUtils.getUserIdFromToken(token);
                if(trace) log.trace("Session Auto Refresh Elapsed3: " + stopWatch.getElapsed() + " ms");
                if(!StrUtil.isEmpty(userId)){
                    UserSessionVO userSessionVO = UserSessionUtil.getUserSessionVOFromRedis(userId);
                    if(trace) log.trace("Session Auto Refresh Elapsed4: " + stopWatch.getElapsed() + " ms");
                    String timeStamp = FoundationUserUtil.getTimeStamp(userId);
                    if(trace) log.trace("Session Auto Refresh Elapsed4-1: " + stopWatch.getElapsed() + " ms");
                    //Redis에 사용자정보가 없거나 Timestamp가 다르면 다시 User정보를 DB에서 읽어 Session정보와 Redis에 반영한다.
                    if(NullUtil.isNull(userSessionVO) || !userSessionVO.getTimeStamp().equals(timeStamp)){
                        //Ehcache에 해당 사용자 정보가 들어있을 수 있으므로 DB에서 읽기전에 해당 사용자에 대한 Ehcache를 Clear한다.
                        FoundationUserUtil.evictCacheForUser(userId);
                        if(trace) log.trace("Session Auto Refresh Elapsed5: " + stopWatch.getElapsed() + " ms");
                        userSessionVO = UserSessionUtil.refreshUserSession(userId);
                        if(trace) log.trace("Session Auto Refresh Elapsed6: " + stopWatch.getElapsed() + " ms");
                    }else{
                        //Redis의 정보로 UserSession Bean을 Refresh한다.
                        UserSessionUtil.refreshUserSession(userSessionVO);
                        log.trace("Session Auto Refresh Elapsed7: " + stopWatch.getElapsed() + " ms");
                    }
                    request.setAttribute(GlobalConstants.SESSION_VO_USER_INFO,userSessionVO);
                    List<GrantedAuthority> list = (List<GrantedAuthority>) makeGrantedAuthority(userSessionVO.getRoleSet());
                    if(trace) log.trace("Session Auto Refresh Elapsed8: " + stopWatch.getElapsed() + " ms");
                    authToken = new UsernamePasswordAuthenticationToken(userId,null,list);
                    if(trace) log.trace("Session Auto Refresh Elapsed9: " + stopWatch.getElapsed() + " ms");
                }else{
                    throw new OmfFoundationException(HttpStatus.FORBIDDEN,"[Access Error]Invalid Token(User Id)");
                }
            }else{
                throw new OmfFoundationException(HttpStatus.FORBIDDEN,((Boolean)map.get(TokenUtils.MAP_KEY_RESULT)).toString(),(Exception)map.get(TokenUtils.MAP_KEY_ERROR));
            }
        }else{
            throw new OmfFoundationException(HttpStatus.FORBIDDEN,"[Access Error]Invalid Token(Empty)");
        }
        return authToken;
    }
    private List<? extends GrantedAuthority> makeGrantedAuthority(List<LinkedHashMap> roles){
        List<GrantedAuthority> list = new ArrayList<>();
        for(LinkedHashMap role : roles){
            list.add(new SimpleGrantedAuthority((String)role.get("authority")));
        }
        return list;
    }
    private List<? extends GrantedAuthority> makeGrantedAuthority(Set<String> roleSet){
        List<GrantedAuthority> list = new ArrayList<>();
        for(String role : roleSet){
            list.add(new SimpleGrantedAuthority(role));
        }
        return list;
    }
}