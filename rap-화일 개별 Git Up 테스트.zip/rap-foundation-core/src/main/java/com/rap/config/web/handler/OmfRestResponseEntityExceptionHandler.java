package com.rap.config.web.handler;

import com.rap.omc.util.PropertiesUtil;
import com.rap.omc.framework.exception.OmfBaseException;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.core.DateUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@RestControllerAdvice

public class OmfRestResponseEntityExceptionHandler extends ResponseEntityExceptionHandler {
    @ExceptionHandler(value = {Exception.class })
    protected ResponseEntity<Object> handleConflict(Exception ex, WebRequest request) {
        ex.printStackTrace();
        Throwable oe = ex.getCause();
        Map<String, Object> map = new HashMap<String, Object>();
        HttpStatus  defaultStatus = HttpStatus.INTERNAL_SERVER_ERROR;
        boolean includeTrace = PropertiesUtil.getBoolean("rest.call.return.include.trace");
        if(ex instanceof OmfResponseStatusException) {
            OmfResponseStatusException re = (OmfResponseStatusException)ex;
            map.put("message"      , re.getReason());
            map.put("statusCode"   , re.getStatus());
            map.put("status"       , re.getStatus().value());
            map.put("messageCode"  , re.getMessageCode());
            if(includeTrace) map.put("rootCause"    , re.getRootCause());
            createRootCause(re,map);
        }else if(ex instanceof ResponseStatusException) {
            ResponseStatusException re = (ResponseStatusException) ex;
            map.put("message"      , re.getReason());
            map.put("statusCode"   , re.getStatus());
            map.put("status"       , re.getStatus().value());
            map.put("messageCode"  , "N/A");
            if(includeTrace) map.put("rootCause"    , re.getRootCause());
            createRootCause(re,map);
        }else if(ex instanceof OmfBaseException) {
            OmfBaseException re = (OmfBaseException)ex;
            map.put("message"      , re.getMessage());
            map.put("statusCode"   , re.getHttpStatus());
            map.put("status"       , re.getHttpStatus().value());
            map.put("messageCode"  , re.getCode());
            if(includeTrace) map.put("rootCause"    , re.getRootCause());
            createRootCause(re,map);
        }else {
            map.put("message"      , ex.getMessage());
            map.put("statusCode"   , "Not Defined");
            map.put("status"       , 999);
            map.put("messageCode"  , "N/A");
            if(includeTrace) map.put("rootCause"    , null);
            map.put("rootMessage"      , null);
            map.put("rootMessageCode"  , null);
        }
        map.put("timestamp", DateUtil.converDateFormat(new Date(), DateUtil.DEFAULT_DATETIME_FORMAT));
        return handleExceptionInternal(ex, map, new HttpHeaders(), defaultStatus, request);
    }
    private void createRootCause(OmfResponseStatusException e, Map<String, Object> map){
        Throwable rre = e.getRootCause();
        if(!NullUtil.isNull(rre)){
            if(rre instanceof OmfBaseException){
                OmfBaseException be = (OmfBaseException)rre;
                map.put("rootMessage"      , be.getMessage());
                map.put("rootMessageCode"  , be.getCode());
            }else{
                map.put("rootMessage"      , rre.getMessage());
                map.put("rootMessageCode"  , "N/A");
            }
        }else{
            map.put("rootMessage"      , null);
            map.put("rootMessageCode"  , null);
        }
    }
    private void createRootCause(ResponseStatusException e, Map<String, Object> map){
        Throwable rre = e.getRootCause();
        if(!NullUtil.isNull(rre)){
            if(rre instanceof OmfBaseException){
                OmfBaseException be = (OmfBaseException)rre;
                map.put("rootMessage"      , be.getMessage());
                map.put("rootMessageCode"  , be.getCode());
            }else{
                map.put("rootMessage"      , rre.getMessage());
                map.put("rootMessageCode"  , "N/A");
            }
        }else{
            map.put("rootMessage"      , null);
            map.put("rootMessageCode"  , null);
        }
    }
    private void createRootCause(OmfBaseException e, Map<String, Object> map){
        Throwable rre = e.getRootCause();
        if(!NullUtil.isNull(rre)){
            if(rre instanceof OmfBaseException){
                OmfBaseException be = (OmfBaseException)rre;
                map.put("rootMessage"      , be.getMessage());
                map.put("rootMessageCode"  , be.getCode());
            }else{
                map.put("rootMessage"      , rre.getMessage());
                map.put("rootMessageCode"  , "N/A");
            }
        }else{
            map.put("rootMessage"      , null);
            map.put("rootMessageCode"  , null);
        }
    }
}