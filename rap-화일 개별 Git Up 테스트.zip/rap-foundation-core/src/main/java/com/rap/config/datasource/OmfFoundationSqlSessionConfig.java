package com.rap.config.datasource;


import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.dataaccess.mybatis.interceptor.OmfLimitCountInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.OmfMyBatisConvertMapInterceptor;
import com.rap.omc.dataaccess.mybatis.interceptor.OmfMyBatisPagingInterceptor;
import com.rap.omc.dataaccess.trace.OmfQueryLoggingInterceptor;
import com.rap.omc.util.PropertiesUtil;
import org.apache.ibatis.mapping.VendorDatabaseIdProvider;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;

import javax.sql.DataSource;


@Configuration
public class OmfFoundationSqlSessionConfig {
    private static final Logger log = LoggerFactory.getLogger(OmfFoundationSqlSessionConfig.class);
	@Bean(name = "foundationDataSource")
    public DataSource foundationDataSource() {
    	return new OmfAtomikosDataSourceBean("foundation");
    }
    
	@Bean(name = "foundationSqlSessionFactory")
    public SqlSessionFactory foundationSqlSessionFactory(DataSource foundationDataSource) throws Exception {
        
    	SqlSessionFactoryBean factoryBean = new SqlSessionFactoryBean();
       
        factoryBean.setDataSource(foundationDataSource);

        factoryBean.setMapperLocations(getResources());

        //Multi Database를 위한 환경 설정
        factoryBean.setDatabaseIdProvider(foundationDatabaseIdProvider());
        
        int sqlMaxCount = PropertiesUtil.getInt("foundation.maxSqlCount");
        log.info("foundation.maxSqlCount:" + sqlMaxCount);
        
        factoryBean.setPlugins(new Interceptor[]{
                new OmfQueryLoggingInterceptor(),
                new OmfLimitCountInterceptor(sqlMaxCount,false),
                new OmfMyBatisPagingInterceptor(),
                new OmfMyBatisConvertMapInterceptor()
        });
        factoryBean.getObject().getConfiguration().setMapUnderscoreToCamelCase(true);
        return factoryBean.getObject();
    }
    
	@Bean(name = "foundationSqlSession", destroyMethod = "clearCache")
    public SqlSession foundationSqlSession(SqlSessionFactory foundationSqlSessionFactory) {
        return new SqlSessionTemplate(foundationSqlSessionFactory);
    }
    @Bean
    VendorDatabaseIdProvider foundationDatabaseIdProvider() {
        return OmfDatabaseProviderUtil.databaseIdProvider();
    }
    private Resource[] getResources() throws Exception{
        PathMatchingResourcePatternResolver resolver = new PathMatchingResourcePatternResolver();
        //factoryBean.setMapperLocations(resolver.getResources("classpath:mybatis/mapper/foundation/*.xml"));
        Resource[] foundationResources = resolver.getResources(GlobalConstants.FOUNDATION_RESOURCE_LOCATION);
        Resource[] moduleResources = resolver.getResources(GlobalConstants.MODULE_RESOURCE_LOCATION);
        Resource[] resources = new Resource[foundationResources.length+moduleResources.length];

        int i = 0;
        for(int j = 0; j < foundationResources.length; j ++){
            resources[i++] = foundationResources[j];
        }
        for(int j = 0; j < moduleResources.length; j ++){
            resources[i++] = moduleResources[j];
        }
        return resources;
    }
}