/**
 * ===========================================
 * System Name : LGE GPDM
 * Program ID : BaseModel1.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.api.object.foundation.model;

import com.rap.omc.framework.exception.OmfFoundationException;
import org.springframework.http.HttpStatus;

import java.lang.reflect.Method;


/**
 * <pre>
 * Class : BaseModel
 * Description : TODO
 * </pre>
 * 
 * @author DongSik.Shin
 */
public class CPamBaseModel{
    public <T> T getAttribute(String attribute){
        StringBuffer methodBufStr = new StringBuffer();
        methodBufStr.append("get").append(attribute.substring(0, 1).toUpperCase()).append(attribute.substring(1));
        try {
            Method method = this.getClass().getMethod(methodBufStr.toString());
            return (T)method.invoke(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return(null);
    }
    public void setAttributeValue(String attribute, Object value){
        StringBuffer methodBufStr = new StringBuffer();
        methodBufStr.append("set").append(attribute.substring(0, 1).toUpperCase()).append(attribute.substring(1));
        try {
            Class<?>[] paramType = new Class<?>[1];
            Object[] sArguments = new Object[1];
            paramType[0] = value.getClass();
            sArguments[0] = value;
            Method method = this.getClass().getMethod(methodBufStr.toString(),paramType);
            method.invoke(this,sArguments);
        } catch (Exception e) {
            e.printStackTrace();
            throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cannot Set value" + value.toString() + ") for Attribute(" + attribute + ")");
        }
    }
}
