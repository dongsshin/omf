/**
 * ===========================================
 * System Name : LGE GPDM
 * Program ID : BaseModel1.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2014. 12. 9. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.api.object.foundation.model;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * <pre>
 * Class : CPamSearchPagingBaseModel
 * Description : TODO
 * </pre>
 * 
 * @author DongSik.Shin
 */
@Setter
@Getter
public class CPamSearchPagingBaseModel extends CPamSearchBaseModel{
    @Schema(example = "1",minimum = "1")
    private int zz1_targetRow = 1;
    @Schema(example = "30",maximum = "500",minimum = "10")
    private int zz2_rowSize = 30;
    @Schema(example = "1",minimum = "1")
    private int zz3_currentPage = 1;
    @Schema(example = "@this.[names] asc,@this.[modified] desc",minLength = 10)
    private String zz4_sortByPattern = "@this.[names] asc,@this.[modified] desc";
}