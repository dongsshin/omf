package com.rap.api.object.foundation.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

public abstract class FilesVOMixIn {
    @JsonIgnore
    abstract public void setCheckouted(String checkouted);
    @JsonIgnore
    abstract public void setModified(String modified);
    @JsonIgnore
    abstract public void setCreated(String created);
}
