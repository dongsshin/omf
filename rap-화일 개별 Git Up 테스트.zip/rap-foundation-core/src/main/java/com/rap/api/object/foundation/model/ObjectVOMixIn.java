package com.rap.api.object.foundation.model;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.HashMap;

public abstract class ObjectVOMixIn {
    @JsonIgnore
    abstract public String getRecordMode();
    @JsonIgnore
    abstract public String getUniqueString() ;
    @JsonIgnore
    abstract public String getUniqueStringParent();
    @JsonIgnore
    abstract public String getDataFindingDirection();
    @JsonIgnore
    abstract public int getExplodedDepth();
    @JsonIgnore
    abstract public HashMap<String, Object> getOutData();
    @JsonIgnore
    abstract public String getDbmsTable();
    @JsonIgnore
    abstract public String getSql();
    @JsonIgnore
    abstract public String getColumns();
}
