# Getting Started

## [수정불가영역]전체 프로젝트에 대한 기반이 되는 Module(Foundation)
Database와의 연결 및 실제 Object에 대한 Handling(CRUD)를 담당하는 영역
각종 Util 및 API를 제공한다.
