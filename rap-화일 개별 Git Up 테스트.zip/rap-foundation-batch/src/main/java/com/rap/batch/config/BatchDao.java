package com.rap.batch.config;


import com.rap.config.datasource.dao.GenericDao;
import com.rap.omc.dataaccess.paging.executer.MyBatisPagingExecutor;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class BatchDao extends GenericDao implements InitializingBean{
	@Autowired
	SqlSession bathSqlSession;
	@Autowired
	MyBatisPagingExecutor myBatisPagingExecutor;
	
	@Override
	public void afterPropertiesSet() throws Exception{
		if (super.genricSqlSession == null) super.genricSqlSession = bathSqlSession;
		if (super.pagingExecutor == null) super.pagingExecutor = myBatisPagingExecutor;
	}
}