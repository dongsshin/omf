package com.rap.order.controller;

import com.constants.GlobalCommonConstants;
import com.rap.api.object.order.dom.OrderDetail;
import com.rap.api.object.order.model.OrderDetailVO;
import com.rap.api.object.order.model.OrderMasterVO;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.PagingUtil;
import com.rap.order.model.CParmOrderDetailVO;
import com.rap.order.model.CParmSearchOrderMasterVO;
import com.rap.order.service.ExampleOrderService;
import io.swagger.v3.oas.annotations.Operation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController

public class ExampleOrderController extends RestBaseController {

    @Autowired
    private ExampleOrderService exampleOrderService;
    @Autowired
    private UserSession userSession;
    @Autowired
    ApplicationEventPublisher eventPublisher;
    /**************************************★★★Order Master Create ★★★ **********************************************/
    @Operation(summary  = "Sample를 Creation하는 API",
            description  = "Sample 제작을 위한 Request를 생성 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"className\":\"SampleRequest\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/example/order/master",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createOrderMaster(@RequestBody OrderMasterVO orderMasterVO) {
        try{
            OrderMasterVO orderVO = exampleOrderService.txnCreateOrderMaster(orderMasterVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,orderVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @Operation(summary  = "Sample를 수정하는 API",
            description  = "Sample Request를 수정 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"obid\":\"$obid\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    /**************************************★★★Order Master Modify ★★★ **********************************************/
    @RequestMapping(value = "/example/order/master",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyOrderMaster(@RequestBody OrderMasterVO orderMasterVO) {
        try{
            OrderMasterVO orderVO = exampleOrderService.txnModifyOrderMaster(orderMasterVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,orderVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    /**************************************★★★Order Master Delete ★★★ **********************************************/
    @RequestMapping(value = "/example/order/master",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> deleteOrderMaster(@RequestBody OrderMasterVO orderMasterVO) {
        try{
            OrderMasterVO orderVO = exampleOrderService.txnDeleteOrderMaster(orderMasterVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,orderVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    /**************************************★★★Order Master Get ★★★ **********************************************/
    @RequestMapping(value = "/example/order/master/{names}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getSampleRequest(@PathVariable(name = "names") String names) {
        try{
            OrderMasterVO orderVO = exampleOrderService.getOrderMaster(names);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,orderVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @Operation(summary  = "Sample를 Creation하는 API",
            description  = "Sample 제작을 위한 Request를 생성 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"className\":\"SampleRequest\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"names\":\"TEST-000001\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/example/order/masters",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getOrderMasterList(@RequestParam(name = "namePattern"        ,required = false) String namePattern,
                                                                @RequestParam(name = "partNoPattern"      ,required = false) String partNoPattern,
                                                                @RequestParam(name = "partDescription"    ,required = false) String partDescription,
                                                                @RequestParam(name = "partSpecification"  ,required = false) String partSpecification,
                                                                @RequestParam(name = "plantName"          ,required = false) String plantName,
                                                                @RequestParam(name = "states"             ,required = false) String states,
                                                                @RequestParam(name = "creationDateFrom"   ,required = false, defaultValue = "2020-01-01") String creationDateFrom,
                                                                @RequestParam(name = "creationDateTo"     ,required = false, defaultValue = "2022-12-21") String creationDateTo,
                                                                @RequestParam(name = "creator"            ,required = false, defaultValue = "me") String creator,
                                                                @RequestParam(name = "modifier"           ,required = false, defaultValue = "me") String modifier,
                                                                @RequestParam(name ="zz1_targetRow"       ,required = true ,defaultValue = "1") int targetRow,
                                                                @RequestParam(name ="zz2_rowSize"         ,required = true ,defaultValue = "30") int rowSize,
                                                                @RequestParam(name ="zz3_currentPage"     ,required = true ,defaultValue = "1") int currentPage,
                                                                @RequestParam(name ="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{
            PagingEntity pagingEntity = new PagingEntity(targetRow,rowSize,currentPage,sortByPattern);
            OrderMasterVO searchVO = new OrderMasterVO();

            if(!StrUtil.isEmpty(modifier) && modifier.equals("me")) modifier = userSession.getUserId();
            if(!StrUtil.isEmpty(creator) && creator.equals("me"))   creator = userSession.getUserId();

            searchVO.setNames(namePattern);
            searchVO.setStates(states);
            searchVO.setModifier(modifier);
            searchVO.setCreator(creator);
            searchVO.setOutDataAttributeValue("creationDateFrom",creationDateFrom);
            searchVO.setOutDataAttributeValue("creationDateTo",creationDateTo);

            List<OrderMasterVO> orderMasterVOList = exampleOrderService.getOrderMasterList(searchVO,pagingEntity);
            OmfPagingList<OrderMasterVO> pagingList = (OmfPagingList<OrderMasterVO>)orderMasterVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingList.getPagingEntity());
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,pagingList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @RequestMapping(value = "/example/order/masters",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getOrderMasterList(@RequestBody CParmSearchOrderMasterVO cParmSearchOrderMasterVO) {
        try{
            List<OrderMasterVO> sampleRequestVOList = exampleOrderService.getOrderMasterList(cParmSearchOrderMasterVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"map"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @RequestMapping(value = "/example/order/masters/paging",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getOrderMasterListPaging(@RequestBody CParmSearchOrderMasterVO cParmSearchOrderMasterVO) {
        try{
            //Paging에 대한 Validation을 수행한다.
            PagingUtil.validatePagingEntity(cParmSearchOrderMasterVO);
            //조회 조건에 맞는 Paging되어진 List를 조회한다.
            List<OrderMasterVO> orderMasterVOList = exampleOrderService.getOrderMasterList(cParmSearchOrderMasterVO);

            //결과를 가지고 리스트와 Paging Entity를 분리하여 Return한다.
            OmfPagingList<OrderMasterVO> pagingList = (OmfPagingList<OrderMasterVO>)orderMasterVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingList.getPagingEntity());
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,pagingList);

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }

    /**************************************★★★Order Detail Create ★★★ **********************************************/
    @Operation(summary  = "Sample를 Creation하는 API",
            description  = "Sample 제작을 위한 Request를 생성 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"className\":\"SampleRequest\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/example/order/detail",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createOrderDetail(@RequestBody CParmOrderDetailVO cParmOrderDetailVO) {
        try{
            OrderDetailVO detailVO = DomUtil.copyAttributeAll(cParmOrderDetailVO,new OrderDetailVO());
            detailVO.setOutDataAttributeValue("orderNo",cParmOrderDetailVO.getOrderNo());
            detailVO = exampleOrderService.txnCreateOrderDetail(detailVO);
            OrderDetail obj = DomUtil.toDom(detailVO.getObid());
            detailVO = obj.getVo();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,detailVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    @Operation(summary  = "Sample를 수정하는 API",
            description  = "Sample Request를 수정 한다.<br>" +
                    "■sampleRequestVO:<br>" +
                    "{<br>\"obid\":\"$obid\"," +
                    "<br>\"descriptions\":\"조기 Sample 제작 필요\"," +
                    "<br>\"partDescription\":\"Part Description\"," +
                    "<br>\"partNo\":\"PART-0001\"," +
                    "<br>\"partSpecification\":\"Part Specificaiton\"," +
                    "<br>\"plantName\":\"ZZZ.EKHQ\"," +
                    "<br>\"titles\":\"[PART-0001]Sample 제작요청\"" +
                    "<br>}"
    )
    /**************************************★★★Order Detail Modify ★★★ **********************************************/
    @RequestMapping(value = "/example/order/detail",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyOrderDetail(@RequestBody OrderDetailVO orderDetailVO) {
        try{
            OrderDetailVO detailVO = exampleOrderService.txnModifyOrderDetail(orderDetailVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,detailVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    /**************************************★★★Order Detail Delete ★★★ **********************************************/
    @RequestMapping(value = "/example/order/detail",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> deleteOrderDetail(@RequestBody OrderDetailVO orderDetailVO) {
        try{
            OrderDetailVO detailVO = exampleOrderService.txnDeleteOrderDetail(orderDetailVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,detailVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
    /**************************************★★★Order Detail Get ★★★ **********************************************/
    @RequestMapping(value = "/example/order/detail/{names}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getOrderDetail(@PathVariable(name = "names") String names) {
        try{
            OrderDetailVO detailVO = exampleOrderService.getOrderDetail(names);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,detailVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }


















}