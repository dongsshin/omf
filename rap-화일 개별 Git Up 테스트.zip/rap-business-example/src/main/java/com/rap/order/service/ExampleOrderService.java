package com.rap.order.service;


import com.rap.api.object.foundation.model.CPamSearchBaseModel;
import com.rap.api.object.order.model.OrderDetailVO;
import com.rap.api.object.order.model.OrderMasterVO;
import com.rap.omc.dataaccess.paging.model.PagingEntity;

import java.util.List;

public interface ExampleOrderService {
    public OrderMasterVO txnCreateOrderMaster(OrderMasterVO orderMasterVO);
    public OrderMasterVO txnModifyOrderMaster(OrderMasterVO orderMasterVO);
    public OrderMasterVO txnDeleteOrderMaster(OrderMasterVO orderMasterVO);
    public OrderMasterVO getOrderMaster(String names);
    public List<OrderMasterVO> getOrderMasterList(OrderMasterVO orderMasterVO, PagingEntity pagingEntity);
    public List<OrderMasterVO> getOrderMasterList(CPamSearchBaseModel searchVOIn);
    public OrderMasterVO getOrderMasterWithObid(String orderMasterObid);

    public OrderDetailVO txnCreateOrderDetail(OrderDetailVO orderDetailVO);
    public OrderDetailVO txnModifyOrderDetail(OrderDetailVO orderDetailVO);
    public OrderDetailVO txnDeleteOrderDetail(OrderDetailVO orderDetailVO);
    public OrderDetailVO getOrderDetail(String names);
    public OrderDetailVO getOrderDetailWithObid(String orderDetailObid);

}