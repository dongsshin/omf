package com.rap.order.service.impl;

import com.constants.GlobalCommonConstants;
import com.rap.api.object.foundation.model.CPamSearchBaseModel;
import com.rap.api.object.order.dom.OrderDetail;
import com.rap.api.object.order.dom.OrderMaster;
import com.rap.api.object.order.model.OrderDetailVO;
import com.rap.api.object.order.model.OrderMasterVO;
import com.rap.omc.controller.model.CParmHeaderVO;
import com.rap.omc.controller.service.FoundationRestService;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.util.foundation.CommonWorkflowHeaderUtil;
import com.rap.order.service.ExampleOrderService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service("exampleOrderService")

public class ExampleOrderServiceImpl implements ExampleOrderService {
    @Autowired
    private UserSession userSession;

    @Autowired
    private FoundationRestService foundationRestService;

    /****************************************Code Master*****************************************/
    @Override
    public OrderMasterVO txnCreateOrderMaster(OrderMasterVO orderMasterVO) {
        CParmHeaderVO cParmHeaderVO = CommonWorkflowHeaderUtil.makeHeaderInfo("url","plant","Comments");
        Map<String,Object> parmMap = new HashMap<String,Object>();
        parmMap.put(GlobalCommonConstants.MAP_KEY_WORKFLOW_HEADER_IN,cParmHeaderVO);
        OrderMaster orderMaster = DomUtil.toDom(orderMasterVO);
        orderMaster.createObject(parmMap);
        return orderMaster.getVo();
    }
    @Override
    public OrderMasterVO txnDeleteOrderMaster(OrderMasterVO orderMasterVO) {
        OrderMaster objDom = new OrderMaster( orderMasterVO.getObid() );
        objDom.deleteObject();
        return objDom.getVo();
    }
    @Override
    public OrderMasterVO txnModifyOrderMaster(OrderMasterVO orderMasterVO) {
        OrderMaster objDom = new OrderMaster( orderMasterVO.getObid());
        DomUtil.copyAttribute(orderMasterVO,objDom.getVo(), getDefaultOrderMasterUpdateAttr(orderMasterVO));
        objDom.modifyObject();
        objDom = new OrderMaster( orderMasterVO.getObid(),true);
        return objDom.getVo();
    }
    @Override
    public OrderMasterVO getOrderMaster(String names) {
        return OrderMaster.findOrderMaster(names);
    }
    @Override
    public OrderMasterVO getOrderMasterWithObid(String orderMasterObid) {
        OrderMaster obj = new OrderMaster(orderMasterObid,true);
        return obj.getVo();
    }

    @Override
    public List<OrderMasterVO> getOrderMasterList(OrderMasterVO orderMasterVO, PagingEntity pagingEntity) {
        return OrderMaster.getOrderMasterList(orderMasterVO, pagingEntity);
    }
    @Override
    public List<OrderMasterVO> getOrderMasterList(CPamSearchBaseModel searchVOIn) {
        return OrderMaster.getOrderMasterList(searchVOIn);
    }

    @Override
    public OrderDetailVO txnCreateOrderDetail(OrderDetailVO orderDetailVO) {
        OrderDetail orderDetail = DomUtil.toDom(orderDetailVO);
        orderDetail.createObject();
        return orderDetail.getVo();
    }
    @Override
    public OrderDetailVO txnModifyOrderDetail(OrderDetailVO orderDetailVO) {
        OrderDetail objDom = new OrderDetail( orderDetailVO.getObid());
        DomUtil.copyAttribute(orderDetailVO,objDom.getVo(), getDefaultOrderDetailUpdateAttr(orderDetailVO));
        objDom.modifyObject();
        objDom = new OrderDetail( orderDetailVO.getObid(),true);
        return objDom.getVo();
    }
    @Override
    public OrderDetailVO txnDeleteOrderDetail(OrderDetailVO orderDetailVO) {
        OrderDetail objDom = new OrderDetail(orderDetailVO.getObid());
        objDom.deleteObject();
        return objDom.getVo();
    }
    @Override
    public OrderDetailVO getOrderDetail(String names) {
        return OrderDetail.findOrderDetail(names);
    }
    @Override
    public OrderDetailVO getOrderDetailWithObid(String orderDetailObid) {
        OrderDetail obj = new OrderDetail(orderDetailObid,true);
        return obj.getVo();
    }
    private Set<String> getDefaultOrderMasterUpdateAttr(OrderMasterVO orderMasterVO){
        Set<String> updateAttrSet = new HashSet<String>();
        updateAttrSet.add("partNo");updateAttrSet.add("partDescription");
        updateAttrSet.add("partSpecification");updateAttrSet.add("plantName");
        updateAttrSet.add("descriptions");updateAttrSet.add("titles");
        return updateAttrSet;
    }
    private Set<String> getDefaultOrderDetailUpdateAttr(OrderDetailVO orderDetailVO){
        Set<String> updateAttrSet = new HashSet<String>();
        updateAttrSet.add("partNo");updateAttrSet.add("partDescription");
        updateAttrSet.add("partSpecification");updateAttrSet.add("plantName");
        updateAttrSet.add("descriptions");updateAttrSet.add("titles");
        return updateAttrSet;
    }
}