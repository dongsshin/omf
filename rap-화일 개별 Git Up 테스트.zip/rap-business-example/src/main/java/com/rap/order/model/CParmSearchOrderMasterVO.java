package com.rap.order.model;

import com.rap.api.object.foundation.model.CPamSearchBaseModel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CParmSearchOrderMasterVO extends CPamSearchBaseModel {
    private String partNo;
    private String partDescription;
    private String partSpecification;
    private String plantName;
}