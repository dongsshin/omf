package com.rap.order.model;

import com.rap.api.object.foundation.model.CPamBaseModel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CParmOrderDetailVO extends CPamBaseModel {
    private String        orderNo                                           ;
    private String        descriptions                                      ;
    private String        titles                                            ;
    private String        itemNo                                            ;
    private Integer       unitMoney                                         ;
    private Integer       quantity                                          ;
}