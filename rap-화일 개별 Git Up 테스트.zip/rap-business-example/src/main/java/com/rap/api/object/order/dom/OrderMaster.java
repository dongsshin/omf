/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : OrderMaster.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.11.16         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.order.dom;


import com.constants.IdGeneratorConstants;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.CPamSearchBaseModel;
import com.rap.api.object.order.model.OrderDetailVO;
import com.rap.api.object.order.model.OrderMasterVO;
import com.rap.example.constants.AppSchemaExampleConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.general.NameGeneratorUtil;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.PagingUtil;
import com.rap.order.model.CParmSearchOrderMasterVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;



public class OrderMaster extends BusinessObjectMaster {
    public OrderMaster(String obid){
        super(obid);
    }
    public OrderMaster(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public OrderMaster(OrderMasterVO vo){
        super(vo);
    }
    @Override
    public OrderMasterVO getVo(){
        return (OrderMasterVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeOrderMaster();
    }
    public void initializeOrderMaster(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "OrderMaster[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeStates(String newState, Map<String,Object> map){
        super.validateForChangeStates(newState,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeStates(String newState, Map<String,Object> map){
        super.preProcessForChangeStates(newState,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeStates(String oldState, Map<String,Object> map){
        super.postProcessForChangeStates(oldState,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }

    @Override
    protected void validateForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldLifeCycle, String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/
        this.getVo().setNames(NameGeneratorUtil.generateUniqueName(IdGeneratorConstants.ID_GENERATOR_ORDER_NO));
    }

    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/
        List<OrderDetailVO> orderDetailVOList = this.getOrderDetailList();
        map.put("orderDetailVOList",orderDetailVOList);
    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/
        List<OrderDetailVO> orderDetailVOList = (List<OrderDetailVO>)map.get("orderDetailVOList");
        if(!NullUtil.isNone(orderDetailVOList)) ObjectRoot.deleteObjectSetBatch(orderDetailVOList);
    }
    public static OrderMasterVO findOrderMaster(String names){
        return BusinessObjectMaster.findObject(AppSchemaExampleConstants.BIZCLASS_ORDERMASTER,names);
    }
    public List<OrderDetailVO> getOrderDetailList(){
        return this.getRelatedObjects(AppSchemaExampleConstants.RELCLASS_ORDEREDITEMS,AppSchemaExampleConstants.BIZCLASS_ORDERDETAIL, GlobalConstants.FLAG_TYPE_TO);
    }

    public static final List<OrderMasterVO> getOrderMasterList(OrderMasterVO searchVO, PagingEntity pagingEntity) {
        StringBuffer selectPatternBuf = new StringBuffer();
        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        boolean isPaging = NullUtil.isNull(pagingEntity) ? false : true;

        String namePattern = "*";

        if(!NullUtil.isNull(searchVO)){
            if(!StrUtil.isEmpty(searchVO.getNames())) namePattern = searchVO.getNames();
            if(!StrUtil.isEmpty(searchVO.getStates())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[states]", GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getStates());
            if(!StrUtil.isEmpty(searchVO.getModifier())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[modifier]", GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getModifier());
            if(!StrUtil.isEmpty(searchVO.getCreator())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[creator]", GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getCreator());
            if(!StrUtil.isEmpty((String)searchVO.getOutDataAttributeValue("creationDateFrom"))) {
                OqlBuilderUtil.constructDateWherePattern(wherePatternBuf, paramPatternBuf, "@this.[created]", GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN, (String)searchVO.getOutDataAttributeValue("creationDateFrom"));
            }
            if(!StrUtil.isEmpty((String)searchVO.getOutDataAttributeValue("creationDateTo"))) {
                OqlBuilderUtil.constructDateWherePattern(wherePatternBuf, paramPatternBuf, "@this.[created]", GlobalConstants.OQL_OPERATOR_LESS_EQTHAN, (String)searchVO.getOutDataAttributeValue("creationDateTo"));
            }
        }
        if(isPaging && StrUtil.isEmpty(pagingEntity.getOrderBy())) new OmfApplicationException(HttpStatus.BAD_REQUEST,"common.code.error.master.paging",new Object[]{"SortBy is Empty"});
        if(!StrUtil.isEmpty(pagingEntity.getOrderBy())) OqlBuilderUtil.addSortByPattern(selectPatternBuf,pagingEntity.getOrderBy());

        List<OrderMasterVO> result = null;
        if(isPaging){
            result = BusinessObjectMaster.findObjectPagingList(AppSchemaExampleConstants.BIZCLASS_ORDERMASTER,namePattern,"",selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),pagingEntity);
        }else{
            String sortByPattern = searchVO.getOutDataStringValue(GlobalConstants.MAP_KEY_sortByPattern);
            if(!StrUtil.isEmpty(sortByPattern)) OqlBuilderUtil.addSortByPattern(selectPatternBuf,sortByPattern);
            result = BusinessObjectMaster.findObjects(AppSchemaExampleConstants.BIZCLASS_ORDERMASTER,namePattern,"",selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),1000);
        }
        return result;
    }
    public static final List<OrderMasterVO> getOrderMasterList(CPamSearchBaseModel searchVOIn) {
        PagingEntity pagingEntity = PagingUtil.makePagingEntity(searchVOIn);
        boolean isPaging = NullUtil.isNull(pagingEntity) ? false : true;

        CParmSearchOrderMasterVO searchVO = new CParmSearchOrderMasterVO();
        DomUtil.copyAttribute(searchVOIn,searchVO);

        StringBuffer selectPatternBuf = new StringBuffer();
        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();

        String namePattern = "*";

        if(!NullUtil.isNull(searchVO)){
            if(!StrUtil.isEmpty(searchVO.getNames())) namePattern = searchVO.getNames();
            if(!StrUtil.isEmpty(searchVO.getPartNo())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[partNo]", GlobalConstants.OQL_OPERATOR_LIKE, searchVO.getPartNo());
            if(!StrUtil.isEmpty(searchVO.getPartDescription())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[partDescription]", GlobalConstants.OQL_OPERATOR_LIKE, searchVO.getPartDescription());
            if(!StrUtil.isEmpty(searchVO.getPartSpecification())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[partSpecification]", GlobalConstants.OQL_OPERATOR_LIKE, searchVO.getPartSpecification());
            if(!StrUtil.isEmpty(searchVO.getPlantName())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[plantName]", GlobalConstants.OQL_OPERATOR_LIKE, searchVO.getPlantName());
            if(!StrUtil.isEmpty(searchVO.getStates())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[states]", GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getStates());
            if(!StrUtil.isEmpty(searchVO.getModifier())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[modifier]", GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getModifier());
            if(!StrUtil.isEmpty(searchVO.getCreator())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[creator]", GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getCreator());
            if(!StrUtil.isEmpty(searchVO.getCreatedFrom())) {
                OqlBuilderUtil.constructDateWherePattern(wherePatternBuf, paramPatternBuf, "@this.[created]", GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN, searchVO.getCreatedFrom());
            }
            if(!StrUtil.isEmpty(searchVO.getCreatedTo())) {
                OqlBuilderUtil.constructDateWherePattern(wherePatternBuf, paramPatternBuf, "@this.[created]", GlobalConstants.OQL_OPERATOR_LESS_EQTHAN, searchVO.getCreatedTo());
            }
        }
        if(isPaging && StrUtil.isEmpty(pagingEntity.getOrderBy())) new OmfApplicationException(HttpStatus.BAD_REQUEST,"common.code.error.master.paging",new Object[]{"SortBy is Empty"});
        if(!StrUtil.isEmpty(pagingEntity.getOrderBy())) OqlBuilderUtil.addSortByPattern(selectPatternBuf,pagingEntity.getOrderBy());

        List<OrderMasterVO> result = null;
        if(isPaging){
            result = BusinessObjectMaster.findObjectPagingList(AppSchemaExampleConstants.BIZCLASS_SAMPLEREQUEST,namePattern,"",selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),pagingEntity);
        }else{
            String sortByPattern = pagingEntity.getOrderBy();
            if(!StrUtil.isEmpty(sortByPattern)) OqlBuilderUtil.addSortByPattern(selectPatternBuf,sortByPattern);
            result = BusinessObjectMaster.findObjects(AppSchemaExampleConstants.BIZCLASS_SAMPLEREQUEST,namePattern,"",selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),1000);
        }
        return result;
    }

}

