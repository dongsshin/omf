package com.rap.sample.model;

import com.rap.api.object.foundation.model.CPamSearchPagingBaseModel;
import lombok.Getter;
import lombok.Setter;
import org.springframework.web.bind.annotation.RequestParam;

@Setter
@Getter
public class CParmSearchSamplePagingVO extends CPamSearchPagingBaseModel {
    private String partNo;
    private String partDescription;
    private String partSpecification;
    private String plantName;
}
