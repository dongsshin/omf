package com.rap.sample.model;

import com.rap.api.object.foundation.model.CPamSearchBaseModel;
import com.rap.api.object.foundation.model.CPamSearchPagingBaseModel;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CParmSearchSampleVO extends CPamSearchBaseModel {
    private String partNo;
    private String partDescription;
    private String partSpecification;
    private String plantName;
}