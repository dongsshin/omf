package com.rap.example.constants;

import com.rap.omc.core.util.PropertyUtil;

public class AppSchemaExampleConstants{
    public static final String LIFECYCLE_ECO = PropertyUtil.getProperty("LIFECYCLE_ECO");
    public static final String LIFECYCLE_SAMPLE = PropertyUtil.getProperty("LIFECYCLE_SAMPLE");
    public static final String LIFECYCLE_ADMINISTRATIVE_OBJECT = PropertyUtil.getProperty("LIFECYCLE_ADMINISTRATIVE_OBJECT");
    public static final String LIFECYCLE_WITHOUT_STATE = PropertyUtil.getProperty("LIFECYCLE_WITHOUT_STATE");
    public static final String LIFECYCLE_ACTIVE_INACTIVE = PropertyUtil.getProperty("LIFECYCLE_ACTIVE_INACTIVE");
    public static final String LIFECYCLE_SAMPLE_REQUEST = PropertyUtil.getProperty("LIFECYCLE_SAMPLE_REQUEST");
    public static final String LIFECYCLE_ORDER = PropertyUtil.getProperty("LIFECYCLE_ORDER");
    public static final String STATE_ECO_1STPROCESSING = PropertyUtil.getProperty("STATE_ECO_1stProcessing");
    public static final String STATE_ECO_2NDPROCESSING = PropertyUtil.getProperty("STATE_ECO_2ndProcessing");
    public static final String STATE_ECO_CANCELLED = PropertyUtil.getProperty("STATE_ECO_Cancelled");
    public static final String STATE_ECO_IMPLEMENTED = PropertyUtil.getProperty("STATE_ECO_Implemented");
    public static final String STATE_ECO_INCOLLABORATION = PropertyUtil.getProperty("STATE_ECO_InCollaboration");
    public static final String STATE_ECO_RELEASE = PropertyUtil.getProperty("STATE_ECO_Release");
    public static final String STATE_ECO_WORKING = PropertyUtil.getProperty("STATE_ECO_Working");
    public static final String STATE_SAMPLE_WORKING = PropertyUtil.getProperty("STATE_SAMPLE_Working");
    public static final String STATE_ADMINISTRATIVE_OBJECT_EXISTS = PropertyUtil.getProperty("STATE_ADMINISTRATIVE_OBJECT_Exists");
    public static final String STATE_WITHOUT_STATE_EXISTS = PropertyUtil.getProperty("STATE_WITHOUT_STATE_Exists");
    public static final String STATE_ACTIVE_INACTIVE_ACTIVE = PropertyUtil.getProperty("STATE_ACTIVE_INACTIVE_Active");
    public static final String STATE_ACTIVE_INACTIVE_INACTIVE = PropertyUtil.getProperty("STATE_ACTIVE_INACTIVE_Inactive");
    public static final String STATE_SAMPLE_REQUEST_1STPROCESSING = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_1stProcessing");
    public static final String STATE_SAMPLE_REQUEST_2NDPROCESSING = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_2ndProcessing");
    public static final String STATE_SAMPLE_REQUEST_CANCELLED = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_Cancelled");
    public static final String STATE_SAMPLE_REQUEST_COMPLETED = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_Completed");
    public static final String STATE_SAMPLE_REQUEST_IFREQUESTED = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_IFRequested");
    public static final String STATE_SAMPLE_REQUEST_WORKING = PropertyUtil.getProperty("STATE_SAMPLE_REQUEST_Working");
    public static final String STATE_ORDER_CANCELLED = PropertyUtil.getProperty("STATE_ORDER_Cancelled");
    public static final String STATE_ORDER_COMPLETED = PropertyUtil.getProperty("STATE_ORDER_Completed");
    public static final String STATE_ORDER_CONFIRMED = PropertyUtil.getProperty("STATE_ORDER_Confirmed");
    public static final String STATE_ORDER_PROCESSING = PropertyUtil.getProperty("STATE_ORDER_Processing");
    public static final String STATE_ORDER_WORKING = PropertyUtil.getProperty("STATE_ORDER_Working");
    public static final String BIZCLASS_ORDERDETAIL = PropertyUtil.getProperty("BIZCLASS_ORDERDETAIL");
    public static final String BIZCLASS_SAMPLEREQUEST = PropertyUtil.getProperty("BIZCLASS_SAMPLEREQUEST");
    public static final String BIZCLASS_ORDERMASTER = PropertyUtil.getProperty("BIZCLASS_ORDERMASTER");
    public static final String RELCLASS_ORDEREDITEMS = PropertyUtil.getProperty("RELCLASS_ORDEREDITEMS");
}
