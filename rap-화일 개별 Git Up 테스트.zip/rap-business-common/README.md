# Getting Started

## 각 응용 모둘에서 공통으로 관리되어져야 하는 항목을 관리하는 모듈
현재 정의도어진 항목으로는 Code, 사용자, Organization 및 Workflow로 정의되어져 있음. 