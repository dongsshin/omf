/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : SubCodeMaster.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.10.30         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.relation.common.dom;


import com.rap.api.object.foundation.dom.BusinessRelationObject;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.relation.common.model.SubCodeMasterVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import lombok.extern.slf4j.Slf4j;

import java.util.List;
import java.util.Map;



public class SubCodeMaster extends BusinessRelationObject {
    public SubCodeMaster(String obid){
        super(obid);
    }
    public SubCodeMaster(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public SubCodeMaster(SubCodeMasterVO vo){
        super(vo);
    }
    @Override
    public SubCodeMasterVO getVo(){
        return (SubCodeMasterVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeSubCodeMaster();
    }
    public void initializeSubCodeMaster(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "SubCodeMaster[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.validateForCreate(fromObject,toObject,map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.preProcessForCreate(fromObject,toObject,map);
        /*code below*/
        ObjectRoot toObjectDom = new ObjectRoot(toObject);
        List<SubCodeMasterVO> list = toObjectDom.getRelationships(AppSchemaCommonConstants.RELCLASS_SUBCODEMASTER,AppSchemaCommonConstants.BIZCLASS_CODEMASTER, GlobalConstants.FLAG_TYPE_TO);
        int maxSeq = 0;
        for(SubCodeMasterVO vo : list){
            if(vo.getSequences() > maxSeq) maxSeq = vo.getSequences();
        }
        this.getVo().setSequences(maxSeq);
    }

    @Override
    protected void postProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.postProcessForCreate(fromObject,toObject,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }
}

