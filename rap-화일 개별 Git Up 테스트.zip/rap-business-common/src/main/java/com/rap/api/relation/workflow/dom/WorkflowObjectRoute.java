/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : WorkflowObjectRoute.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.09.09         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.relation.workflow.dom;


import com.rap.api.object.foundation.dom.BusinessRelationObject;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.relation.workflow.model.WorkflowObjectRouteVO;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import org.springframework.http.HttpStatus;

import java.util.Map;


public class WorkflowObjectRoute extends BusinessRelationObject {
    public WorkflowObjectRoute(String obid){
        super(obid);
    }
    public WorkflowObjectRoute(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public WorkflowObjectRoute(WorkflowObjectRouteVO vo){
        super(vo);
    }
    @Override
    public WorkflowObjectRouteVO getVo(){
        return (WorkflowObjectRouteVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeWorkflowObjectRoute();
    }
    public void initializeWorkflowObjectRoute(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "WorkflowObjectRoute[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.validateForCreate(fromObject,toObject,map);
        /*code below*/
        StateInfo stateInfo = (com.rap.omc.foundation.lifecycle.model.StateInfo)map.get("stateInfo");
        if(NullUtil.isNull(stateInfo)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"stateInfo is empty");
    }

    @Override
    protected void preProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.preProcessForCreate(fromObject,toObject,map);
        /*code below*/
        StateInfo stateInfo = (com.rap.omc.foundation.lifecycle.model.StateInfo)map.get("stateInfo");
        this.getVo().setRoutePurpose(stateInfo.getDefaultRoutePurpose());
        this.getVo().setRouteLifeCycle(stateInfo.getLifeCycleName());
        this.getVo().setRouteState(stateInfo.getStateName());
    }

    @Override
    protected void postProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.postProcessForCreate(fromObject,toObject,map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
}

