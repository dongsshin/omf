/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : WorkflowRoute.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.09.09         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.workflow.dom;


import com.constants.IdGeneratorConstants;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.foundation.dom.BusinessObjectRoot;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.api.object.workflow.model.WorkflowRouteVO;
import com.rap.api.object.workflow.model.WorkflowStepVO;
import com.rap.api.relation.workflow.dom.WorkflowStepNodeUser;
import com.rap.api.relation.workflow.model.WorkflowObjectRouteVO;
import com.rap.api.relation.workflow.model.WorkflowStepNodeUserVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.general.NameGeneratorUtil;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.schema.util.OmcApplicationConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.OqlParameter;
import com.rap.omc.util.foundation.CommonApiServiceUtil;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.util.WorkflowConstants;
import com.rap.workflow.util.WorkflowUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

import java.util.*;

public class WorkflowRoute extends Route {
    private static final Logger log = LoggerFactory.getLogger(WorkflowRoute.class);
    public WorkflowRoute(String obid){
        super(obid);
    }
    public WorkflowRoute(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public WorkflowRoute(WorkflowRouteVO vo){
        super(vo);
    }
    @Override
    public WorkflowRouteVO getVo(){
        return (WorkflowRouteVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeWorkflowRoute();
    }
    public void initializeWorkflowRoute(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "WorkflowRoute[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldLifeCycle, String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/
        StateInfo stateInfo = (StateInfo)map.get(WorkflowConstants.MAP_KEY_stateInfo);
        if(NullUtil.isNull(stateInfo)) throw new IllegalArgumentException("State info cannot be empty to create Route.");
        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get(WorkflowConstants.MAP_KEY_wfHeaderVO);
        if(NullUtil.isNull(wfHeaderVO)) throw new IllegalArgumentException("Workflow Header info cannot be empty to create Route.");
        List<ApprovalVO> approvalVOList = (List<ApprovalVO>)map.get(WorkflowConstants.MAP_KEY_approvalVOList);
        if(NullUtil.isNone(approvalVOList)) throw new IllegalArgumentException("Approval List info cannot be empty to create Route.");

        WorkflowHeader wfHeaderObj = new WorkflowHeader(wfHeaderVO);
        WorkflowRouteVO workflowRouteVO = wfHeaderObj.getRouteByTargetState(stateInfo.getStateName());
        if(!NullUtil.isNull(workflowRouteVO))  throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.duplicateRoute",  new Object[] { stateInfo.getStateName() });
    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/
        StateInfo stateInfo = (StateInfo)map.get(WorkflowConstants.MAP_KEY_stateInfo);
        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get(WorkflowConstants.MAP_KEY_wfHeaderVO);
        WorkflowHeader wfHeaderObj = new WorkflowHeader(wfHeaderVO);
        //최신 Target Object를 Setting한다.
        wfHeaderObj.setTargetObject();

        this.getVo().setNames(NameGeneratorUtil.generateUniqueName(IdGeneratorConstants.ID_GENERATOR_WORKFLOW_ROUTE_NAME));
        this.getVo().setRouteCompletionAction(stateInfo.getRouteCompleteAction());
        this.getVo().setDescriptions(wfHeaderObj.getTargetObject().getObid()+"_"+wfHeaderObj.getTargetObject().getNames()+"_"+stateInfo.getStateName());
        this.getVo().setRestartUpOnTaskRejection((WorkflowConstants.TRUE.equals(stateInfo.getRouteAutoStartOnReject())?true:false));
        this.getVo().setAutoStopOnRejection(stateInfo.getRouteHowToOnReject()); //Immediate , Deferred
        this.getVo().setRouteBasePurpose(stateInfo.getDefaultRoutePurpose());
        this.getVo().setStates(WorkflowConstants.STATES_TYPE_DEFINE);
        this.getVo().setTitles(wfHeaderObj.getNames());
        this.getVo().setOrganizations(ThreadLocalUtil.getString(ThreadLocalUtil.KEY.divisionUnit, "None"));
        if(!NullUtil.isNull(wfHeaderVO.getOutDataAttributeValue(WorkflowConstants.MAP_KEY_processTimestamp))) {
            this.getVo().setProcessTimestamp(wfHeaderVO.getOutDataAttributeValue(WorkflowConstants.MAP_KEY_processTimestamp));
        }
    }
    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/
        StateInfo stateInfo = (StateInfo)map.get(WorkflowConstants.MAP_KEY_stateInfo);
        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get(WorkflowConstants.MAP_KEY_wfHeaderVO);
        List<ApprovalVO> approvalVOList = (List<ApprovalVO>)map.get(WorkflowConstants.MAP_KEY_approvalVOList);
        createObjectRoute(wfHeaderVO,stateInfo);
        this.addStepsAndUsers(wfHeaderVO,stateInfo,approvalVOList);
    }
    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeStates(String newStates,Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/
    }
    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }
    /**************************************************************************************************************************/
    /** 이미 등록되어진 Step인경우에는 Add User만 실행되어짐                                                                       **/
    /**************************************************************************************************************************/
    public void addStepsAndUsers(WorkflowHeaderVO wfHeaderVO, StateInfo stateInfo, List<ApprovalVO> approvalVOList) {
        WorkflowUtil.sortApprovalVOList(approvalVOList);
        Map<Integer, List<ApprovalVO>> approvalVOListMapByStep = WorkflowUtil.filterApprovalVOListByStep(approvalVOList);
        boolean isFirst = true;
        Map<Integer, WorkflowStepVO> stepTreeMap = getStepTreeMap();
        validateForAddUsers(stepTreeMap,approvalVOListMapByStep.keySet());
        for (Integer stepSequences : approvalVOListMapByStep.keySet()) {
            WorkflowStepVO madeStepVO = stepTreeMap.get(stepSequences);
            if(NullUtil.isNull(madeStepVO)){
                WorkflowStepVO previousStepVO = WorkflowUtil.getPreviousStep(stepTreeMap,stepSequences);
                WorkflowStepVO nextStepVO = WorkflowUtil.getNextStep(stepTreeMap,stepSequences);
                WorkflowStepVO stepVO = this.addStep(wfHeaderVO,stateInfo,stepSequences,previousStepVO,nextStepVO,approvalVOListMapByStep.get(stepSequences));
                stepTreeMap.put(stepVO.getStepSequences(),stepVO);
            }else{
                WorkflowStep madeStepObj = new WorkflowStep(madeStepVO);
                madeStepObj.addUsers(wfHeaderVO,this.getVo(),stateInfo,approvalVOListMapByStep.get(stepSequences));
            }
        }
    }
    public Map<Integer, WorkflowStepVO> getStepTreeMap() {
        List<WorkflowStepVO> createdDBList = this.getStepList();
        Map<Integer, WorkflowStepVO> stepTreeMap = new TreeMap<Integer, WorkflowStepVO>();
        for(WorkflowStepVO vo : createdDBList) stepTreeMap.put(vo.getStepSequences(),vo);
        return stepTreeMap;
    }
    public void promoteConnectedObject(WorkflowHeaderVO wfHeaderVO, BusinessObjectRootVO targetVO) {
        //this.start(wfHeaderVO);
        if(OmcApplicationConstants.WF_RCA_PROMOTE_CONNECTED_OBJECT.equals(this.getRouteCompletionAction())) {
            //StateInfo targetState = CommonApiServiceUtil.getTargetState(targetVO.getObid(),targetVO.getBranchTo(),GlobalConstants.WORKFLOW_TYPE_PROMOTE);
            CommonApiServiceUtil.promote(wfHeaderVO.getNames());
        }
    }
    public void start(WorkflowHeaderVO wfHeaderVO) {
        this.reset();
        this.startSub();
        WorkflowStepVO wfFistStepVO = this.getFirstStep();
        if(NullUtil.isNull(wfFistStepVO)) {log.debug("To be start workflow step does not exists."); return;}
        WorkflowStep wfFistStepObj = DomUtil.toDom(wfFistStepVO);
        wfFistStepObj.start(wfHeaderVO, this.getVo());
    }
    public final void reset() {
        StateInfo firstState = getFirstState();
        while(!firstState.getStateName().equals(getVo().getStates())) demote();
    }
    private final void startSub() {
        if(!WorkflowConstants.STATES_TYPE_DEFINE.equals(this.getVo().getStates())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.noStartRoute" );
        this.promote();
    }

    public void deleteWorkflowInboxTaskList(WorkflowHeaderVO wfHeaderVO, Set<String> deletedWorkflowStepNodeUserObidSet) {
        if(NullUtil.isNone(deletedWorkflowStepNodeUserObidSet)) return;

        List<WorkflowInboxTaskVO> workflowInboxTaskVOList = this.getInboxTaskList();
        for(WorkflowInboxTaskVO workflowInboxTaskVO: workflowInboxTaskVOList) {
            if(deletedWorkflowStepNodeUserObidSet.contains(workflowInboxTaskVO.getRouteNodeObid())) {//삭제 대상
                if(StringUtils.isEmpty(workflowInboxTaskVO.getOriginTaskOwner())) { //일반적인 inbox task일 경우
                    WorkflowInboxTask workflowInboxTask = DomUtil.toDom(workflowInboxTaskVO);
                    if(workflowInboxTask.getStates().equals(WorkflowConstants.STATES_TYPE_ASSIGNED))
                        WorkflowUtil.createDeleteApprovalInfoToEP(wfHeaderVO, this.getVo(), workflowInboxTask.getVo());

                    workflowInboxTask.deleteInboxTask(this);
                }else{
                    if(workflowInboxTaskVO.getOriginTaskOwner().equals(workflowInboxTaskVO.getTaskOwner())) { //origin inbox task일 경우
                        WorkflowInboxTask workflowInboxTask = DomUtil.toDom(workflowInboxTaskVO);
                        if(workflowInboxTask.getStates().equals(WorkflowConstants.STATES_TYPE_ASSIGNED))
                            WorkflowUtil.createDeleteApprovalInfoToEP(wfHeaderVO, this.getVo(), workflowInboxTask.getVo());
                        workflowInboxTask.deleteInboxTask(this);//위임건도 다 삭제 되어 짐.
                    }
                }
            }
        }
    }
    private void validateForAddUsers(Map<Integer, WorkflowStepVO> stepTreeMap, Set<Integer> sequencesSet) {
        //DB에 만들어져 있는지 Check한다.
    }
    private WorkflowStepVO addStep(WorkflowHeaderVO wfHeaderVO  ,
                                   StateInfo stateInfo          ,
                                   Integer stepSequences                 ,
                                   WorkflowStepVO previousStepVO,
                                   WorkflowStepVO nextStepVO    ,
                                   List<ApprovalVO> approvalVOList) {

        if(NullUtil.isNone(approvalVOList)) return null;

        Map<String,Object> map = new HashMap<>();
        map.put(WorkflowConstants.MAP_KEY_stateInfo,stateInfo);
        map.put(WorkflowConstants.MAP_KEY_wfHeaderVO,wfHeaderVO);
        map.put(WorkflowConstants.MAP_KEY_wfRouteVO,this.getVo());//첫번째 Step에 대해서만 Relation생성
        map.put(WorkflowConstants.MAP_KEY_previousStepVO,previousStepVO);
        map.put(WorkflowConstants.MAP_KEY_nextStepVO,nextStepVO);
        map.put(WorkflowConstants.MAP_KEY_approvalVOList,approvalVOList);

        WorkflowStepVO workflowStepVO = new WorkflowStepVO();
        workflowStepVO.setStepSequences(stepSequences);
        workflowStepVO.setTitles(wfHeaderVO.getObid() + ":" + this.getVo().getObid());
        WorkflowStep workflowStep = DomUtil.toDom(workflowStepVO);
        workflowStep.createObject(map);
        return workflowStep.getVo();
    }
    /**************************************getInboxTaskList**********************************************/
    public List<WorkflowInboxTaskVO> getInboxTaskList(){
        return this.getRelatedObjects(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK,AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK,GlobalConstants.FLAG_TYPE_TO);
    }
    public WorkflowInboxTaskVO getInboxTask(String stepNodeUserObid){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[stepNodeUserObid]",GlobalConstants.OQL_OPERATOR_EQUAL,stepNodeUserObid);
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[previousObid]",GlobalConstants.OQL_OPERATOR_EQUAL, "1");
        return this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK,AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK,GlobalConstants.FLAG_TYPE_TO,
                oqlParameter.getSelectPattern(),oqlParameter.getWherePattern(),oqlParameter.getParamPattern());
    }
    /**************************************getStepList**********************************************/
    public List<WorkflowStepVO> getStepList(){
        return this.getRelatedObjects(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP + "," + AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP,AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,GlobalConstants.FLAG_TYPE_TO,0);
    }
    /**************************************findStepList**********************************************/
    public List<WorkflowStepVO> findStepList(){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[routeNodeObid]",GlobalConstants.OQL_OPERATOR_EQUAL,this.getObid());
        return ObjectRoot.findObjects(AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,oqlParameter.getSelectPattern(),oqlParameter.getWherePattern(),oqlParameter.getParamPattern());
    }
    /**************************************findStepList**********************************************/
    public List<WorkflowStepVO> findStepList(Integer sequences, boolean previous, boolean include){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[routeNodeObid]",GlobalConstants.OQL_OPERATOR_EQUAL,this.getObid());
        if(previous){
            if(include){
                OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[sequences]",GlobalConstants.OQL_OPERATOR_LESS_EQTHAN,sequences+"");
            }else{
                OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[sequences]",GlobalConstants.OQL_OPERATOR_LESS_THAN,sequences+"");
            }
        }
        if(include){
            OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[sequences]",GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN,sequences+"");
        }else{
            OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[sequences]",GlobalConstants.OQL_OPERATOR_GREATER_THAN,sequences+"");
        }
        OqlBuilderUtil.addSortByPattern(oqlParameter.getSelectPatternBuf(),"@this.[sequences] asc");
        return ObjectRoot.findObjects(AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,oqlParameter.getSelectPattern(),oqlParameter.getWherePattern(),oqlParameter.getParamPattern());
    }
    /**************************************findStep**********************************************/
    public WorkflowStepVO findStep(Integer sequences){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[routeNodeObid]",GlobalConstants.OQL_OPERATOR_EQUAL,this.getObid());
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[sequences]",GlobalConstants.OQL_OPERATOR_EQUAL,sequences+"");
        List<WorkflowStepVO> list = ObjectRoot.findObjects(AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,oqlParameter.getSelectPattern(),oqlParameter.getWherePattern(),oqlParameter.getParamPattern());
        if(NullUtil.isNone(list)) return null;
        if(list.size() > 1) throw  new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Step info integrity error");
        return list.get(0);
    }
    /**************************************getFirstStep**********************************************/

    public final WorkflowStepVO getFirstStep() {
        return this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP, AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP, GlobalConstants.FLAG_TYPE_TO);
    }
    /**************************************getNextStep**********************************************/
    public WorkflowStepVO getNextStep(Integer sequences){
        WorkflowStepVO rtnWorkflowStepVO = null;
        List<WorkflowStepVO> stepList  = getStepList();
        Collections.sort(stepList, new SequenceComparator());
        for(WorkflowStepVO workflowStepVO : stepList) {
            if(sequences < workflowStepVO.getStepSequences()) {
                if(!WorkflowConstants.STATES_TYPE_DEFINE.equals(workflowStepVO.getStates())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"The state of next step is incorrect["+workflowStepVO.getStates()+"]");
                rtnWorkflowStepVO =  workflowStepVO;
                break;
            }
        }
        return rtnWorkflowStepVO;
    }
    /**************************************getInboxTask**********************************************/
    public WorkflowInboxTaskVO getInboxTask(WorkflowStepNodeUserVO stepUserVO){
        return this.getInboxTask(stepUserVO.getStepNodeUserObid());
    }
    /**************************************getInProcessingStep**********************************************/
    public WorkflowStepVO getInProcessingStep(){
        List<WorkflowStepVO> stepList = getStepList();
        for(WorkflowStepVO workflowStepVO: stepList) {
            if(WorkflowConstants.STATES_TYPE_INPROCESS.equals(workflowStepVO.getStates())) return workflowStepVO;
        }
        return null;
    }
    /**************************************getStepListMap**********************************************/
    public Map<String, Object> getStepListMap(){
        Map<String, Object> rtnWorkflowStepNSubStepMap = new HashMap<String, Object>();
        List<WorkflowStepVO> wgStepVOList = this.getStepList();
        TreeMap<Integer, WorkflowStepVO> workflowStepListMap = new TreeMap<Integer, WorkflowStepVO>();
        for(WorkflowStepVO wfStepVO : wgStepVOList) {
            workflowStepListMap.put(wfStepVO.getStepSequences(), wfStepVO);
        }
        rtnWorkflowStepNSubStepMap.put(WorkflowConstants.MAP_KEY_workflowStepListMap, workflowStepListMap);
        rtnWorkflowStepNSubStepMap.put(WorkflowConstants.MAP_KEY_workflowSubStepList, wgStepVOList);
        return rtnWorkflowStepNSubStepMap;
    }

    public final void resetStepList() {
        List<WorkflowStepVO> stepList = getStepList();
        for(WorkflowStepVO stepVO : stepList) {
            if(!WorkflowConstants.STATES_TYPE_DEFINE.equals(stepVO.getStates())) {
                WorkflowStep workflowStep = DomUtil.toDom(stepVO);
                workflowStep.reset();
            }
        }
    }
    /**
     * ���ӹ��� inboxtask ���
     *
     * @param originWorkflowInboxTaskVO
     * @return
     */
    public final List<WorkflowInboxTaskVO> getDelegatedWorkflowInboxTaskList(WorkflowInboxTaskVO originWorkflowInboxTaskVO) {
        if(NullUtil.isNone(originWorkflowInboxTaskVO.getOriginTaskOwner())) return Collections.<WorkflowInboxTaskVO>emptyList();
        List<WorkflowInboxTaskVO> workflowInboxTaskVOList = getInboxTaskList();
        if(NullUtil.isNone(workflowInboxTaskVOList)) return Collections.<WorkflowInboxTaskVO>emptyList();

        List<WorkflowInboxTaskVO> rtnWorkflowInboxTaskVOList = new ArrayList<WorkflowInboxTaskVO>();
        for(WorkflowInboxTaskVO workflowInboxTaskVO : workflowInboxTaskVOList) {
            if(NullUtil.isNone(workflowInboxTaskVO.getOriginTaskOwner())) continue;
            if(originWorkflowInboxTaskVO.getOriginTaskOwner().equals(workflowInboxTaskVO.getOriginTaskOwner())
                    && originWorkflowInboxTaskVO.getStepSequences().equals(workflowInboxTaskVO.getStepSequences())
                    && WorkflowConstants.STATES_TYPE_ASSIGNED.equals(workflowInboxTaskVO.getStates())
                    && !workflowInboxTaskVO.getOriginTaskOwner().equals(workflowInboxTaskVO.getTaskOwner()) ) {
                rtnWorkflowInboxTaskVOList.add(workflowInboxTaskVO);
            }
        }
        return rtnWorkflowInboxTaskVOList;
    }
    public final boolean isAllApproved(){
        boolean bResult = true;
        List<WorkflowInboxTaskVO> workflowInboxTaskVOList = this.getInboxTaskList();
        for(WorkflowInboxTaskVO workflowInboxTaskVO : workflowInboxTaskVOList) {
            if(!WorkflowConstants.STATES_TYPE_COMPLETE.equals(workflowInboxTaskVO.getStates()) &&
                    !WorkflowConstants.APPROVAL_STATUS_APPROVE.equals( workflowInboxTaskVO.getApprovalStatus())    ){
                bResult = false;
                break;
            }
        }
        return bResult;
    }
    public final BusinessObjectRoot getBusinessObjectRoot() {
        List<WorkflowObjectRouteVO> rtnWorkflowObjectRouteVOList = getRelationships(AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE);

        if(NullUtil.isNone(rtnWorkflowObjectRouteVOList)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"The business object does not exists.");

        BusinessObjectRoot businessObjectRoot = DomUtil.toDom(rtnWorkflowObjectRouteVOList.get(0).getFromObid(), false);
        return businessObjectRoot;
    }
    public void refreshWorkflow(WorkflowHeaderVO wfHeaderVO, StateInfo stateInfo, Map<String, Object> approvalVOListMapByRecodeMode) {
        List<ApprovalVO> creationList     = (List<ApprovalVO>)approvalVOListMapByRecodeMode.get(GlobalConstants.CREATE_RECORD_MODE); //RouteState별 RecordMode가 [C]인 Approval List
        List<ApprovalVO> modificationList = (List<ApprovalVO>)approvalVOListMapByRecodeMode.get(GlobalConstants.UPDATE_RECORD_MODE); //RouteState별 RecordMode가 [U]인 Approval List
        List<ApprovalVO> deletionList     = (List<ApprovalVO>)approvalVOListMapByRecodeMode.get(GlobalConstants.DELETE_RECORD_MODE); //RouteState별 RecordMode가 [D]인 Approval List

        if(!NullUtil.isNone(creationList))     this.addStepsAndUsers(wfHeaderVO,stateInfo,creationList);
        if(!NullUtil.isNone(modificationList)) this.updateUsers(modificationList);
        if(!NullUtil.isNone(deletionList))     this.deleteUsers(deletionList);
    }
    private WorkflowObjectRouteVO createObjectRoute(WorkflowHeaderVO wfHeaderVO,StateInfo stateInfo){
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("stateInfo",stateInfo);
        return this.addFromObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE, wfHeaderVO, new HashMap<String, Object>(),map);
    }
    private void deleteUsers(List<ApprovalVO> deletionList) {
        if(NullUtil.isNone(deletionList)) return;

        WorkflowUtil.sortApprovalVOList(deletionList);
        Map<Integer, List<ApprovalVO>> voListMapByStep = WorkflowUtil.filterApprovalVOListByStep(deletionList);

        Map<Integer, WorkflowStepVO> stepTreeMap = this.getStepTreeMap();
        for (Integer stepSequences : voListMapByStep.keySet()) {
            WorkflowStepVO madeStepVO = stepTreeMap.get(stepSequences);
            WorkflowStep madeStepObj = DomUtil.toDom(madeStepVO);
            madeStepObj.removeUsers(voListMapByStep.get(stepSequences));
        }
    }
    private void updateUsers(List<ApprovalVO> approvalVOList) {
        Map<Integer, WorkflowStepVO> stepTreeMap = this.getStepTreeMap();
        Set<String> preStepSet = new HashSet<>();
        for(ApprovalVO approvalVO: approvalVOList) {
            WorkflowStepNodeUser workflowStepNodeUser = DomUtil.toDom(approvalVO.getStepNodeUserObid(), false);
            WorkflowStepVO workflowStepVO = stepTreeMap.get(approvalVO.getStepSequences());
            WorkflowStep wfStepObj = DomUtil.toDom(workflowStepVO);
            if(!workflowStepNodeUser.getToObid().equals(approvalVO.getAssigneeObid())) { //결재자를 수정 한 경우
                Users users = DomUtil.toDom(approvalVO.getAssigneeObid());
                workflowStepNodeUser.changeAssignee(users.getVo());
            }
            //화면에서 변경할 수 있는 내용(결재자, Process Rule, 필수 결재자 여부, Step, 메일 발송여부, 역할, Route Instruction
            workflowStepNodeUser.setParallelNodeProcessionRule(approvalVO.getParallelNodeProcessionRule());
            workflowStepNodeUser.setIsEssential(approvalVO.getIsEssential());
            workflowStepNodeUser.setStepSequences(approvalVO.getStepSequences());
            workflowStepNodeUser.setRouteInstructions(approvalVO.getRouteInstructions());
            workflowStepNodeUser.setNotifyEmail(approvalVO.getNotifyEmail());
            workflowStepNodeUser.setResponsibility(approvalVO.getResponsibility());
            workflowStepNodeUser.modifyObject();
            if(!workflowStepNodeUser.getFromObid().equals(wfStepObj.getVo().getObid())) {
                preStepSet.add(workflowStepNodeUser.getFromObid());
                workflowStepNodeUser.changeStep(wfStepObj.getVo());
            }
        }
        //Step변경으로 인해 User가 없는 Step은 삭제 대상임.
        if(!NullUtil.isNone(preStepSet)){
            for(String stepObid:preStepSet){
                WorkflowStep preWfStepObj = DomUtil.toDom(stepObid);
                if(NullUtil.isNone(preWfStepObj.getAssignedUserList())) preWfStepObj.deleteObject();
            }
        }
    }



    private static class SequenceComparator implements Comparator<WorkflowStepVO> {
        @Override
        public int compare(WorkflowStepVO s, WorkflowStepVO t) {
            return s.getStepSequences().compareTo(t.getStepSequences());
        }
    }

}

