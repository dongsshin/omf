/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : InBoxTask.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.09.09         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.workflow.dom;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.BusinessRelationObjectVO;
import com.rap.api.object.workflow.model.InBoxTaskVO;
import com.rap.api.object.workflow.model.RouteVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.api.relation.workflow.model.WorkflowProjectTaskVO;
import com.rap.api.relation.workflow.model.WorkflowRouteTaskVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.StrUtil;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.model.ReassignVO;
import com.rap.workflow.util.WorkflowConstants;

import java.util.*;


public class InBoxTask extends BusinessObject {
    public InBoxTask(String obid){
        super(obid);
    }
    public InBoxTask(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public InBoxTask(InBoxTaskVO vo){
        super(vo);
    }
    @Override
    public InBoxTaskVO getVo(){
        return (InBoxTaskVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeInBoxTask();
    }
    public void initializeInBoxTask(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "InBoxTask[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForChange(String newClassName, String newName, String newRevision, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newRevision, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newRevision, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newRevision, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldRevision,String oldLifeCycle,  String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldRevision, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/

    }

    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/

    }

    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeStates(String newStates,Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/
    }

    @Override
    protected void validateForRevise(Map<String, Object> map){
        super.validateForRevise(map);
        /*code below*/

    }

    @Override
    protected void preProcessForRevise(Map<String, Object> map){
        super.preProcessForRevise(map);
        /*code below*/

    }

    @Override
    protected void postProcessForRevise(Map<String, Object> map){
        super.postProcessForRevise(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeNamesAndRevision(String newNames, String newRevision, Map<String,Object> map){
        super.validateForChangeNamesAndRevision(newNames,newRevision,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNamesAndRevision(String newNames, String newRevision, Map<String,Object> map){
        super.preProcessForChangeNamesAndRevision(newNames,newRevision,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNamesAndRevision(String oldNames, String oldRevision, Map<String,Object> map){
        super.postProcessForChangeNamesAndRevision(oldNames,oldRevision,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }



    public void    setRouteAction(String routeAction){
        this.getVo().setRouteAction(routeAction);
    }
    public void    setRouteInstructions(String setRouteInstructions){
        this.getVo().setRouteInstructions(setRouteInstructions);
    }
    public void    setComments(String comments){
        this.getVo().setComments(comments);
    }
    public void    setApprovalStatus(String approvalStatus){
        this.getVo().setApprovalStatus(approvalStatus);
    }
    @JsonIgnore
    public void    setScheduledCompletionDate(Date scheduledCompletionDate){
        this.getVo().setScheduledCompletionDate(scheduledCompletionDate);
    }
    @JsonIgnore
    public void    setScheduledCompletionDate(String    scheduledCompletionDate){
        this.getVo().setScheduledCompletionDate(scheduledCompletionDate);
    }
    @JsonIgnore
    public void    setActualCompletionDate(Date actualCompletionDate){
        this.getVo().setActualCompletionDate(actualCompletionDate);
    }
    @JsonIgnore
    public void    setActualCompletionDate(String    actualCompletionDate){
        this.getVo().setActualCompletionDate(actualCompletionDate);
    }
    public void    setResponsibility(String responsibility){
        this.getVo().setResponsibility(responsibility);
    }
    public void    setTaskRequirement(String taskRequirement){
        this.getVo().setTaskRequirement(taskRequirement);
    }
    public void    setAllowDelegation(Boolean allowDelegation){
        this.getVo().setAllowDelegation(allowDelegation);
    }

    public void    setParallelNodeProcessionRule(String parallelNodeProcessionRule){
        this.getVo().setParallelNodeProcessionRule(parallelNodeProcessionRule);
    }
    public void    setActionComments(String actionComments){
        this.getVo().setActionComments(actionComments);
    }
    public void    setDelegatedFrom(String delegatedFrom){
        this.getVo().setDelegatedFrom(delegatedFrom);
    }
    public void    setDelegatedTo(String delegatedTo){
        this.getVo().setDelegatedTo(delegatedTo);
    }
    public void    setTaskOwner(String taskOwner){
        this.getVo().setTaskOwner(taskOwner);
    }

    public void    setOriginTaskOwner(String originTaskOwner){
        this.getVo().setOriginTaskOwner(originTaskOwner);
    }
    public void    setInboxTaskType(String inboxTaskType){
        this.getVo().setInboxTaskType(inboxTaskType);
    }

    public String getRouteAction(){
        return this.getVo().getRouteAction();
    }
    public String getRouteInstructions(){
        return this.getVo().getRouteInstructions();
    }
    public String getComments(){
        return this.getVo().getComments();
    }
    public String getApprovalStatus(){
        return this.getVo().getApprovalStatus();
    }
    public Date getScheduledCompletionDate(){
        return this.getVo().getScheduledCompletionDate();
    }
    public Date getActualCompletionDate(){
        return this.getVo().getActualCompletionDate();
    }
    public String getResponsibility(){
        return this.getVo().getResponsibility();
    }
    public String getTaskRequirement(){
        return this.getVo().getTaskRequirement();
    }
    public Boolean getAllowDelegation(){
        return this.getVo().getAllowDelegation();
    }

    public String getParallelNodeProcessionRule(){
        return this.getVo().getParallelNodeProcessionRule();
    }
    public String getActionComments(){
        return this.getVo().getActionComments();
    }
    public String getDelegatedFrom(){
        return this.getVo().getDelegatedFrom();
    }
    public String getDelegatedTo(){
        return this.getVo().getDelegatedTo();
    }
    public String getTaskOwner(){
        return getVo().getTaskOwner();
    }

    public String getOriginTaskOwner(){
        return getVo().getOriginTaskOwner();
    }
    public String getInboxTaskType(){
        return getVo().getInboxTaskType();
    }

    public <T extends InBoxTaskVO> T reassignApprover(ReassignVO reassignVO, Map<String,Object> map) {
        validateForReassignApprover(reassignVO,map);
        preProcessForReassignApprover(reassignVO,map);
        reassignApproverCore(reassignVO,map);
        postProcessForReassignApprover(reassignVO,map);
        return (T)map.get("reassignedInboxVO");
    }
    protected void validateForReassignApprover(ReassignVO reassignVO, Map<String,Object> map) {

    }
    protected void reassignApproverCore(ReassignVO reassignVO, Map<String,Object> map) {
        this.promote();
        this.promote();
    }
    protected void preProcessForReassignApprover(ReassignVO reassignVO, Map<String,Object> map) {

    }
    protected void postProcessForReassignApprover(ReassignVO reassignVO, Map<String,Object> map) {

    }

    public <T extends RouteVO> T getRoute() {
        return this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK, AppSchemaCommonConstants.BIZCLASS_WORKFLOWROUTE, GlobalConstants.FLAG_TYPE_FROM);
    }

    public WorkflowRouteTaskVO getWorkflowRouteTask() {
        return getRelationship(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK, AppSchemaCommonConstants.BIZCLASS_WORKFLOWROUTE, GlobalConstants.FLAG_TYPE_FROM);
    }

    /**
     *
     *
     * @return
     */
    public List<BusinessRelationObjectVO> getWorkflowRouteTaskHistoryVOList() {
        return getRelationships(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASKHISTORY, AppSchemaCommonConstants.BIZCLASS_WORKFLOWROUTE, GlobalConstants.FLAG_TYPE_FROM);
    }

    /**
     *
     *
     * @return
     */
    public UsersVO getUsersVO() {
        return this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWPROJECTTASK, AppSchemaCommonConstants.BIZCLASS_USERS, GlobalConstants.FLAG_TYPE_FROM);
    }

    public WorkflowProjectTaskVO getProjectTask() {
        return this.getRelationship(AppSchemaCommonConstants.RELCLASS_WORKFLOWPROJECTTASK, AppSchemaCommonConstants.BIZCLASS_USERS, GlobalConstants.FLAG_TYPE_FROM);
    }
    protected final static int getInboxCountForUserSub( String userId,
                                                Set<String> routeActionSet,
                                                Set<String> stateSet,
                                                Set<String> inboxTaskTypeSet,
                                                Set<String> approvalStatusSet){

        PagingEntity searcInfo = new PagingEntity();
        searcInfo.setRowSize(1);
        List<WorkflowInboxTaskVO> result = getInboxListForUserCore(userId,routeActionSet,stateSet,inboxTaskTypeSet,approvalStatusSet,null,null,searcInfo,true);
        return ((OmfPagingList<WorkflowInboxTaskVO>)result).getTotalCount();
    }
    public static List<WorkflowInboxTaskVO> getInboxListForUser(String       userId,
                                                                String       startDate,
                                                                String       endDate,
                                                                String       taskType,
                                                                boolean      isActivity,
                                                                PagingEntity pagingEntity){
        Set<String> routeActionSet = new HashSet<String>();
        Set<String> stateSet = new HashSet<String>();
        Set<String> inboxTaskTypeSet = new HashSet<String>();
        Set<String> approvalStatusSet = new HashSet<String>();
        String       startDateNew = "";
        String       endDateNew = "";
       /*
       create index "ix_ptinboxtask_99" on ptinboxtask("ptask_owner","pstates","proute_action","papproval_status");
        */
        if( WorkflowConstants.INBOX_TASK_TYPE_APPROVAL.equals(taskType) ){
            stateSet.add(WorkflowConstants.STATES_TYPE_ASSIGNED);
            routeActionSet.addAll(WorkflowConstants.ROUTE_ACTIONS_NOT_COMMENT_SET);
            if(isActivity){
                inboxTaskTypeSet.add(WorkflowConstants.INBOX_TASK_TYPE_WBSActivity);
            }else{
                inboxTaskTypeSet.add(WorkflowConstants.INBOX_TASK_TYPE_Workflow);
            }
        }
        if( WorkflowConstants.INBOX_TASK_TYPE_SAVE_DRAFT.equals(taskType) ){
            stateSet.add(AppSchemaCommonConstants.STATE_INBOX_TASK_ASSIGNED);
            stateSet.add(AppSchemaCommonConstants.STATE_INBOX_TASK_REVIEW);
            routeActionSet.add(WorkflowConstants.ACTION_TYPE_END_WORKING);
        }
        if( WorkflowConstants.INBOX_TASK_TYPE_DISTRIBUTION.equals(taskType) ){
            stateSet.add(AppSchemaCommonConstants.STATE_INBOX_TASK_ASSIGNED);
            routeActionSet.add(WorkflowConstants.ROUTE_ACTIONS_COMMENT);
        }
        if( WorkflowConstants.INBOX_TASK_TYPE_REQUESTED.equals(taskType) ){
            stateSet.add(AppSchemaCommonConstants.STATE_INBOX_TASK_COMPLETE);
            routeActionSet.add(WorkflowConstants.ACTION_TYPE_END_WORKING);
        }
        if( WorkflowConstants.INBOX_TASK_TYPE_APPROVED.equals(taskType) ){
            stateSet.addAll(StrUtil.convertArrayToList(WorkflowConstants.INBOX_STATES_ALL));
            routeActionSet.add(WorkflowConstants.ROUTE_ACTIONS_APPROVE);routeActionSet.add(WorkflowConstants.ROUTE_ACTIONS_CONFIRM);routeActionSet.add(WorkflowConstants.ROUTE_ACTIONS_COMMENT);
            approvalStatusSet.addAll(WorkflowConstants.APPROVAL_STATUS_SET_FOR_APPROVED);
            startDateNew = startDate;endDateNew = endDate;
        }

        return getInboxListForUserCore(userId,routeActionSet,stateSet,inboxTaskTypeSet,approvalStatusSet,startDateNew,endDateNew,pagingEntity,false);
    }
    private static List<WorkflowInboxTaskVO> getInboxListForUserCore(String      userId,
                                                                     Set<String> routeActionSet,
                                                                     Set<String> stateSet,
                                                                     Set<String> inboxTaskTypeSet,
                                                                     Set<String>  approvalStatusSet,
                                                                     String       startDate,
                                                                     String       endDate,
                                                                     PagingEntity pagingEntity,
                                                                     boolean      forCountOnly){
        StringBuffer selectPattern = new StringBuffer();
        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();
        if(!forCountOnly)
        {
            OqlBuilderUtil.constructSelectPattern( selectPattern, "To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK + "].From.To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE + "].Self.fromObid targetObid");
            OqlBuilderUtil.constructSelectPattern( selectPattern, "To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK + "].From.To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE + "].Self.fromClass targetClassName");
            OqlBuilderUtil.constructSelectPattern( selectPattern, "To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK + "].fromObid routeObid");
            OqlBuilderUtil.constructSelectPattern( selectPattern, "To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK + "].From.activityUrl activityUrl");
            OqlBuilderUtil.constructSelectPattern(selectPattern, "getUserInfo(@this.[creator], 'T') creatorName");
            OqlBuilderUtil.addSortByPattern(selectPattern, "@this.[created] desc");
        }
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[taskOwner]", GlobalConstants.OQL_OPERATOR_EQUAL, userId);
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[previousObid]", GlobalConstants.OQL_OPERATOR_EQUAL, "1");
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK + "].From.To[" + AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE + "].Self.obid", GlobalConstants.OQL_OPERATOR_GREATER_THAN, " ");

        if(!NullUtil.isNone(routeActionSet)) OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[routeAction]", GlobalConstants.OQL_OPERATOR_IN, StrUtil.convertSet2Str(routeActionSet));
        if(!NullUtil.isNone(stateSet)) OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[states]", GlobalConstants.OQL_OPERATOR_IN, StrUtil.convertSet2Str(stateSet));
        if(!NullUtil.isNone(inboxTaskTypeSet)) OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[inboxTaskType]", GlobalConstants.OQL_OPERATOR_IN, StrUtil.convertSet2Str(inboxTaskTypeSet));
        if(!NullUtil.isNone(approvalStatusSet)) OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[approvalStatus]", GlobalConstants.OQL_OPERATOR_IN, StrUtil.convertSet2Str(approvalStatusSet));
        if(!StrUtil.isEmpty(startDate)) OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[created]",GlobalConstants.OQL_OPERATOR_GREATER_EQTHAN, "TO_DATE:" + startDate + " 00:00:00");
        if(!StrUtil.isEmpty(endDate)) OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[created]",GlobalConstants.OQL_OPERATOR_LESS_EQTHAN, "TO_DATE:" + endDate + " 23:59:59");
        List<WorkflowInboxTaskVO> result = null;
        if(!NullUtil.isNull(pagingEntity)){
            result = ObjectRoot.findObjectPagingList(AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK, GlobalConstants.FLAG_TYPE_ALL, GlobalConstants.FLAG_TYPE_ALL, selectPattern.toString(), wherePattern.toString(), paramPattern.toString(), pagingEntity);
        }
        else{
            result = ObjectRoot.findObjects(AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK, selectPattern.toString(), wherePattern.toString(), paramPattern.toString());
        }
        return result;
    }
    public final void submit(ApprovalVO approvalVO , Map<String, Object> map){
        if(NullUtil.isNull(map)) map = new HashMap<>();
        validateForSubmit(approvalVO,map);
        preProcessForSubmit(approvalVO,map);
        submitProcess(approvalVO,map);
        postProcessForSubmit(approvalVO,map);
    }
    protected void validateForSubmit(ApprovalVO approvalVO , Map<String, Object> map){
    }
    protected void preProcessForSubmit(ApprovalVO approvalVO , Map<String, Object> map){
    }
    protected void submitProcess(ApprovalVO approvalVO , Map<String, Object> map){
    }
    protected void postProcessForSubmit(ApprovalVO approvalVO , Map<String, Object> map){
    }
}

