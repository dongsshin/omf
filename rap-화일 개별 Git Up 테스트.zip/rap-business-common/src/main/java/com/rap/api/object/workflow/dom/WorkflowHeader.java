/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : WorkflowHeader.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.09.09         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.workflow.dom;


import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.BusinessObjectVO;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.object.workflow.model.*;
import com.rap.api.relation.workflow.dom.WorkflowStepNodeUser;
import com.rap.api.relation.workflow.model.WorkflowStepNodeUserVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.*;
import com.rap.omc.util.foundation.CommonApiServiceUtil;
import com.rap.omc.util.foundation.LifeCycleUtil;
import com.rap.workflow.model.ApprovalHistoryVO;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.model.MailSendVO;
import com.rap.workflow.model.ReassignVO;
import com.rap.workflow.util.*;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

import java.util.*;


public class WorkflowHeader extends BusinessObject {
    private BusinessObjectRootVO targetObjectVO;
    public WorkflowHeader(String obid){
        super(obid);
    }
    public WorkflowHeader(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public WorkflowHeader(WorkflowHeaderVO vo){
        super(vo);
    }
    @Override
    public WorkflowHeaderVO getVo(){
        return (WorkflowHeaderVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeWorkflowHeader();
    }
    public void initializeWorkflowHeader(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "WorkflowHeader[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForChange(String newClassName, String newName, String newRevision, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newRevision, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newRevision, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newRevision, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldRevision,String oldLifeCycle,  String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldRevision, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/

    }
    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/
        //targetObjectVO = CommonApiServiceUtil.getObject(super.getNames());
    }
    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeStates(String newStates,Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/
    }

    @Override
    protected void validateForRevise(Map<String, Object> map){
        super.validateForRevise(map);
        /*code below*/

    }

    @Override
    protected void preProcessForRevise(Map<String, Object> map){
        super.preProcessForRevise(map);
        /*code below*/

    }

    @Override
    protected void postProcessForRevise(Map<String, Object> map){
        super.postProcessForRevise(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeNamesAndRevision(String newNames, String newRevision, Map<String,Object> map){
        super.validateForChangeNamesAndRevision(newNames,newRevision,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNamesAndRevision(String newNames, String newRevision, Map<String,Object> map){
        super.preProcessForChangeNamesAndRevision(newNames,newRevision,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNamesAndRevision(String oldNames, String oldRevision, Map<String,Object> map){
        super.postProcessForChangeNamesAndRevision(oldNames,oldRevision,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }
    public void    setObjectClassName(String objectClassName){
        this.getVo().setObjectClassName(objectClassName);
    }
    public void    setObjectName(String objectName){
        this.getVo().setObjectName(objectName);
    }
    public void    setObjectLifeCycle(String objectLifeCycle){
        this.getVo().setObjectLifeCycle(objectLifeCycle);
    }
    public void    setObjectCurrentStates(String objectCurrentStates){
        this.getVo().setObjectCurrentStates(objectCurrentStates);
    }
    public void    setObjectCreator(String objectCreator){
        this.getVo().setObjectCreator(objectCreator);
    }
    public void    setObjectDetailUrl(String objectDetailUrl){
        this.getVo().setObjectDetailUrl(objectDetailUrl);
    }
    public void    setOrganizations(String organizations){
        this.getVo().setOrganizations(organizations);
    }
    public void    setMailSendFlagApproval(Boolean mailSendFlagApproval){
        this.getVo().setMailSendFlagApproval(mailSendFlagApproval);
    }
    public void    setMailSendFlagDistribution(Boolean mailSendFlagDistribution){
        this.getVo().setMailSendFlagDistribution(mailSendFlagDistribution);
    }
    public void    setAllowDelegation(Boolean allowDelegation){
        this.getVo().setAllowDelegation(allowDelegation);
    }
    public void    setParallelNodeProcessionRule(String parallelNodeProcessionRule){
        this.getVo().setParallelNodeProcessionRule(parallelNodeProcessionRule);
    }
    public void    setRequestComments(String requestComments){
        this.getVo().setRequestComments(requestComments);
    }
    public void    setProcessTimestamp(String processTimestamp){
        this.getVo().setProcessTimestamp(processTimestamp);
    }
    public String getObjectClassName(){
        return this.getVo().getObjectClassName();
    }
    public String getObjectName(){
        return this.getVo().getObjectName();
    }
    public String getObjectLifeCycle(){
        return this.getVo().getObjectLifeCycle();
    }
    public String getObjectCurrentStates(){
        return this.getVo().getObjectCurrentStates();
    }
    public String getObjectCreator(){
        return this.getVo().getObjectCreator();
    }
    public String getObjectDetailUrl(){
        return this.getVo().getObjectDetailUrl();
    }
    public String getOrganizations(){
        return this.getVo().getOrganizations();
    }
    public Boolean getMailSendFlagApproval(){
        return this.getVo().getMailSendFlagApproval();
    }
    public Boolean getMailSendFlagDistribution(){
        return this.getVo().getMailSendFlagDistribution();
    }
    public Boolean getAllowDelegation(){
        return this.getVo().getAllowDelegation();
    }
    public String getParallelNodeProcessionRule(){
        return this.getVo().getParallelNodeProcessionRule();
    }
    public String getRequestComments(){
        return this.getVo().getRequestComments();
    }

    public BusinessObjectRootVO getTargetObject(){
        return targetObjectVO;
    }
    public void setTargetObject(){
        targetObjectVO = CommonApiServiceUtil.getObject(this.getNames());
    }

    public <T extends RouteVO> List<T> getRouteList(){
        return this.getRelatedObjects(AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE,AppSchemaCommonConstants.BIZCLASS_ROUTE, GlobalConstants.FLAG_TYPE_TO);
    }

    public void createAndUpdateWorkflow(List<ApprovalVO> approvalVOList){
        Map<String, List<ApprovalVO>> approvalVOListMap = WorkflowUtil.classifyApprovalVOListByRouteState(approvalVOList);
        for (String states : approvalVOListMap.keySet()) {
            StateInfo stateInfo = LifeCycleUtil.getLifeCycleStateByStateName(this.getObjectLifeCycle(), states);
            if(NullUtil.isNull(stateInfo)) new OmfApplicationException(HttpStatus.BAD_REQUEST,"[Workflow]Not Found:Policy({}) and State({})",  new Object[] { this.getLifeCycle(), states});

            this.setOutDataAttributeValue(WorkflowConstants.MAP_KEY_stateInfo, stateInfo);
            Map<String, Object> approvalVOMapListByRecodeMode = WorkflowUtil.splitApprovalVOByRecodeMode(approvalVOListMap.get(states));

            WorkflowRouteVO existsRouteVO = this.getRouteByTargetState(states);
            if(!NullUtil.isNull(existsRouteVO)) {
                WorkflowRoute existsRouteObj = DomUtil.toDom(existsRouteVO);
                existsRouteObj.refreshWorkflow(this.getVo(),stateInfo,approvalVOMapListByRecodeMode);
            }else{
                this.createWorkflowRoute(stateInfo, approvalVOMapListByRecodeMode);
            }
        }
    }
    public void startRoute() {
        StateInfo firstStateInfo = LifeCycleUtil.getLifeCycleInfo(this.getTargetObject().getLifeCycle()).getFirstState();
        startRoute(firstStateInfo.getStateName());
    }
    public void startRoute(String startState) {
        StateInfo stateInfo = LifeCycleUtil.getLifeCycleStateByStateName(this.getTargetObject().getLifeCycle(), startState);
        if(NullUtil.isNull(stateInfo)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.noDefineRoute",  new Object[] { startState });
        WorkflowRouteVO workflowRouteVO = this.getRouteByTargetState(stateInfo.getStateName());
        if(WorkflowConstants.ROUTE_PURPOSE_DISTRIBUTION.equals(stateInfo.getDefaultRoutePurpose())) {
            if(NullUtil.isNull(workflowRouteVO)) return;
        }else{
            if(NullUtil.isNull(workflowRouteVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.routeNotExist",  new Object[] { startState });
        }
        /**
         * 처음으로 Route가 시작 될 경우 time stamp를 구해서 입력 해 줌.
         */
        StateInfo firstStateInfo = LifeCycleUtil.getLifeCycleInfo(this.getTargetObject().getLifeCycle()).getFirstState();
        if(firstStateInfo.getStateName().equals(startState)) {
            String processTimestamp = WorkflowUtil.getRandomTimestamp();
            workflowRouteVO.setProcessTimestamp(processTimestamp);
            List<WorkflowRouteVO> wfRouteVOList = this.getRouteList();
            for(WorkflowRouteVO vo : wfRouteVOList){
                WorkflowRoute workflowRoute = DomUtil.toDom(vo);
                workflowRoute.setProcessTimestamp(processTimestamp);
                workflowRoute.modifyObject();
            }
        }
        WorkflowRoute wfStartRouteObj = DomUtil.toDom(workflowRouteVO);
        wfStartRouteObj.start(this.getVo());
    }
    public WorkflowRouteVO getInProcessWorkflowRoute() {
        List<WorkflowRouteVO> rtnObjectRootVOList = this.getRouteList(WorkflowConstants.STATES_TYPE_INPROCESS);
        if(!NullUtil.isNone(rtnObjectRootVOList)) return rtnObjectRootVOList.get(0);
        return null;
    }
    public void rebuildInboxTaskWithDelegated() {
        WorkflowRouteVO routeVO = this.getRouteByTargetState(this.getTargetObject().getStates());
        if(NullUtil.isNull(routeVO)) return;
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        if(WorkflowConstants.STATES_TYPE_DEFINE.equals(routeObj.getStates())) routeObj.promote();
        if(!WorkflowConstants.STATES_TYPE_INPROCESS.equals(routeObj.getStates())) return;

        //In Process인 WorkflowStep이 있는지 확인
        WorkflowStepVO inProcessingStepVO = routeObj.getInProcessingStep();
        WorkflowStep stepObj = null;
        if(!NullUtil.isNull(inProcessingStepVO)) {
            stepObj = DomUtil.toDom(inProcessingStepVO);
        }else{//진행 중인 Step이 없을 경우
            WorkflowStepVO stepVO = routeObj.getFirstStep();
            if(NullUtil.isNull(stepVO)) return;
            stepObj = DomUtil.toDom(stepVO);
            if(WorkflowConstants.STATES_TYPE_DEFINE.equals(stepVO.getStates())) stepObj.promote();
        }
        List<WorkflowStepNodeUserVO> stepNodeUserVOList = stepObj.getAssignedUserList();
        for(WorkflowStepNodeUserVO stepNodeUserVO : stepNodeUserVOList) {
            WorkflowStepNodeUser stepNodeUserObj = DomUtil.toDom(stepNodeUserVO);
            WorkflowInboxTaskVO inboxTaskVO      = routeObj.getInboxTask(stepNodeUserVO.getObid());
            if(NullUtil.isNull(inboxTaskVO)){ //In Process인 WorkflowStep에서 신규건일 경우
                WorkflowUtil.createInboxTask(this.getVo(),routeVO,stepNodeUserVO);
                WorkflowUtil.buildDelegatedInboxTask(this.getVo(), routeVO, stepObj.getVo(), stepNodeUserVO);
            }else{ //Working 일 경우만 해당
                WorkflowInboxTask inboxTask = DomUtil.toDom(inboxTaskVO);
                inboxTask.updateWorkflowInboxTask(stepNodeUserVO);
            }
        }
    }
    public void submitApproval(ApprovalVO approvalVO , List<FilesVO> fileList) {
        Map<String, Object> inputParams = new HashMap<String, Object>();
        if(!WorkflowConstants.APPROVAL_STATUS_ACTION_SET.contains(approvalVO.getApprovalStatus())) throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"");
        inputParams.put("approvalStatus"         , approvalVO.getApprovalStatus());
        inputParams.put("inboxTaskObid"          , approvalVO.getInboxTaskObid());
        inputParams.put("comments"               , approvalVO.getComments());
        inputParams.put("mobileApproval"         , approvalVO.getMobileApproval());
        inputParams.put("rejectCode"             , approvalVO.getSelfReject());
        inputParams.put("signal"                 , approvalVO.getSignal());
        this.preProcessApproval(inputParams);

        Map<String,Object> map = new HashMap<>();
        if(WorkflowConstants.APPROVAL_STATUS_REJECT.equals(approvalVO.getApprovalStatus())) {
            this.getVo().setBranchTo(approvalVO.getApprovalStatus());
            this.getTargetObject().setBranchTo(approvalVO.getApprovalStatus());
        }
        WorkflowInboxTask wfInboxTask = DomUtil.toDom(approvalVO.getInboxTaskObid());
        map.put("wfHeaderVO",this.getVo());
        map.put("fileList",fileList);
        map.put("targetVO",this.getTargetObject());
        wfInboxTask.submit(approvalVO,map);
    }




    public void reassignApprover(ReassignVO reassignVO) {
        InBoxTask inboxTaskObj = DomUtil.toDom(reassignVO.getInboxTaskObid());
        Map<String,Object> map = new HashMap<String,Object>();
        InBoxTaskVO newInboxVO = inboxTaskObj.reassignApprover(reassignVO,map);
    }

    public void txnSubmitSelfReject(ApprovalVO approvalVO) {
        //현재 Route가 Standard이거나 Distribution이면 self reject이 안되게 Exception 발생
        StateInfo stateInfo = LifeCycleUtil.getLifeCycleStateByStateName(this.getLifeCycle(), this.getStates());
        if(!WorkflowConstants.ROUTE_PURPOSE_APPROVAL.equals(stateInfo.getDefaultRoutePurpose()) ) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Not allowed self reject in "+this.getStates());

        WorkflowRouteVO inProcessRouteVO  = this.getInProcessWorkflowRoute();
        WorkflowRoute   inProcessRouteObj = DomUtil.toDom(inProcessRouteVO);
        WorkflowStepVO  inProcessStepVO   = inProcessRouteObj.getInProcessingStep();

        if(NullUtil.isNull(inProcessStepVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.noStepInProcess");
        ApprovalVO selfRejectVO = null;
        WorkflowStep inProcessStepObj = DomUtil.toDom(inProcessStepVO);
        Users users = Users.getUsers(ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, null));
        WorkflowInboxTaskVO wfInboxTaskVO = inProcessStepObj.getCurrentInboxForUser(users.getVo());

        if(!NullUtil.isNull(wfInboxTaskVO) && wfInboxTaskVO.getStates().equals(WorkflowConstants.STATES_TYPE_ASSIGNED) && wfInboxTaskVO.getTaskOwner().equals(users.getNames())){
            if(wfInboxTaskVO.getStates().equals(WorkflowConstants.STATES_TYPE_ASSIGNED) && wfInboxTaskVO.getTaskOwner().equals(users.getNames())){
                selfRejectVO = new ApprovalVO();
                selfRejectVO.setRouteState(this.getStates());
                selfRejectVO.setApprovalStatus(WorkflowConstants.APPROVAL_STATUS_REJECT);
                selfRejectVO.setComments(null != approvalVO.getComments() ? approvalVO.getComments()+" [Self Rejection]": "Self Rejection.");
                selfRejectVO.setInboxTaskObid(wfInboxTaskVO.getObid());
                selfRejectVO.setStepNodeUserObid(wfInboxTaskVO.getRouteNodeObid());
                selfRejectVO.setRouteNodeObid(wfInboxTaskVO.getObid());
                selfRejectVO.setStepSequences(wfInboxTaskVO.getStepSequences());
                selfRejectVO.setParallelNodeProcessionRule(wfInboxTaskVO.getParallelNodeProcessionRule());
                submitApproval(selfRejectVO,null);
            }
        }
        if(NullUtil.isNull(selfRejectVO)) {
            ApprovalVO toCreateApprovalVO = new ApprovalVO();
            toCreateApprovalVO.setAssigneeObid(users.getObid());
            toCreateApprovalVO.setRouteState(this.getStates());
            toCreateApprovalVO.setParallelNodeProcessionRule(WorkflowConstants.ROUTE_ACTION_RULE_ALL);
            toCreateApprovalVO.setStepSequences(inProcessStepVO.getStepSequences());
            toCreateApprovalVO.setRecordMode("C");
            toCreateApprovalVO.setSelfReject(true);
            WorkflowInboxTaskVO addedWfInboxTaskVO = inProcessStepObj.createInboxForSelfReject(this.getVo(),inProcessRouteVO,stateInfo,toCreateApprovalVO);

            selfRejectVO = new ApprovalVO();
            selfRejectVO.setApprovalStatus(WorkflowConstants.APPROVAL_STATUS_REJECT);
            selfRejectVO.setComments(!NullUtil.isNone(approvalVO.getComments()) ? approvalVO.getComments()+" [Self Rejection]": "Self Rejection.");
            selfRejectVO.setInboxTaskObid(addedWfInboxTaskVO.getObid());
            selfRejectVO.setStepNodeUserObid(addedWfInboxTaskVO.getRouteNodeObid());
            selfRejectVO.setRouteNodeObid(addedWfInboxTaskVO.getObid());
            selfRejectVO.setStepSequences(addedWfInboxTaskVO.getStepSequences());
            selfRejectVO.setParallelNodeProcessionRule(addedWfInboxTaskVO.getParallelNodeProcessionRule());
            submitApproval(selfRejectVO,null);
            if(!approvalVO.getRemainSelfRejectionInboxTask()) {
                WorkflowInboxTask addedWfInboxTaskObj = DomUtil.toDom(addedWfInboxTaskVO);
                WorkflowStepNodeUser wfStepNodeUserObj = DomUtil.toDom(addedWfInboxTaskVO.getRouteNodeObid());
                wfStepNodeUserObj.deleteObject();
                addedWfInboxTaskObj.deleteObject();
            }
        }
    }
    public void txnAddDistribution(List<ApprovalVO> approvalVOList, String fromUserId) {
        if(NullUtil.isNone(approvalVOList)) throw new IllegalArgumentException();
        List<ApprovalVO> toSendMailApprovalList = new ArrayList<ApprovalVO>();
        List<String> toUserIdList = new ArrayList<String>();
        for(ApprovalVO approvalVO : approvalVOList) {
            approvalVO.validateForAddUser();
            approvalVO.setRecordMode(GlobalConstants.CREATE_RECORD_MODE);
            toUserIdList.add( approvalVO.getAssigneeUserId() );
            toSendMailApprovalList.add(approvalVO);
        }
        WorkflowRoute workflowRoute = null;
        List<WorkflowStepNodeUser> redistributeList = new ArrayList<WorkflowStepNodeUser>();
        WorkflowRouteVO workflowRouteVO = this.getRouteByTargetState(approvalVOList.get(0).getRouteState());

        if(!NullUtil.isNull(workflowRouteVO)) {
            workflowRoute = DomUtil.toDom(workflowRouteVO);
            WorkflowStepVO rtnWorkflowStepVO = workflowRoute.getFirstStep();
            if(!NullUtil.isNull(rtnWorkflowStepVO)) {
                WorkflowStep workflowStep = DomUtil.toDom(rtnWorkflowStepVO);
                List<WorkflowStepNodeUserVO> stepNodeUserVOList = workflowStep.getAssignedUserList();
                for(WorkflowStepNodeUserVO stepNodeUserVO : stepNodeUserVOList) {
                    for(int idx = approvalVOList.size() - 1; idx >=  0; idx --) {
                        if(stepNodeUserVO.getToObid().equals(approvalVOList.get(idx).getAssigneeObid())) {
                            WorkflowStepNodeUser workflowStepNodeUser = DomUtil.toDom(stepNodeUserVO.getObid(), false);
                            redistributeList.add(workflowStepNodeUser);
                            approvalVOList.remove(idx);
                        }
                    }
                }
            }
        }
        if(!NullUtil.isNone(approvalVOList)) {
            this.createAndUpdateWorkflow(approvalVOList);
            this.rebuildInboxTaskWithDelegated();
        }
        for(WorkflowStepNodeUser workflowStepNodeUser : redistributeList) {
            WorkflowInboxTaskVO workflowInboxTaskVO =  workflowRoute.getInboxTask(workflowStepNodeUser.getVo());
            if(!NullUtil.isNull(workflowInboxTaskVO) && WorkflowConstants.STATES_TYPE_INPROCESS.equals(workflowRoute.getStates())) {
                WorkflowInboxTask workflowInboxTask = DomUtil.toDom(workflowInboxTaskVO);
                if(WorkflowConstants.STATES_TYPE_ASSIGNED.equals(workflowInboxTaskVO.getStates())) {
                    workflowInboxTask.setApprovalStatus(WorkflowConstants.APPROVAL_STATUS_ACKNOWLEDGE);
                    workflowInboxTask.setComments("Auto Acknowledge by System for distribute.");
                    workflowInboxTask.setActualCompletionDate(TimeServiceUtil.getDBLocalTime());
                    workflowInboxTask.modifyObject();

                    workflowInboxTask.promote();
                    workflowInboxTask = DomUtil.toDom(workflowInboxTaskVO.getObid());
                    workflowInboxTask.promote();
                    workflowRoute.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASKHISTORY, workflowInboxTaskVO, new HashMap<String, Object>());
                    WorkflowUtil.createSubmitApprovalInfoToEP(this.getVo(), workflowRoute.getVo(), workflowStepNodeUser.getVo(), WorkflowConstants.APPROVAL_STATUS_APPROVE);
                }
                BusinessObjectVO revisedBusinessObjectVO = workflowInboxTask.revise();
                //TODO revised 된 Inbox task 초기화 시켜야 함. WorkflowStepNodeUser의 정보도 반영 되어야 함.
                WorkflowInboxTask revisedWorkflowInboxTask = DomUtil.toDom(revisedBusinessObjectVO.getObid(), false);
                revisedWorkflowInboxTask.reset(workflowRoute.getProcessTimestamp(), TimeServiceUtil.getDBLocalTime());
                WorkflowUtil.createApprovalInfoToEP(this.getVo(), workflowRoute.getVo(), revisedWorkflowInboxTask.getVo());
            }
        }

        // ManualDistribution의 경우 대상 Object가 배포 상태일 경우 메일발송
        if( toSendMailApprovalList.get(0).getRouteInstructions().equals( WorkflowConstants.INSTRUCTION_TYPE_MANUAL_DISTRIBUTION ) ){
            BusinessObjectRootVO businessObjectVO = this.getVo();
            if( businessObjectVO.getStates().equals( toSendMailApprovalList.get(0).getRouteState() ) ){
                MailSendVO mailSendVO = new MailSendVO();
                mailSendVO.setSendType( WorkflowConstants.MAIL_TYPE_DISTRIBUTION );
                mailSendVO.setObid( businessObjectVO.getObid() );
                mailSendVO.setClassName( businessObjectVO.getClassName() );
                mailSendVO.setNames( businessObjectVO.getNames() );
                mailSendVO.setCurrentStatus( businessObjectVO.getStates() );
                mailSendVO.setFromUserId( fromUserId );
                mailSendVO.setToUserIdList( toUserIdList );
                WorkflowUtil.txnCreateMailSendInfo( mailSendVO );
            }
        }
    }
    public List<WorkflowInboxTaskVO> getDistributionHistoryList() {

        StringBuffer fromPattern = new StringBuffer();
        fromPattern.append("<this>ThisConnectedWithTo<[WorkflowRouteTask]@I2R>+");
        fromPattern.append("<[WorkflowRouteTask]@I2R>FromConnectedWithThis<[WorkflowRoute]@WR>+");
        fromPattern.append("<[WorkflowRoute]@WR>ThisConnectedWithTo<[WorkflowObjectRoute]@W2O>+");
        fromPattern.append("<this>ThisConnectedWithTo<[WorkflowProjectTask]@I2U>+");
        fromPattern.append("<[WorkflowProjectTask]@I2U>FromConnectedWithThis<[Users]@U>+");

        OqlParameter oqlParameter = new OqlParameter();

        OqlBuilderUtil.constructSelectPattern(oqlParameter,"@U.[titles] targetUserName");
        OqlBuilderUtil.addSortByPattern(oqlParameter,"this.[sequences]");
        OqlBuilderUtil.constructWherePattern(oqlParameter, "@this.[routeInstructions]",
                GlobalConstants.OQL_OPERATOR_IN, WorkflowConstants.INSTRUCTION_TYPE_DISTRIBUTION + "," + WorkflowConstants.INSTRUCTION_TYPE_MANUAL_DISTRIBUTION);
        OqlBuilderUtil.constructWherePattern(oqlParameter, "@W2O.[fromObid]",
                GlobalConstants.OQL_OPERATOR_EQUAL, this.getObid());

        List<WorkflowInboxTaskVO> result = ObjectRoot.searchObjects(AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK,
                oqlParameter.getSelectPattern(),
                fromPattern.toString(),
                oqlParameter.getWherePattern(),
                oqlParameter.getParamPattern(),
                0);
        return result;
    }




    public List<ApprovalHistoryVO> getApprovalHistoryList(){
//        List<String> routeStateList = LifeCycleControl.retrieveUserInputLifiecycleStateStringListByName(businessObjectRoot.getLifeCycle());

        StringBuffer sql = new StringBuffer();
        sql.append("@WOR.[*]+@WFR.[*]+@WTH.[*]+@WIT.[*]+From[Files].obid wit_fileExistYn+SortBy@WTH.[created] asc ");

        String selectPattern = sql.toString();
        sql.setLength(0);   // string buffer 초기화
        sql.append("<this>ThisConnectedWithFrom<[WorkflowObjectRoute]@WOR>+");
        sql.append("<[WorkflowObjectRoute]@WOR>ToConnectedWithThis<[WorkflowRoute]@WFR>+");
        sql.append("<[WorkflowRoute]@WFR>ThisConnectedWithFrom<[WorkflowRouteTaskHistory]@WTH>+");
        sql.append("<[WorkflowRouteTaskHistory]@WTH>ToConnectedWithThis<[WorkflowInboxTask]@WIT>+");

        String fromPattern = sql.toString();
        sql.setLength(0);   // string buffer 초기화

        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[obid]", GlobalConstants.OQL_OPERATOR_EQUAL, this.getObid() );

        String wherePattern = wherePatternBuf.toString();
        String parameterPattern = paramPatternBuf.toString();

        List<ObjectRootVO> rtnWorkflowHistoryList = ObjectRoot.searchObjects( this.getClassName(),
                selectPattern, fromPattern, wherePattern, parameterPattern, 0
        );

        List<ApprovalHistoryVO> rtnApprovalHistoryVOList = new ArrayList<ApprovalHistoryVO>();
        for(ObjectRootVO objectRootVO : rtnWorkflowHistoryList) {
            Map<String, Object> outData = (Map<String, Object>)objectRootVO.getOutData();
            ApprovalHistoryVO approvalHistoryVO = new ApprovalHistoryVO();
            approvalHistoryVO.setAssignee(NullUtil.isNull(outData.get("witTaskownerUserTitles"))? "" : (String)outData.get("witTaskownerUserTitles"));
            approvalHistoryVO.setAssigneeObid(NullUtil.isNull(outData.get("witTaskOwnerUserObid"))? "" : (String)outData.get("witTaskOwnerUserObid"));
            Users users = Users.getUsers((String)outData.get("wit_taskOwner"));
            String titleName = StringUtils.isEmpty(users.getTitles()) ? "" : users.getTitles();
            approvalHistoryVO.setApproverInfo(users.getDescriptions() + " "+ titleName + " "+ users.getVo().getDepartmentTitles());
            approvalHistoryVO.setSite((String)outData.get("wfr_site"));
            approvalHistoryVO.setState((String)outData.get("wor_routeState"));
            approvalHistoryVO.setApprovalStatus((String)outData.get("wit_approvalStatus"));
            setActionForApprovalHistory(approvalHistoryVO);
            approvalHistoryVO.setComments((String)outData.get("wit_comments"));
            String actualCompletionDate = (NullUtil.isNull(outData.get("wit_actualCompletionDate"))? "" : (String)outData.get("wit_actualCompletionDate"));
            approvalHistoryVO.setActualCompletionDate(actualCompletionDate);
            approvalHistoryVO.setRouteInstructions((String)outData.get("wit_routeInstructions"));
            approvalHistoryVO.setStep((String)outData.get("wit_step"));
            approvalHistoryVO.setActionComments((String)outData.get("wit_actionComments"));
            approvalHistoryVO.setTaskName((String)outData.get("wit_names"));
            approvalHistoryVO.setRev((String)outData.get("wit_revision"));
            approvalHistoryVO.setTaskObid((String)outData.get("wit_obid"));
            approvalHistoryVO.setFileExistYn((String)outData.get("wit_fileExistYn"));
            approvalHistoryVO.setProcessRole((String)outData.get("wit_responsibility"));
            rtnApprovalHistoryVOList.add(approvalHistoryVO);
        }
        return rtnApprovalHistoryVOList;
    }
    public List<WorkflowInboxTaskVO> getNotificationFromRoute() {

        List<WorkflowInboxTaskVO> existList = null;

        StringBuffer selectPattern = new StringBuffer();
        StringBuffer fromPattern = new StringBuffer();
        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();

        selectPattern.append("@WOR.[toObid] workflowRouteObid");
        selectPattern.append("+ @WOR.[routeState] routeState");
        selectPattern.append("+ @WOR.[fromObid] docId");
        selectPattern.append("+ @WR.[creator] routeCreator");
        selectPattern.append("+ @WR.[obid] routeObid");
        OqlBuilderUtil.addSortByPattern(selectPattern, "@this.[sequences]");

        fromPattern.append("<this>                         ThisConnectedWithTo       <[WorkflowRouteTask]@WRT>+");
        fromPattern.append("<[WorkflowRouteTask]@WRT>         FromConnectedWithThis       <[WorkflowRoute]@WR>+");
        fromPattern.append("<[WorkflowRoute]@WR>         ThisConnectedWithTo       <[WorkflowObjectRoute]@WOR>+");

        // Where 조건 설정
        String distributionInCondition = WorkflowConstants.INSTRUCTION_TYPE_ORIGINATOR
                + "," + WorkflowConstants.INSTRUCTION_TYPE_DISTRIBUTION;

        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@WOR.[fromObid]",
                GlobalConstants.OQL_OPERATOR_EQUAL, this.getObid());

        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[routeInstructions]",
                GlobalConstants.OQL_OPERATOR_NOT_IN, distributionInCondition); // Task Title != ‘Originator’ && Task Title != ‘Distribution’

        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[approvalStatus]",
                GlobalConstants.OQL_OPERATOR_EQUAL, WorkflowConstants.APPROVAL_STATUS_NONE); // Action = ‘Awaiting Approval’

        existList = ObjectRoot.searchObjects(
                AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK,
                selectPattern.toString(),
                fromPattern.toString(),
                wherePattern.toString(),
                paramPattern.toString(),
                0);
        for(int i=0; i<existList.size(); i++){
            ApprovalVO approvalVO = new ApprovalVO();
            approvalVO.setApprovalStatus(existList.get(i).getApprovalStatus());
            setAction(approvalVO);
            UsersVO usersVO = ObjectRoot.findObject( AppSchemaCommonConstants.BIZCLASS_USERS, existList.get(i).getTaskOwner());
            existList.get(i).setReviewersComments(usersVO.getTitles()); // Assignee(결재자정보)
            existList.get(i).setApprovalStatus(approvalVO.getAction()); // Action(Awaiting Approval)
            existList.get(i).setActionComments(usersVO.getDepartmentTitles()); // Department(부서정보)
        }
        return existList;
    }
    public void txnCopyWorkflow(WorkflowHeader targetWfHeaderObj, String workingState){
        if(!this.getLifeCycle().equals(targetWfHeaderObj.getLifeCycle())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Life Cycle is different.");
        if(isInProcessingWorkflow()) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Copy is not possible because workflow is already in progress.");

        List<ApprovalVO> rtnApprovalVOList = new ArrayList<ApprovalVO>();

        List<String> routeStateList = LifeCycleUtil.getLifeCycleStateStringListByName(this.getObjectLifeCycle());
        Map<String,Object> map = this.getWorkflowListAll();
        Map<String, WorkflowRouteVO> routeVOMap = (Map<String, WorkflowRouteVO>)map.get("routeVOMap");
        Map<String, WorkflowStepVO> stepVOMap = (Map<String, WorkflowStepVO>)map.get("stepVOMap");
        List<UsersVO> usersVOList = (List<UsersVO>)map.get("usersVOList");


        for (UsersVO usersVO : usersVOList) {
            ApprovalVO approvalVO = new ApprovalVO();

            WorkflowStepNodeUserVO stepNodeUserVO = convertToStepNodeUserVO(usersVO);
            WorkflowStepNodeUser   stepNodeUserObj = DomUtil.toDom(stepNodeUserVO);

            WorkflowRouteVO routeVO  = routeVOMap.get(stepNodeUserVO.getRouteNodeObid());
            WorkflowStepVO  stepVO   = stepVOMap.get(stepNodeUserVO.getStepNodeObid());
            WorkflowRoute   routeObj = DomUtil.toDom(routeVO);

            WorkflowInboxTaskVO inboxTaskVO = stepNodeUserObj.findInboxTaskCurrent();
            //WorkflowInboxTaskVO inboxTaskVO =  routeObj.getInboxTask(stepNodeUserVO.getRouteNodeObid());

            approvalVO.setRoutePurpose(routeVO.getOutDataAttributeValue("rel_routePurpose"));
            approvalVO.setRouteLifeCycle(routeVO.getOutDataAttributeValue("rel_routeLifeCycle"));
            approvalVO.setRouteState(routeVO.getOutDataAttributeValue("rel_routeState"));

            if(!workingState.equals(approvalVO.getRouteState()) && AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE.equals(usersVO.getStates())){
                approvalVO.setRouteInstructions(stepNodeUserVO.getRouteInstructions());
                approvalVO.setResponsibility(stepNodeUserVO.getResponsibility());
                approvalVO.setStepSequences(stepVO.getStepSequences());
                approvalVO.setStepNodeUserSequences(stepNodeUserVO.getStepNodeUserSequences());
                approvalVO.setIsEssential(stepNodeUserVO.getIsEssential());
                approvalVO.setParallelNodeProcessionRule(stepNodeUserVO.getParallelNodeProcessionRule());
                approvalVO.setNotifyEmail(stepNodeUserVO.getNotifyEmail());
                approvalVO.setRoutePurpose(routeVO.getRouteBasePurpose());
                approvalVO.setAssigneeTitles(usersVO.getTitles());
                approvalVO.setAssigneeObid(usersVO.getObid());
                approvalVO.setUserStatus(usersVO.getStates());
                rtnApprovalVOList.add(approvalVO);
            }
        }
        if(NullUtil.isNone(rtnApprovalVOList)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"The approval list to copy does not exist.");
        this.createAndUpdateWorkflow(rtnApprovalVOList);
    }
    public final <T extends RouteVO> T getFirstRoute() {
        StateInfo firstState = getFirstState();
        if(!NullUtil.isNull(firstState)) {
            return this.getRouteByTargetState(firstState.getStateName());
        }
        return null;
    }
    public final <T extends RouteVO> List<T>  getRouteList(String states){
        if (NullUtil.isNone(states)) throw new IllegalArgumentException();
        return getRouteListCore("",states);
    }
    public final <T extends RouteVO> T getRouteByTargetState(String routeState){
        if (NullUtil.isNone(routeState)) throw new IllegalArgumentException();
        List<T> list = this.getRouteListCore(routeState,"");
        if(NullUtil.isNone(list)) return null;
        if(list.size() > 1) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR, "Too Many Route for '" + routeState + "'.");
        return list.get(0);

    }
    public Map<String,Object> getWorkflowListObjects() {
        List<ApprovalVO> rtnApprovalVOList = new ArrayList<ApprovalVO>();
        List<String> routeStateList = LifeCycleUtil.getLifeCycleStateStringListByName(this.getObjectLifeCycle());
        Map<String,Object> map = this.getWorkflowListAll();
        Map<String, WorkflowRouteVO> routeVOMap = (Map<String, WorkflowRouteVO>)map.get(WorkflowConstants.MAP_KEY_WF_INFO_routeVOMap);
        Map<String, WorkflowStepVO> stepVOMap = (Map<String, WorkflowStepVO>)map.get(WorkflowConstants.MAP_KEY_WF_INFO_stepVOMap);
        List<UsersVO> usersVOList = (List<UsersVO>)map.get(WorkflowConstants.MAP_KEY_WF_INFO_usersVOList);

        String loginUser = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, "");
        for (UsersVO usersVO : usersVOList) {
            ApprovalVO approvalVO = new ApprovalVO();
            WorkflowStepNodeUserVO stepNodeUserVO = convertToStepNodeUserVO(usersVO);
            WorkflowRouteVO routeVO  = routeVOMap.get(stepNodeUserVO.getRouteNodeObid());
            WorkflowStepVO  stepVO   = stepVOMap.get(stepNodeUserVO.getStepNodeObid());
            WorkflowRoute   routeObj = DomUtil.toDom(routeVO);

            WorkflowInboxTaskVO inboxTaskVO =  routeObj.getInboxTask(stepNodeUserVO.getStepNodeUserObid());

            approvalVO.setWfRequesterObid(this.getObid());
            approvalVO.setRouteNodeObid(stepNodeUserVO.getRouteNodeObid());
            approvalVO.setStepNodeObid(stepNodeUserVO.getStepNodeObid());
            approvalVO.setStepNodeUserObid(stepNodeUserVO.getStepNodeUserObid());

            approvalVO.setStepSequences(stepNodeUserVO.getStepSequences());
            approvalVO.setStepNodeUserSequences(stepNodeUserVO.getStepNodeUserSequences());

            approvalVO.setStateOfRoute(routeVO.getStates());
            approvalVO.setStateOfStep(stepVO.getStates());
            approvalVO.setRouteStateSequence(routeStateList.indexOf(routeVO.getOutDataAttributeValue("rel_routeState")));

            approvalVO.setUserStatus(usersVO.getStates());
            approvalVO.setDepartment(usersVO.getDepartmentTitles());
            approvalVO.setAssigneeObid(usersVO.getObid());
            approvalVO.setAssigneeTitles(usersVO.getTitles());
            approvalVO.setAssigneeMailAddress("assigneeMailAddress");
            approvalVO.setAssigneeInfo(usersVO.getDescriptions() + " "+ usersVO.getTitles() + " (" + usersVO.getEmailAddress() + ") "+ usersVO.getDepartmentTitles());
            approvalVO.setCanApproval(false);

            approvalVO.setRoutePurpose(routeVO.getOutDataAttributeValue("rel_routePurpose"));
            approvalVO.setRouteLifeCycle(routeVO.getOutDataAttributeValue("rel_routeLifeCycle"));
            approvalVO.setRouteState(routeVO.getOutDataAttributeValue("rel_routeState"));

            approvalVO.setRouteCompletionAction(routeVO.getRouteCompletionAction());
            approvalVO.setSubRouteVisibility(routeVO.getSubRouteVisibility());
            approvalVO.setRouteBasePurpose(routeVO.getRouteBasePurpose());
            approvalVO.setRestartUpOnTaskRejection(routeVO.getRestartUpOnTaskRejection());
            approvalVO.setAutoStopOnRejection(routeVO.getAutoStopOnRejection());
            approvalVO.setOrganizations(routeVO.getOrganizations());
            approvalVO.setRouteStatus(routeVO.getRouteStatus());
            approvalVO.setProcessTimestamp(routeVO.getProcessTimestamp());
            approvalVO.setActivityUrl(routeVO.getActivityUrl());

            approvalVO.setRouteNodeObid(stepNodeUserVO.getRouteNodeObid());
            approvalVO.setRouteAction(stepNodeUserVO.getRouteAction());
            approvalVO.setRouteInstructions(stepNodeUserVO.getRouteInstructions());
            approvalVO.setComments(stepNodeUserVO.getComments());
            approvalVO.setApprovalStatus(stepNodeUserVO.getApprovalStatus());
            approvalVO.setScheduledCompletionDate(stepNodeUserVO.getScheduledCompletionDate());
            approvalVO.setActualCompletionDate(stepNodeUserVO.getActualCompletionDate());

            approvalVO.setResponsibility(stepNodeUserVO.getResponsibility());
            approvalVO.setTaskRequirement(stepNodeUserVO.getTaskRequirement());
            approvalVO.setReviewTask(stepNodeUserVO.getReviewTask());
            approvalVO.setReviewersComments(stepNodeUserVO.getReviewersComments());
            approvalVO.setReviewCommentsNeeded(stepNodeUserVO.getReviewCommentsNeeded());
            approvalVO.setDueDateOffset(stepNodeUserVO.getDueDateOffset());
            approvalVO.setDateOffsetFrom(stepNodeUserVO.getDateOffsetFrom());
            approvalVO.setAssigneeSetDueDate(stepNodeUserVO.getAssigneeSetDueDate());
            approvalVO.setAllowDelegation(stepNodeUserVO.getAllowDelegation());
            approvalVO.setIsEssential(stepNodeUserVO.getIsEssential());
            approvalVO.setParallelNodeProcessionRule(stepNodeUserVO.getParallelNodeProcessionRule());
            approvalVO.setTitles(stepNodeUserVO.getTitles());

            approvalVO.setActionComments(stepNodeUserVO.getActionComments());
            approvalVO.setNotifyEmail(stepNodeUserVO.getNotifyEmail());
            approvalVO.setSelfReject(stepNodeUserVO.getSelfReject());

            approvalVO.setTaskOwner(usersVO.getNames());//User Id를 Setting한다.

            if(!NullUtil.isNull(inboxTaskVO)) {
                List<FilesVO> filesVOList = new WorkflowInboxTask(inboxTaskVO).getRelatedFiles();
                approvalVO.setInboxTaskObid(inboxTaskVO.getObid());
                approvalVO.setReviewersComments(inboxTaskVO.getReviewersComments());
                approvalVO.setComments(inboxTaskVO.getComments());
                approvalVO.setActualCompletionDate(inboxTaskVO.getActualCompletionDate());
                approvalVO.setApprovalStatus(StringUtils.isEmpty(inboxTaskVO.getApprovalStatus()) ? "" : inboxTaskVO.getApprovalStatus());
                approvalVO.setStateOfInbox(inboxTaskVO.getStates());
                approvalVO.setOriginTaskOwner(inboxTaskVO.getOriginTaskOwner());
                approvalVO.setTaskOwner(inboxTaskVO.getTaskOwner());
                approvalVO.setInboxTaskType(inboxTaskVO.getInboxTaskType());
            }
            if(WorkflowConstants.ROUTE_ACTIONS_COMMENT.equals(approvalVO.getRouteAction())) {//Distribution
                this.setActionForDistributionState(approvalVO);
            }else{
                setAction(approvalVO);
            }
            rtnApprovalVOList.add(approvalVO);

            if(!NullUtil.isNull(inboxTaskVO)) {
                List<WorkflowInboxTaskVO> delegatedWorkflowInboxTaskVOList = routeObj.getDelegatedWorkflowInboxTaskList(inboxTaskVO);
                for(WorkflowInboxTaskVO delegatedWorkflowInboxTaskVO : delegatedWorkflowInboxTaskVOList) {
                    ApprovalVO delegatedApprovalVO = new ApprovalVO();

                    delegatedApprovalVO.setStateOfRoute(routeVO.getStates());
                    delegatedApprovalVO.setStateOfStep(stepVO.getStates());
                    delegatedApprovalVO.setRouteStateSequence(routeStateList.indexOf(routeVO.getOutDataAttributeValue("rel_routeState")));

                    WorkflowInboxTask delegatedWorkflowInboxTask = DomUtil.toDom(delegatedWorkflowInboxTaskVO);
                    UsersVO delegatedUsersVO = delegatedWorkflowInboxTask.getUsersVO();

                    delegatedApprovalVO.setUserStatus(delegatedUsersVO.getStates());
                    delegatedApprovalVO.setDepartment(delegatedUsersVO.getDepartmentTitles());
                    delegatedApprovalVO.setAssigneeTitles(delegatedUsersVO.getTitles());
                    delegatedApprovalVO.setAssigneeObid(delegatedUsersVO.getObid());
                    delegatedApprovalVO.setAssigneeMailAddress("assigneeMailAddress");
                    delegatedApprovalVO.setAssigneeInfo(delegatedUsersVO.getDescriptions() + " "+ delegatedUsersVO.getTitles() + " (" + delegatedUsersVO.getEmailAddress() + ") "+ delegatedUsersVO.getDepartmentTitles());
                    delegatedApprovalVO.setCanApproval(false);
                    if(loginUser.equals(delegatedUsersVO.getNames())) {
                        delegatedApprovalVO.setCanApproval(true);
                    }
                    delegatedApprovalVO.setRoutePurpose(approvalVO.getRoutePurpose());
                    delegatedApprovalVO.setRouteLifeCycle(approvalVO.getRouteLifeCycle());
                    delegatedApprovalVO.setRouteState(approvalVO.getRouteState());

                    delegatedApprovalVO.setRouteCompletionAction(routeVO.getRouteCompletionAction());
                    delegatedApprovalVO.setSubRouteVisibility(routeVO.getSubRouteVisibility());
                    delegatedApprovalVO.setRouteBasePurpose(routeVO.getRouteBasePurpose());
                    delegatedApprovalVO.setRestartUpOnTaskRejection(routeVO.getRestartUpOnTaskRejection());
                    delegatedApprovalVO.setAutoStopOnRejection(routeVO.getAutoStopOnRejection());
                    delegatedApprovalVO.setOrganizations(routeVO.getOrganizations());
                    delegatedApprovalVO.setRouteStatus(routeVO.getRouteStatus());
                    delegatedApprovalVO.setProcessTimestamp(routeVO.getProcessTimestamp());
                    delegatedApprovalVO.setActivityUrl(routeVO.getActivityUrl());

                    delegatedApprovalVO.setRouteNodeObid(delegatedWorkflowInboxTaskVO.getRouteNodeObid());
                    delegatedApprovalVO.setRouteAction(delegatedWorkflowInboxTaskVO.getRouteAction());
                    delegatedApprovalVO.setRouteInstructions(delegatedWorkflowInboxTaskVO.getRouteInstructions());
                    delegatedApprovalVO.setComments(delegatedWorkflowInboxTaskVO.getComments());
                    delegatedApprovalVO.setApprovalStatus(delegatedWorkflowInboxTaskVO.getApprovalStatus());
                    delegatedApprovalVO.setScheduledCompletionDate(delegatedWorkflowInboxTaskVO.getScheduledCompletionDate());
                    delegatedApprovalVO.setActualCompletionDate(delegatedWorkflowInboxTaskVO.getActualCompletionDate());

                    delegatedApprovalVO.setResponsibility(delegatedWorkflowInboxTaskVO.getResponsibility());
                    delegatedApprovalVO.setTaskRequirement(delegatedWorkflowInboxTaskVO.getTaskRequirement());
                    delegatedApprovalVO.setReviewTask(delegatedWorkflowInboxTaskVO.getReviewTask());
                    delegatedApprovalVO.setReviewersComments(delegatedWorkflowInboxTaskVO.getReviewersComments());
                    delegatedApprovalVO.setReviewCommentsNeeded(delegatedWorkflowInboxTaskVO.getReviewCommentsNeeded());
                    delegatedApprovalVO.setDueDateOffset(delegatedWorkflowInboxTaskVO.getDueDateOffset());
                    delegatedApprovalVO.setDateOffsetFrom(delegatedWorkflowInboxTaskVO.getDateOffsetFrom());
                    delegatedApprovalVO.setAssigneeSetDueDate(delegatedWorkflowInboxTaskVO.getAssigneeSetDueDate());
                    delegatedApprovalVO.setAllowDelegation(delegatedWorkflowInboxTaskVO.getAllowDelegation());
                    delegatedApprovalVO.setIsEssential(delegatedWorkflowInboxTaskVO.getIsEssential());
                    delegatedApprovalVO.setParallelNodeProcessionRule(delegatedWorkflowInboxTaskVO.getParallelNodeProcessionRule());
                    delegatedApprovalVO.setTitles(delegatedWorkflowInboxTaskVO.getTitles());

                    delegatedApprovalVO.setActionComments(delegatedWorkflowInboxTaskVO.getActionComments());
                    delegatedApprovalVO.setNotifyEmail(delegatedWorkflowInboxTaskVO.getNotifyEmail());
                    delegatedApprovalVO.setSelfReject(false);
                    approvalVO.setTaskOwner(delegatedWorkflowInboxTaskVO.getTaskOwner());

                    approvalVO.setOriginTaskOwner(delegatedWorkflowInboxTaskVO.getOriginTaskOwner());
                    approvalVO.setDelegatedFrom(delegatedWorkflowInboxTaskVO.getDelegatedFrom());
                    approvalVO.setDelegatedTo(delegatedWorkflowInboxTaskVO.getDelegatedTo());
                    approvalVO.setMobileApproval(delegatedWorkflowInboxTaskVO.getMobileApproval());
                    approvalVO.setInboxTaskType(delegatedWorkflowInboxTaskVO.getInboxTaskType());

                    if(WorkflowConstants.ROUTE_ACTIONS_COMMENT.equals(delegatedApprovalVO.getRouteAction())) {//Distribution
                        setActionForDistributionState(delegatedApprovalVO);
                    }else{
                        setAction(delegatedApprovalVO);
                    }
                    rtnApprovalVOList.add(delegatedApprovalVO);
                }
            }
        }
        Collections.sort(rtnApprovalVOList, new WorkflowChainedComparator(
                new WorkflowRouteComparator(),
                new WorkflowRouteStepComparator(),
                new WorkflowRouteNodeComparator())
        );
        map.put(WorkflowConstants.MAP_KEY_WF_INFO_approvalVOList,rtnApprovalVOList);
        return map;
    }
    private void createWorkflowRoute(StateInfo stateInfo, Map<String, Object> approvalVOListMapByRecodeMode) {
        List<ApprovalVO> approvalVOList = (List<ApprovalVO>)approvalVOListMapByRecodeMode.get(GlobalConstants.CREATE_RECORD_MODE);
        if(NullUtil.isNone(approvalVOList))  return;
        createWorkflowRoute(stateInfo,approvalVOList);
    }
    private WorkflowRoute createWorkflowRoute(StateInfo stateInfo,List<ApprovalVO> approvalVOList) {
        WorkflowRoute wfRouteObj = DomUtil.toDom(new WorkflowRouteVO());
        wfRouteObj.getVo().setTitles("dd");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put(WorkflowConstants.MAP_KEY_stateInfo,stateInfo);
        map.put(WorkflowConstants.MAP_KEY_wfHeaderVO,this.getVo());
        map.put(WorkflowConstants.MAP_KEY_approvalVOList,approvalVOList);
        wfRouteObj.createObject(map);
        return wfRouteObj;
    }

    private WorkflowStepNodeUserVO convertToStepNodeUserVO(UsersVO usersVO){
        WorkflowStepNodeUserVO vo =  new WorkflowStepNodeUserVO();
        vo.setObid                          (usersVO.getOutDataAttributeValue("rel_obid"));
        vo.setFromClass                     (usersVO.getOutDataAttributeValue("rel_fromClass"));
        vo.setFromObid                      (usersVO.getOutDataAttributeValue("rel_fromObid"));
        vo.setToClass                       (usersVO.getOutDataAttributeValue("rel_toClass"));
        vo.setToObid                        (usersVO.getOutDataAttributeValue("rel_toObid"));
        vo.setFlags                         (Long.parseLong(usersVO.getOutDataAttributeValue("rel_flags") + ""));
        vo.setClassName                     (usersVO.getOutDataAttributeValue("rel_className"));
        vo.setOwner                         (usersVO.getOutDataAttributeValue("rel_owner"));
        vo.setLocker                        (usersVO.getOutDataAttributeValue("rel_locker"));
        vo.setCheckouter                    (usersVO.getOutDataAttributeValue("rel_checkouter"));
        vo.setCheckouted                    ((String)usersVO.getOutData().get("rel_checkouted"));
        vo.setCreator                       (usersVO.getOutDataAttributeValue("rel_creator"));
        vo.setCreated                       ((String)usersVO.getOutData().get("rel_created"));
        vo.setModifier                      (usersVO.getOutDataAttributeValue("rel_modifier"));
        vo.setModified                      ((String)usersVO.getOutData().get("rel_modified"));
        vo.setRouteNodeObid                 (usersVO.getOutDataAttributeValue("rel_routeNodeObid"));
        vo.setStepNodeObid                  (usersVO.getOutDataAttributeValue("rel_stepNodeObid"));
        vo.setStepNodeUserObid              (usersVO.getOutDataAttributeValue("rel_stepNodeUserObid"));
        vo.setStepSequences                 (usersVO.getOutDataAttributeValue("rel_stepSequences"));
        vo.setStepNodeUserSequences         (usersVO.getOutDataAttributeValue("rel_stepNodeUserSequences"));
        vo.setRouteAction                   (usersVO.getOutDataAttributeValue("rel_routeAction"));
        vo.setRouteInstructions             (usersVO.getOutDataAttributeValue("rel_routeInstructions"));
        vo.setComments                      (usersVO.getOutDataAttributeValue("rel_comments"));
        vo.setApprovalStatus                (usersVO.getOutDataAttributeValue("rel_approvalStatus"));
        vo.setScheduledCompletionDate       ((Date)usersVO.getOutData().get("rel_scheduledCompletionDate"));
        vo.setActualCompletionDate          ((Date)usersVO.getOutData().get("rel_actualCompletionDate"));
        vo.setResponsibility                (usersVO.getOutDataAttributeValue("rel_responsibility"));
        vo.setTaskRequirement               (usersVO.getOutDataAttributeValue("rel_taskRequirement"));
        vo.setReviewTask                    (Boolean.parseBoolean(usersVO.getOutDataAttributeValue("rel_reviewTask")));
        vo.setReviewersComments             (usersVO.getOutDataAttributeValue("rel_reviewersComments"));
        vo.setReviewCommentsNeeded          (Boolean.parseBoolean(usersVO.getOutDataAttributeValue("rel_reviewCommentsNeeded")));
        vo.setDueDateOffset                 (usersVO.getOutDataAttributeValue("rel_dueDateOffset"));
        vo.setDateOffsetFrom                (usersVO.getOutDataAttributeValue("rel_dateOffsetFrom"));
        vo.setAssigneeSetDueDate            ((Date) usersVO.getOutData().get("rel_assigneeSetDueDate"));
        vo.setAllowDelegation               (Boolean.parseBoolean(usersVO.getOutDataAttributeValue("rel_allowDelegation")));
        vo.setIsEssential                   (Boolean.parseBoolean(usersVO.getOutDataAttributeValue("rel_isEssential")));
        vo.setParallelNodeProcessionRule    (usersVO.getOutDataAttributeValue("rel_parallelNodeProcessionRule"));
        vo.setTitles                        (usersVO.getOutDataAttributeValue("rel_titles"));
        vo.setActionComments                (usersVO.getOutDataAttributeValue("rel_actionComments"));
        vo.setNotifyEmail                   (Boolean.parseBoolean(usersVO.getOutDataAttributeValue("rel_notifyEmail")));
        vo.setSelfReject                    (Boolean.parseBoolean(usersVO.getOutDataAttributeValue("rel_selfReject")));
        return vo;

    }
    private void setActionForDistributionState(ApprovalVO approvalVO) {
        switch(approvalVO.getApprovalStatus()) {
            case WorkflowConstants.APPROVAL_STATUS_NONE :
                approvalVO.setAction(WorkflowConstants.ACTION_TYPE_AWAITING_ACKNOWLEDGE);
                break;
            case WorkflowConstants.APPROVAL_STATUS_ACKNOWLEDGE :
                approvalVO.setAction(WorkflowConstants.ACTION_TYPE_ACKNOWLEDGED);
                break;
            default:
                approvalVO.setAction(WorkflowConstants.ACTION_TYPE_PENDING);
                break;
        }
    }
    private void setAction(ApprovalVO approvalVO) {
        switch(approvalVO.getApprovalStatus()) {
            case WorkflowConstants.APPROVAL_STATUS_NONE :
                approvalVO.setAction(WorkflowConstants.ACTION_TYPE_AWAITING_APPROVAL);
                break;

            case WorkflowConstants.APPROVAL_STATUS_APPROVE:
                approvalVO.setAction(WorkflowConstants.ACTION_TYPE_APPROVED);
                break;

            case WorkflowConstants.APPROVAL_STATUS_REJECT:
                approvalVO.setAction(WorkflowConstants.ACTION_TYPE_REJECTED);
                break;

            default:
                approvalVO.setAction(WorkflowConstants.ACTION_TYPE_PENDING);
                break;
        }
    }
    private void setActionForApprovalHistory(ApprovalHistoryVO approvalHistoryVO) {
        switch(approvalHistoryVO.getApprovalStatus()) {
            case WorkflowConstants.APPROVAL_STATUS_APPROVE:
                approvalHistoryVO.setAction(WorkflowConstants.ACTION_TYPE_APPROVED);
                break;

            case WorkflowConstants.APPROVAL_STATUS_REJECT:
                approvalHistoryVO.setAction(WorkflowConstants.ACTION_TYPE_REJECTED);
                break;

            case WorkflowConstants.APPROVAL_STATUS_ACKNOWLEDGE:
                approvalHistoryVO.setAction(WorkflowConstants.ACTION_TYPE_ACKNOWLEDGED);
                break;

            case WorkflowConstants.WORKFLOW_REASSIGN:
                approvalHistoryVO.setAction(WorkflowConstants.ACTION_TYPE_REASSIGNED);
                break;

            default:
                approvalHistoryVO.setAction("Not Defined");
                break;
        }
    }

    private boolean isInProcessingWorkflow(){
        boolean isProcessing = false;
        List<WorkflowRouteVO> routeVOList = this.getRouteList();
        if(NullUtil.isNone(routeVOList)) return false;
        for(WorkflowRouteVO vo:  routeVOList) {
            if(WorkflowConstants.STATES_TYPE_INPROCESS.equals( vo.getStates())) return true;
        }
        return false;
    }

    private final <T extends RouteVO> List<T> getRouteListCore(String objRouteState, String states){
        OqlParameter parameter = new OqlParameter();
        if(!StrUtil.isEmpty(objRouteState)) OqlBuilderUtil.constructWherePattern(parameter, "@rel.[routeState]",GlobalConstants.OQL_OPERATOR_EQUAL, objRouteState);
        if(!StrUtil.isEmpty(states))        OqlBuilderUtil.constructWherePattern(parameter, "@this.[states]",GlobalConstants.OQL_OPERATOR_EQUAL, states);
        return this.getRelatedObjects(AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE,
                AppSchemaCommonConstants.BIZCLASS_WORKFLOWROUTE,
                GlobalConstants.FLAG_TYPE_TO,
                parameter.getSelectPattern(),
                parameter.getWherePattern(),
                parameter.getParamPattern());
    }

    private Map<String,Object> getWorkflowListAll() {
        List<BusinessObjectRootVO> wfVOList = this.getRelatedObjects(
                AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE +"," + AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP +"," + AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP + "," + AppSchemaCommonConstants.RELCLASS_WORKFLOWSTEPNODEUSER,
                AppSchemaCommonConstants.BIZCLASS_WORKFLOWROUTE +"," + AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP + "," + AppSchemaCommonConstants.BIZCLASS_USERS,
                GlobalConstants.FLAG_TYPE_TO,
                50);
        Map<String, WorkflowRouteVO> routeVOMap = new HashMap<String, WorkflowRouteVO>();
        Map<String, WorkflowStepVO> stepVOMap = new HashMap<String, WorkflowStepVO>();
        List<UsersVO> usersVOList = new ArrayList<>();
        for(BusinessObjectRootVO vo : wfVOList) {
            if(vo instanceof WorkflowRouteVO){
                routeVOMap.put(vo.getObid(),(WorkflowRouteVO)vo);
            }
            if(vo instanceof WorkflowStepVO){
                stepVOMap.put(vo.getObid(),(WorkflowStepVO)vo);
            }
            if(vo instanceof UsersVO){
                usersVOList.add((UsersVO)vo);
            }
        }
        Map<String,Object> map = new HashMap<>();

        map.put(WorkflowConstants.MAP_KEY_WF_INFO_routeVOMap,routeVOMap);
        map.put(WorkflowConstants.MAP_KEY_WF_INFO_stepVOMap,stepVOMap);
        map.put(WorkflowConstants.MAP_KEY_WF_INFO_usersVOList,usersVOList);
        return map;
    }
}