/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : Code2Organization.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.07.14         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.relation.common.dom;


import com.rap.api.object.foundation.dom.BusinessRelationObject;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.relation.common.model.Code2OrganizationVO;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;


public class Code2Organization extends BusinessRelationObject {
    public Code2Organization(String obid){
        super(obid);
    }
    public Code2Organization(String obid, boolean withOutData) {
        super(obid,withOutData);
    }
    public Code2Organization(Code2OrganizationVO vo){
        super(vo);
    }
    @Override
    public Code2OrganizationVO getVo(){
        return (Code2OrganizationVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeCode2Organization();
    }
    public void initializeCode2Organization(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "Code2Organization[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.validateForCreate(fromObject,toObject,map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.preProcessForCreate(fromObject,toObject,map);
        /*code below*/

    }

    @Override
    protected void postProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.postProcessForCreate(fromObject,toObject,map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
}

