/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : WorkflowStep.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.09.09         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.workflow.dom;


import com.constants.IdGeneratorConstants;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.api.object.workflow.model.WorkflowRouteVO;
import com.rap.api.object.workflow.model.WorkflowStepVO;
import com.rap.api.relation.workflow.dom.WorkflowRouteStep;
import com.rap.api.relation.workflow.dom.WorkflowStepNodeUser;
import com.rap.api.relation.workflow.model.WorkflowRouteStepVO;
import com.rap.api.relation.workflow.model.WorkflowStepNodeUserVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.general.NameGeneratorUtil;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.OqlParameter;
import com.rap.omc.util.TimeServiceUtil;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.util.WorkflowConstants;
import com.rap.workflow.util.WorkflowUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class WorkflowStep extends BusinessObjectMaster {
    private static final Logger log = LoggerFactory.getLogger(WorkflowStep.class);
    public WorkflowStep(String obid){
        super(obid);
    }
    public WorkflowStep(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public WorkflowStep(WorkflowStepVO vo){
        super(vo);
    }
    @Override
    public WorkflowStepVO getVo(){
        return (WorkflowStepVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeWorkflowStep();
    }
    public void initializeWorkflowStep(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "WorkflowStep[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldLifeCycle, String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/
        if(NullUtil.isNull(this.getStepSequences()))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Sequence is Empty!!");
        if(this.getStepSequences() <= 0)
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Sequence must be greater than 0!!");


        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get(WorkflowConstants.MAP_KEY_wfHeaderVO);
        StateInfo stateInfo = (StateInfo)map.get(WorkflowConstants.MAP_KEY_stateInfo);
        WorkflowRouteVO wfRouteVO = (WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_wfRouteVO);
        WorkflowStepVO previousStepVO = (WorkflowStepVO)map.get(WorkflowConstants.MAP_KEY_previousStepVO);
        WorkflowStepVO nextStepVO = (WorkflowStepVO)map.get(WorkflowConstants.MAP_KEY_nextStepVO);
        List<ApprovalVO> approvalVOList = (List<ApprovalVO>)map.get(WorkflowConstants.MAP_KEY_approvalVOList);

        if(NullUtil.isNull(wfHeaderVO))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Workflow Header input nothing!!");
        if(NullUtil.isNull(stateInfo))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"State Info input nothing!!");
        if(NullUtil.isNull(wfRouteVO))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Workflow Header input nothing!!");

        if(!map.keySet().contains(WorkflowConstants.MAP_KEY_previousStepVO))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Previous Step input nothing!!");

        if(!map.keySet().contains(WorkflowConstants.MAP_KEY_nextStepVO))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Next Step input nothing!!");

        if(NullUtil.isNone(approvalVOList))
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Users input nothing");

        if(!NullUtil.isNull(previousStepVO)){
            if(previousStepVO.getStepSequences() >= this.getStepSequences()) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Sequence Error(Pre Check)!!");
            if(!NullUtil.isNull(nextStepVO)){
                if(previousStepVO.getStepSequences() == nextStepVO.getStepSequences()) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Sequence Error(Pre=Next)!!");
                WorkflowRoute routeObj = DomUtil.toDom((WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_wfRouteVO));
                Map<Integer, WorkflowStepVO> stepTreeMap = routeObj.getStepTreeMap();
                WorkflowStepVO tempPreVO=WorkflowUtil.getPreviousStep(stepTreeMap,nextStepVO.getStepSequences());
                if(NullUtil.isNull(tempPreVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Chain check Error(Input Chain)!!");
                if(!tempPreVO.getObid().equals(previousStepVO.getObid())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Chain check Error!!");
            }
        }
        if(!NullUtil.isNull(nextStepVO)){
            if(nextStepVO.getStepSequences() <= this.getStepSequences()) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Sequence Error(Next Check)!!");
        }
    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/
        WorkflowRouteVO wRouteVO = (WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_wfRouteVO);
        StateInfo stateInfo = (StateInfo)map.get(WorkflowConstants.MAP_KEY_stateInfo);

        this.getVo().setNames(NameGeneratorUtil.generateUniqueName(IdGeneratorConstants.ID_GENERATOR_WORKFLOW_STEP_NAME));
        this.getVo().setRouteNodeObid(wRouteVO.getObid());
        this.getVo().setStates(WorkflowConstants.STATES_TYPE_DEFINE);
        this.getVo().setDescriptions(this.getObid()+"_"+stateInfo.getStateName());
        this.getVo().setTitles("Step "+ this.getVo().getStepSequences());
    }

    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/
        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get(WorkflowConstants.MAP_KEY_wfHeaderVO);
        StateInfo stateInfo = (StateInfo)map.get(WorkflowConstants.MAP_KEY_stateInfo);
        WorkflowRouteVO wfRouteVO = (WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_wfRouteVO);
        WorkflowStepVO previousStepVO = (WorkflowStepVO)map.get(WorkflowConstants.MAP_KEY_previousStepVO);
        WorkflowStepVO nextStepVO = (WorkflowStepVO)map.get(WorkflowConstants.MAP_KEY_nextStepVO);
        List<ApprovalVO> approvalVOList = (List<ApprovalVO>)map.get(WorkflowConstants.MAP_KEY_approvalVOList);
        WorkflowRoute routeObj = DomUtil.toDom(wfRouteVO);
        if(NullUtil.isNull(previousStepVO)){
            if(NullUtil.isNull(nextStepVO)){
                //최초 등록인 경우
                this.addFromObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP,wfRouteVO);
            }else{
                //맨앞쪽에 추가되는 경우
                WorkflowStepVO originalFirstStepVO = routeObj.getFirstStep();
                //if(NullUtil.isNull(originalFirstStepVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Data Integrity is invalid!!");
                //if(!previousStepVO.isSame(originalFirstStepVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Data Integrity is invalid!!");
                WorkflowRouteStepVO  routeStepVO = routeObj.getRelationship(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP,AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,GlobalConstants.FLAG_TYPE_TO);
                WorkflowRouteStep routeStepObj = DomUtil.toDom(routeStepVO);
                routeStepObj.changeToObject(this.getVo());
                this.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP,originalFirstStepVO);
            }
        }else{
            if(NullUtil.isNull(nextStepVO)){
                this.addFromObject( AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP, previousStepVO);
            }else{
                WorkflowStep orginNextStepObj = DomUtil.toDom(nextStepVO);
                WorkflowRouteStepVO  routeStepVO = orginNextStepObj.getRelationship(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP,AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,GlobalConstants.FLAG_TYPE_FROM);
                WorkflowRouteStep routeStepObj = DomUtil.toDom(routeStepVO);
                routeStepObj.changeToObject(this.getVo());
                this.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP,nextStepVO);
            }
        }
        this.addUsers(wfHeaderVO,wfRouteVO, stateInfo,approvalVOList);
    }

    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/
        WorkflowRouteVO routeVO = this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP,AppSchemaCommonConstants.BIZCLASS_WORKFLOWROUTE,GlobalConstants.FLAG_TYPE_FROM);
        WorkflowStepVO fromStepVO = this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP,AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,GlobalConstants.FLAG_TYPE_FROM);
        WorkflowStepVO toStepVO = this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP,AppSchemaCommonConstants.BIZCLASS_WORKFLOWSTEP,GlobalConstants.FLAG_TYPE_TO);
        map.put("routeVO",routeVO);
        map.put("fromStepVO",fromStepVO);
        map.put("toStepVO",toStepVO);
    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/
        WorkflowRouteVO routeVO = (WorkflowRouteVO)map.get("routeVO");
        WorkflowStepVO fromStepVO = (WorkflowStepVO)map.get("fromStepVO");
        WorkflowStepVO toStepVO = (WorkflowStepVO)map.get("toStepVO");
        if(!NullUtil.isNull(routeVO)){
            WorkflowRoute fomObj = DomUtil.toDom(routeVO);
            if(!NullUtil.isNull(toStepVO)){
                fomObj.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTESTEP,toStepVO);
            }
        }else{
            if(!NullUtil.isNull(fromStepVO)){
                WorkflowStep fromStepObj = DomUtil.toDom(fromStepVO);
                if(!NullUtil.isNull(toStepVO)){
                    fromStepObj.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWSUBSTEP,toStepVO);
                }
            }else{
                log.info("Data Invalid state");
            }
        }
    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeStates(String newStates,Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/
    }
    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }
    public void    setStepSequences(Integer sequences){
        this.getVo().setStepSequences(sequences);
    }
    public Integer getStepSequences(){
        return this.getVo().getStepSequences();
    }



    public List<WorkflowStepNodeUserVO> getAssignedUserList(){
        return this.getRelationships( AppSchemaCommonConstants.RELCLASS_WORKFLOWSTEPNODEUSER,AppSchemaCommonConstants.BIZCLASS_USERS, GlobalConstants.FLAG_TYPE_TO);
    }
    public WorkflowStepNodeUserVO getMyNodeUser(UsersVO usersVO){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"toObid",GlobalConstants.OQL_OPERATOR_EQUAL,usersVO.getObid());
        return this.getRelationship( AppSchemaCommonConstants.RELCLASS_WORKFLOWSTEPNODEUSER,AppSchemaCommonConstants.BIZCLASS_USERS, GlobalConstants.FLAG_TYPE_TO,
                oqlParameter.getSelectPattern(),oqlParameter.getWherePattern(),oqlParameter.getParamPattern());
    }
    public WorkflowInboxTaskVO getCurrentInboxForUser(UsersVO usersVO){
        WorkflowStepNodeUserVO wfStepNodeUserVO = getMyNodeUser(usersVO);
        if(!NullUtil.isNull(wfStepNodeUserVO)){
            WorkflowStepNodeUser   stepNodeUserObj = DomUtil.toDom(wfStepNodeUserVO);
            return stepNodeUserObj.findInboxTaskCurrent();
        }
        return null;
    }





    /**
     *
     * @return
     */
    public Integer getNextSequenceOfWorkflowStepNodeUser(){
        Integer rtnSequence = 1;
        StringBuffer sql = new StringBuffer();

        sql.append("@REL.[sequences]");
        sql.append("+SortBy@REL.[sequences] desc ");

        String selectPattern = sql.toString();
        sql.setLength(0);   // string buffer 초기화

        sql.append("<this>ThisConnectedWithTo<[WorkflowStepNodeUser]@REL>+");
        sql.append("<[WorkflowStepNodeUser]@REL>FromConnectedWithThis<[WorkflowStep]@WFS>+");
        String fromPattern = sql.toString();
        sql.setLength(0);  // string buffer 초기화

        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@WFS.[obid]", GlobalConstants.OQL_OPERATOR_EQUAL, getVo().getObid());
        String wherePattern = wherePatternBuf.toString();
        String parameterPattern = paramPatternBuf.toString();

        List<ObjectRootVO> searchObjectList = ObjectRoot.searchObjects( AppSchemaCommonConstants.BIZCLASS_USERS, selectPattern, fromPattern, wherePattern, parameterPattern, 0);

        if(searchObjectList.size() > 0) {
            ObjectRootVO objectRootVO = searchObjectList.get(0);
            Map<String, Object> rtnOutData = objectRootVO.getOutData();
            rtnSequence = (Integer)rtnOutData.get("rel_sequences") + 1;
        }
        return rtnSequence;
    }

    /**
     *
     *
     * @return
     */
    public boolean isAllApproved(WorkflowRouteVO routeVO){
        boolean bResult = true;
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        List<WorkflowStepNodeUserVO> stepNodeUserVOList = this.getAssignedUserList();
        for(WorkflowStepNodeUserVO stepNodeUserVO : stepNodeUserVOList) {
            WorkflowInboxTaskVO workflowInboxTaskVO = routeObj.getInboxTask(stepNodeUserVO);
            if(!WorkflowConstants.STATES_TYPE_COMPLETE.equals(workflowInboxTaskVO.getStates()) &&
                    !WorkflowConstants.APPROVAL_STATUS_APPROVE.equals( workflowInboxTaskVO.getApprovalStatus())){
                bResult = false;
                break;
            }
        }
        return bResult;
    }

    /**
     *
     *
     * @param usersObid
     * @return
     */
    public WorkflowStepNodeUserVO getWorkflowStepNodeUserVOByUsersObid(String usersObid) {
        WorkflowStepNodeUserVO rtnWorkflowStepNodeUserVO = null;
        List<WorkflowStepNodeUserVO> stepNodeUserVOList = getAssignedUserList();
        for(WorkflowStepNodeUserVO stepNodeUserVO : stepNodeUserVOList) {
            WorkflowStepNodeUser workflowStepNodeUser = DomUtil.toDom(stepNodeUserVO.getObid(), false);
            if(usersObid.equals(workflowStepNodeUser.getVo().getToObid())) {
                rtnWorkflowStepNodeUserVO = workflowStepNodeUser.getVo();
                break;
            }
        }
        return rtnWorkflowStepNodeUserVO;
    }
    public final void start(WorkflowHeaderVO wfHeaderVO, WorkflowRouteVO routeVO) {
        if(!WorkflowConstants.STATES_TYPE_DEFINE.equals(this.getVo().getStates())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"The states of workflow step must be Define.");
        this.promote();
        buildInboxTaskForStepStart(wfHeaderVO,routeVO);
    }
    public final void reset() {
        StateInfo firstState = getFirstState();
        while(!firstState.getStateName().equals(getVo().getStates())) {
            demote();
        }
    }



    public boolean canBeUserAdded(){
        if(AppSchemaCommonConstants.STATE_STEP_DEFINE.equals(this.getStates())) return true;
        return false;
    }
    public void addUsers(WorkflowHeaderVO wfHeaderVO, WorkflowRouteVO wfRouteVO, StateInfo stateInfo, List<ApprovalVO> approvalVOList) {
        if(!canBeUserAdded()) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cannot add User");
        for(ApprovalVO approvalVO: approvalVOList) {
            this.addUser(wfHeaderVO,wfRouteVO, stateInfo, approvalVO);
        }
    }
    public WorkflowInboxTaskVO createInboxForSelfReject(WorkflowHeaderVO wfHeaderVO, WorkflowRouteVO wfRouteVO, StateInfo stateInfo, ApprovalVO approvalVO) {
        WorkflowStepNodeUserVO wfStepNodeUserVO = this.addUser(wfHeaderVO,wfRouteVO, stateInfo, approvalVO);
        WorkflowInboxTaskVO wfInboxTaskVO = WorkflowUtil.createInboxTask(wfHeaderVO,wfRouteVO,wfStepNodeUserVO);
        return wfInboxTaskVO;
    }
    private WorkflowStepNodeUserVO addUser(WorkflowHeaderVO wfHeaderVO, WorkflowRouteVO wfRouteVO, StateInfo stateInfo, ApprovalVO approvalVO) {
        Users assignee = DomUtil.toDom(approvalVO.getAssigneeObid(), false);
        Map<String, Object> attributeMap = new HashMap<String, Object>();

        Map<String,String> actionMap = WorkflowUtil.getActionInfo(stateInfo.getDefaultRoutePurpose());
        attributeMap.put("routeAction"      , actionMap.get("routeAction"));
        attributeMap.put("actionComments"   , actionMap.get("actionComments"));
        attributeMap.put("routeInstructions", actionMap.get("routeInstructions"));

        if(WorkflowConstants.TRUE.equals(stateInfo.getInboxTaskAutoComplete())) {
            attributeMap.put("dueDateOffset", stateInfo.getDateOffsetDay());
        }else{
            attributeMap.put("dueDateOffset", 0);
        }
        attributeMap.put("isEssential",  ("Y".equals(approvalVO.getIsEssential()))? true : false); //결재자가 필수 결재자 인지 아닌지 여부
        attributeMap.put("parallelNodeProcessionRule", approvalVO.getParallelNodeProcessionRule());
        if(NullUtil.isNull(approvalVO.getStepSequences())){
            approvalVO.setStepSequences(this.getNextSequenceOfWorkflowStepNodeUser());
        }
        attributeMap.put("stepSequences"                , approvalVO.getStepSequences());
        attributeMap.put("stepNodeUserSequences"        , approvalVO.getStepNodeUserSequences());
        attributeMap.put("titles"                       , wfHeaderVO.getTitles());
        attributeMap.put("selfReject"                   , approvalVO.getSelfReject());
        attributeMap.put("notifyEmail"                  , approvalVO.getNotifyEmail());
        attributeMap.put("responsibility"               , approvalVO.getResponsibility());

        Map<String,Object> map = new HashMap<String,Object>();
        map.put(WorkflowConstants.MAP_KEY_wfRouteVO,wfRouteVO);
        return this.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWSTEPNODEUSER, assignee.getVo(), attributeMap,map);
    }
    public void removeUsers(List<ApprovalVO> deletionList) {
        for(ApprovalVO approvalVO : deletionList) removeUser(approvalVO);
    }
    public void removeUser(ApprovalVO approvalVO) {
        WorkflowStepNodeUser workflowStepNodeUser = DomUtil.toDom(approvalVO.getStepNodeUserObid());
        //TODO 삭제 전 Validation Check
        WorkflowStep workflowStep = DomUtil.toDom(workflowStepNodeUser.getFromObid(), false);
        if(WorkflowConstants.APPROVAL_STATUS_COMPLETE.equals(workflowStep.getVo().getStates())){
            new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"You can\'t delete the step was completed.");
        }
        workflowStepNodeUser.deleteObject();
    }
    private void buildInboxTaskForStepStart(WorkflowHeaderVO wfHeaderVO,WorkflowRouteVO routeVO) {
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        List<WorkflowStepNodeUserVO> stepNodeUserList = this.getAssignedUserList();
        for( WorkflowStepNodeUserVO stepNodeUserVO : stepNodeUserList ){
            WorkflowStepNodeUser wfStepNodeUserObj   = DomUtil.toDom(stepNodeUserVO);
            WorkflowInboxTaskVO  workflowInboxTaskVO = wfStepNodeUserObj.findInboxTaskCurrent();
            if( !NullUtil.isNull(workflowInboxTaskVO) ){
                WorkflowInboxTask wfInboxTask = DomUtil.toDom(workflowInboxTaskVO);
                wfStepNodeUserObj.reset();
                WorkflowInboxTaskVO newInboxVO = wfInboxTask.revise();
                //TODO revised 된 Inbox task 초기화 시켜야 함. WorkflowStepNodeUser의 정보도 반영 되어야 함.
                WorkflowInboxTask newInboxObj = DomUtil.toDom(newInboxVO);
                newInboxObj.setParallelNodeProcessionRule(stepNodeUserVO.getParallelNodeProcessionRule());
                newInboxObj.setRouteInstructions(stepNodeUserVO.getRouteInstructions());
                newInboxObj.setStepNodeUserSequences(stepNodeUserVO.getStepNodeUserSequences());
                newInboxObj.setNotifyEmail(stepNodeUserVO.getNotifyEmail());
                newInboxObj.setStepSequences(this.getStepSequences());
                newInboxObj.modifyObject();
                newInboxObj.reset(routeVO.getProcessTimestamp(), TimeServiceUtil.getDBLocalTime());
                WorkflowUtil.createApprovalInfoToEP(wfHeaderVO, routeVO, newInboxObj.getVo());
            }
            else{
                WorkflowUtil.createInboxTask(wfHeaderVO,routeVO,stepNodeUserVO);
            }
            WorkflowUtil.buildDelegatedInboxTask(wfHeaderVO, routeVO, this.getVo(), stepNodeUserVO);
        }
    }
}