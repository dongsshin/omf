/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : CodeMaster.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2017.04.??       DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.common.code.dom;


import com.rap.api.object.common.code.model.CodeDetailVO;
import com.rap.api.object.common.code.model.CodeMasterVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.constants.BusinessCommonConstants;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.omc.util.StrUtil;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.biz.BizCommonUtil;
import org.springframework.http.HttpStatus;

import java.util.*;


public class CodeMaster extends BusinessObjectMaster {
    public CodeMaster(String obid){
        super(obid);
    }
    public CodeMaster(String obid, boolean withOutData) {
        super(obid,withOutData);
    }
    public CodeMaster(CodeMasterVO vo){
        super(vo);
    }
    @Override
    public CodeMasterVO getVo(){
        return (CodeMasterVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeCodeMaster();
    }
    public void initializeCodeMaster(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "CodeMaster[toString()=" + super.toString() + "]";
    }

    @Override
    protected void validateForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/
        CodeMaster dbObj = new CodeMaster(this.getObid());
        List<CodeDetailVO> list = this.getCodeDetailListAll();
        //이미 Code Detail이 생성되어져 있다면 Code Master의 Name은 변경 불가함. Code Detail의 Name은 Code Master의 Name과 값은 Name을 사용함.
        if(!NullUtil.isNone(list) && !dbObj.getNames().equals(newName)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Code Master's name can be changed");

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldLifeCycle, String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldLifeCycle, oldStates, map);
        /*code below*/

    }

   @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/
        this.validationForScope();
        CodeMasterVO materVO = BusinessObjectMaster.findBusinessObjectMaster(this.getClassName(),this.getNames());
        if(!NullUtil.isNull(materVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Code Master(" + this.getNames() + ") is already exists.");
    }

   @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/

    }

   @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/

    }

   @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/
        List<CodeDetailVO> list = this.getCodeDetailListAll();
        //if(!NullUtil.isNone(list)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Code Master{} cannot be deleted because have(has) Code Detail",new Object[]{this.getNames()});
        if(!NullUtil.isNone(list)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"common.code.error.master.delete",new Object[]{this.getNames()});
    }

   @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

   @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

   @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/
       this.validationForScope();
    }

   @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

   @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

   @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

   @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

   @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

   @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

   @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

   @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

   @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

   @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

   @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

   @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

   @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

   @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeStates(String newStates,Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/

    }
    public static final List<CodeMasterVO> getCodeMasterList(String namePattern, CodeMasterVO searchVO, PagingEntity pagingEntity) {
        StringBuffer selectPatternBuf = new StringBuffer();
        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        boolean isPaging = NullUtil.isNull(pagingEntity) ? false : true;

        if(isPaging && StrUtil.isEmpty(pagingEntity.getOrderBy())) new OmfApplicationException(HttpStatus.BAD_REQUEST,"common.code.error.master.paging",new Object[]{"SortBy is Empty"});
        if(!StrUtil.isEmpty(pagingEntity.getOrderBy())) OqlBuilderUtil.addSortByPattern(selectPatternBuf,pagingEntity.getOrderBy());

        if(NullUtil.isNull(searchVO) && !StrUtil.isEmpty(searchVO.getCodeMasterScope())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[codeMasterScope]",GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getCodeMasterScope());
        List<CodeMasterVO> result = null;
        if(isPaging){
            result = BusinessObjectMaster.findObjectPagingList(AppSchemaCommonConstants.BIZCLASS_CODEMASTER,namePattern,"",selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),pagingEntity);
        }else{
            String sortByPattern = searchVO.getOutDataStringValue(GlobalConstants.MAP_KEY_sortByPattern);
            if(!StrUtil.isEmpty(sortByPattern)) OqlBuilderUtil.addSortByPattern(selectPatternBuf,sortByPattern);
            result = BusinessObjectMaster.findObjects(AppSchemaCommonConstants.BIZCLASS_CODEMASTER,namePattern,"",selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),1000);
        }
        return result;
    }
    public static final List<CodeMasterVO> getCodeMasterList(String namePattern, PagingEntity pagingEntity) {
        return getCodeMasterList(namePattern,null,pagingEntity);
    }
    public static List<CodeDetailVO> getCodeDetailList(String codeMasterNames){
    	CodeMasterVO codeMasterVO = findCodeMaster(codeMasterNames);
    	if(NullUtil.isNull(codeMasterVO)) return new ArrayList<CodeDetailVO>();
    	CodeMaster codeMasterDom = new CodeMaster(codeMasterVO);
    	return codeMasterDom.getCodeDetailListAll();
    }
    public static CodeMasterVO findCodeMaster(String codeMasterNames) {
        return BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_CODEMASTER, codeMasterNames);
    }
    //public static List<CodeDetailVO> getCodeListByScope(String codeMasterNames, String code, String codeScope, String states) {
    public static List<CodeDetailVO> getCodeListByScope(CodeDetailVO searchVO, PagingEntity pagingEntity) {
        List<CodeDetailVO> codeDetailList = new ArrayList<CodeDetailVO>();
        CodeMasterVO codeMasterVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_CODEMASTER, searchVO.getNames());

        if(NullUtil.isNull(codeMasterVO)) return codeDetailList;
        StringBuffer fromPattern = new StringBuffer();
        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        StringBuffer selectPatternBuf = new StringBuffer();
        if(!StrUtil.isEmpty(searchVO.getStates())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[states]",GlobalConstants.OQL_OPERATOR_EQUAL, searchVO.getStates());
        if(!StrUtil.isEmpty(searchVO.getUsingOrganizationList())) OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[usingOrganizationList]",GlobalConstants.OQL_OPERATOR_LIKE, "*^" + searchVO.getUsingOrganizationList() + "^*");
        if(NullUtil.isNull(pagingEntity)){
            String sortByPattern = searchVO.getOutDataStringValue(GlobalConstants.MAP_KEY_sortByPattern);
            if(!StrUtil.isEmpty(sortByPattern)) OqlBuilderUtil.addSortByPattern(selectPatternBuf,sortByPattern);
            return BusinessObject.findObjects(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL,searchVO.getNames(),searchVO.getRevision(),
                    selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),
                    1000);
        }
        else{
            return BusinessObject.findObjectPagingList(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL,searchVO.getNames(),searchVO.getRevision(),
                    selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),
                    pagingEntity);
        }
        /*
        if(StrUtil.isEmpty(codeScope)){
            return BusinessObject.findObjects(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL,codeMasterNames,code,selectPatternBuf.toString(),wherePatternBuf.toString(),paramPatternBuf.toString(),false,1000);
        }else{
            fromPattern.append("<this>                   ThisConnectedWithFrom<[Code2Organization]@D2O>+");
            fromPattern.append("<[Code2Organization]@D2O>ToConnectedWithThis  <[" + codeMasterVO.getCodeMasterScope() +"]@ORG>+");

            StringUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@ORG.[className]",GlobalConstants.OQL_OPERATOR_EQUAL, codeMasterVO.getCodeMasterScope());
            StringUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[names]",GlobalConstants.OQL_OPERATOR_EQUAL, codeMasterNames);

            if(!StrUtil.isEmpty(codeScope)) StringUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@ORG.[names]",GlobalConstants.OQL_OPERATOR_EQUAL, codeScope);
            if(!StrUtil.isEmpty(states)) StringUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[states]",GlobalConstants.OQL_OPERATOR_EQUAL, states);
            if(!StrUtil.isEmpty(code)) StringUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[revision]",GlobalConstants.OQL_OPERATOR_IN, code);

            return ObjectRoot.searchObjects(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL, "SortBy@this.[sequences]", fromPattern.toString(),wherePatternBuf.toString(),paramPatternBuf.toString());
        }
        */
    }
    public List<CodeDetailVO> getCodeListByDetailAndScope(String code, String codeScope){
        CodeDetailVO searchVO = new CodeDetailVO();
        searchVO.setNames(this.getNames());
        searchVO.setRevision(code);
        searchVO.setUsingOrganizationList(codeScope);
        return getCodeListByScope(searchVO,null);
    }
    public List<CodeDetailVO> getCodeDetailListAll(){
        return this.getRelatedObjects(AppSchemaCommonConstants.RELCLASS_CODEMASTER2CODE, AppSchemaCommonConstants.BIZCLASS_CODEDETAIL, GlobalConstants.FLAG_TYPE_TO);
    }

    public static final List<CodeDetailVO> getCodeDetailList(String codeMasterObid, String code, String usingOrganizationList, String states, String locale) {
    	CodeMaster codeMasterDom = new CodeMaster(codeMasterObid);
        Map<String,String> parmMap = new HashMap<String,String>();
    	parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_names, codeMasterDom.getVo().getNames());
        parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_revision, code);

        parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_organizationList, usingOrganizationList);
    	parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_states, states);
    	return getCodeDetailListSub(codeMasterDom.getVo(), parmMap, locale, false, false, null);
    }
    public static final List<CodeDetailVO> getCodeDetailWithNames(String codeMasterName, String code){
    	Map<String,String> parmMap = new HashMap<String,String>();
    	parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_names, codeMasterName);
        parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_revision, code);
    	return getCodeDetailList(codeMasterName,parmMap, GlobalConstants.LANG_KO, false, false, null);
    	
    }
    public static final List<CodeDetailVO> getCodeDetailListWithCodeSet(String codeMasterName, Set<String> codeSet){
        Map<String,String> parmMap = new HashMap<String,String>();
        String revisionListStr = StrUtil.convertSet2Str(codeSet);
        parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_names, codeMasterName);
        parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_revision, revisionListStr);
        return getCodeDetailList(codeMasterName,parmMap, GlobalConstants.LANG_KO, false, false, null);

    }
    private static final List<CodeDetailVO> getCodeDetailListSub(CodeMasterVO codeMasterVO, Map<String,String> parmMap, String locale, boolean sort, boolean isPaging, PagingEntity pagingEntity){
    	CodeMaster codeMasterDom = new CodeMaster(codeMasterVO);
        String detailNames = codeMasterVO.getNames();
        String detailRevison = parmMap.get(BusinessCommonConstants.CODE_DETAIL_PARM_revision);
        String states = parmMap.get(BusinessCommonConstants.CODE_DETAIL_PARM_states);
        String organizationList = parmMap.get(BusinessCommonConstants.CODE_DETAIL_PARM_organizationList);
        String attribute01 = parmMap.get(BusinessCommonConstants.CODE_DETAIL_PARM_attribute01);
        String attribute02 = parmMap.get(BusinessCommonConstants.CODE_DETAIL_PARM_attribute02);
        String attribute03 = parmMap.get(BusinessCommonConstants.CODE_DETAIL_PARM_attribute03);
        String titles = parmMap.get(BusinessCommonConstants.CODE_DETAIL_PARM_titles);
        
        StringBuffer selectPattern = new StringBuffer();
        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();
        
        if(sort) OqlBuilderUtil.addSortByPattern(selectPattern, "@this.[sequences]");
        
        if (!StrUtil.isEmpty(detailNames)){
        	OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[names]", GlobalConstants.OQL_OPERATOR_EQUAL, detailNames);
        }
        if (!StrUtil.isEmpty(detailRevison)){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[revision]", GlobalConstants.OQL_OPERATOR_IN, detailRevison);
        }
        if (!StrUtil.isEmpty(states)){
        	OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[states]", GlobalConstants.OQL_OPERATOR_EQUAL, states);
        }
        if (!StrUtil.isEmpty(titles)){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "UPPER(@this.[titles])", GlobalConstants.OQL_OPERATOR_LIKE, GlobalConstants.FLAG_TYPE_ALL + titles + GlobalConstants.FLAG_TYPE_ALL);
        }
        if (!StrUtil.isEmpty(attribute01)){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[attribute01]", GlobalConstants.OQL_OPERATOR_IN, attribute01);
        }

        if (!StrUtil.isEmpty(attribute02)){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[attribute02]", GlobalConstants.OQL_OPERATOR_IN, attribute02);
        }

        if (!StrUtil.isEmpty(attribute03)){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[attribute03]", GlobalConstants.OQL_OPERATOR_EQUAL, attribute03);
        }
        if (!StrUtil.isEmpty(organizationList)){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@ORG.[usingOrganizationList]", GlobalConstants.OQL_OPERATOR_LIKE, organizationList);
        }
        List<CodeDetailVO> result = null;
        if(isPaging) {
        	result = codeMasterDom.getRelatedObjectsPaging(AppSchemaCommonConstants.RELCLASS_CODEMASTER2CODE, AppSchemaCommonConstants.BIZCLASS_CODEDETAIL, GlobalConstants.FLAG_TYPE_TO,
        			selectPattern.toString(), wherePattern.toString(), paramPattern.toString(), pagingEntity);
        }else {
        	result = codeMasterDom.getRelatedObjects(AppSchemaCommonConstants.RELCLASS_CODEMASTER2CODE, AppSchemaCommonConstants.BIZCLASS_CODEDETAIL, GlobalConstants.FLAG_TYPE_TO, 
        			selectPattern.toString(),wherePattern.toString(), paramPattern.toString(), 1);
        }
        setDisplayNameKr(result,locale);
        return result;
    }
    
    public static final List<CodeDetailVO> getCodeDetailList(String codeMasterName, Map<String,String> parmMap, String locale, boolean sort, boolean isPaging, PagingEntity pagingEntity){
    	CodeMasterVO codeMasterVO = CodeMaster.findCodeMaster(codeMasterName);
        parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_names,codeMasterVO.getNames());
    	return getCodeDetailListSub(codeMasterVO,parmMap,locale,sort,isPaging,pagingEntity);
    }
    public static final CodeDetailVO getCodeDetail(String codeMasterObid, String code) {
        CodeMaster codeMaster  = new CodeMaster(codeMasterObid);
        Map<String,String> parmMap = new HashMap<String,String>();
    	parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_names, codeMaster.getVo().getNames());
        parmMap.put(BusinessCommonConstants.CODE_DETAIL_PARM_revision, code);

        List<CodeDetailVO> result = getCodeDetailListSub(codeMaster.getVo(), parmMap, GlobalConstants.LANG_KO, false, false, null);
        return result == null || result.isEmpty() ? null : result.get(0);
    }
    public static final List<CodeMasterVO> getCodeMasterByAssignedAuthType(String authName) {
        StringBuffer selectPatternBuf = new StringBuffer();
        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        OqlBuilderUtil.addSortByPattern(selectPatternBuf, "@this.[names]");
        if( !StrUtil.isEmpty(authName)){
            OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "UPPER(@this.[authType])", GlobalConstants.OQL_OPERATOR_LIKE, GlobalConstants.FLAG_TYPE_ALL + authName.toUpperCase() + GlobalConstants.FLAG_TYPE_ALL);
        }
        return ObjectRoot.findObjects(AppSchemaCommonConstants.BIZCLASS_CODEMASTER, selectPatternBuf.toString(), wherePatternBuf.toString(), paramPatternBuf.toString());
    }
    private static void setDisplayNameKr(List<CodeDetailVO> result, String locale) {
    	if(NullUtil.isNone(result)) return;
        if(result != null && result.size() > 0){
            for( int inx = 0; inx < result.size(); inx++ ){
                if( GlobalConstants.LANG_KO.equals(locale)){
                    if(!StrUtil.isEmpty(result.get(inx).getDisplayNameKr())) {
                        result.get(inx).setTitles(result.get(inx).getDisplayNameKr());
                    }
                }
            }
        }
    }
    private void validationForScope(){
        HashMap<String,Object> chkMap = BizCommonUtil.validateRangeValue(this.getClassName(),"codeMasterScope",this.getAttributeValue("codeMasterScope"));
        if(!BizCommonUtil.isSuccess(chkMap)){
            throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR, BizCommonUtil.getMessage(chkMap));
        }
    }
    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }
}

