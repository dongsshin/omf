/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : WorkflowInboxTask.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.09.09         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.workflow.dom;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.BusinessObjectRoot;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.api.object.workflow.model.WorkflowRouteVO;
import com.rap.api.object.workflow.model.WorkflowStepVO;
import com.rap.api.relation.workflow.dom.WorkflowProjectTask;
import com.rap.api.relation.workflow.dom.WorkflowStepNodeUser;
import com.rap.api.relation.workflow.model.WorkflowProjectTaskVO;
import com.rap.api.relation.workflow.model.WorkflowStepNodeUserVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.schema.util.OmcApplicationConstants;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.TimeServiceUtil;
import com.rap.omc.util.foundation.CommonApiServiceUtil;
import com.rap.omc.util.foundation.LifeCycleUtil;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.model.MailSendVO;
import com.rap.workflow.model.ReassignVO;
import com.rap.workflow.util.WorkflowConstants;
import com.rap.workflow.util.WorkflowUtil;
import org.springframework.http.HttpStatus;

import java.util.*;


public class WorkflowInboxTask extends InBoxTask {
    public WorkflowInboxTask(String obid){
        super(obid);
    }
    public WorkflowInboxTask(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public WorkflowInboxTask(WorkflowInboxTaskVO vo){
        super(vo);
    }
    @Override
    public WorkflowInboxTaskVO getVo(){
        return (WorkflowInboxTaskVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeWorkflowInboxTask();
    }
    public void initializeWorkflowInboxTask(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "WorkflowInboxTask[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForChange(String newClassName, String newName, String newRevision, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newRevision, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newRevision, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newRevision, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldRevision,String oldLifeCycle,  String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldRevision, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/
        UsersVO usersVO = (UsersVO)map.get(WorkflowConstants.MAP_KEY_INBOX_userVO);
        this.getVo().setTaskOwner(usersVO.getNames());
    }

    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/
        WorkflowRouteVO workflowRouteVO = (WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_INBOX_routeVO);
        UsersVO usersVO = (UsersVO)map.get(WorkflowConstants.MAP_KEY_INBOX_userVO);
        this.addFromObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASK, workflowRouteVO, new HashMap<String, Object>());
        this.addFromObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWPROJECTTASK, usersVO, new HashMap<String, Object>());
    }

    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeStates(String newStates,Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/
    }

    @Override
    protected void validateForRevise(Map<String, Object> map){
        super.validateForRevise(map);
        /*code below*/

    }

    @Override
    protected void preProcessForRevise(Map<String, Object> map){
        super.preProcessForRevise(map);
        /*code below*/

    }

    @Override
    protected void postProcessForRevise(Map<String, Object> map){
        super.postProcessForRevise(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeNamesAndRevision(String newNames, String newRevision, Map<String,Object> map){
        super.validateForChangeNamesAndRevision(newNames,newRevision,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNamesAndRevision(String newNames, String newRevision, Map<String,Object> map){
        super.preProcessForChangeNamesAndRevision(newNames,newRevision,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNamesAndRevision(String oldNames, String oldRevision, Map<String,Object> map){
        super.postProcessForChangeNamesAndRevision(oldNames,oldRevision,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }
    public void    setProcessTimestamp(String processTimestamp){
        this.getVo().setProcessTimestamp(processTimestamp);
    }
    public void    setMobileApproval(String mobileApproval){
        this.getVo().setMobileApproval(mobileApproval);
    }
    public void    setNotifyEmail(Boolean notifyEmail){
        this.getVo().setNotifyEmail(notifyEmail);
    }
    public void    setStepNodeObid(String stepNodeObid){
        this.getVo().setStepNodeObid(stepNodeObid);
    }
    public void    setStepNodeUserObid(String stepNodeUserObid){
        this.getVo().setStepNodeUserObid(stepNodeUserObid);
    }
    public void    setStepSequences(Integer stepSequences){
        this.getVo().setStepSequences(stepSequences);
    }
    public void    setStepNodeUserSequences(Integer stepNodeUserSequences){
        this.getVo().setStepNodeUserSequences(stepNodeUserSequences);
    }
    public void    setIsEssential(Boolean isEssential){
        this.getVo().setIsEssential(isEssential);
    }
    public void    setRouteNodeObid(String routeNodeObid){
        this.getVo().setRouteNodeObid(routeNodeObid);
    }
    public void    setReviewTask(Boolean reviewTask){
        this.getVo().setReviewTask(reviewTask);
    }
    public void    setReviewersComments(String reviewersComments){
        this.getVo().setReviewersComments(reviewersComments);
    }
    public void    setReviewCommentsNeeded(Boolean reviewCommentsNeeded){
        this.getVo().setReviewCommentsNeeded(reviewCommentsNeeded);
    }
    public void    setDueDateOffset(Integer dueDateOffset){
        this.getVo().setDueDateOffset(dueDateOffset);
    }
    public void    setDateOffsetFrom(String dateOffsetFrom){
        this.getVo().setDateOffsetFrom(dateOffsetFrom);
    }
    @JsonIgnore
    public void    setAssigneeSetDueDate(Date assigneeSetDueDate){
        this.getVo().setAssigneeSetDueDate(assigneeSetDueDate);
    }
    @JsonIgnore
    public void    setAssigneeSetDueDate(String    assigneeSetDueDate){
        this.getVo().setAssigneeSetDueDate(assigneeSetDueDate);
    }
    public Boolean getReviewTask(){
        return this.getVo().getReviewTask();
    }
    public String getReviewersComments(){
        return this.getVo().getReviewersComments();
    }
    public Boolean getReviewCommentsNeeded(){
        return this.getVo().getReviewCommentsNeeded();
    }
    public Integer getDueDateOffset(){
        return this.getVo().getDueDateOffset();
    }
    public String getDateOffsetFrom(){
        return this.getVo().getDateOffsetFrom();
    }
    public Date getAssigneeSetDueDate(){
        return this.getVo().getAssigneeSetDueDate();
    }
    public String getRouteNodeObid(){
        return this.getVo().getRouteNodeObid();
    }
    public String getStepNodeObid(){
        return this.getVo().getStepNodeObid();
    }
    public String getStepNodeUserObid(){
        return this.getVo().getStepNodeUserObid();
    }
    public Integer getStepSequences(){
        return this.getVo().getStepSequences();
    }
    public Integer getStepNodeUserSequences(){
        return this.getVo().getStepNodeUserSequences();
    }
    public Boolean getIsEssential(){
        return this.getVo().getIsEssential();
    }
    public String getProcessTimestamp(){
        return getVo().getProcessTimestamp();
    }
    public String getMobileApproval(){
        return getVo().getMobileApproval();
    }
    public Boolean getNotifyEmail(){
        return getVo().getNotifyEmail();
    }
    //***************************************************************************************************************************//
    @Override
    protected void validateForSubmit(ApprovalVO approvalVO , Map<String, Object> map){
        super.validateForSubmit(approvalVO,map);
        if(!WorkflowConstants.APPROVAL_STATUS_ACTION_SET.contains(approvalVO.getApprovalStatus())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Approval Status Error");

        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get("wfHeaderVO");
        if(NullUtil.isNull(wfHeaderVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Header Info Error");

        BusinessObjectRootVO targetVO = (BusinessObjectRootVO)map.get("targetVO");
        if(NullUtil.isNull(targetVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Target Info Error");

        WorkflowRouteVO routeVO = this.getRoute();
        if(NullUtil.isNull(routeVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Route Info Error");
        WorkflowStepNodeUserVO stepNodeUserVO = this.getStepNodeUser();
        if(NullUtil.isNull(stepNodeUserVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Step Node User Info Error");
        map.put("routeVO",routeVO);
        map.put("stepNodeUserVO",stepNodeUserVO);
    }
    @Override
    protected void preProcessForSubmit(ApprovalVO approvalVO , Map<String, Object> map){
        super.preProcessForSubmit(approvalVO,map);
    }
    @Override
    protected void submitProcess(ApprovalVO approvalVO , Map<String, Object> map){
        super.submitProcess(approvalVO,map);
        WorkflowRouteVO routeVO = (WorkflowRouteVO)map.get("routeVO");
        WorkflowStepNodeUserVO stepNodeUserVO= (WorkflowStepNodeUserVO)map.get("stepNodeUserVO");
        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get("wfHeaderVO");
        BusinessObjectRootVO targetVO = (BusinessObjectRootVO)map.get("targetVO");
        List<FilesVO> fileList = (List<FilesVO>)map.get("fileList");

        processInboxForSubmitProcess(approvalVO, wfHeaderVO,targetVO, routeVO,stepNodeUserVO);

        if(WorkflowConstants.APPROVAL_STATUS_APPROVE.equals(approvalVO.getApprovalStatus()))     this.approve(wfHeaderVO,targetVO, routeVO,stepNodeUserVO);
        if(WorkflowConstants.APPROVAL_STATUS_REJECT.equals(approvalVO.getApprovalStatus()))      this.reject(wfHeaderVO, targetVO, routeVO,stepNodeUserVO);
        if(WorkflowConstants.APPROVAL_STATUS_ACKNOWLEDGE.equals(approvalVO.getApprovalStatus())) this.acknowledge(wfHeaderVO, targetVO, routeVO,stepNodeUserVO);

        processFilesForSubmitProcess(fileList);
    }
    @Override
    protected final void postProcessForSubmit(ApprovalVO approvalVO , Map<String, Object> map){
        super.postProcessForSubmit(approvalVO,map);
    }
    public WorkflowStepNodeUserVO getStepNodeUser(){
        WorkflowStepNodeUser obj = DomUtil.toDom(this.getStepNodeUserObid());
        return obj.getVo();
    }
    private void processFilesForSubmitProcess(List<FilesVO> fileList) {
        if(!NullUtil.isNone(fileList)){
            this.checkInFiles(GlobalConstants.FILE_UNLOCK, GlobalConstants.FILE_APPEND, fileList);
        }
    }
    private void processInboxForSubmitProcess(ApprovalVO approvalVO, WorkflowHeaderVO wfHeaderVO, BusinessObjectRootVO targetVO, WorkflowRouteVO routeVO, WorkflowStepNodeUserVO stepNodeUserVO) {
        WorkflowStepNodeUser stepNodeUserObj = DomUtil.toDom(stepNodeUserVO);
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        Set<String> attributes = new HashSet<>();
        //결재 대상이 위임건이 아닌 경우 일반 결재 형식으로 하고 다만 Reject 일 경우 위임으로 인해 생성 된 inboxtask는 삭제 되어야 한다.
        if(NullUtil.isNone(this.getOriginTaskOwner())) {
            if(!WorkflowConstants.STATES_TYPE_ASSIGNED.equals(this.getStates())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"No subject to approval.");

            stepNodeUserObj.setComments(approvalVO.getComments());
            stepNodeUserObj.setApprovalStatus(approvalVO.getApprovalStatus());
            stepNodeUserObj.setActualCompletionDate(TimeServiceUtil.getDBLocalTime());

            this.setActualCompletionDate(stepNodeUserObj.getActualCompletionDate());
            this.setComments(stepNodeUserObj.getComments());
            this.setApprovalStatus(stepNodeUserObj.getApprovalStatus());
            this.setMobileApproval(approvalVO.getMobileApproval());

            attributes.clear();
            attributes.add("comments");attributes.add("approvalStatus");attributes.add("actualCompletionDate");
            stepNodeUserObj.updateObject(attributes);

            attributes.clear();
            attributes.add("comments");attributes.add("approvalStatus");attributes.add("actualCompletionDate");attributes.add("mobileApproval");
            this.updateObject(attributes);
            this.promote();
            this.promote();

            if(approvalVO.getApprovalStatus().equals(WorkflowConstants.APPROVAL_STATUS_REJECT)) {
                List<WorkflowInboxTaskVO> workflowInboxTaskVOList = routeObj.getInboxTaskList();
                for(WorkflowInboxTaskVO inboxTaskVO : workflowInboxTaskVOList) {
                    if(NullUtil.isNone(inboxTaskVO.getOriginTaskOwner())) continue;
                    if(WorkflowConstants.STATES_TYPE_ASSIGNED.equals(inboxTaskVO.getStates()) && this.getStepSequences() == inboxTaskVO.getStepSequences()) {
                        if(inboxTaskVO.getOriginTaskOwner().equals(inboxTaskVO.getTaskOwner())) { //origin inboxTask
                            inboxTaskVO.setOriginTaskOwner(null);
                            WorkflowInboxTask inboxTask = DomUtil.toDom(inboxTaskVO);
                            attributes.clear();attributes.add("originTaskOwner");
                            inboxTask.updateObject(attributes);
                        }else{
                            WorkflowInboxTask inboxTask = DomUtil.toDom(inboxTaskVO);
                            inboxTask.deleteInboxTask(routeObj);
                        }
                    }
                }
            }
            routeObj.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASKHISTORY, this.getVo(), new HashMap<String, Object>());
        }else{//위임에 의해 생성 된 inbox task도 처리
            String orgineTaskOwner = this.getOriginTaskOwner();
            Integer stepSequences = this.getStepSequences();
            List<WorkflowInboxTaskVO> workflowInboxTaskVOList = routeObj.getInboxTaskList();
            for(WorkflowInboxTaskVO inboxTaskVO : workflowInboxTaskVOList) {
                if(NullUtil.isNone(inboxTaskVO.getOriginTaskOwner())
                        || !orgineTaskOwner.equals(inboxTaskVO.getOriginTaskOwner())
                        || !(stepSequences == inboxTaskVO.getStepSequences())
                        || !WorkflowConstants.STATES_TYPE_ASSIGNED.equals(inboxTaskVO.getStates())) continue;

                if(inboxTaskVO.getOriginTaskOwner().equals(inboxTaskVO.getTaskOwner())) { //origin inboxTask
                    stepNodeUserObj = DomUtil.toDom(inboxTaskVO.getRouteNodeObid(), false);
                    UsersVO usersVo = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_USERS, ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, ""));

                    stepNodeUserObj.setComments(approvalVO.getComments() + " by "+  usersVo.getTitles()+" [Delegate]" );
                    stepNodeUserObj.setApprovalStatus(approvalVO.getApprovalStatus());
                    stepNodeUserObj.setActualCompletionDate(TimeServiceUtil.getDBLocalTime());
                    attributes.clear();attributes.add("comments");attributes.add("approvalStatus");attributes.add("actualCompletionDate");
                    stepNodeUserObj.updateObject(attributes);

                    if(!WorkflowConstants.STATES_TYPE_ASSIGNED.equals(inboxTaskVO.getStates())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"No subject to approval.");

                    inboxTaskVO.setOriginTaskOwner(null);
                    inboxTaskVO.setActualCompletionDate(stepNodeUserObj.getActualCompletionDate());
                    inboxTaskVO.setComments(stepNodeUserObj.getComments());
                    inboxTaskVO.setApprovalStatus(stepNodeUserObj.getApprovalStatus());
                    inboxTaskVO.setMobileApproval(approvalVO.getMobileApproval());
                    attributes.clear();attributes.add("originTaskOwner");attributes.add("comments");attributes.add("approvalStatus");attributes.add("actualCompletionDate");attributes.add("mobileApproval");
                    WorkflowInboxTask originWorkflowInboxTask = DomUtil.toDom(inboxTaskVO);
                    originWorkflowInboxTask.updateObject(attributes);
                    originWorkflowInboxTask.promote();
                    originWorkflowInboxTask.promote();
                    routeObj.addToObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASKHISTORY, inboxTaskVO, new HashMap<String, Object>());
                }else{
                    WorkflowInboxTask inboxTask = DomUtil.toDom(inboxTaskVO);
                    inboxTask.deleteObject();
                }
            }
        }
    }
    @Override
    protected void validateForReassignApprover(ReassignVO reassignVO, Map<String,Object> map) {
        super.validateForReassignApprover(reassignVO,map);
        if(WorkflowConstants.APPROVAL_STATUS_COMPLETE.equals(this.getStates())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"It cannot be reassigned.[Reason: complete approval]");

        if(StrUtil.isEmpty(this.getStepNodeUserObid())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"getStepNodeUserObid Invalid");
        if(StrUtil.isEmpty(this.getRouteNodeObid()))    throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"getRouteNodeObid Invalid");
        if(StrUtil.isEmpty(this.getStepNodeObid()))     throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"getStepNodeObid Invalid");

        WorkflowStepNodeUser wfStepNodeUserObj = DomUtil.toDom(this.getStepNodeUserObid());
        Users toUsers = DomUtil.toDom(reassignVO.getToAssigneeObid(), false);

        WorkflowRouteVO wfRouteVO = this.getRoute();
        if(NullUtil.isNull(wfRouteVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Data Invalid");
        WorkflowRoute wfRouteObj    = DomUtil.toDom(wfRouteVO);
        WorkflowHeaderVO wfHeaderVO = wfRouteObj.getWorkflowHeader();
        if(NullUtil.isNull(wfHeaderVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Data Invalid");

        if(!this.getRouteNodeObid().equals(wfRouteObj.getObid()))                throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"this.getRouteNodeObid().equals(wfRouteObj.getObid()) Invalid");
        if(wfStepNodeUserObj.getToObid().equals(reassignVO.getToAssigneeObid())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Cannot be reassigned to the same person.");

        WorkflowStep wfStepObj = DomUtil.toDom(this.getStepNodeObid());
        List<WorkflowStepNodeUserVO> stepNodeUserVOList = wfStepObj.getAssignedUserList();
        for(WorkflowStepNodeUserVO stepNodeUserVO : stepNodeUserVOList) {
            if(reassignVO.getToAssigneeObid().equals(stepNodeUserVO.getToObid())) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Person to reassign already exists in state.");
        }
        map.put("wfHeaderVO",wfHeaderVO);
        map.put("wfRouteVO",wfRouteVO);
        map.put("wfStepVO",wfStepObj.getVo());
        map.put("wfStepNodeUserVO",wfStepNodeUserObj.getVo());
        map.put("toUsersVO",toUsers.getVo());
    }
    @Override
    protected void preProcessForReassignApprover(ReassignVO reassignVO, Map<String,Object> map) {
        super.preProcessForReassignApprover(reassignVO,map);
    }
    @Override
    protected void reassignApproverCore(ReassignVO reassignVO, Map<String,Object> map) {
        WorkflowStepNodeUserVO wfStepNodeUserVO = (WorkflowStepNodeUserVO)map.get("wfStepNodeUserVO");
        UsersVO toUsersVO = (UsersVO)map.get("toUsersVO");
        WorkflowRouteVO wfRouteVO = (WorkflowRouteVO)map.get("wfRouteVO");

        //Relation 생성전 Revise해야 함.
        WorkflowInboxTaskVO newWfInboxTaskVO = this.revise();

        //이전 버전은 History로 남겨 둔다.
        this.addFromObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWROUTETASKHISTORY, wfRouteVO, new HashMap<String, Object>());

        WorkflowInboxTask newWfInboxTaskObj = DomUtil.toDom(newWfInboxTaskVO);

        WorkflowProjectTaskVO wfProjectTaskVO = newWfInboxTaskObj.getProjectTask();
        WorkflowProjectTask wfProjectTaskObj  = DomUtil.toDom(wfProjectTaskVO);
        wfProjectTaskObj.changeFromObject(toUsersVO);

        WorkflowStepNodeUser wfStepNodeUserObj = DomUtil.toDom(wfStepNodeUserVO);
        wfStepNodeUserObj.changeToObject(toUsersVO);

        refreshDelegationInfo(reassignVO,newWfInboxTaskObj,toUsersVO);

        //신규로 할당되어진 Inbox를 Return한다.
        map.put("reassignedInboxVO",newWfInboxTaskObj.getVo());
    }
    @Override
    protected void postProcessForReassignApprover(ReassignVO reassignVO, Map<String,Object> map) {
        super.postProcessForReassignApprover(reassignVO,map);

        WorkflowHeaderVO wfHeaderVO = (WorkflowHeaderVO)map.get("wfHeaderVO");
        WorkflowRouteVO wfRouteVO   = (WorkflowRouteVO)map.get("wfRouteVO");
        WorkflowStepVO wfStepVO     = (WorkflowStepVO)map.get("wfStepVO");
        WorkflowStepNodeUserVO wfStepNodeUserVO = (WorkflowStepNodeUserVO)map.get("wfStepNodeUserVO");
        WorkflowInboxTaskVO newInboxVO = (WorkflowInboxTaskVO)map.get("reassignedInboxVO");
        UsersVO toUsersVO = (UsersVO)map.get("toUsersVO");

        WorkflowUtil.createReassignApprovalInfoToEP(wfHeaderVO, wfRouteVO, newInboxVO, wfStepNodeUserVO);
        if(newInboxVO.getNotifyEmail() )  WorkflowUtil.notifyMail(wfHeaderVO, wfRouteVO, toUsersVO);
        WorkflowUtil.buildDelegatedInboxTask(wfHeaderVO,wfRouteVO, wfStepVO, wfStepNodeUserVO);
    }
    private void refreshDelegationInfo(ReassignVO reassignVO,WorkflowInboxTask newWfInboxTaskObj, UsersVO toUsersVO){
        refreshNewInbox(reassignVO,newWfInboxTaskObj, toUsersVO);
        refreshPreviousInbox(reassignVO, toUsersVO);
    }
    private void refreshNewInbox(ReassignVO reassignVO,WorkflowInboxTask newWfInboxTaskObj, UsersVO toUsersVO){
        Set<String> attrSet = new HashSet<>();
        newWfInboxTaskObj.setTaskOwner(toUsersVO.getNames());
        newWfInboxTaskObj.setOriginTaskOwner(this.getTaskOwner());
        attrSet.add("taskOwner");attrSet.add("originTaskOwner");
        newWfInboxTaskObj.updateObject(attrSet);
    }
    private void refreshPreviousInbox(ReassignVO reassignVO, UsersVO toUsersVO){
        this.setDelegatedTo(reassignVO.getToAssigneeObid());
        this.setApprovalStatus(WorkflowConstants.WORKFLOW_REASSIGN);
        this.setComments(WorkflowConstants.WORKFLOW_REASSIGN +" "+ toUsersVO.getTitles());
        this.setActionComments(reassignVO.getComments());
        this.setActualCompletionDate(TimeServiceUtil.getDBLocalTime());
        Set<String> attrSet = new HashSet<>();
        attrSet.add("delegatedTo");attrSet.add("approvalStatus");attrSet.add("delegatedFrom");
        attrSet.add("comments");attrSet.add("actionComments");attrSet.add("actualCompletionDate");
        this.updateObject(attrSet);
    }
    public void reset(String processTimestamp, Date dbLocalTime){
        getVo().setActualCompletionDate((Date)null);
        getVo().setComments(null);
        getVo().setApprovalStatus(WorkflowConstants.APPROVAL_STATUS_NONE);
        getVo().setDelegatedFrom(null);
        getVo().setDelegatedTo(null);
        getVo().setProcessTimestamp(processTimestamp);
        if(WorkflowConstants.WBS_DATE_OFFSET_FROM.equals(getVo().getDateOffsetFrom()) && getVo().getDueDateOffset() > 0) {
            Calendar c = Calendar.getInstance();
            c.setTime(dbLocalTime);
            c.add(Calendar.DATE, getVo().getDueDateOffset());
            getVo().setScheduledCompletionDate(c.getTime());
        }
        modifyObject();

        StateInfo firstState = this.getFirstState();
        while(!firstState.getStateName().equals(getVo().getStates())) {
            demote();
        }
    }
    /**
     * WorkflowRoute 및 BusinessObjectRoot 가져 오기
     *
     * @return
     */
    public final List<ObjectRootVO> getWorkflowRouteVOAndBusinessObjectRootVO() {
        List<ObjectRootVO> rtnObjectRootVOList = new ArrayList<ObjectRootVO>();

        WorkflowRouteVO routeVO = getRoute();
        WorkflowRoute   routeObj = DomUtil.toDom(routeVO);
        rtnObjectRootVOList.add(routeVO);

        BusinessObjectRoot businessObjectRoot = routeObj.getBusinessObjectRoot();
        rtnObjectRootVOList.add(businessObjectRoot.getVo());
        return rtnObjectRootVOList;
    }
    public final static WorkflowInboxTaskVO getWorkflowInboxTaskVO(String routeNodeObid) {
        if(NullUtil.isNone(routeNodeObid) ) throw new IllegalArgumentException();
        StringBuffer selectPatternBuf = new StringBuffer();
        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[routeNodeObid]",GlobalConstants.OQL_OPERATOR_EQUAL, routeNodeObid);
        return ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK, GlobalConstants.FLAG_TYPE_ALL, true, selectPatternBuf.toString(), wherePatternBuf.toString(), paramPatternBuf.toString());
    }
    public void updateWorkflowInboxTask(WorkflowStepNodeUserVO stepNodeUser){
        this.setRouteInstructions(stepNodeUser.getRouteInstructions());
        this.setParallelNodeProcessionRule(stepNodeUser.getParallelNodeProcessionRule());
        this.setIsEssential(stepNodeUser.getIsEssential());
        this.setNotifyEmail(stepNodeUser.getNotifyEmail());
        this.setRouteNodeObid(stepNodeUser.getRouteNodeObid());
        this.setStepNodeObid(stepNodeUser.getStepNodeObid());
        this.setStepNodeUserObid(stepNodeUser.getStepNodeUserObid());
        this.setStepSequences(stepNodeUser.getStepSequences());
        this.setStepNodeUserSequences(stepNodeUser.getStepNodeUserSequences());
        this.modifyObject();
    }
    public static int getInboxTaskCountForUser(String userId){
        Set<String> routeActionSet = new HashSet<String>();
        Set<String> stateSet = new HashSet<String>();
        Set<String> inboxTaskTypeSet = new HashSet<String>();
        Set<String> approvalStatusSet = new HashSet<String>();

        routeActionSet.addAll(WorkflowConstants.ROUTE_ACTIONS_NOT_COMMENT_SET);
        stateSet.add(AppSchemaCommonConstants.STATE_INBOX_TASK_ASSIGNED);
        inboxTaskTypeSet.add(WorkflowConstants.INBOX_TASK_TYPE_Workflow);
        approvalStatusSet.add(WorkflowConstants.APPROVAL_STATUS_NONE);

        return getInboxCountForUserSub(userId,routeActionSet,stateSet,inboxTaskTypeSet,approvalStatusSet);
    }
    private void approve(WorkflowHeaderVO wfHeaderVO, BusinessObjectRootVO targetVO, WorkflowRouteVO routeVO, WorkflowStepNodeUserVO stepNodeUserVO) {
        WorkflowUtil.createSubmitApprovalInfoToEP(wfHeaderVO, routeVO, stepNodeUserVO, WorkflowConstants.APPROVAL_STATUS_APPROVE);
        WorkflowStep stepObj = DomUtil.toDom(stepNodeUserVO.getFromObid());
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        /*
         * Any일 경우에는 해당 Step의 모든 결재를 승인으로 한 후
         */
        boolean goToTheNext = false;
        if(WorkflowConstants.ROUTE_ACTION_RULE_ANY.equals(stepNodeUserVO.getParallelNodeProcessionRule())) {//Next Step 또는 Branch 정보로 Next Route로 이동
            /*
             *  1) 현재 Step의 결재 중 승인 건 외에는 모드 삭제 함.(InboxTask, Route Node)
             *  2) 다음 Stpe이 존재 하는지 체크하여
             *          Next Step(O)일 경우에는 다음 Step의 결재의 Inbox task를 생성
             *          Next Step(X) Final일 경우에는 Branch 정보로 Next Route로 이동 후 start route 시킴
             */
            //현 Step의 다른 Any type의 Inbox Task 삭제
            this.deleteWorkflowInboxTaskExceptThis(wfHeaderVO, routeVO, stepObj.getVo(), stepNodeUserVO);
            goToTheNext = true;
        }else if(WorkflowConstants.ROUTE_ACTION_RULE_ALL.equals(stepNodeUserVO.getParallelNodeProcessionRule()) && stepObj.isAllApproved(routeVO)) {
            goToTheNext = true;
        }
        if(goToTheNext) { //현재 Step의 모든 결재가 완료 된 상태이면
            stepObj.promote();
            WorkflowStepVO nextWorkflowStepVO = routeObj.getNextStep(stepObj.getStepSequences());
//            String routeCompletionAction      = routeObj.getRouteCompletionAction();
            if(NullUtil.isNull(nextWorkflowStepVO)) { //final Step이면
                routeObj.promoteConnectedObject(wfHeaderVO, targetVO);
            }else{
                WorkflowStep nextWorkflowStep = DomUtil.toDom(nextWorkflowStepVO);
                nextWorkflowStep.start(wfHeaderVO,routeVO);
            }
        }
    }
    private void acknowledge(WorkflowHeaderVO wfHeaderVO, BusinessObjectRootVO targetVO, WorkflowRouteVO routeVO, WorkflowStepNodeUserVO stepNodeUserVO) {
        WorkflowUtil.createSubmitApprovalInfoToEP(wfHeaderVO, routeVO, stepNodeUserVO, WorkflowConstants.APPROVAL_STATUS_APPROVE);
        WorkflowStep workflowStep = DomUtil.toDom(stepNodeUserVO.getFromObid());
        if(workflowStep.isAllApproved(routeVO)) {
            workflowStep.promote();//현재 Step을 완료 시킴
            WorkflowRoute routeObj = DomUtil.toDom(routeVO);
            routeObj.promote();//현재 Route를 완료 시킴
            if (OmcApplicationConstants.WF_RCA_PROMOTE_CONNECTED_OBJECT.equals(routeVO.getRouteCompletionAction())) {
                //Target Object promote.
                routeObj.promoteConnectedObject(wfHeaderVO,targetVO);
            }
            StateInfo targetState = CommonApiServiceUtil.getTargetState(wfHeaderVO.getObid(), wfHeaderVO.getBranchTo(), GlobalConstants.WORKFLOW_TYPE_PROMOTE);
            WorkflowHeader wfHeaderDom = DomUtil.toDom(wfHeaderVO);
            //Next Route Start
            if(!NullUtil.isNull(targetState)) wfHeaderDom.startRoute(targetState.getStateName());
        }
    }
    private void reject(WorkflowHeaderVO wfHeaderVO, BusinessObjectRootVO targetVO, WorkflowRouteVO routeVO, WorkflowStepNodeUserVO stepNodeUserVO) {

        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        WorkflowStepNodeUser stepNodeUserObj = DomUtil.toDom(stepNodeUserVO);
        WorkflowHeader wfHeaderObj = DomUtil.toDom(wfHeaderVO);

        if(!NullUtil.isNull(stepNodeUserVO)) WorkflowUtil.createSubmitApprovalInfoToEP(wfHeaderVO, routeVO, stepNodeUserVO, WorkflowConstants.APPROVAL_STATUS_REJECT);
        //같은 Step에 결재 요청중인 InboxTask 삭제
        List<WorkflowInboxTaskVO> toBeDeleteWorkflowInboxTaskVOList = routeObj.getInboxTaskList();
        for(WorkflowInboxTaskVO workflowInboxTaskVO : toBeDeleteWorkflowInboxTaskVOList) {
            if(!WorkflowConstants.STATES_TYPE_ASSIGNED.equals(workflowInboxTaskVO.getStates())) continue;
            WorkflowInboxTask toBeDeleteWorkflowInboxTask = DomUtil.toDom(workflowInboxTaskVO);
            toBeDeleteWorkflowInboxTask.deleteInboxTask(routeObj);
            WorkflowUtil.createDeleteApprovalInfoToEP(wfHeaderVO, routeVO, toBeDeleteWorkflowInboxTask.getVo());
        }

        List<String> rtnStateList = LifeCycleUtil.getLifeCycleStateStringListByName(wfHeaderVO.getObjectLifeCycle());
        int currentRouteStatesIndex = rtnStateList.indexOf(wfHeaderVO.getObjectCurrentStates());

        CommonApiServiceUtil.promote(wfHeaderVO.getObid());

        BusinessObjectRoot rejectedBusinessObjectRoot = DomUtil.toDom(this.getObid(), false);
        int rejectTargetRouteStatesIndex = rtnStateList.indexOf(rejectedBusinessObjectRoot.getStates());
        for(int idx = currentRouteStatesIndex ; idx >= rejectTargetRouteStatesIndex; idx --) {
            WorkflowRouteVO workflowRouteVO = wfHeaderObj.getRouteByTargetState(rtnStateList.get(idx));
            if(!NullUtil.isNull(workflowRouteVO)) {
                WorkflowRoute toBeResetWorkflowRoute = DomUtil.toDom(workflowRouteVO);
                toBeResetWorkflowRoute.reset();
                toBeResetWorkflowRoute.resetStepList();
            }
        }
        /*
         * Restart WorkflowRoute
         */
        StateInfo restartState = LifeCycleUtil.getLifeCycleStateByStateName(targetVO.getLifeCycle(), targetVO.getStates());
        if(WorkflowConstants.TRUE.equals(restartState.getRouteAutoStartOnReject())) {
            wfHeaderObj.setOutDataAttributeValue("approvalStatus", WorkflowConstants.APPROVAL_STATUS_REJECT);
            wfHeaderObj.startRoute(wfHeaderObj.getStates());
        }
        //Send Mail For Reject (For creator)
        MailSendVO mailSendVO = new MailSendVO();
        mailSendVO.setSendType(WorkflowConstants.MAIL_TYPE_REJECT);
        mailSendVO.setObid(targetVO.getObid());
        mailSendVO.setClassName(targetVO.getClassName());
        mailSendVO.setNames(targetVO.getNames());
        mailSendVO.setCurrentStatus( targetVO.getStates() );
        mailSendVO.setFromUserId(ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID));
        List<String> toUserIdList = new ArrayList<String>();
        toUserIdList.add(rejectedBusinessObjectRoot.getCreator());

        mailSendVO.setToUserIdList(toUserIdList);
        WorkflowUtil.txnCreateMailSendInfo(mailSendVO);

    }
    public void deleteInboxTask(WorkflowRoute workflowRoute) {
        String originTaskOwner = getVo().getOriginTaskOwner();
        Integer stepSequence   = getVo().getStepSequences();
        //위임건 삭제
        if(!StrUtil.isEmpty(this.getOriginTaskOwner()) && this.getOriginTaskOwner().equals(this.getTaskOwner())) {
            List<WorkflowInboxTaskVO> workflowInboxTaskVOList = workflowRoute.getInboxTaskList();
            for(WorkflowInboxTaskVO wfInboxTaskVO : workflowInboxTaskVOList) {
                if(!NullUtil.isNone(wfInboxTaskVO.getOriginTaskOwner()) &&
                        originTaskOwner.equals(wfInboxTaskVO.getOriginTaskOwner()) &&
                        stepSequence == wfInboxTaskVO.getStepSequences()) {
                    WorkflowInboxTask workflowInboxTask = DomUtil.toDom(wfInboxTaskVO.getObid(), false);
                    workflowInboxTask.deleteObject();
                }
            }
        }
    }

    private void deleteWorkflowInboxTaskExceptThis(WorkflowHeaderVO wfHeaderVO, WorkflowRouteVO routeVO, WorkflowStepVO stepVO,
                                                   WorkflowStepNodeUserVO workflowStepNodeUserVO) {

        WorkflowStep stepObj = DomUtil.toDom(stepVO);
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);

        List<WorkflowStepNodeUserVO> stepNodeUserVOList = stepObj.getAssignedUserList();
        Set<String> deletedWorkflowStepNodeUserObidSet = new HashSet<String>();
        for(WorkflowStepNodeUserVO stepNodeUserVO : stepNodeUserVOList) {
            WorkflowStepNodeUser toBeDeleteWorkflowStepNodeUser = DomUtil.toDom(stepNodeUserVO.getObid());
            if(!workflowStepNodeUserVO.getObid().equals(stepNodeUserVO.getObid())
                    ||  !WorkflowConstants.APPROVAL_STATUS_APPROVE.equals(toBeDeleteWorkflowStepNodeUser.getApprovalStatus())) {
                deletedWorkflowStepNodeUserObidSet.add(stepNodeUserVO.getObid());
                toBeDeleteWorkflowStepNodeUser.setComments("Automatically skiped by system.");
                toBeDeleteWorkflowStepNodeUser.setApprovalStatus(WorkflowConstants.APPROVAL_STATUS_APPROVE);
                toBeDeleteWorkflowStepNodeUser.setActualCompletionDate(TimeServiceUtil.getDBLocalTime());
                toBeDeleteWorkflowStepNodeUser.modifyObject();
            }
        }

        routeObj.deleteWorkflowInboxTaskList(wfHeaderVO,deletedWorkflowStepNodeUserObidSet);
    }
}

