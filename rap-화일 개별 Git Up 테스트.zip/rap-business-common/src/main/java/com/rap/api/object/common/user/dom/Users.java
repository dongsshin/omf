/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : Users.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.07.14         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.common.user.dom;


import com.rap.api.object.common.organization.model.PlantUnitVO;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.workflow.dom.InBoxTask;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.BusinessObjectRoot;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.UserPropertyConstants;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.schema.util.OmcUniqueIDGenerator;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.workflow.util.WorkflowConstants;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class Users extends AbstractUsers {
    public Users(String obid){
        super(obid);
    }
    public Users(String obid, boolean withOutData) {
        super(obid,withOutData);
    }
    public Users(UsersVO vo){
        super(vo);
    }
    @Override
    public UsersVO getVo(){
        return (UsersVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeUsers();
    }
    public void initializeUsers(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "Users[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldLifeCycle, String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/

    }

    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/

    }

    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForWithdraw(Map<String, Object> map){
       super.validateForWithdraw(map);
       /*code below*/
       /*����������� �ٲ�� Session�� Refresh�ϱ� ���� System User�� Time Stamp�� �ٲپ��ش�.*/
       String timeStamp = OmcUniqueIDGenerator.getObid();
       FoundationUserUtil.setTimeStampSystemUser(this.getVo().getNames(), timeStamp);

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeStates(String newStates,Map<String, Object> map){
        super.validateForChangeStates(newStates,map);
        /*code below*/


    }
    @Override
    protected void preProcessForChangeStates(String newStates,Map<String, Object> map){
        super.preProcessForChangeStates(newStates,map);
        /*code below*/

    }
    @Override
    protected void postProcessForChangeStates(String oldStates,Map<String, Object> map){
        super.postProcessForChangeStates(oldStates,map);
        /*code below*/
        if(this.getStates().equals(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_INACTIVE)){
            FoundationUserUtil.inActiviateUser(this.getNames());
        }else if(this.getStates().equals(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE)){
            FoundationUserUtil.activiateUser(this.getNames());
        }
    }
    public final Map<String,Object> getUserSessionInfo(){
    	return FoundationUserUtil.getUserSessionInfo(this.getVo().getNames());
    }
    public final String getUserLocale(){
       return FoundationUserUtil.getUserProperty(this.getNames(),UserPropertyConstants.USER_PROPERTY_LOCALE);
    }
    public final void inActivate(){

        this.changeStates(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_INACTIVE);
    }
    public final void activate(){

        this.changeStates(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);
    }
    public final void addRole(Set<String> roleSet) {

        FoundationUserUtil.addRoleToUser(this.getNames(),roleSet);
    }
    public final void removeRole(Set<String> roleSet) {
        FoundationUserUtil.removeRoleToUser(this.getNames(),roleSet);
    }

    public final void addGroup(Set<String> groupSet) {

        FoundationUserUtil.addGroupToUser(this.getNames(),groupSet);
    }
    public final void removeGroup(Set<String> groupSet) {
        FoundationUserUtil.removeGroupToUser(this.getNames(),groupSet);
    }

    public final static UsersVO findMe(String userId) {
        return ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_USERS, userId);
    }
    public List<PlantUnitVO> retrievePlantUnitList(){
        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[states]", GlobalConstants.OQL_OPERATOR_EQUAL, AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);
        return getRelatedObjects(AppSchemaCommonConstants.RELCLASS_MEMBERS,AppSchemaCommonConstants.BIZCLASS_PLANTUNIT, GlobalConstants.FLAG_TYPE_ALL,
                "SortBy@this.[titles]",wherePattern.toString(),paramPattern.toString(),
                false,false,0,1);
    }

    public List<WorkflowInboxTaskVO> getApprovalList(){
        return getApprovalList(this.getVo().getNames());
    }

    /**
     * ���� ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @return
     */
    public List<WorkflowInboxTaskVO> getApprovalList(PagingEntity pagingEntity){
        return getApprovalList(pagingEntity, this.getVo().getNames());
    }

    //INBOX_TASK_TYPE_SAVEDRAFT

    /**
     * ���� ��� ��ȸ
     *
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getApprovalList(String userId){
        return getInboxTaskList(userId, WorkflowConstants.INBOX_TASK_TYPE_APPROVAL);
    }

    /**
     * ���� ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getApprovalList(PagingEntity pagingEntity, String userId){
        return getInboxTaskList(pagingEntity, userId, WorkflowConstants.INBOX_TASK_TYPE_APPROVAL,new HashMap<String,Object>());
    }
    /**
     * Save Draft ��ȸ
     *
     * @return
     */
    public List<WorkflowInboxTaskVO> getSaveDraftList(){
        return getSaveDraftList(this.getVo().getNames());
    }

    /**
     * Save Draft With Paging
     *
     * @param pagingEntity
     * @return
     */
    public List<WorkflowInboxTaskVO> getSaveDraftList(PagingEntity pagingEntity){
        return getSaveDraftList(pagingEntity, this.getVo().getNames());
    }

    /**
     * Save Draft ��ȸ
     *
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getSaveDraftList(String userId){
        return getInboxTaskList(userId, WorkflowConstants.INBOX_TASK_TYPE_SAVE_DRAFT);
    }

    /**
     * Save Draft ��ȸ With Paging
     *
     * @param pagingEntity
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getSaveDraftList(PagingEntity pagingEntity, String userId){
        return getInboxTaskList(pagingEntity, userId, WorkflowConstants.INBOX_TASK_TYPE_SAVE_DRAFT,new HashMap<String,Object>());
    }
    /**
     * ���� ��� ��ȸ
     *
     * @return
     */
    public List<WorkflowInboxTaskVO> getDistributionList(){
        return getDistributionList(this.getVo().getNames());
    }

    /**
     * ���� ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @return
     */
    public List<WorkflowInboxTaskVO> getDistributionList(PagingEntity pagingEntity){
        return getDistributionList(pagingEntity, this.getVo().getNames());
    }

    /**
     * ���� ��� ��ȸ
     *
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getDistributionList(String userId){
        return getInboxTaskList(userId, WorkflowConstants.INBOX_TASK_TYPE_DISTRIBUTION);
    }

    /**
     * ���� ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getDistributionList(PagingEntity pagingEntity, String userId){
        return getInboxTaskList(pagingEntity, userId, WorkflowConstants.INBOX_TASK_TYPE_DISTRIBUTION,new HashMap<String,Object>());
    }

    /**
     * �����û ��� ��ȸ
     *
     * @return
     */
    public List<WorkflowInboxTaskVO> getRequestedList(){
        return getRequestedList(this.getVo().getNames());
    }

    /**
     * �����û ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @return
     */
    public List<WorkflowInboxTaskVO> getRequestedList(PagingEntity pagingEntity){
        return getRequestedList(pagingEntity, this.getVo().getNames());
    }

    /**
     * Pending Change ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @return
     */
    public List<WorkflowInboxTaskVO> getPendingChangeList(PagingEntity pagingEntity){
        return getPendingChangeList(pagingEntity, this.getVo().getNames());
    }

    /**
     * Pending Change Mailing ��� ��ȸ
     *
     * @param
     * @return
     */
    public static List<WorkflowInboxTaskVO> getPendingChangeMailingList(){
        return getInboxTaskList(null, null, WorkflowConstants.INBOX_TASK_TYPE_PENDING_CHANGE,new HashMap<String,Object>());
    }

    /**
     * �����û ��� ��ȸ
     *
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getRequestedList(String userId){
        return getInboxTaskList(userId, WorkflowConstants.INBOX_TASK_TYPE_REQUESTED);
    }

    /**
     * ���û ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getRequestedList(PagingEntity pagingEntity, String userId){
        return getInboxTaskList(pagingEntity, userId, WorkflowConstants.INBOX_TASK_TYPE_REQUESTED,new HashMap<String,Object>());
    }

    /**
     * Pending Change ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getPendingChangeList(PagingEntity pagingEntity, String userId){
        return getInboxTaskList(pagingEntity, userId, WorkflowConstants.INBOX_TASK_TYPE_PENDING_CHANGE,new HashMap<String,Object>());
    }

    /**
     * ���οϷ� ��� ��ȸ
     *
     * @return
     */
    public List<WorkflowInboxTaskVO> getApprovedList(){
        return getApprovedList(this.getVo().getNames());
    }

    /**
     * ���οϷ� ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @return
     */
    public List<WorkflowInboxTaskVO> getApprovedList(PagingEntity pagingEntity){
        return getApprovedList(pagingEntity, this.getVo().getNames());
    }

    /**
     * ���οϷ� ��� ��ȸ
     *
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getApprovedList(String userId){
        return getInboxTaskList(userId, WorkflowConstants.INBOX_TASK_TYPE_APPROVED);
    }

    /**
     * ���οϷ� ��� ��ȸ With Paging
     *
     * @param pagingEntity
     * @param userId
     * @return
     */
    public static final List<WorkflowInboxTaskVO> getApprovedList(PagingEntity pagingEntity, String userId){
        return getInboxTaskList(pagingEntity, userId, WorkflowConstants.INBOX_TASK_TYPE_APPROVED,new HashMap<String,Object>());
    }

    /**
     * ����� ID �� taskType �������� InboxTask ��� ��ȸ
     *
     * @param userId
     * @param taskType
     * @return
     */
    private static List<WorkflowInboxTaskVO> getInboxTaskList(PagingEntity pagingEntity, String userId, String taskType, Map<String,Object> parmMap){
        boolean isActivity = false;
        List<WorkflowInboxTaskVO> result = InBoxTask.getInboxListForUser(userId, (String)parmMap.get("startDate"), (String)parmMap.get("endDate"), taskType, isActivity, pagingEntity);
        if(result != null && result.size() > 0) {
            String obid = null;
            BusinessObjectRoot obj = null;
            for( int inx = result.size() - 1; inx >= 0; inx-- ){
                obid = (String)result.get(inx).getOutDataAttributeValue("targetObid");
                try{
                    obj = DomUtil.toDom((String)result.get(inx).getOutDataAttributeValue("targetObid"));
                    if(!NullUtil.isNull(obj)){
                        result.get(inx).setOutDataAttributeValue("names", obj.getVo().getNames());
                        result.get(inx).setOutDataAttributeValue("states", obj.getVo().getStates());
                        result.get(inx).setOutDataAttributeValue("titles", obj.getCommonTitlesForDisplay());
                        result.get(inx).setOutDataAttributeValue("lifeCycle", obj.getVo().getLifeCycle());
                        result.get(inx).setOutDataAttributeValue("targetClassDesc", obj.getVo().getOutDataAttributeValue("this_displayedClassName"));
                    }
                }
                catch(Exception e){
                    e.printStackTrace();
                    result.get(inx).setOutDataAttributeValue("names", "-");
                    result.get(inx).setOutDataAttributeValue("states", "-");
                    result.get(inx).setOutDataAttributeValue("titles", obid);
                    result.get(inx).setOutDataAttributeValue("lifeCycle", "-");
                    result.get(inx).setOutDataAttributeValue("targetClassDesc", "Deleted");
                }
            }
        }
        return result;
    }


    /**
     * ����� ID �� taskType �������� InboxTask ��� ��ȸ
     *
     * @param userId
     * @param taskType
     * @return
     */
    private static List<WorkflowInboxTaskVO> getInboxTaskList(String userId, String taskType){
        return getInboxTaskList(new PagingEntity(), userId, taskType,null);
    }


    /**
     * get Users by EmpNo
     *
     * @param names
     * @return
     */
    public static final Users getUsers(String names){
        if(NullUtil.isNull(names) ) { return null; };

        UsersVO usersVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_USERS, names);
        if(!NullUtil.isNull(usersVO) ){ return DomUtil.toDom(usersVO); }
        return null;
    }
    /**
     * get Users by EmpNo
     *
     * @param idList
     * @return
     */
    public static final List<UsersVO> getUserListById(String idList ){
        if( NullUtil.isNull(idList) ){
            return null;
        };

        List<UsersVO> voUserList = BusinessObjectMaster.findObjects( AppSchemaCommonConstants.BIZCLASS_USERS, idList );
        return voUserList;
    }

    /**
     * get Users by user Mail Id
     *
     * @param mailId
     * @return
     */
    public static final Users getUsersByMailId(String mailId){
        return getUsersByMailId(mailId, null);
    }

    public static final Users getUsersByMailId(String mailId, String inOffiStatFlag){

        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();

        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[mailId]",
                GlobalConstants.OQL_OPERATOR_EQUAL, mailId);
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "IFNULL(NULLIF(@this.[inOffiStatFlag],''),'C')",
                GlobalConstants.OQL_OPERATOR_EQUAL, "C");
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[states]",
                GlobalConstants.OQL_OPERATOR_EQUAL, "Active");

        UsersVO usersVO = ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_USERS
                , "", false, "", wherePattern.toString(), paramPattern.toString());
        if( !NullUtil.isNull(usersVO) ){ return DomUtil.toDom(usersVO); }
        return null;
    }

    private String getMakeTitles(){
        String titles = "";
        titles = this.getVo().getDescriptions();
        return titles;
    }

    private String getAccountingDepartmentCode() {
        return "getAccountingDepartmentCode Not Defined";
    }
    private String getAccountingDepartmentCodeDesc() {
        return "getAccountingDepartmentCodeDesc Not Defined";
    }

    private String getMainModule(){
        return "getMainModule";
    }


    public UsersVO getDelegator(){
        if(StrUtil.isEmpty(this.getVo().getAbsenceDelegate())) return null;
        return BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_USERS,this.getVo().getAbsenceDelegate());
    }
    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }
    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }
}