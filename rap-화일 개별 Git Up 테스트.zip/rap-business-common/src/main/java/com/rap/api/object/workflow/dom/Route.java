/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : Route.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.11.30         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.object.workflow.dom;


import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.workflow.model.RouteVO;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import lombok.extern.slf4j.Slf4j;

import java.util.Map;



public class Route extends BusinessObjectMaster {
    public Route(String obid){
        super(obid);
    }
    public Route(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public Route(RouteVO vo){
        super(vo);
    }
    @Override
    public RouteVO getVo(){
        return (RouteVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeRoute();
    }
    public void initializeRoute(){
    /*code here*/
    }
    @Override
    public String toString() {
        return "Route[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForWithdraw(Map<String, Object> map){
        super.validateForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void preProcessForWithdraw(Map<String, Object> map){
        super.preProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void postProcessForWithdraw(Map<String, Object> map){
        super.postProcessForWithdraw(map);
        /*code below*/

    }

    @Override
    protected void validateForDemote(Map<String, Object> map){
        super.validateForDemote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDemote(Map<String, Object> map){
        super.preProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDemote(Map<String, Object> map){
        super.postProcessForDemote(map);
        /*code below*/

    }

    @Override
    protected void validateForPromote(Map<String, Object> map){
        super.validateForPromote(map);
        /*code below*/

    }

    @Override
    protected void preProcessForPromote(Map<String, Object> map){
        super.preProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void postProcessForPromote(Map<String, Object> map){
        super.postProcessForPromote(map);
        /*code below*/

    }

    @Override
    protected void validateForClone(Map<String, Object> map){
        super.validateForClone(map);
        /*code below*/

    }

    @Override
    protected void preProcessForClone(Map<String, Object> map){
        super.preProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void postProcessForClone(Map<String, Object> map){
        super.postProcessForClone(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeStates(String newState, Map<String,Object> map){
        super.validateForChangeStates(newState,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeStates(String newState, Map<String,Object> map){
        super.preProcessForChangeStates(newState,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeStates(String oldState, Map<String,Object> map){
        super.postProcessForChangeStates(oldState,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.validateForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeLifeCycleAndStates(String newLifeCycle, String newStates,Map<String,Object> map){
        super.preProcessForChangeLifeCycleAndStates(newLifeCycle,newStates,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeLifeCycleAndStates(String oldLifeCycle, String oldStates,Map<String,Object> map){
        super.postProcessForChangeLifeCycleAndStates(oldLifeCycle,oldStates,map);
        /*code below*/

    }

    @Override
    protected void validateForChangeNames(String newNames, Map<String,Object> map){
        super.validateForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeNames(String newNames, Map<String,Object> map){
        super.preProcessForChangeNames(newNames,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeNames(String oldNames, Map<String,Object> map){
        super.postProcessForChangeNames(oldNames,map);
        /*code below*/

    }

    @Override
    protected void validateForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.validateForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void preProcessForChange(String newClassName, String newName, String newLifeCycle, String newStates, Map<String, Object> map){
        super.preProcessForChange(newClassName, newName, newLifeCycle, newStates, map);
        /*code below*/

    }

    @Override
    protected void postProcessForChange(String oldClassName, String oldName, String oldLifeCycle, String oldStates, Map<String, Object> map){
        super.postProcessForChange(oldClassName, oldName, oldLifeCycle, oldStates, map);
        /*code below*/

    }

    @Override
    protected void validateForCreate(Map<String, Object> map){
        super.validateForCreate(map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(Map<String, Object> map){
        super.preProcessForCreate(map);
        /*code below*/

    }

    @Override
    protected void postProcessForCreate(Map<String, Object> map){
        super.postProcessForCreate(map);
        /*code below*/

    }

    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }

    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/

    }

    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }

    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/

    }

    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/

    }

    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/

    }
    public void    setRouteCompletionAction(String routeCompletionAction){
        this.getVo().setRouteCompletionAction(routeCompletionAction);
    }
    public void    setSubRouteVisibility(Boolean subRouteVisibility){
        this.getVo().setSubRouteVisibility(subRouteVisibility);
    }
    public void    setRouteBasePurpose(String routeBasePurpose){
        this.getVo().setRouteBasePurpose(routeBasePurpose);
    }
    public void    setRestartUpOnTaskRejection(Boolean restartUpOnTaskRejection){
        this.getVo().setRestartUpOnTaskRejection(restartUpOnTaskRejection);
    }
    public void    setAutoStopOnRejection(String autoStopOnRejection){
        this.getVo().setAutoStopOnRejection(autoStopOnRejection);
    }
    public void    setOrganizations(String organizations){
        this.getVo().setOrganizations(organizations);
    }
    public void    setRouteStatus(String routeStatus){
        this.getVo().setRouteStatus(routeStatus);
    }
    public void    setProcessTimestamp(String processTimestamp){
        this.getVo().setProcessTimestamp(processTimestamp);
    }
    public void    setActivityUrl(String activityUrl){
        this.getVo().setActivityUrl(activityUrl);
    }
    public String getRouteCompletionAction(){
        return this.getVo().getRouteCompletionAction();
    }
    public Boolean getSubRouteVisibility(){
        return this.getVo().getSubRouteVisibility();
    }
    public String getRouteBasePurpose(){
        return this.getVo().getRouteBasePurpose();
    }
    public Boolean getRestartUpOnTaskRejection(){
        return this.getVo().getRestartUpOnTaskRejection();
    }
    public String getAutoStopOnRejection(){
        return this.getVo().getAutoStopOnRejection();
    }
    public String getOrganizations(){
        return this.getVo().getOrganizations();
    }
    public String getRouteStatus(){
        return this.getVo().getRouteStatus();
    }
    public String getProcessTimestamp(){
        return this.getVo().getProcessTimestamp();
    }
    public String getActivityUrl(){
        return this.getVo().getActivityUrl();
    }

    public WorkflowHeaderVO getWorkflowHeader(){
        return this.getRelatedObject(AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE, AppSchemaCommonConstants.BIZCLASS_WORKFLOWHEADER, GlobalConstants.FLAG_TYPE_FROM);
    }

}

