/*
 * ===================================================================
 * System Name : PLM Project
 * Program ID : WorkflowStepNodeUser.java
 * ===================================================================
 *  Modification Date      Modifier           Description
 *      2020.09.09         DS Shin            Initial
 * ===================================================================
 */
package com.rap.api.relation.workflow.dom;


import com.fasterxml.jackson.annotation.JsonIgnore;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.BusinessRelationObject;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.object.workflow.dom.WorkflowInboxTask;
import com.rap.api.object.workflow.dom.WorkflowStep;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.api.object.workflow.model.WorkflowRouteVO;
import com.rap.api.object.workflow.model.WorkflowStepVO;
import com.rap.api.relation.workflow.model.WorkflowStepNodeUserVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.OqlParameter;
import com.rap.workflow.util.WorkflowConstants;
import org.springframework.http.HttpStatus;

import java.util.*;


public class WorkflowStepNodeUser extends BusinessRelationObject {
    public WorkflowStepNodeUser(String obid){
        super(obid);
    }
    public WorkflowStepNodeUser(String obid,boolean withOutData){
        super(obid,withOutData);
    }
    public WorkflowStepNodeUser(WorkflowStepNodeUserVO vo){
        super(vo);
    }
    @Override
    public WorkflowStepNodeUserVO getVo(){
        return (WorkflowStepNodeUserVO)super.getVo();
    }
    @Override
    public void initialize(){
        super.initialize();
        initializeWorkflowStepNodeUser();
    }
    public void initializeWorkflowStepNodeUser(){
    /*code here*/
        if(this.getVo().getComments() == null) this.setComments("");
    }
    @Override
    public String toString() {
        return "WorkflowStepNodeUser[toString()=" + super.toString() + "]";
    }


    @Override
    protected void validateForDelete(Map<String, Object> map){
        super.validateForDelete(map);
        /*code below*/
        WorkflowStep workflowStep = DomUtil.toDom(this.getFromObid(), false);
        if(WorkflowConstants.APPROVAL_STATUS_COMPLETE.equals(workflowStep.getVo().getStates())){
            new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"You can\'t delete the step was completed.");
        }
    }
    @Override
    protected void preProcessForDelete(Map<String, Object> map){
        super.preProcessForDelete(map);
        /*code below*/
        WorkflowStep stepObj = DomUtil.toDom(this.getFromObid());
        map.put("_stepObj_",stepObj);
    }
    @Override
    protected void postProcessForDelete(Map<String, Object> map){
        super.postProcessForDelete(map);
        /*code below*/
        //연관된 Inbox를 삭제한다.
        this.clearInbox();
        //최종 삭제이면 Step을 삭제함
        WorkflowStep stepObj = (WorkflowStep)map.get("_stepObj_");
        int count =stepObj.getCountForRelatedObjects(AppSchemaCommonConstants.RELCLASS_WORKFLOWSTEPNODEUSER,AppSchemaCommonConstants.BIZCLASS_USERS, GlobalConstants.FLAG_TYPE_TO,"","","");
        if(count == 0){
            stepObj.deleteObject();
        }
    }
    @Override
    protected void validateForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.validateForCreate(fromObject,toObject,map);
        /*code below*/

    }

    @Override
    protected void preProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.preProcessForCreate(fromObject,toObject,map);
        /*code below*/
        WorkflowRouteVO wfRouteVO = (WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_wfRouteVO);
        this.setRouteNodeObid(wfRouteVO.getObid());
        WorkflowStep stepDom = DomUtil.toDom(this.getFromObid());
        this.setStepNodeObid(stepDom.getObid());
        this.setStepNodeUserObid("Temporary");//DB에 Not Null되어져 있기 때문에 Setting한 후 Post에서 다시 Update함
        this.setStepSequences(stepDom.getStepSequences());
    }

    @Override
    protected void postProcessForCreate(ObjectRootVO fromObject, ObjectRootVO toObject, Map<String,Object> map){
        super.postProcessForCreate(fromObject,toObject,map);
        /*code below*/
        this.setStepNodeUserObid(this.getObid());

        Set<String> attributes = new HashSet<>();
        attributes.add("stepNodeUserObid");
        this.updateObject(attributes);
    }
    @Override
    protected void validateForModify(Map<String, Object> map){
        super.validateForModify(map);
        /*code below*/
        WorkflowRouteVO wfRouteVO = (WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_wfRouteVO);
        if(NullUtil.isNull(wfRouteVO)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Route Info is empty!!!");
    }
    @Override
    protected void preProcessForModify(Map<String, Object> map){
        super.preProcessForModify(map);
        /*code below*/
        this.setStepNodeUserObid(this.getObid());
        WorkflowStep stepDom = DomUtil.toDom(this.getFromObid());
        this.setStepNodeObid(stepDom.getObid());
        this.setStepSequences(stepDom.getStepSequences());
        WorkflowRouteVO wfRouteVO = (WorkflowRouteVO)map.get(WorkflowConstants.MAP_KEY_wfRouteVO);
        this.setRouteNodeObid(wfRouteVO.getObid());
    }

    @Override
    protected void postProcessForModify(Map<String, Object> map){
        super.postProcessForModify(map);
        /*code below*/

    }
    @Override
    protected void validateForChangeClassName(String newClassName, Map<String,Object> map){
        super.validateForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void preProcessForChangeClassName(String newClassName, Map<String,Object> map){
        super.preProcessForChangeClassName(newClassName,map);
        /*code below*/

    }

    @Override
    protected void postProcessForChangeClassName(String oldClassName, Map<String,Object> map){
        super.postProcessForChangeClassName(oldClassName,map);
        /*code below*/

    }


    public void    setRouteAction(String routeAction){
        this.getVo().setRouteAction(routeAction);
    }
    public void    setRouteInstructions(String routeInstructions){
        this.getVo().setRouteInstructions(routeInstructions);
    }
    public void    setComments(String comments){
        this.getVo().setComments(comments);
    }
    public void    setApprovalStatus(String approvalStatus){
        this.getVo().setApprovalStatus(approvalStatus);
    }
    @JsonIgnore
    public void    setScheduledCompletionDate(Date scheduledCompletionDate){
        this.getVo().setScheduledCompletionDate(scheduledCompletionDate);
    }
    @JsonIgnore
    public void    setScheduledCompletionDate(String    scheduledCompletionDate){
        this.getVo().setScheduledCompletionDate(scheduledCompletionDate);
    }
    @JsonIgnore
    public void    setActualCompletionDate(Date actualCompletionDate){
        this.getVo().setActualCompletionDate(actualCompletionDate);
    }
    @JsonIgnore
    public void    setActualCompletionDate(String    actualCompletionDate){
        this.getVo().setActualCompletionDate(actualCompletionDate);
    }
    public void    setResponsibility(String responsibility){
        this.getVo().setResponsibility(responsibility);
    }
    public void    setTaskRequirement(String taskRequirement){
        this.getVo().setTaskRequirement(taskRequirement);
    }
    public void    setRouteNodeObid(String routeNodeObid){
        this.getVo().setRouteNodeObid(routeNodeObid);
    }
    public void    setStepNodeUserObid(String stepNodeUserObid){
        this.getVo().setStepNodeUserObid(stepNodeUserObid);
    }
    public void    setStepNodeObid(String stepNodeObid){
        this.getVo().setStepNodeObid(stepNodeObid);
    }
    public void    setReviewTask(Boolean reviewTask){
        this.getVo().setReviewTask(reviewTask);
    }
    public void    setReviewersComments(String reviewersComments){
        this.getVo().setReviewersComments(reviewersComments);
    }
    public void    setReviewCommentsNeeded(Boolean reviewCommentsNeeded){
        this.getVo().setReviewCommentsNeeded(reviewCommentsNeeded);
    }
    public void    setDueDateOffset(Integer dueDateOffset){
        this.getVo().setDueDateOffset(dueDateOffset);
    }
    public void    setDateOffsetFrom(String dateOffsetFrom){
        this.getVo().setDateOffsetFrom(dateOffsetFrom);
    }
    @JsonIgnore
    public void    setAssigneeSetDueDate(Date assigneeSetDueDate){
        this.getVo().setAssigneeSetDueDate(assigneeSetDueDate);
    }
    @JsonIgnore
    public void    setAssigneeSetDueDate(String    assigneeSetDueDate){
        this.getVo().setAssigneeSetDueDate(assigneeSetDueDate);
    }
    public void    setAllowDelegation(Boolean allowDelegation){
        this.getVo().setAllowDelegation(allowDelegation);
    }
    public void    setIsEssential(Boolean isEssential){
        this.getVo().setIsEssential(isEssential);
    }
    public void    setParallelNodeProcessionRule(String parallelNodeProcessionRule){
        this.getVo().setParallelNodeProcessionRule(parallelNodeProcessionRule);
    }
    public void    setTitles(String titles){
        this.getVo().setTitles(titles);
    }

    public void    setStepSequences(Integer stepSequences){
        this.getVo().setStepSequences(stepSequences);
    }

    public void    setActionComments(String actionComments){
        this.getVo().setActionComments(actionComments);
    }
    public void    setNotifyEmail(Boolean notifyEmail){
        this.getVo().setNotifyEmail(notifyEmail);
    }
    public void    setSelfReject(Boolean selfReject){
        this.getVo().setSelfReject(selfReject);
    }
    public String getRouteAction(){
        return this.getVo().getRouteAction();
    }
    public String getRouteInstructions(){
        return this.getVo().getRouteInstructions();
    }
    public String getComments(){
        return this.getVo().getComments();
    }


    public String getApprovalStatus(){
        return this.getVo().getApprovalStatus();
    }
    public Date getScheduledCompletionDate(){
        return this.getVo().getScheduledCompletionDate();
    }
    public Date getActualCompletionDate(){
        return this.getVo().getActualCompletionDate();
    }
    public String getResponsibility(){
        return this.getVo().getResponsibility();
    }
    public String getTaskRequirement(){
        return this.getVo().getTaskRequirement();
    }
    public String getRouteNodeObid(){
        return this.getVo().getRouteNodeObid();
    }
    public String getStepNodeUserObid(){
        return this.getVo().getStepNodeUserObid();
    }
    public String getStepNodeObid(){
        return this.getVo().getStepNodeObid();
    }


    public Boolean getReviewTask(){
        return this.getVo().getReviewTask();
    }
    public String getReviewersComments(){
        return this.getVo().getReviewersComments();
    }
    public Boolean getReviewCommentsNeeded(){
        return this.getVo().getReviewCommentsNeeded();
    }
    public Integer getDueDateOffset(){
        return this.getVo().getDueDateOffset();
    }
    public String getDateOffsetFrom(){
        return this.getVo().getDateOffsetFrom();
    }
    public Date getAssigneeSetDueDate(){
        return this.getVo().getAssigneeSetDueDate();
    }
    public Boolean getAllowDelegation(){
        return this.getVo().getAllowDelegation();
    }
    public Boolean getIsEssential(){
        return this.getVo().getIsEssential();
    }
    public String getParallelNodeProcessionRule(){
        return this.getVo().getParallelNodeProcessionRule();
    }
    public String getTitles(){
        return this.getVo().getTitles();
    }
    public Integer getStepSequences(){
        return this.getVo().getStepSequences();
    }
    public Integer getStepNodeUserSequences(){
        return this.getVo().getStepNodeUserSequences();
    }
    public String getActionComments(){
        return this.getVo().getActionComments();
    }
    public Boolean getNotifyEmail(){
        return this.getVo().getNotifyEmail();
    }
    public Boolean getSelfReject(){
        return this.getVo().getSelfReject();
    }

    public final UsersVO getUsersVO() {
        Users users = DomUtil.toDom(getVo().getToObid(), false);
        return users.getVo();
    }

    public final void reset() {
        this.setApprovalStatus(WorkflowConstants.APPROVAL_STATUS_NONE);
        this.setComments(null);
        this.setActualCompletionDate((Date)null);
        Set<String> attrSet = new HashSet<>();
        attrSet.add("approvalStatus");attrSet.add("comments");attrSet.add("actualCompletionDate");
        this.updateObject(attrSet);
    }
    public final Users getUser() {
        Users users = DomUtil.toDom(getVo().getToObid(), false);
        return users;
    }
    public final WorkflowStepVO getWorkflowStepVO() {
        WorkflowStepVO rtnWorkflowStepVO = null;
        WorkflowStep workflowStep = DomUtil.toDom(getVo().getFromObid(), false);
        if(!NullUtil.isNull(workflowStep)) {
            rtnWorkflowStepVO = workflowStep.getVo();
        }
        return rtnWorkflowStepVO;
    }
    public void changeAssignee(UsersVO toUsersVO){
        if(this.getToObid().equals(toUsersVO.getObid())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Same User!");
        this.changeToObject(toUsersVO);
    }
    public void changeStep(WorkflowStepVO toWfStepVO){
        if(this.getFromObid().equals(toWfStepVO.getObid())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Same Step!");
        this.changeFromObject(toWfStepVO);
    }
    private void clearInbox(){
        List<WorkflowInboxTaskVO> inboxList = this.findInboxTaskAll();
        for(WorkflowInboxTaskVO inboxVO : inboxList){
            WorkflowInboxTask inboxObj = DomUtil.toDom(inboxVO);
            inboxObj.deleteObject();
        }
    }
    private List<WorkflowInboxTaskVO> findInboxTaskAll(){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[setStepNodeUserObid]",GlobalConstants.OQL_OPERATOR_EQUAL,this.getObid());
        return BusinessObject.findObjects(AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK,oqlParameter.getSelectPattern(),oqlParameter.getWherePattern(),oqlParameter.getParamPattern());
    }
    public WorkflowInboxTaskVO findInboxTaskCurrent(){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[stepNodeUserObid]",GlobalConstants.OQL_OPERATOR_EQUAL,this.getObid());
        OqlBuilderUtil.constructWherePattern(oqlParameter,"@this.[previousObid]",GlobalConstants.OQL_OPERATOR_EQUAL,"1");
        List<WorkflowInboxTaskVO> list = BusinessObject.findObjects(AppSchemaCommonConstants.BIZCLASS_WORKFLOWINBOXTASK,oqlParameter.getSelectPattern(),oqlParameter.getWherePattern(),oqlParameter.getParamPattern());
        if(NullUtil.isNone(list)) return null;
        if(list.size() > 1) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Data Error!");
        return list.get(0);
    }
}

