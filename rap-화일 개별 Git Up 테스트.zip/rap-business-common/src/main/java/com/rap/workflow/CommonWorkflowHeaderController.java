/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : WorkflowController.java1
 * ===========================================
 * Modify Date    Modifier    Description
 * -------------------------------------------
 * 2015.03.13 kwanghyui.choi   Initial
 * 2015.11.23 eunsu.Jang  2D, 3D File Down 로직 추가
 * ===========================================
 */
package com.rap.workflow;


import com.constants.OmfURLConstants;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.controller.model.CParmHeaderVO;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.workflow.service.WorkflowService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;

@RestController
public class CommonWorkflowHeaderController extends RestBaseController {
    private static final Logger log = LoggerFactory.getLogger(CommonWorkflowHeaderController.class);
    @Autowired
    private UserSession userSession;

    @Resource(name = "workflowService")
    private WorkflowService workflowService;

    @RequestMapping( value= OmfURLConstants.URI_FOUNDATION_wfHeader,method= {RequestMethod.POST},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> createWorkflowHeader(@RequestBody CParmHeaderVO cParmHeaderVO) {
        try{
            BusinessObjectRootVO objVO = DomUtil.makeVO(cParmHeaderVO.getBizObjMap());
            WorkflowHeaderVO headerVO = workflowService.txnCreateWorkflowHeader(objVO,cParmHeaderVO.getCParmWorkflowHeader());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,headerVO),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping(value = OmfURLConstants.URI_FOUNDATION_wfHeader,method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> makeNormalSampleRequest(@RequestBody WorkflowHeaderVO headerVO) {
        try{
            headerVO.setStates(AppSchemaCommonConstants.STATE_WORKFLOW_HEADER_DEFINE);
            ObjectRootVO objVO = workflowService.txnChangeState(headerVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,"CodeMasterVO");
        }
    }
}