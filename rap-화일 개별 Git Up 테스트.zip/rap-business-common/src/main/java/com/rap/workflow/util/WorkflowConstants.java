package com.rap.workflow.util;


import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.schema.util.OmcApplicationConstants;
import com.rap.omc.schema.util.OmcUniqueIDGenerator;

import java.util.Set;

public class WorkflowConstants {


	public static final String[] INBOX_STATES_ALL = {AppSchemaCommonConstants.STATE_INBOX_TASK_COMPLETE,AppSchemaCommonConstants.STATE_INBOX_TASK_ASSIGNED,AppSchemaCommonConstants.STATE_INBOX_TASK_REVIEW};

	public static final String TRUE = "TRUE";
	public static final String FALSE = "FALSE";
	public static final String STATE_WORKING = "Working";
	
    public static final String DELIM_1 = ":";
    public static final String DELIM_1_S = "\\:";
    public static final String DELIM_2 = ",";
    public static final String DELIM_2_S = "\\,";

    // Mail Type
    public static final String MAIL_TYPE_NAME_ECO_DELAY = "ECO Delay";
    public static final String MAIL_TYPE_NAME_DELEGATE = "Delegate Information";
    public static final String MAIL_TYPE_NAME_DELEGATE_FAIL = "Delegate Fail Information";
    public static final String MAIL_TYPE_NAME_DISTRIBUTION = "Distribution";
    public static final String MAIL_TYPE_NAME_SCO_WORK = "Site ECO Coordinator Work";
    public static final String MAIL_TYPE_NAME_MBRPS = "MODEL BOM Distribution";
    public static final String MAIL_TYPE_NAME_USER_LOGIN_ALERT = "User Login History Alert";
    public static final String MAIL_TYPE_NAME_PERMISSION_EXPIRATION = "Permission Expiration";
    public static final String MAIL_TYPE_NAME_PERMISSION_EXPIRATION_NOTIFIY = "Permission Expiration Notify";

    // Mail Send Type
    public static final String MAIL_SEND_TYPE_SYSTEM = "System";
    public static final String MAIL_SEND_TYPE_MANUAL = "Manual";
    
    public static final String MAIL_TYPE_REJECT = "Reject";
    public static final String MAIL_TYPE_DISTRIBUTION = "Distribution";
    public static final String MAIL_TYPE_APPROVAL = "Approval";
    public static final String MAIL_TYPE_REASSIGN = "Reassign";
    
    public static final String APPROVAL_STATUS_NONE = "None";
    public static final String APPROVAL_STATUS_APPROVE = "Approve";
    public static final String APPROVAL_STATUS_REJECT = "Reject";
    public static final String APPROVAL_STATUS_ACKNOWLEDGE = "Acknowledge";
    public static final String APPROVAL_STATUS_COMPLETE = "Complete";
    public static final Set<String> APPROVAL_STATUS_ALL = Set.of(APPROVAL_STATUS_NONE,APPROVAL_STATUS_APPROVE,APPROVAL_STATUS_REJECT,APPROVAL_STATUS_ACKNOWLEDGE,APPROVAL_STATUS_COMPLETE);
    public static final Set<String> APPROVAL_STATUS_SET_FOR_APPROVED = Set.of(APPROVAL_STATUS_APPROVE,APPROVAL_STATUS_REJECT,APPROVAL_STATUS_ACKNOWLEDGE,APPROVAL_STATUS_COMPLETE);
    public static final Set<String> APPROVAL_STATUS_ACTION_SET = Set.of(APPROVAL_STATUS_APPROVE,APPROVAL_STATUS_REJECT,APPROVAL_STATUS_ACKNOWLEDGE);


    public static final String INBOX_TASK_TYPE_APPROVAL = "Approval";
    public static final String INBOX_TASK_TYPE_SAVE_DRAFT = "SaveDraft";
    public static final String INBOX_TASK_TYPE_MOBILE_APPROVAL = "MobileApproval";
    public static final String INBOX_TASK_TYPE_DISTRIBUTION = "Distribution";
    public static final String INBOX_TASK_TYPE_REQUESTED = "Requested";
    public static final String INBOX_TASK_TYPE_PENDING_CHANGE = "PendingChange";
    public static final String INBOX_TASK_TYPE_APPROVED = "Approved";


    //    public static final String INSTRUCTION_TYPE_APPROVAL = "Approval";
    public static final String INSTRUCTION_TYPE_STANDARD            = "Standard";
    public static final String INSTRUCTION_TYPE_ORIGINATOR          = "Originator";
    public static final String INSTRUCTION_TYPE_DISTRIBUTION        = "Distribution";
    public static final String INSTRUCTION_TYPE_MANUAL_DISTRIBUTION = "ManualDistribution";

    public static final String INSTRUCTION_TYPE_Approver    = "Approver";
    public static final String INSTRUCTION_TYPE_Reviewer    = "Reviewer";
    public static final String INSTRUCTION_TYPE_CoWorker    = "CoWorker";
    public static final String INSTRUCTION_TYPE_Originator  = "Originator";
    public static final String INSTRUCTION_TYPE_Distributee = "Distributee";
    public static final String INSTRUCTION_TYPE_Referer     = "Referer";
    public static final String INSTRUCTION_TYPE_Standard     = "Standard";
    public static final Set<String> INSTRUCTION_TYPE_SET = Set.of(INSTRUCTION_TYPE_Approver,INSTRUCTION_TYPE_Reviewer,INSTRUCTION_TYPE_CoWorker,INSTRUCTION_TYPE_Originator,INSTRUCTION_TYPE_Distributee,INSTRUCTION_TYPE_Referer,INSTRUCTION_TYPE_Standard);

    public static final String STATES_TYPE_DEFINE    = "Define";
    public static final String STATES_TYPE_ASSIGNED  = "Assigned";
    public static final String STATES_TYPE_INPROCESS = "In Process";
    public static final String STATES_TYPE_COMPLETE  = "Complete";

    public static final String ROUTE_STATUS_TYPE_NOT_STARTED = "Not Started";
    public static final String ROUTE_STATUS_TYPE_TARTED = "Started";
    public static final String ROUTE_STATUS_TYPE_STOPPED = "Stopped";
    public static final String ROUTE_STATUS_TYPE_FINISHED = "Finished";
    public static final Set<String> ROUTE_STATUS_SET = Set.of(ROUTE_STATUS_TYPE_NOT_STARTED,ROUTE_STATUS_TYPE_TARTED,ROUTE_STATUS_TYPE_STOPPED,ROUTE_STATUS_TYPE_FINISHED);

    public static final String WORKFLOW_REASSIGN = "Reassign";

    //INBOX_TASK_TYPE
    public static final String INBOX_TASK_TYPE_Workflow         = "Workflow";
    public static final String INBOX_TASK_TYPE_WBSActivity      = "WBS Activity";


    public static final String ROUTE_ACTIONS_APPROVE        = "Approve";
    public static final String ROUTE_ACTIONS_CONFIRM        = "Confirm";
    public static final String ROUTE_ACTIONS_COMMENT        = "Comment";
    public static final String ROUTE_ACTIONS_END_WORKING    = "End Working";
    public static final String ROUTE_ACTIONS_STANDARD       = "Standard";

    public static final Set<String> ROUTE_ACTIONS_SET = Set.of(ROUTE_ACTIONS_APPROVE,ROUTE_ACTIONS_CONFIRM,ROUTE_ACTIONS_COMMENT, ROUTE_ACTIONS_END_WORKING);
    public static final Set<String> ROUTE_ACTIONS_NOT_COMMENT_SET = Set.of(ROUTE_ACTIONS_APPROVE,ROUTE_ACTIONS_CONFIRM, ROUTE_ACTIONS_END_WORKING);

    //ACTION_COMMENTS
    public static final String ACTION_COMMENTS_APPROVE          = "Approve";
    public static final String ACTION_COMMENTS_CONFIRM          = "Agree";
    public static final String ACTION_COMMENTS_COMMENT          = "Comment";
    public static final String ACTION_COMMENTS_END_WORKING      = "End Works";
    public static final String ACTION_COMMENTS_DISTRIBUTION     = "Acknowledge";
    public static final String ACTION_COMMENTS_STANDARD         = "No Action";

    public static final Set<String> ACTION_COMMENTS_SET             = Set.of(ACTION_COMMENTS_APPROVE,ACTION_COMMENTS_CONFIRM,ACTION_COMMENTS_COMMENT, ACTION_COMMENTS_DISTRIBUTION);

    //ROUTE_PURPOSE: Life Cycle Excel에 정의되어진 State Info의 "Default Route Purpose"
    public static final String ROUTE_PURPOSE_END_WORKING        = OmcApplicationConstants.WF_ROUTE_PURPOSE_EndWorking;
    public static final String ROUTE_PURPOSE_APPROVAL           = OmcApplicationConstants.WF_ROUTE_PURPOSE_Approval;
    public static final String ROUTE_PURPOSE_REVIEW             = OmcApplicationConstants.WF_ROUTE_PURPOSE_Review;
    public static final String ROUTE_PURPOSE_CONFIRMATION       = OmcApplicationConstants.WF_ROUTE_PURPOSE_Confirmation;
    public static final String ROUTE_PURPOSE_DISTRIBUTION       = OmcApplicationConstants.WF_ROUTE_PURPOSE_Distribution;
    public static final String ROUTE_PURPOSE_STANDARD           = OmcApplicationConstants.WF_ROUTE_PURPOSE_Standard;
    public static final Set<String> ROUTE_PURPOSE_SET           = Set.of(ROUTE_PURPOSE_END_WORKING,ROUTE_PURPOSE_APPROVAL,ROUTE_PURPOSE_REVIEW,ROUTE_PURPOSE_CONFIRMATION,ROUTE_PURPOSE_DISTRIBUTION,ROUTE_PURPOSE_STANDARD);

    public static final String ACTION_TYPE_PENDING              = "Pending";
    public static final String ACTION_TYPE_APPROVED             = "Approved";
    public static final String ACTION_TYPE_REJECTED             = "Rejected";
    public static final String ACTION_TYPE_ACKNOWLEDGED         = "Acknowledged";
    public static final String ACTION_TYPE_AWAITING_APPROVAL    = "Awaiting Approval";
    public static final String ACTION_TYPE_AWAITING_ACKNOWLEDGE = "Awaiting Acknowledge";
    public static final String ACTION_TYPE_REASSIGNED           = "Reassigned";
    public static final String ACTION_TYPE_END_WORKING          = "End Working";
    public static final Set<String> ACTION_TYPE_SET             = Set.of(ACTION_TYPE_PENDING,ACTION_TYPE_APPROVED,ACTION_TYPE_REJECTED,ACTION_TYPE_ACKNOWLEDGED,ACTION_TYPE_AWAITING_APPROVAL,ACTION_TYPE_AWAITING_ACKNOWLEDGE,ACTION_TYPE_REASSIGNED,ACTION_TYPE_END_WORKING);

    // Route Action
    public static final String ROUTE_ACTION_RULE_ALL = OmcApplicationConstants.WF_PARALLEL_PROCESS_RULE_All;
    public static final String ROUTE_ACTION_RULE_ANY = OmcApplicationConstants.WF_PARALLEL_PROCESS_RULE_Any;
    public static final Set<String> ROUTE_ACTION_RULE_SET             = Set.of(ROUTE_ACTION_RULE_ALL,ROUTE_ACTION_RULE_ANY);

    // WBS inbox task
    public static final String WBS_INBOX_TASK_TYPE          = "WBS Activity";
    public static final String WBS_APPROVERS_RESPONSIBILITY = "Engineering";
    public static final String WBS_TASK_REQUIREMENT = "Optional";
    public static final String WBS_DATE_OFFSET_FROM = "Task Create Date";
    public static final String WBS_ACTION_COMMENTS = "Approve";
    public static final String INBOXTASK_TYPE_WORKFLOW = "Workflow";
    public static final String INBOXTASK_TYPE_WBSACTIVITY = "WBS Activity";


    public static final String MAP_KEY_WF_INFO_routeVOMap = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_WF_INFO_stepVOMap = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_WF_INFO_usersVOList = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_WF_INFO_approvalVOList = OmcUniqueIDGenerator.getObid();


    public static final String MAP_KEY_processTimestamp = "processTimestamp";
    public static final String MAP_KEY_stateInfo = "stateInfo";
    public static final String MAP_KEY_wfHeaderVO = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_wfRouteVO = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_approvalVOList = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_previousStepVO = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_nextStepVO = OmcUniqueIDGenerator.getObid();

    public static final String MAP_KEY_workflowStepListMap = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_workflowSubStepList = OmcUniqueIDGenerator.getObid();


    public static final String MAP_KEY_INBOX_routeVO = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_INBOX_userVO = OmcUniqueIDGenerator.getObid();

    public static final String COMMON_VALUE_NONE = "None";

}
