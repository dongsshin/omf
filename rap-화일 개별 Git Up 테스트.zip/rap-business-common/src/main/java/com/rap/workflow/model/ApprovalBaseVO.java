/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : ApprovalLineVO.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 2. 13.  kwanghyui.choi   Initial
 * ===========================================
 */
package com.rap.workflow.model;

import com.rap.api.object.foundation.model.BaseModel;
import lombok.Getter;
import lombok.Setter;


/**
 * <pre>
 * Class : ApprovalLineVO
 * Description : TODO
 * </pre>
 * 
 * @author  dongsshin
 */
@Setter
@Getter
public class ApprovalBaseVO extends BaseModel {
    private String wfRequesterObid;         // EP System PK

    private String routeNodeObid;           // EP System PK
    private String stepNodeObid;           // EP System PK
    private String stepNodeUserObid;
    private String inboxTaskObid;           // EP Task ID

    //Object Route 속성
    private String  routeState ;                //Route Creation Unit
    //기타
    private Integer stepSequences;              //Step Sequences
    private Integer stepNodeUserSequences;      //Step Sequences
    private Integer routeStateSequence;         //Life Cycle State Sequences
    private String  assigneeUserId;             //Approver User ID



    private Boolean isEssential                 = (Boolean)false;
    private String  parallelNodeProcessionRule  = "All";
    private String  responsibility              = "Engineering";

}