/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : ReassignVO.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 5. 18.  kwanghyui.choi   Initial
 * ===========================================
 */
package com.rap.workflow.model;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ReassignVO {
    private String wfRequestObid;
    private String inboxTaskObid;
    private String fromAssigneeObid;
    private String toAssigneeObid;
    private String comments;
}
