package com.rap.workflow.service;

import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.workflow.dom.WorkflowHeader;
import com.rap.api.object.workflow.dom.WorkflowInboxTask;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.omc.controller.model.CParmWorkflowHeader;
import com.rap.workflow.model.ApprovalHistoryVO;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.model.ReassignVO;
import com.workflow.WfSimpleApprovalVO;

import java.util.List;
import java.util.Map;

public interface WorkflowService {
    WorkflowHeaderVO txnCreateWorkflowHeader(BusinessObjectRootVO bizVO, CParmWorkflowHeader cParmWorkflowHeader);
    WorkflowHeaderVO txnModifyWorkflowHeader(WorkflowHeaderVO headerVO, BusinessObjectRootVO bizVO, CParmWorkflowHeader cParmWorkflowHeader);
    void txnDeleteWorkflowHeader(WorkflowHeaderVO headerVO);
    WorkflowHeaderVO txnChangeState(WorkflowHeaderVO workflowHeaderVO);
    WorkflowHeaderVO getLatestWorkflowHeader(BusinessObjectRootVO bizVO);
    Map<String, Object> initializeWorkflow(WorkflowHeader wfHeaderObj);
    Map<String, Object> getWorkflowRequestInfo(String obid);
    void txnClearWorkflowList(WorkflowHeader wfHeaderObj);
    void txnCreateAndUpdateWorkflow(WorkflowHeader wfHeaderObj, List<ApprovalVO> approvalVOList);
    public void txnStartWorkflow(WorkflowHeader wfHeaderObj);
    void txnSubmitApproval(WorkflowHeader wfHeaderObj, ApprovalVO approvalVO ,List<FilesVO> fileList);
    void txnAddDistribution(WorkflowHeader wfHeaderObj, List<ApprovalVO> approvalVOList);
    void txnSubmitSelfReject(WorkflowHeader wfHeaderObj, ApprovalVO approvalVO);
    void txnReassignApprover(WorkflowHeader wfHeaderObj, ReassignVO reassignVO);
    void txnCopyWorkflow(WorkflowHeader sourceWfHeaderObj, WorkflowHeader targetWfHeaderObj, String workingState);
    void txnDoMassAcknowledge(List<ApprovalVO> targetObjectList);
    void txnManualDistribute(List<UsersVO> assigneeList, List<BusinessObjectRootVO> targetObjectList, String comments);
    void txnDoReassignList(List<ReassignVO> reassignVOList);
    List<ApprovalVO> getWorkflowList(WorkflowHeader wfHeaderObj);
    WfSimpleApprovalVO getSimpleWorkflowList(WorkflowHeader wfHeaderObj);
    List<ApprovalHistoryVO> getApprovalHistoryList(WorkflowHeader wfHeaderObj);
    String getDistributionState(String lifeCycleName);
    ApprovalVO getInProcessWorkflowRouteNStep(WorkflowHeader wfHeaderObj);
    List<ApprovalVO> getSendBackToList(ApprovalVO approvalVO);
    List<WorkflowInboxTaskVO> getDistributionHistoryList(WorkflowHeader wfHeaderObj);
    List<WorkflowInboxTaskVO> getNotificationFromRoute(WorkflowHeader wfHeaderObj);
    List<FilesVO> getFilesVOList(WorkflowInboxTask workflowInboxTask);
    List<ApprovalHistoryVO> getPreviousRejectedHistory(WorkflowHeader wfHeaderObj);




    //public void txnBuildWorkflow(BusinessObjectRoot businessObjectRoot, List<ApprovalVO> approvalVOList);
    //@Deprecated
    //public void txnBuildWorkflowAndStartFirstState(WorkflowHeader wfHeaderObj, List<ApprovalVO> approvalVOList);
    //void txnStartRoute(BusinessObjectRoot businessObjectRoot, String toBeStartState);
    //public void txnBuildWorkflowAndPromote(WorkflowHeader wfHeaderObj, List<ApprovalVO> approvalVOList);
    //@Deprecated
    //void txnReject(BusinessObjectRoot businessObjectRoot, String routeState);
    //@Deprecated
    //void txnChangeOriginator(BusinessObjectRoot businessObjectRoot, ReassignVO reassignVO);
    //@Deprecated
    //List<ApprovalVO> txnSubmitMassApproval(List<ApprovalVO> targetObjectList);
    //@Deprecated
    //void txnManualApprove(WorkflowInboxTask workflowInboxTask, String approvalStatus, String comments, boolean isFromWebService);
    //@Deprecated
    //void txnManualApprove(WorkflowInboxTask workflowInboxTask, String approvalStatus, String comments, boolean isFromWebService, String webServiceFlag);
    //void txnCreateMailSendInfo(MailSendVO mailSendVO);
    //void createApprovalInfoToEP(BusinessObjectRoot businessObjectRoot, WorkflowRoute workflowRoute, WorkflowInboxTask workflowInboxTask);
    //@Deprecated
    //void createSubmitApprovalInfoToEP(BusinessObjectRoot businessObjectRoot, WorkflowRoute  workflowRoute, WorkflowInboxTask workflowInboxTask, String approvalStatus);
    //@Deprecated
    //void createReassignApprovalInfoToEP(BusinessObjectRoot businessObjectRoot, WorkflowRoute  workflowRoute, WorkflowInboxTask fromWorkflowInboxTask, WorkflowInboxTask toWorkflowInboxTask);
    //@Deprecated
    //void txnCreateDeleteApprovalInfoToEP(String workflowRouteObid, String workflowInboxTaskObid);
    //@Deprecated
    //boolean isStartedFirstState(BusinessObjectRoot businessObjectRoot);
    //boolean isInProcessingWorkflow(BusinessObjectRoot businessObjectRoot);
    //@Deprecated
    //boolean isExistWorkflowStepNodeUser(BusinessObjectRoot businessObjectRoot, String states, int step, String userName);
    //@Deprecated
    //boolean isExistsAssigneeTargetStates(BusinessObjectRoot businessObjectRoot, String routeStates);
    //@Deprecated
    //boolean isLastApprovalInWorking(BusinessObjectRoot businessObjectRoot, ApprovalVO approvalVO);
    //@Deprecated
    //boolean isLastApprovalInState(BusinessObjectRoot businessObjectRoot, String state);//@Deprecated
    //WorkflowInboxTaskVO retrieveFinalApprove(BusinessObjectRoot businessObjectRoot, String routeState);
    //@Deprecated
    //List<BusinessObjectRootVO> retrieveApprovedList(BusinessObjectRoot businessObjectRoot);
    //@Deprecated
    //List<WorkflowInboxTaskVO> retrieveWorkflowInboxTaskVONUsersVOList(BusinessObjectRoot businessObjectRoot, String routeStates);
    //@Deprecated
    //List<WorkflowStepNodeUserVO> retrieveWorkflowStepNodeUserVONUsersList(BusinessObjectRoot businessObjectRoot, String routeStates);
    //List<WorkflowStepNodeUserVO> retrieveWorkflowStepNodeUserVONUsersListByStep(BusinessObjectRoot businessObjectRoot, String states, int step);
    //List<CodeDetailVO> retrieveApprovalStateList(String lifeCycleName);
    //List<CodeDetailVO> retrieveAllApprovalStateList(String lifeCycleName);
    //List<CodeDetailVO> retrieveApprovalStateList(String lifeCycleName, boolean isIncludeWorking);
    //void notifyMail(BusinessObjectRoot businessObjectRoot, WorkflowRoute  workflowRoute, BusinessObjectRootVO usersVO);
    //@Deprecated
    //void notifyMail(BusinessObjectRoot businessObjectRoot, WorkflowRoute  workflowRoute, String usersNames/*사번*/);
    //@Deprecated
    //List<BusinessRelationObjectVO> retrieveAssigneeTargetStates(BusinessObjectRoot businessObjectRoot, String routeStates);
    //@Deprecated
    //WorkflowInboxTask retrieveUserApproveInfo(String taskObid, String userId);
    //@Deprecated
    //String getMobileApprovalDetail( BusinessObjectRootVO targetVo );
    //@Deprecated
    //List<FilesVO> getMobileFileDetail(BusinessObjectRootVO targetVo );
    //@Deprecated
    //List<ApprovalVO> retrieveAssigneeList(BusinessObjectRoot businessObjectRoot);
    //@Deprecated
    //List<HashMap<String, Object>> retrieveApprovalHistoryMig(String obid);
}
