/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : WorkflowServiceImpl.java1
 * ===========================================
 * Modify Date    Modifier    Description
 * -------------------------------------------
 * 2015. 2. 12.  kwanghyui.choi   Initial
 * */
package com.rap.workflow.service.impl;

import com.rap.api.object.common.code.model.CodeDetailVO;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.workflow.dom.WorkflowHeader;
import com.rap.api.object.workflow.dom.WorkflowInboxTask;
import com.rap.api.object.workflow.dom.WorkflowRoute;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.api.object.workflow.model.WorkflowRouteVO;
import com.rap.api.object.workflow.model.WorkflowStepVO;
import com.rap.api.relation.workflow.dom.WorkflowStepNodeUser;
import com.rap.api.relation.workflow.model.WorkflowObjectRouteVO;
import com.rap.common.code.service.CodeService;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.constants.BizCommonCodeConstants;
import com.rap.common.constants.BusinessCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.controller.model.CParmWorkflowHeader;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.foundation.classes.service.TimeService;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.LifeCycleUtil;
import com.rap.workflow.model.ApprovalHistoryVO;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.model.ReassignVO;
import com.rap.workflow.service.WorkflowService;
import com.rap.workflow.util.WorkflowConstants;
import com.rap.workflow.util.WorkflowUtil;
import com.workflow.WfSimpleApprovalVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.*;


@Service("workflowService")

public class WorkflowServiceImpl implements WorkflowService {

    @Resource(name = "timeService")
    private TimeService timeService;

    @Resource(name = "codeService")
    private CodeService codeService;

    @Autowired
    UserSession userSession;

    /*****************************************************************************************************************************************************/
    /*                             txnCreateWorkflowHeader                                                                                               */
    /*****************************************************************************************************************************************************/
    @Override
    public WorkflowHeaderVO txnCreateWorkflowHeader(BusinessObjectRootVO bizVO, CParmWorkflowHeader cParmWorkflowHeader) {
        WorkflowHeaderVO headerVO = DomUtil.copyAttributeAll(cParmWorkflowHeader,new WorkflowHeaderVO());
        headerVO.setNames(bizVO.getObid());
        headerVO.setTitles(bizVO.getTitles());
        headerVO.setRevision("1");
        copyAttributeFromBizObj(headerVO,bizVO);
        WorkflowHeader headerObj = new WorkflowHeader(headerVO);
        headerObj.createObject();
        headerObj = DomUtil.toDom(headerObj.getObid(),true);
        return headerObj.getVo();
    }
    /*****************************************************************************************************************************************************/
    /*                             txnModifyWorkflowHeader                                                                                               */
    /*****************************************************************************************************************************************************/
    @Override
    public WorkflowHeaderVO txnModifyWorkflowHeader(WorkflowHeaderVO headerVO, BusinessObjectRootVO bizVO, CParmWorkflowHeader cParmWorkflowHeader){
        WorkflowHeader  dbHeaderObj = DomUtil.toDom(headerVO.getObid());
        copyAttributeFromBizObj(dbHeaderObj.getVo(),bizVO);
        DomUtil.copyAttributeAll(cParmWorkflowHeader,dbHeaderObj.getVo());
        dbHeaderObj.modifyObject();
        dbHeaderObj = DomUtil.toDom(dbHeaderObj.getObid(),true);
        return dbHeaderObj.getVo();
    }
    /*****************************************************************************************************************************************************/
    /*                             txnDeleteWorkflowHeader                                                                                               */
    /*****************************************************************************************************************************************************/
    @Override
    public void txnDeleteWorkflowHeader(WorkflowHeaderVO headerVO) {
        WorkflowHeader dbHeaderObj = DomUtil.toDom(headerVO);
    }
    /*****************************************************************************************************************************************************/
    /*                             txnChangeState                                                                                                        */
    /*****************************************************************************************************************************************************/
    @Override
    public WorkflowHeaderVO txnChangeState(WorkflowHeaderVO workflowHeaderVO) {
        WorkflowHeader dbHeaderObj = DomUtil.toDom(workflowHeaderVO.getObid());
        dbHeaderObj.changeStates(workflowHeaderVO.getStates());
        return dbHeaderObj.getVo();
    }
    /*****************************************************************************************************************************************************/
    /*                             getLatestWorkflowHeader                                                                                               */
    /*****************************************************************************************************************************************************/
    @Override
    public WorkflowHeaderVO getLatestWorkflowHeader(BusinessObjectRootVO bizVO) {
        return BusinessObject.findLatestObject(AppSchemaCommonConstants.BIZCLASS_WORKFLOWHEADER,bizVO.getObid());
    }
    /*****************************************************************************************************************************************************/
    /*                             txnBuildWorkflow                                                                                                      */
    /*****************************************************************************************************************************************************/
    @Override
    public Map<String, Object> initializeWorkflow(WorkflowHeader wfHeaderObj) {
        return makeParameterForInitialize(wfHeaderObj);
    }
    /*****************************************************************************************************************************************************/
    /*                             getWorkflowRequestInfo                                                                                                */
    /*****************************************************************************************************************************************************/
    @Override
    public Map<String, Object> getWorkflowRequestInfo(String obid) {
        Map<String,Object> map = new HashMap<String,Object>();
        WorkflowHeader     wfHeaderObj = DomUtil.toDom(obid);
        List<CodeDetailVO> routeInstructionsList    =  codeService.getCodeDetailListByScope(BizCommonCodeConstants.CODE_MASTER_NAME_APPROVALLINE_APPROVAL_TYPE, BusinessCommonConstants.MAIN_COMPANY_NAME);
        List<CodeDetailVO> processRoleList          =  codeService.getCodeDetailListByScope(BizCommonCodeConstants.CODE_MASTER_NAME_APPROVALLINE_JOB_GRADE, BusinessCommonConstants.MAIN_COMPANY_NAME);
        Users creatorDom = Users.getUsers(wfHeaderObj.getObjectCreator());
        map.put("wfHeaderVO"            ,wfHeaderObj.getVo());
        map.put("creatorObid"           ,creatorDom == null ? "" : creatorDom.getObid());
        map.put("routeInstructionsList" ,routeInstructionsList);
        map.put("processRoleList"       ,processRoleList);
        map.put("loginUser"             ,userSession.getUserBizObid());
        return map;
    }
    /*****************************************************************************************************************************************************/
    /*                             txnUpdateWorkflow(사용중)                                                                                              */
    /*****************************************************************************************************************************************************/
    //1차 완료
    @Override
    public void txnCreateAndUpdateWorkflow(WorkflowHeader wfHeaderObj, List<ApprovalVO> approvalVOList) {
        wfHeaderObj.createAndUpdateWorkflow(approvalVOList);
        //wfHeaderObj.rebuildInboxTaskWithDelegated();
        //if(true) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"TTTTTT");
    }
    @Override
    public void txnStartWorkflow(WorkflowHeader wfHeaderObj) {
        wfHeaderObj.startRoute();
    }
    /*****************************************************************************************************************************************************/
    /*                             txnBuildWorkflowAndPromote                                                                                            */
    /*****************************************************************************************************************************************************/
    //1차 완료
    @Override
    public void txnSubmitApproval(WorkflowHeader wfHeaderObj, ApprovalVO approvalVO ,List<FilesVO> fileList) {
        wfHeaderObj.submitApproval(approvalVO,fileList);
    }

    /*****************************************************************************************************************************************************/
    /*                             txnAddDistribution                                                                                                    */
    /*****************************************************************************************************************************************************/
    @Override
    public void txnAddDistribution(WorkflowHeader wfHeaderObj, List<ApprovalVO> approvalVOList) {
        wfHeaderObj.txnAddDistribution(approvalVOList,userSession.getUserId());

    }
    /*****************************************************************************************************************************************************/
    /*                             txnSubmitSelfReject                                                                                                   */
    /*****************************************************************************************************************************************************/
    @Override
    public void txnSubmitSelfReject(WorkflowHeader wfHeaderObj, ApprovalVO approvalVO) {
        wfHeaderObj.txnSubmitSelfReject(approvalVO);
    }
    /*****************************************************************************************************************************************************/
    /*                             txnReassignApprover                                                                                                   */
    /*****************************************************************************************************************************************************/
    @Override
    public void txnReassignApprover(WorkflowHeader wfHeaderObj, ReassignVO reassignVO) {
        wfHeaderObj.reassignApprover(reassignVO);
    }
    /*****************************************************************************************************************************************************/
    /*                             txnCopyWorkflow                                                                                                       */
    /*****************************************************************************************************************************************************/
    @Override
    public void txnCopyWorkflow(WorkflowHeader sourceWfHeaderObj, WorkflowHeader targetWfHeaderObj, String workingState) {
        sourceWfHeaderObj.txnCopyWorkflow(targetWfHeaderObj, workingState);
    }
    /*****************************************************************************************************************************************************/
    /*                             txnDoMassAcknowledge                                                                                                  */
    /*****************************************************************************************************************************************************/
    //1차 완료
    @Override
    public void txnDoMassAcknowledge(List<ApprovalVO> targetObjectList) {

        for( int i = 0; i < targetObjectList.size(); i++) targetObjectList.get(i).validateForSubmit();
        ApprovalVO approvalVO = null;
        WorkflowHeader wfHeaderObj = null;
        Map<String, Object> inputParams = null;
        for( int inx = 0; inx < targetObjectList.size(); inx++ ){
            approvalVO = targetObjectList.get(inx);
            wfHeaderObj = DomUtil.toDom(approvalVO.getWfRequesterObid());
            inputParams = new HashMap<String, Object>();
            inputParams.put( "approvalStatus", approvalVO.getApprovalStatus() );
            inputParams.put( "stepNodeUserObid", approvalVO.getStepNodeUserObid() );
            wfHeaderObj.preProcessApproval(inputParams);
            this.txnSubmitApproval(wfHeaderObj, approvalVO,null);
        }
    }
    /*****************************************************************************************************************************************************/
    /*                             txnManualDistribute                                                                                                   */
    /*****************************************************************************************************************************************************/
    /**
     * 사용자 수동 배포
     * @param assigneeList
     * @param targetObjectList
     * @param comments
     * @see WorkflowService#txnManualDistribute(List, List, String)
     */
    //1차 완료
    @Override
    public void txnManualDistribute(List<UsersVO> assigneeList, List<BusinessObjectRootVO> targetObjectList, String comments){
        WorkflowRouteVO routeVO = new WorkflowRouteVO();
        routeVO.setRouteBasePurpose(WorkflowConstants.ROUTE_PURPOSE_DISTRIBUTION);
        WorkflowRoute routeObj = new WorkflowRoute(routeVO);
        for ( int idx = 0 ; idx < targetObjectList.size() ; idx++ ) {
            WorkflowHeader wfHeaderObj = DomUtil.toDom(targetObjectList.get(idx).getObid());
            wfHeaderObj.setTargetObject();
            for ( UsersVO assignee : assigneeList ) {
                WorkflowUtil.notifyMail(wfHeaderObj.getTargetObject(), routeVO, assignee);
            }
        }
    }
    /*****************************************************************************************************************************************************/
    /*                             txnDoReassignList                                                                                                     */
    /*****************************************************************************************************************************************************/
    //1차 완료
    @Override
    public void txnDoReassignList(List<ReassignVO> reassignVOList) {
        for(ReassignVO reassignVO : reassignVOList) {
            WorkflowHeader wfHeader = DomUtil.toDom(reassignVO.getWfRequestObid());
            wfHeader.reassignApprover(reassignVO);
        }
    }

    /*****************************************************************************************************************************************************/
    /*                             retrieveWorkflow(사용중)                                                                                               */
    /*****************************************************************************************************************************************************/
    //1차 완료
    @Override
    public void txnClearWorkflowList(WorkflowHeader wfHeaderObj) {
        Map<String,Object> map = wfHeaderObj.getWorkflowListObjects();
        List<ApprovalVO> list = (List<ApprovalVO>)map.get(WorkflowConstants.MAP_KEY_WF_INFO_approvalVOList);
        Map<String, WorkflowRouteVO> routeVOMap = (Map<String, WorkflowRouteVO>)map.get(WorkflowConstants.MAP_KEY_WF_INFO_routeVOMap);

        Set<String> routeSet = new HashSet<String>();
        Set<String> routeNoderUserSet = new HashSet<String>();
        for(ApprovalVO vo : list){
            routeSet.add(vo.getRouteNodeObid());
            routeNoderUserSet.add(vo.getStepNodeUserObid());
        }
        for(String obid : routeNoderUserSet){
            WorkflowStepNodeUser obj = new WorkflowStepNodeUser(obid);
            obj.deleteObject();
        }
        for(String obid : routeVOMap.keySet()){
            WorkflowRoute obj = new WorkflowRoute(routeVOMap.get(obid));
            obj.deleteObject();
        }
    }

    /*****************************************************************************************************************************************************/
    /*                             getWorkflowList(사용중)                                                                                                */
    /*****************************************************************************************************************************************************/
    //1차 완료
    @Override
    public List<ApprovalVO> getWorkflowList(WorkflowHeader wfHeaderObj) {
        Map<String,Object> map = wfHeaderObj.getWorkflowListObjects();
        return (List<ApprovalVO>)map.get(WorkflowConstants.MAP_KEY_WF_INFO_approvalVOList);
    }

    @Override
    public WfSimpleApprovalVO getSimpleWorkflowList(WorkflowHeader wfHeaderObj) {
        List<ApprovalVO> list = getWorkflowList(wfHeaderObj);
        return WorkflowUtil.convertSimpleApprovalVO(list);
    }
    /*****************************************************************************************************************************************************/
    /*                             getApprovalHistoryList                                                                                                */
    /*****************************************************************************************************************************************************/
    @Override
    public List<ApprovalHistoryVO> getApprovalHistoryList(WorkflowHeader wfHeaderObj){
        return wfHeaderObj.getApprovalHistoryList();
    }
    /*****************************************************************************************************************************************************/
    /*                             retrieveDistributionState                                                                                             */
    /*****************************************************************************************************************************************************/
    @Override
    public String getDistributionState(String lifeCycleName){
        String rtnStates = null;
        List<StateInfo> stateInfoList = LifeCycleUtil.getLifieCycleStateListByName(lifeCycleName);
        for(StateInfo stateInfo : stateInfoList) {
            if("Distribution".equals(stateInfo.getDefaultRoutePurpose())) {
                rtnStates =  stateInfo.getStateName();
                break;
            }
        }
        return rtnStates;
    }
    /*****************************************************************************************************************************************************/
    /*                             getInProcessWorkflowRouteNStep(완료)                                                                                   */
    /*****************************************************************************************************************************************************/
    @Override
    public ApprovalVO getInProcessWorkflowRouteNStep(WorkflowHeader wfHeaderObj) {
        ApprovalVO rtnApprovalVO = new ApprovalVO();
        WorkflowRouteVO routeVO = wfHeaderObj.getInProcessWorkflowRoute();
        if(!NullUtil.isNull(routeVO)) {
            WorkflowRoute routeObj = DomUtil.toDom(routeVO);
            WorkflowObjectRouteVO objectRouteVO = routeObj.getRelationship(AppSchemaCommonConstants.RELCLASS_WORKFLOWOBJECTROUTE,AppSchemaCommonConstants.BIZCLASS_WORKFLOWHEADER,GlobalConstants.FLAG_TYPE_FROM);
            if(!NullUtil.isNull(objectRouteVO)) {
                rtnApprovalVO.setRouteState(objectRouteVO.getRouteState());
            }
            WorkflowStepVO stepVO = routeObj.getInProcessingStep();
            if(!NullUtil.isNull(stepVO)){
                rtnApprovalVO.setStepSequences(stepVO.getStepSequences());
            }
        }
        return rtnApprovalVO;
    }
    /*****************************************************************************************************************************************************/
    /*                             getSendBackToList                                                                                                     */
    /*****************************************************************************************************************************************************/
    //1차 완료
    @Override
    public List<ApprovalVO> getSendBackToList(ApprovalVO approvalVO) {
        WorkflowHeader wfHeaderObj = DomUtil.toDom(approvalVO.getWfRequesterObid());
        if(WorkflowConstants.APPROVAL_STATUS_REJECT.equals(approvalVO.getApprovalStatus())) {
            wfHeaderObj.getVo().setBranchTo(approvalVO.getApprovalStatus());
        }
        List<ApprovalVO> rtnWorkflowInboxTaskVOList = new ArrayList<ApprovalVO>();
        StateInfo toStates = LifeCycleUtil.getTargetState(wfHeaderObj.getVo(), GlobalConstants.WORKFLOW_TYPE_PROMOTE);
        if(NullUtil.isNull(toStates)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Target state is null");
        Map<String,Object> map = wfHeaderObj.getWorkflowListObjects();
        List<ApprovalVO> rtnApprovalVOList = (List<ApprovalVO>)map.get(WorkflowConstants.MAP_KEY_WF_INFO_approvalVOList);
        //Step에 대한 구분이 있어야 함.
        for(ApprovalVO approval : rtnApprovalVOList) {
            if(toStates.getStateName().equals(approval.getRouteState())) {
                rtnWorkflowInboxTaskVOList.add(approval);
            }
        }
        return rtnWorkflowInboxTaskVOList;
    }
    /*****************************************************************************************************************************************************/
    /*                             getDistributionHistoryList                                                                                            */
    /*****************************************************************************************************************************************************/
    @Override
    public List<WorkflowInboxTaskVO> getDistributionHistoryList(WorkflowHeader wfHeaderObj) {
        return wfHeaderObj.getDistributionHistoryList();
    }
    /*****************************************************************************************************************************************************/
    /*                             getNotificationFromRoute                                                                                              */
    /*****************************************************************************************************************************************************/
    @Override
    public List<WorkflowInboxTaskVO> getNotificationFromRoute(WorkflowHeader wfHeaderObj) {
        return wfHeaderObj.getNotificationFromRoute();
    }
    /*****************************************************************************************************************************************************/
    /*                             getFilesVOList                                                                                                        */
    /*****************************************************************************************************************************************************/
    @Override
    public List<FilesVO> getFilesVOList(WorkflowInboxTask workflowInboxTask){
        return workflowInboxTask.getRelatedFiles(true);
    }
    /*****************************************************************************************************************************************************/
    /*                             getPreviousRejectedHistory                                                                                            */
    /*****************************************************************************************************************************************************/
    @Override
    public List<ApprovalHistoryVO> getPreviousRejectedHistory(WorkflowHeader wfHeaderObj){
        return wfHeaderObj.getApprovalHistoryList();
    }
    private void copyAttributeFromBizObj(WorkflowHeaderVO headerVO, BusinessObjectRootVO bizVO) {
        headerVO.setObjectClassName(bizVO.getClassName());
        headerVO.setObjectLifeCycle(bizVO.getLifeCycle());
        headerVO.setObjectName(bizVO.getNames());
        headerVO.setObjectCurrentStates(bizVO.getStates());
        headerVO.setObjectCreator(bizVO.getCreator());
    }
    private Map<String, Object> makeParameterForInitialize(WorkflowHeader wfHeaderObj) {
        Map<String,Object> map = new HashMap<String,Object>();
        List<CodeDetailVO> stateList                = this.getApprovalStateList(wfHeaderObj.getVo().getObjectLifeCycle());
        List<CodeDetailVO> allStateList             = this.getAllApprovalStateList(wfHeaderObj.getVo().getObjectLifeCycle());
        String distributionState                    = this.getDistributionState(wfHeaderObj.getVo().getObjectLifeCycle());

        List<CodeDetailVO> routeInstructionsList    = codeService.getCodeDetailListByScope(BizCommonCodeConstants.CODE_MASTER_NAME_APPROVALLINE_APPROVAL_TYPE, BusinessCommonConstants.MAIN_COMPANY_NAME);
        List<CodeDetailVO> processRoleList          = codeService.getCodeDetailListByScope(BizCommonCodeConstants.CODE_MASTER_NAME_APPROVALLINE_JOB_GRADE, BusinessCommonConstants.MAIN_COMPANY_NAME);

        List<ApprovalVO> approvalList   = new ArrayList<ApprovalVO>();
        if(!StrUtil.isEmpty(wfHeaderObj.getVo().getObid())) {
            approvalList                 =     this.getWorkflowList(wfHeaderObj);
            ApprovalVO inProcessState    =     this.getInProcessWorkflowRouteNStep(wfHeaderObj);
            if(NullUtil.isNull(inProcessState.getRouteState())) {
                inProcessState = new ApprovalVO();
                inProcessState.setRouteState(wfHeaderObj.getStates());
            }
            map.put("inProcessState",inProcessState);
        }
        map.put("approvalList"      ,approvalList);
        map.put("businessObjectInfo",wfHeaderObj.getVo());
        map.put("className"         ,wfHeaderObj.getVo().getClassName());
        map.put("lifeCycle"         ,wfHeaderObj.getVo().getLifeCycle());
        map.put("stateList"         ,stateList);
        map.put("allStateList"      ,allStateList);
        map.put("distributionState" ,distributionState);
        if(!StrUtil.isEmpty(wfHeaderObj.getObid()) ) {
            map.put("creatorObid",Users.getUsers(wfHeaderObj.getCreator()).getObid());
        } else {
            map.put("creatorObid",userSession.getUserBizObid());
        }
        map.put("routeInstructionsList", routeInstructionsList);
        map.put("processRoleList",       processRoleList);
        map.put("loginUserObid",         userSession.getUserBizObid());
        return map;
    }

    /*****************************************************************************************************************************************************/
    /*                             getApprovalStateList                                                                                                  */
    /*****************************************************************************************************************************************************/
    private List<CodeDetailVO> getApprovalStateList(String lifeCycleName){
        return getApprovalStateList(lifeCycleName, true);
    }
    /*****************************************************************************************************************************************************/
    /*                             getAllApprovalStateList                                                                                               */
    /*****************************************************************************************************************************************************/
    private List<CodeDetailVO> getAllApprovalStateList(String lifeCycleName) {
        List<CodeDetailVO> rtnSteteList = new ArrayList<CodeDetailVO>();
        List<StateInfo> rtnLifeCycleVOList = LifeCycleUtil.getLifieCycleStateListByName(lifeCycleName);
        int idx = 0;
        for( StateInfo stateInfo : rtnLifeCycleVOList ){
            if(!"Cancelled".equals(stateInfo.getStateName())) {
                CodeDetailVO codeDetailVO = new CodeDetailVO();
                codeDetailVO.setSequences(idx);
                codeDetailVO.setNames(stateInfo.getStateName());
                codeDetailVO.setTitles(("Y".equals(stateInfo.getUserInputMandantory())? "**"+stateInfo.getStateName(): stateInfo.getStateName()));
                codeDetailVO.setAttribute01( stateInfo.getProcessRule());
                rtnSteteList.add(codeDetailVO);
                idx++;
            }
        }
        return rtnSteteList;
    }
    /*****************************************************************************************************************************************************/
    /*                             getApprovalStateList                                                                                                  */
    /*****************************************************************************************************************************************************/
    private List<CodeDetailVO> getApprovalStateList(String lifeCycleName, boolean isIncludeWorking) {
        List<CodeDetailVO> rtnStateList = new ArrayList<CodeDetailVO>();
        List<StateInfo> rtnLifeCycleVOList = LifeCycleUtil.getUserInputLifieCycleStateListByName(lifeCycleName);
        int idx = 0;
        for( StateInfo stateInfo : rtnLifeCycleVOList ){
            if( isIncludeWorking || !WorkflowConstants.STATE_WORKING.equals(stateInfo.getStateName())){
                CodeDetailVO codeDetailVO = new CodeDetailVO();
                codeDetailVO.setSequences(idx++);
                codeDetailVO.setNames(stateInfo.getStateName());
                codeDetailVO.setTitles(("Y".equals(stateInfo.getUserInputMandantory())? "**"+stateInfo.getStateName(): stateInfo.getStateName()));
                codeDetailVO.setAttribute01( stateInfo.getProcessRule() );
                codeDetailVO.setAttribute02( stateInfo.getDefaultRoutePurpose() );
                rtnStateList.add(codeDetailVO);
            }
        }

        return rtnStateList;
    }
}
    
