package com.rap.workflow.controller.model;

import com.rap.api.object.foundation.model.CPamBaseModel;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.workflow.model.ApprovalVO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class CParmApprovalVO extends CPamBaseModel {
    private ApprovalVO approvalVO;
    private List<ApprovalVO> sendBackToList;
    private List<FilesVO> fileList;
}
