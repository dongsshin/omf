/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : ApprovalLineVO.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 2. 13.  kwanghyui.choi   Initial
 * ===========================================
 */
package com.rap.workflow.model;

import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import com.rap.workflow.util.WorkflowConstants;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpStatus;

import java.util.Date;
import java.util.List;

@Setter
@Getter
public class ApprovalVO extends ApprovalBaseVO {

    private String stateOfRoute;
    private String stateOfStep;
    private String stateOfInbox;

    // User Viewing용임
    private String userStatus;
    private String department;
    private String assigneeObid;
    private String assigneeTitles;
    private String assigneeMailAddress;
    private String assigneeInfo;
    private Boolean canApproval = false;   //Login User와 같은 사용자이면 true를 Return(화면 Operation을 위해)

    private List<ApprovalVO> sendBackToList;
    private String action;
    private String rejectCode;//화면에서 Reject시 구분자를 넘겨준다.
    private String signal;//화면에서 Reject시 구분자를 넘겨준다.
    Boolean remainSelfRejectionInboxTask = true;

    //Object Route 속성
    private String        routePurpose                 = "Standard";
    private String        routeLifeCycle              ;

    //Route 속성
    private String        routeCompletionAction        = "None";
    private Boolean       subRouteVisibility           = (Boolean)false;
    private String        routeBasePurpose             = "Standard";
    private Boolean       restartUpOnTaskRejection     = (Boolean)true;
    private String        autoStopOnRejection          = "Immediate";
    private String        organizations               ;
    private String        routeStatus                  = "Not Started";
    private String        processTimestamp            ;
    private String        activityUrl                  = "None";
    
    //WorkflowStepNodeUserVO 속성
    private String        routeAction                 = WorkflowConstants.ROUTE_ACTIONS_STANDARD;
    private String        routeInstructions           = WorkflowConstants.ROUTE_PURPOSE_STANDARD;

    private String        comments                    ;
    private String        approvalStatus               = "None";
    private Date          scheduledCompletionDate     ;
    private Date          actualCompletionDate        ;


    private String        taskRequirement              = "Optional";
    private Boolean       reviewTask                   = (Boolean)false;
    private String        reviewersComments           ;
    private Boolean       reviewCommentsNeeded         = (Boolean)false;

    private Integer       dueDateOffset                = 2;
    private String        dateOffsetFrom               = "Task Create Date";
    private Date          assigneeSetDueDate          ;

    private Boolean       allowDelegation              = (Boolean)true;
    private String        titles                    ;
    private String        actionComments            ;
    private Boolean       notifyEmail                = (Boolean)true;
    private Boolean       selfReject                 = (Boolean)false;

    //InboxTask 속성
    private String        taskOwner                 ;
    private String        originTaskOwner           ;
    private String        delegatedFrom             ;
    private String        delegatedTo               ;
    private String        mobileApproval            ;
    private String        inboxTaskType              = "Workflow";
    public void validateForAddUser(){

        if(!WorkflowConstants.INSTRUCTION_TYPE_SET.contains(routeInstructions))
            throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"Route Instructions(" + routeInstructions + ") is invalid.");
        if(!WorkflowConstants.ROUTE_ACTIONS_SET.contains(routeAction))
            throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"Route Action(" + routeAction + ") is invalid.");
        if(!WorkflowConstants.ROUTE_ACTION_RULE_SET.contains(this.getParallelNodeProcessionRule()))
            throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"Process Rule(" + this.getParallelNodeProcessionRule() + ") is invalid.");
        if(NullUtil.isNull(this.getStepSequences()))
            throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"Step info is empty.");
        if(NullUtil.isNull(this.getStepNodeUserSequences()))
            throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"User Sequence info is empty.");
        if(NullUtil.isNull(this.getAssigneeObid()))
            throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"User info is empty.");
        if(NullUtil.isNull(this.getResponsibility()))
            throw  new OmfApplicationException(HttpStatus.BAD_REQUEST,"Responsibility info is empty.");
    }
    public void validateForSubmit(){
        if(StrUtil.isEmpty(this.getWfRequesterObid())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Request Object id is empty.");
        if(StrUtil.isEmpty(this.getApprovalStatus())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Approval Status is empty.");
        if(StrUtil.isEmpty(this.getComments())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Comments is empty.");
        if(StrUtil.isEmpty(this.getStepNodeUserObid())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Step Node User Object id is empty.");
        if(NullUtil.isNull(this.getStepSequences())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Step is empty.");
        if(NullUtil.isNull(this.getParallelNodeProcessionRule())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Process Rule is empty.");
    }
}
