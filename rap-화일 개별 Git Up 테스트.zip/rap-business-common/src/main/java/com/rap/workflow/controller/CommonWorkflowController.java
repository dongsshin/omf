/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : WorkflowController.java1
 * ===========================================
 * Modify Date    Modifier    Description
 * -------------------------------------------
 * 2015.03.13 kwanghyui.choi   Initial
 * 2015.11.23 eunsu.Jang  2D, 3D File Down 로직 추가
 * ===========================================
 */
package com.rap.workflow.controller;


import com.constants.GlobalCommonConstants;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.BusinessObjectRoot;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.FilesVO;
import com.rap.api.object.workflow.dom.WorkflowHeader;
import com.rap.api.object.workflow.dom.WorkflowInboxTask;
import com.rap.api.object.workflow.dom.WorkflowRoute;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.common.code.service.CodeService;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.user.service.UsersService;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.lifecycle.model.LifeCycleInfo;
import com.rap.omc.foundation.ui.service.UIService;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.annotation.OmfJsonResolver;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.LifeCycleUtil;
import com.rap.workflow.controller.model.CParmApprovalVO;
import com.rap.workflow.model.ApprovalHistoryVO;
import com.rap.workflow.model.ApprovalVO;
import com.rap.workflow.model.ReassignVO;
import com.rap.workflow.service.WorkflowService;
import com.rap.workflow.util.WorkflowConstants;
import com.workflow.WfSimpleApprovalVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController

public class CommonWorkflowController extends RestBaseController {

    @Autowired
    private UserSession userSession;

    @Resource(name = "workflowService")
    private WorkflowService workflowService;

    @Resource(name = "codeService")
    private CodeService codeService;


    @Resource(name = "usersService")
    private UsersService usersService;

    @Resource(name = "uiService")
    private UIService uiService;


    //1차 완료
    @RequestMapping( value="/common/workflow/init/{obid}",method= {RequestMethod.GET},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> initWorkflowInfo(@PathVariable(name = "obid") String obid) {
        try{
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            Map<String,Object> map = workflowService.initializeWorkflow(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //1차 완료
    @RequestMapping(value="/common/workflow/approval/{obid}",method= {RequestMethod.GET},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> getInProcessState(@PathVariable(value = "obid") String obid) {
        try{
            if(StrUtil.isEmpty(obid))  throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.illegalArgument", new Object[] { "Obid is null" });
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            ApprovalVO inProcessState =  workflowService.getInProcessWorkflowRouteNStep(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,inProcessState),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value="/common/workflow/approvals/{obid}", method = {RequestMethod.PUT},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> refreshWorkflowList(@PathVariable(value = "obid") String obid,
                                                 @RequestBody                  List<ApprovalVO> approvalList) {
        try{
            obid = "RfrjN$p7HCy6NKtMAmhU";
            if(StrUtil.isEmpty(obid))  throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.illegalArgument", new Object[] { "Obid is null" });
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);

            approvalList = makeApprovalVOList(AppSchemaCommonConstants.LIFECYCLE_SAMPLE_REQUEST);
            // Modify Approval - Done 수행 시 Validation
            //Map<String, Object> inputParams = new HashMap<String, Object>();
            //inputParams.put( "approvalList", approvalList );
            //wfHeaderObj.preProcessUpdate( inputParams );

            //workflowService.txnCreateAndUpdateWorkflow(wfHeaderObj, approvalList);
            List<ApprovalVO> rtnApprovalList = workflowService.getWorkflowList(wfHeaderObj);
            changeApprovalVOList(rtnApprovalList);
            workflowService.txnCreateAndUpdateWorkflow(wfHeaderObj, rtnApprovalList);
            //workflowService.txnClearWorkflowList(wfHeaderObj);

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,rtnApprovalList),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value="/common/workflow/approvals/{obid}",method= {RequestMethod.DELETE},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> clearWorkflowList(@PathVariable(value = "obid") String obid) {
        try{
            if(StrUtil.isEmpty(obid))  throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.illegalArgument", new Object[] { "Obid is null" });
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            workflowService.txnClearWorkflowList(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"N/A"),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //2차 완료
    @RequestMapping( value="/common/workflow/approvals/{obid}",method= {RequestMethod.GET},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> getWorkflowList(@PathVariable(value = "obid") String obid) {
        try{
            if(StrUtil.isEmpty(obid))  throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.illegalArgument", new Object[] { "Obid is null" });
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            List<ApprovalVO> approvalList = workflowService.getWorkflowList(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,approvalList),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value="/common/workflow/approvals/simple/{obid}/",method= {RequestMethod.GET},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> getApprovalsList(@PathVariable(value = "obid") String targetObid) {
        try{
            if(StrUtil.isEmpty(targetObid))  throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.illegalArgument", new Object[] { "Obid is null" });
            WorkflowHeaderVO headerVO = BusinessObject.findObject(AppSchemaCommonConstants.BIZCLASS_WORKFLOWHEADER,targetObid,"1");
            WorkflowHeader wfHeaderObj = DomUtil.toDom(headerVO);
            WfSimpleApprovalVO simpleApprovalVO = workflowService.getSimpleWorkflowList(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,simpleApprovalVO),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //2차 완료
    @RequestMapping( value="/common/workflow/approval/reassign", method = RequestMethod.PUT ,produces = "application/json; charset=utf-8")
    public ResponseEntity<?> reassignApprover(@RequestBody ReassignVO reassignVO) {
        try{
            if (StrUtil.isEmpty(reassignVO.getWfRequestObid())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            if (StrUtil.isEmpty(reassignVO.getInboxTaskObid())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            WorkflowHeader wfHeaderObj = DomUtil.toDom(reassignVO.getWfRequestObid());
            workflowService.txnReassignApprover(wfHeaderObj, reassignVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Action Completed!"),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Reassigning Approver!",e);
        }
    }
    //Multiple Reassign (Approval, AdminApproval 탭에서 사용하는 기능)
    @RequestMapping( value="/common/workflow/approval/reassigns", method = RequestMethod.PUT ,produces = "application/json; charset=utf-8")
    public ResponseEntity<?> doReassignList(@RequestBody List<ReassignVO> reassignVOList) {
        try{
            this.doReassignListSub(reassignVOList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Completed!"),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Reassigning!",e);
        }
    }
    //2차 완료
    @RequestMapping( value="/common/workflow/request/{obid}", method= {RequestMethod.GET},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> getWorkflowRequestInfo(@PathVariable(value = "obid") String obid) {
        try{
            if(StrUtil.isEmpty(obid))  throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"api.object.error.workflow.illegalArgument", new Object[] { "Obid is null" });
            Map<String,Object> map = workflowService.getWorkflowRequestInfo(obid);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value="/common/workflow/start/{obid}", method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> doApproval(@PathVariable(value = "obid") String obid) {
        try{
            WorkflowHeader wfHeaderObj = DomUtil.toDom("RfrjN$p7HCy6NKtMAmhU");
            wfHeaderObj.setTargetObject();
            workflowService.txnStartWorkflow(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Action Completed!"),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="/common/workflow/approval", method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> doApproval(@RequestBody CParmApprovalVO cParmApprovalVO) {
        try{

            WorkflowHeader wfHeaderObj = DomUtil.toDom("RfrjN$p7HCy6NKtMAmhU");
            wfHeaderObj.setTargetObject();
            List<ApprovalVO> approvalList = workflowService.getWorkflowList(wfHeaderObj);
            //WorkflowHeader wfHeaderObj = DomUtil.toDom(cParmApprovalVO.getApprovalVO().getWfRequesterObid());
            approvalList.get(0).setComments("dddddddddddddddddddd");
            approvalList.get(0).setApprovalStatus("Approve");
            cParmApprovalVO.setApprovalVO(approvalList.get(0));
            validateApprovalVO(cParmApprovalVO.getApprovalVO());

//            if(!NullUtil.isNone(cParmApprovalVO.getSendBackToList())) wfHeaderObj.setOutDataAttributeValue("sendBackToList", cParmApprovalVO.getSendBackToList());
            WorkflowRoute routeObj = DomUtil.toDom(cParmApprovalVO.getApprovalVO().getRouteNodeObid());



            workflowService.txnSubmitApproval(wfHeaderObj, cParmApprovalVO.getApprovalVO(), cParmApprovalVO.getFileList());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Action Completed!"),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //보류
    @RequestMapping( value="/common/workflow/ep/approval", method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> epApprove(@RequestBody HashMap<String,Object> parmMap){
        try{
        String obid = (String)parmMap.get("obid");
        boolean isApproved = (Boolean)parmMap.get("isApproved");
        //TODO
        //return "workflow/epApprove";
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Action Completed!"),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //보류
    @RequestMapping( value="/common/workflow/ep/approvals", method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getEpApprovedList(@RequestBody HashMap<String,Object> parmMap){
        try{
            //return "workflow/epApprovedList";
            //TODO
            //return "workflow/epApprove";
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Action Completed!"),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="/common/workflow/selfreject", method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> submitSelfReject(@RequestBody ApprovalVO approvalVO) {
        try {
            if (StrUtil.isEmpty(approvalVO.getWfRequesterObid())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            WorkflowHeader wfHeaderObj = DomUtil.toDom(approvalVO.getWfRequesterObid());
            workflowService.txnSubmitSelfReject(wfHeaderObj, approvalVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY, "Action Completed!"), HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error Occurred in Rejecting!", e);
        }
    }
    //1차 완료
    @RequestMapping( value="/workflow/search/approvals/{userId}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getApprovalListPging(@PathVariable("userId" ) String userId,
                                                  @RequestParam(name="listType"            ,required = true ,defaultValue = "Approval") String listType,
                                                  @RequestParam(name="zz1_targetRow"       ,required = true ,defaultValue = "1") int targetRow,
                                                  @RequestParam(name="zz2_rowSize"         ,required = true ,defaultValue = "30") int rowSize,
                                                  @RequestParam(name="zz3_currentPage"     ,required = true ,defaultValue = "1") int currentPage,
                                                  @RequestParam(name="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{
            PagingEntity pagingEntity = new PagingEntity(targetRow,rowSize,currentPage,sortByPattern);
            List<WorkflowInboxTaskVO> approvalList = null;
            if(StrUtil.isEmpty(userId)) userId = userSession.getUserBizObid();
            Users users = new Users(Users.findMe(userId));;
            switch (listType){
                case "Approval":
                    approvalList = users.getApprovalList(pagingEntity);
                    break;
                case "SaveDraft":
                    approvalList = users.getSaveDraftList(pagingEntity );
                    break;
                case "Distribution":
                    approvalList = users.getDistributionList(pagingEntity);
                    break;
                case "Requested":
                    approvalList = users.getRequestedList(pagingEntity);
                    break;
                case "Approved":
                    approvalList = users.getApprovedList(pagingEntity);
                    break;
                default:
                    throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Request Parameter is Invalid.");
            }
            if ( approvalList instanceof OmfPagingList) {
                OmfPagingList<WorkflowInboxTaskVO> pagingList = (OmfPagingList<WorkflowInboxTaskVO>)approvalList;
                pagingEntity    =  pagingList.getPagingEntity();
            }
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingEntity);
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,approvalList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/approval/sendBackTo", method = {RequestMethod.PUT},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> retrieveSendBackToList(@RequestBody ApprovalVO approvalVO) {
        try{
            if (StrUtil.isEmpty(approvalVO.getWfRequesterObid()))           throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Approval Object ID"});
            if (StrUtil.isEmpty(approvalVO.getApprovalStatus())) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Approval Status"});
            List<ApprovalVO> rtnApprovalVOVOList = workflowService.getSendBackToList(approvalVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,rtnApprovalVOVOList),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting SendBack List!",e);
        }
    }
    /*
    @RequestMapping( value="/workflow/search/approvals/{userId}/{listType}",method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getApprovalList(@RequestBody WorkflowInboxTaskVO searchInfo,
                                             @PathVariable("userId" ) String userId,
                                             @PathVariable("listType" ) String listType) {
        try{
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }

     */

    //1차 완료
    @RequestMapping( value="common/workflow/distribution/{obid}",method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> addManualDistribution(@PathVariable("obid") String obid,
                                                   @OmfJsonResolver("approvalVO") ApprovalVO approvalVO) {
        try{
            if (StrUtil.isEmpty(obid)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            if (StrUtil.isEmpty(approvalVO.getAssigneeObid()))   throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Assignee Object ID"});
            List<ApprovalVO> approvalVOList = new ArrayList<ApprovalVO>();
            approvalVOList.add(approvalVO);
            workflowService.txnCreateAndUpdateWorkflow(wfHeaderObj, approvalVOList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Added Successfully."),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Adding Distribution!",e);
        }
    }

    //사용자 수동 배포(Workflow 무관)
    //1차 완료
    @RequestMapping( value="common/workflow/distributions",method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> manualDistributeItemList(@OmfJsonResolver("assigneeList") List<UsersVO> assigneeList,
                                                      @OmfJsonResolver("targetObjectList") List<BusinessObjectRootVO> targetObjectList,
                                                      @OmfJsonResolver("comments") String comments){
        try {
            if (NullUtil.isNone(assigneeList)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "There is(are) no data to Target User.");
            if (NullUtil.isNone(targetObjectList)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "There is(are) no data to distribute");
            workflowService.txnManualDistribute(assigneeList, targetObjectList, comments);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Distributed Successfully."),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Distributing!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/distributions/manualAtList",method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> distributeItemListAtList(@OmfJsonResolver( "assigneeList" ) List<UsersVO> assigneeList,
                                                      @OmfJsonResolver( "targetObjectList" ) List<WorkflowHeaderVO> targetObjectList,
                                                      @OmfJsonResolver( "comments" ) String comments){
        try {
            validationForManualDistributeByList(targetObjectList);
            distributeItemListSub(assigneeList,targetObjectList,comments);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Distributed Successfully."),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Distributing!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/distributions/manualAtDetail",method = {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> distributeItemListAtDetail(@OmfJsonResolver( "assigneeList" ) List<UsersVO> assigneeList,
                                                        @OmfJsonResolver( "targetObjectList" ) List<WorkflowHeaderVO> targetObjectList,
                                                        @OmfJsonResolver( "comments" ) String comments){
        try {
            validationForManualDistributeByDetail(targetObjectList);
            distributeItemListSub(assigneeList,targetObjectList,comments);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Distributed Successfully."),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Distributing!",e);
        }
    }
    //배포이력 조회
    //1차완료
    @RequestMapping( value="common/workflow/distribution/{obid}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getDistributionHistoryList( String targetObid, ModelMap map ) throws Exception {
        try{
            WorkflowHeader wfHeaderObj = DomUtil.toDom(targetObid);
            List<WorkflowInboxTaskVO> inboxVOList = workflowService.getDistributionHistoryList(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,inboxVOList),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Distribution List!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/approval/history/{obid}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getApprovalHistoryList(@PathVariable("obid") String obid) {
        try{
            if (StrUtil.isEmpty(obid)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            List<ApprovalHistoryVO> approvalHistoryList = workflowService.getApprovalHistoryList(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,approvalHistoryList),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Approval History!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/approval/rejectedHistory/{obid}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> retrievePreviousRejectedHistory(@PathVariable("obid") String obid) {
        try{
            if (StrUtil.isEmpty(obid)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            List<ApprovalHistoryVO> approvalHistoryList = workflowService.getPreviousRejectedHistory(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,approvalHistoryList),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Approval History!",e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/approval/files/{obid}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getFilesVOList(@PathVariable("obid") String obid) {
        try {
            if (StrUtil.isEmpty(obid)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            List<FilesVO> fileList = workflowService.getFilesVOList(new WorkflowInboxTask(obid));
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,fileList),HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error Occurred in Getting Approval History!", e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/approval/notifications/{obid}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getEmailNotificationList(@PathVariable("obid") String obid) {
        try {
            if (StrUtil.isEmpty(obid)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Object ID"});
            WorkflowHeader wfHeaderObj = DomUtil.toDom(obid);
            List<WorkflowInboxTaskVO> emailNotificationList = workflowService.getNotificationFromRoute(wfHeaderObj);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,emailNotificationList),HttpStatus.OK);
        } catch (Exception e) {
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error Occurred in Getting Notification List!", e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/approval/acknowledges/{userId}",method = {RequestMethod.PUT},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> massAcknowledge(@RequestBody List<ApprovalVO> targetObjectList,
                                             @PathVariable( "userId" ) String userId){
        try {
            if(StrUtil.isEmpty(userId)) userId = userSession.getUserId();
            validateForMassAcknowledge(targetObjectList,userId);
            workflowService.txnDoMassAcknowledge( targetObjectList );
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Completed!"),HttpStatus.OK);
        }catch (Exception e) {
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error Occurred in Acknowledging!", e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/states/{policyName}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getStateListByPolicy(@PathVariable("policyName") String policyName) {
        try {
            if (StrUtil.isEmpty(policyName)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "Request inf({}) is empty", new Object[]{"Policy Name"});
            List<String> stateList = LifeCycleUtil.getLifeCycleStateStringListByName(policyName);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,stateList),HttpStatus.OK);
        }catch (Exception e) {
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error Occurred in Getting Life Cycle's States!", e);
        }
    }
    //1차 완료
    @RequestMapping( value="common/workflow/object/biz/{obid}",method = {RequestMethod.GET},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> getBusinessObjectDetailInfo(@PathVariable("obid") String obid) {
        try {
            BusinessObjectRoot bizObj = new BusinessObjectRoot(obid);
            Map<String,Object> map = new HashMap<String,Object>();
            map.put("detailVO",bizObj.getVo());
            map.put("workflowDetailUrl",BusinessObjectRoot.getWorkflowUrl(obid));
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e) {
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, "Error Occurred in Getting Detail Info!", e);
        }
    }
    private void validationForManualDistributeByList(List<WorkflowHeaderVO> targetObjectList){
        List<WorkflowInboxTaskVO> inboxTaskVOList = Users.getApprovalList(userSession.getUserId());
        if(NullUtil.isNone(inboxTaskVOList)) throw new OmfApplicationException(HttpStatus.FORBIDDEN,"plm.common.error.menu.access");
        boolean isExist = false;
        for(WorkflowHeaderVO bizVO: targetObjectList){
            isExist = false;
            for(WorkflowInboxTaskVO inboxVO :  inboxTaskVOList){
                if(bizVO.getObid().equals(inboxVO.getOutDataStringValue("targetObid")) ){
                    isExist = true;
                    break;
                }
            }
            if( !isExist ) throw new OmfApplicationException(HttpStatus.FORBIDDEN,"plm.common.error.menu.access");
        }
    }
    private void validationForManualDistributeByDetail(List<WorkflowHeaderVO> targetObjectList){
        if( !uiService.checkMenuAccess("CommandConstants.cmdDistributeForLifeCycle", targetObjectList.get(0).getObid()) ){
            throw new OmfApplicationException(HttpStatus.FORBIDDEN,"plm.common.error.menu.access");
        }
    }

    private void distributeItemListSub(List<UsersVO> assigneeList,List<WorkflowHeaderVO> targetObjectList,String comments){
        List<ApprovalVO> approvalVOList = null;
        WorkflowHeader wfHeaderObj = null;
        if(!NullUtil.isNone(assigneeList) && !NullUtil.isNone(targetObjectList)) {
            approvalVOList = makeApprovalVOList(assigneeList, comments);
            for (WorkflowHeaderVO bizVO : targetObjectList) {
                wfHeaderObj = DomUtil.toDom(bizVO.getObid());
                String distributionState = workflowService.getDistributionState(wfHeaderObj.getObjectLifeCycle());
                for (ApprovalVO approvalVO : approvalVOList) {
                    approvalVO.setRouteState(distributionState);
                }
                workflowService.txnAddDistribution(wfHeaderObj, approvalVOList);
            }
        }
    }

    private List<ApprovalVO> makeApprovalVOList(List<UsersVO> assigneeList, String comments){
        List<ApprovalVO> approvalVOList = new ArrayList<ApprovalVO>();
        for( int inx = 0; inx < assigneeList.size(); inx++ ){
            ApprovalVO approvalVO = new ApprovalVO();
            approvalVO.setAssigneeObid( assigneeList.get(inx).getObid() );
            approvalVO.setParallelNodeProcessionRule( "All" );
            approvalVO.setStepSequences(1);
            approvalVO.setRouteInstructions( WorkflowConstants.INSTRUCTION_TYPE_STANDARD );
            approvalVO.setRecordMode( "C" );
            approvalVO.setComments( comments );
            approvalVO.setAssigneeUserId( assigneeList.get(inx).getNames() );
            approvalVO.setAssigneeObid( assigneeList.get(inx).getObid() );
            approvalVOList.add( approvalVO );
        }
        return approvalVOList;
    }

    private void validateForMassAcknowledge(List<ApprovalVO> targetObjectList,
                                            String userId) {
        boolean isValid = false;
        List<WorkflowInboxTaskVO> inboxTaskVOList = Users.getDistributionList(userId);
        if (NullUtil.isNone(inboxTaskVOList))
            throw new OmfApplicationException(HttpStatus.BAD_REQUEST, "plm.common.acknowledge.error", new Object[]{"You don't have item to acknowledge."});
        if (!NullUtil.isNone(targetObjectList)) {
            for (ApprovalVO approvalVO : targetObjectList) {
                isValid = false;
                for (WorkflowInboxTaskVO inboxTaskVO : inboxTaskVOList) {
                    if (inboxTaskVO.getObid().equals(approvalVO.getInboxTaskObid())) {
                        isValid = true;
                        break;
                    }
                }
                if (!isValid)
                    throw new OmfApplicationException(HttpStatus.FORBIDDEN, "plm.common.acknowledge.error", new Object[]{approvalVO.getInboxTaskObid()});
            }
        }
    }

    private void validateApprovalVO(ApprovalVO approvalVO){
        StringBuffer strBuf = new StringBuffer();
        if(StrUtil.isEmpty(approvalVO.getWfRequesterObid())) strBuf.append(",Object ID");
        if(StrUtil.isEmpty(approvalVO.getApprovalStatus())) strBuf.append(",Approval Status");
        if(StrUtil.isEmpty(approvalVO.getComments())) strBuf.append(",Comments");
        if(StrUtil.isEmpty(approvalVO.getInboxTaskObid())) strBuf.append(",Workflow InboxTask Object ID");
        if(StrUtil.isEmpty(approvalVO.getRouteNodeObid())) strBuf.append("Workflow Route Object ID");
        if(StrUtil.isEmpty(approvalVO.getStepSequences().toString())) strBuf.append("Workflow Step");
        if(StrUtil.isEmpty(approvalVO.getParallelNodeProcessionRule())) strBuf.append("Parallel Node Procession Rule");

        if(strBuf.length() > 0) {
            String ddd = strBuf.toString();
            throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Request info({}) is empty",new Object[]{strBuf.toString().substring(1)});
        }
    }
    private void doReassignListSub(List<ReassignVO> reassignVOList) {
        boolean isOwner = true;
        boolean isExist = false;
        List<WorkflowInboxTaskVO> inboxTaskVOList = Users.getApprovalList(userSession.getUserId());
        if(!NullUtil.isNone(inboxTaskVOList)){
            for( int inx = 0; inx < reassignVOList.size(); inx++ ){
                isExist = false;
                for( int jnx = 0; jnx < inboxTaskVOList.size(); jnx++ ){
                    if( reassignVOList.get(inx).getInboxTaskObid().equals(inboxTaskVOList.get(jnx).getObid()) ){
                        isExist = true;
                        break;
                    }
                }
                if( !isExist ){
                    isOwner = false;
                    break;
                }
            }
        }else{
            isOwner = false;
        }
        // Menu(Button) Access check 추가
        if( !isOwner && !uiService.checkMenuAccess("CommandConstants.cmdAdminApprovalPortal", "") ){
            throw new OmfApplicationException(HttpStatus.FORBIDDEN,"plm.common.error.menu.access" );
        }
        if( !NullUtil.isNone(reassignVOList)){
            for(ReassignVO reassignVO : reassignVOList) reassignVO.setFromAssigneeObid( userSession.getUserBizObid() );
            workflowService.txnDoReassignList( reassignVOList );
        }
    }

    private void changeApprovalVOList(List<ApprovalVO> list){
        for(ApprovalVO vo : list){
            vo.setRecordMode("");
            if(vo.getRouteState().equals(AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_1STPROCESSING) && vo.getStepSequences() == 2){
                vo.setRecordMode("D");
            }
        }
    }

    private List<ApprovalVO> makeApprovalVOList(String lifeCycle){
        List<ApprovalVO> list = new ArrayList<>();
//Working(Y),1st Processing(Y),2nd Processing(YY),IF Requested,Completed(Y),Cancelled

        LifeCycleInfo lifeCycleInfo   = LifeCycleUtil.getLifeCycleInfo(lifeCycle);

        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_WORKING      ,"XP3866"      ,1,1,"All",true));

        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_1STPROCESSING,"XP3866"      ,1,1,"All",true));
        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_1STPROCESSING,"T-DSS-0001"  ,1,2,"All",true));
        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_1STPROCESSING,"XP3866"      ,2,1,"All",true));

        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_2NDPROCESSING,"XP3866"      ,1,1,"All",true));
        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_2NDPROCESSING,"XP3866"      ,2,1,"Any",true));
        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_2NDPROCESSING,"T-DSS-0001"  ,2,2,"Any",true));

        list.add(makeApprovalVO(lifeCycleInfo,AppSchemaCommonConstants.STATE_SAMPLE_REQUEST_COMPLETED    ,"XP3866"      ,1,1,"All",true));
        return list;
    }
    private ApprovalVO makeApprovalVO(LifeCycleInfo lifeCycleInfo, String  routeState,String  assigneeUserId,Integer stepSequences,Integer stepNodeUserSequences, String parallelNodeProcessionRule, Boolean isEssential){

        UsersVO userVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_USERS,assigneeUserId);
        ApprovalVO approvalVO = new ApprovalVO();
        approvalVO.setRecordMode("C");
        approvalVO.setRouteState(routeState);
        approvalVO.setRouteStateSequence(lifeCycleInfo.getRouteStateSequence(routeState));
        approvalVO.setStepSequences(stepSequences);
        approvalVO.setStepNodeUserSequences(stepNodeUserSequences);
        approvalVO.setAssigneeUserId(assigneeUserId);
        approvalVO.setAssigneeObid(userVO.getObid());
        approvalVO.setParallelNodeProcessionRule(parallelNodeProcessionRule);
        approvalVO.setIsEssential(isEssential);
        return approvalVO;
    }
}