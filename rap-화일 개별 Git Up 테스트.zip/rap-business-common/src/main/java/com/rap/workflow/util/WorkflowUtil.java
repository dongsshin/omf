/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : WorkflowUtil.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2015. 6. 29.  kwanghyui.choi   Initial
 * ===========================================
 */
package com.rap.workflow.util;

import com.constants.IdGeneratorConstants;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.workflow.dom.WorkflowInboxTask;
import com.rap.api.object.workflow.dom.WorkflowRoute;
import com.rap.api.object.workflow.dom.WorkflowStep;
import com.rap.api.object.workflow.model.WorkflowHeaderVO;
import com.rap.api.object.workflow.model.WorkflowInboxTaskVO;
import com.rap.api.object.workflow.model.WorkflowRouteVO;
import com.rap.api.object.workflow.model.WorkflowStepVO;
import com.rap.api.relation.workflow.dom.WorkflowStepNodeUser;
import com.rap.api.relation.workflow.model.WorkflowStepNodeUserVO;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.controller.model.CWorkflowExecuteMethodVO;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.general.NameGeneratorUtil;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.SchemaDaoUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.TimeServiceUtil;
import com.rap.omc.util.foundation.ClassInfoUtil;
import com.rap.omc.util.foundation.CommonApiServiceUtil;
import com.rap.workflow.model.*;
import com.workflow.WfSimpleApprovalVO;
import com.workflow.WfSimpleStateVO;
import com.workflow.WfSimpleStepVO;
import com.workflow.WfSimpleUsersVO;
import org.springframework.http.HttpStatus;
import org.springframework.util.StringUtils;

import java.util.*;

public class WorkflowUtil {
    public static WfSimpleApprovalVO convertSimpleApprovalVO(List<ApprovalVO> list) {
        Integer stepSequences = -1111;
        String  routeState = "6666666";
        boolean isFirst = true;
        List<WfSimpleUsersVO> usersList = null;
        TreeMap<Integer, WfSimpleStepVO> stepMap    = null;
        TreeMap<String, WfSimpleStateVO> statesMap  = null;
        for(ApprovalVO vo : list){
            if(isFirst){
                usersList = new ArrayList<WfSimpleUsersVO>();
                stepMap   = new TreeMap<Integer, WfSimpleStepVO>();
                statesMap = new TreeMap<String, WfSimpleStateVO>();
                stepSequences = vo.getStepSequences();
                routeState   = vo.getRouteState();
            }
            if(vo.getRouteState().equals(routeState)){
                if(vo.getStepSequences() != stepSequences){
                    stepMap.put(stepSequences, new WfSimpleStepVO(stepSequences,usersList));
                    usersList = new ArrayList<WfSimpleUsersVO>();
                }
            }else{
                stepMap.put(stepSequences, new WfSimpleStepVO(stepSequences,usersList));
                usersList = new ArrayList<WfSimpleUsersVO>();
                statesMap.put(routeState,new WfSimpleStateVO(routeState,stepMap));
                stepMap   = new TreeMap<Integer, WfSimpleStepVO>();
            }
            usersList.add(new WfSimpleUsersVO(vo.getAssigneeObid()));
            stepSequences = vo.getStepSequences();
            routeState   = vo.getRouteState();
            isFirst       = false;
        }
        if(!NullUtil.isNone(usersList)){
            stepMap.put(stepSequences, new WfSimpleStepVO(stepSequences,usersList));
            statesMap.put(routeState,new WfSimpleStateVO(routeState,stepMap));
        }
        return new WfSimpleApprovalVO(statesMap);
    }

    public static String getRandomTimestamp() {
        int leftLimit = 97; 
        int rightLimit = 122; 
        int targetStringLength = 20;
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int) 
              (new Random().nextFloat() * (rightLimit - leftLimit));
            buffer.append((char) randomLimitedInt);
        }
        return buffer.toString();
     
    }
    public static Map<String,String> getActionInfo(String defaultRoutePurpose){
        Map<String,String> map = new HashMap<>();
        if(StrUtil.isEmpty(defaultRoutePurpose)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Action Type is empty.");
        if(!WorkflowConstants.ROUTE_PURPOSE_SET.contains(defaultRoutePurpose)) throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Default Route purpose Type(" +  defaultRoutePurpose + ")is invalid.");
        //routeInstructions에는 State에 대한 defaultRoutePurpose의 값을 넣어준다.
        switch (defaultRoutePurpose) {
            case WorkflowConstants.ROUTE_PURPOSE_END_WORKING:
                map.put("routeAction", WorkflowConstants.ROUTE_ACTIONS_END_WORKING);
                map.put("actionComments", WorkflowConstants.ACTION_COMMENTS_END_WORKING);
                map.put("routeInstructions", WorkflowConstants.INSTRUCTION_TYPE_Originator);
                break;
            case WorkflowConstants.ROUTE_PURPOSE_APPROVAL:
                map.put("routeAction", WorkflowConstants.ROUTE_ACTIONS_APPROVE);
                map.put("actionComments", WorkflowConstants.ACTION_COMMENTS_APPROVE);
                map.put("routeInstructions", WorkflowConstants.INSTRUCTION_TYPE_Approver);
                break;
            case WorkflowConstants.ROUTE_PURPOSE_REVIEW:
                map.put("routeAction", WorkflowConstants.ROUTE_ACTIONS_COMMENT);
                map.put("actionComments", WorkflowConstants.ACTION_COMMENTS_COMMENT);
                map.put("routeInstructions", WorkflowConstants.INSTRUCTION_TYPE_Reviewer);
                break;
            case WorkflowConstants.ROUTE_PURPOSE_CONFIRMATION:
                map.put("routeAction", WorkflowConstants.ROUTE_ACTIONS_CONFIRM);
                map.put("actionComments", WorkflowConstants.ACTION_COMMENTS_CONFIRM);
                map.put("routeInstructions", WorkflowConstants.INSTRUCTION_TYPE_Referer);
                break;
            case WorkflowConstants.ROUTE_PURPOSE_DISTRIBUTION:
                map.put("routeAction", WorkflowConstants.ROUTE_ACTIONS_COMMENT);
                map.put("actionComments", WorkflowConstants.ACTION_COMMENTS_DISTRIBUTION);
                map.put("routeInstructions", WorkflowConstants.INSTRUCTION_TYPE_Distributee);
                break;
            case WorkflowConstants.ROUTE_PURPOSE_STANDARD:
                map.put("routeAction", WorkflowConstants.ROUTE_ACTIONS_STANDARD);
                map.put("actionComments", WorkflowConstants.ACTION_COMMENTS_STANDARD);
                map.put("routeInstructions", WorkflowConstants.INSTRUCTION_TYPE_Standard);
                break;
            default:
                throw new OmfApplicationException(HttpStatus.BAD_REQUEST,"Not defined Workflow Process Type for '" + defaultRoutePurpose + "'.");
        }
        //routeInstructions에는 State에 대한 defaultRoutePurpose의 값을 넣어준다.
        return map;
    }
    public static WorkflowStepVO getPreviousStep(Map<Integer, WorkflowStepVO> stepTreeMap, Integer sequences) {
        return getLinkStep(stepTreeMap,sequences,true);
    }
    public static WorkflowStepVO getNextStep(Map<Integer, WorkflowStepVO> stepTreeMap, Integer sequences) {
        return getLinkStep(stepTreeMap,sequences,false);
    }
    private static WorkflowStepVO getLinkStep(Map<Integer, WorkflowStepVO> stepTreeMap, Integer sequences, boolean isPrevious) {
        Iterator<Integer> keys = stepTreeMap.keySet().iterator();
        WorkflowStepVO vo = null;

        while(keys.hasNext()){
            Integer key = keys.next();
            if(isPrevious){
                if(sequences <= key) break;
                vo = stepTreeMap.get(key);
            }else{
                if(key >= sequences) {
                    if(!keys.hasNext()) break;
                    vo = stepTreeMap.get(keys.next());
                    break;
                }
            }
        }
        return vo;
    }
    public static String getMaxByteString(String str, int maxLen) {
        String rtnStr = null;
        String ellipsis = "...";
        if(str.getBytes().length <= maxLen) {
            rtnStr = str;
        }else{
            StringBuilder sb = new StringBuilder();
            int curLen = 0;
            String curChar;
            for(int i = 0; i < str.length(); i++) {
                curChar = str.substring(i, i+1); 
                curLen += curChar.getBytes().length; 
                if (curLen > maxLen - ellipsis.getBytes().length){
                    break; 
                }
                else{
                    sb.append(curChar); 
                }
            } 
            sb.append(ellipsis);
            rtnStr = sb.toString();
        }
        return rtnStr;
    }
    public static WorkflowInboxTaskVO createInboxTask(WorkflowHeaderVO wfHeaderVO, WorkflowRouteVO routeVO, WorkflowStepNodeUserVO stepNodeUserVO) {

        WorkflowStep workflowStep = DomUtil.toDom(stepNodeUserVO.getFromObid(), false);
        WorkflowInboxTaskVO workflowInboxTaskVO = new WorkflowInboxTaskVO();
        WorkflowUtil.copyAttribute(wfHeaderVO, routeVO, workflowStep.getVo(),stepNodeUserVO,workflowInboxTaskVO);
        WorkflowInboxTask workflowInboxTask = DomUtil.toDom(workflowInboxTaskVO);
        WorkflowStepNodeUser  stepNodeUserObj = DomUtil.toDom(stepNodeUserVO);
        Map<String,Object> map = new HashMap<>();
        map.put(WorkflowConstants.MAP_KEY_INBOX_routeVO,routeVO);
        map.put(WorkflowConstants.MAP_KEY_INBOX_userVO,stepNodeUserObj.getUsersVO());
        workflowInboxTask.createObject(map);
        WorkflowUtil.createApprovalInfoToEP(wfHeaderVO, routeVO, workflowInboxTaskVO);
        if(!routeVO.getRouteBasePurpose().equals(WorkflowConstants.ROUTE_PURPOSE_END_WORKING) && workflowInboxTask.getNotifyEmail()) {
            WorkflowUtil.notifyMail(wfHeaderVO, routeVO, workflowInboxTask.getUsersVO());
        }
        return workflowInboxTask.getVo();
    }
    public static void buildDelegatedInboxTask(WorkflowHeaderVO wfHeaderVO, WorkflowRouteVO routeVO, WorkflowStepVO wfStepVO, WorkflowStepNodeUserVO stepNodeUserVO) {
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        if(routeObj.getRouteBasePurpose().equals(WorkflowConstants.ROUTE_PURPOSE_DISTRIBUTION)) return;

        WorkflowStepNodeUser  stepNodeUserObj  = DomUtil.toDom(stepNodeUserVO);
        Users assigneeObj = DomUtil.toDom(stepNodeUserObj.getUsersVO());
        String originTaskOwner =  assigneeObj.getNames();
        boolean isFirst = true;
        while(true){
            UsersVO delegateToAssigneeVO = assigneeObj.getDelegator();
            if(NullUtil.isNull(delegateToAssigneeVO) || delegateToAssigneeVO.getObid().equals(assigneeObj.getObid())) break;
            if(isFirst) {
                WorkflowInboxTaskVO originWorkflowInboxTaskVO =  routeObj.getInboxTask(stepNodeUserVO.getObid());
                originWorkflowInboxTaskVO.setOriginTaskOwner(originTaskOwner);
                WorkflowInboxTask originWorkflowInboxTask = DomUtil.toDom(originWorkflowInboxTaskVO);
                originWorkflowInboxTask.modifyObject();
            }

            WorkflowInboxTaskVO delegateWorkflowInboxTaskVO = new WorkflowInboxTaskVO();
            WorkflowUtil.copyAttribute(wfHeaderVO,routeObj.getVo(),wfStepVO,stepNodeUserVO,delegateWorkflowInboxTaskVO);

            delegateWorkflowInboxTaskVO.setOriginTaskOwner(originTaskOwner);
            delegateWorkflowInboxTaskVO.setRouteNodeObid("Delegated");
            delegateWorkflowInboxTaskVO.setDelegatedFrom(assigneeObj.getObid());

            Map<String,Object> map = new HashMap<>();
            map.put(WorkflowConstants.MAP_KEY_INBOX_routeVO,routeVO);
            map.put(WorkflowConstants.MAP_KEY_INBOX_userVO,delegateToAssigneeVO);

            WorkflowInboxTask delegateWorkflowInboxTask = DomUtil.toDom(delegateWorkflowInboxTaskVO);
            delegateWorkflowInboxTask.createObject(map);

            if(!routeVO.getRouteBasePurpose().equals(WorkflowConstants.ROUTE_PURPOSE_END_WORKING)) { //Standard (Working)을 제외하고 메일 발송
                WorkflowUtil.notifyMail(wfHeaderVO, routeVO, delegateToAssigneeVO);
            }
            assigneeObj = DomUtil.toDom(delegateToAssigneeVO);
        }
        isFirst = false;
    }
    public static void executePreProcessApproval(ApprovalVO approvalVO, BusinessObjectRootVO objVO){
        CWorkflowExecuteMethodVO executeMethodVO = new CWorkflowExecuteMethodVO();
        executeMethodVO.addParameter("approvalStatus"         , approvalVO.getApprovalStatus());
        executeMethodVO.addParameter("obidOfWorkflowInboxTask", approvalVO.getInboxTaskObid());
        executeMethodVO.addParameter("comments"               , approvalVO.getComments());
        executeMethodVO.addParameter("mobileApproval"         , approvalVO.getMobileApproval());
        executeMethodVO.addParameter("rejectCode"             , approvalVO.getSelfReject());
        executeMethodVO.setMethodName("preProcessApproval");
        executeMethodVO.setObid(objVO.getObid());
        CommonApiServiceUtil.executeMethod(executeMethodVO);
    }
    public static void sortApprovalVOList(List<ApprovalVO> approvalVOList) {
        Collections.sort(approvalVOList, new WorkflowChainedComparator(
                new WorkflowRouteComparator(), new WorkflowRouteStepComparator(), new WorkflowRouteNodeComparator())
        );
    }

    public static Map<Integer, List<ApprovalVO>> filterApprovalVOListByStep(List<ApprovalVO> approvalVOList) {
        List<ApprovalVO> safeInputList = NullUtil.isNull(approvalVOList) ? Collections.<ApprovalVO>emptyList() : approvalVOList;
        Map<Integer, List<ApprovalVO>> rtnApprovalVOStepList = new TreeMap<Integer, List<ApprovalVO>>();
        for(ApprovalVO approvalVO: safeInputList) {
            List<ApprovalVO> tempApprovalList = rtnApprovalVOStepList.get(approvalVO.getStepSequences());
            if (NullUtil.isNone(tempApprovalList)) {
                tempApprovalList = new ArrayList<ApprovalVO>();
                rtnApprovalVOStepList.put(approvalVO.getStepSequences(), tempApprovalList);
            }
            tempApprovalList.add(approvalVO);
        }
        return rtnApprovalVOStepList;
    }
    public static void createSubmitApprovalInfoToEP(WorkflowHeaderVO targetObjVO, WorkflowRouteVO routeVO, WorkflowStepNodeUserVO workflowStepNodeUserVO, String approvalStatus) {
        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        WorkflowInboxTaskVO workflowInboxTaskVO = routeObj.getInboxTask(workflowStepNodeUserVO);
        if(!validateApprovalInfoToEP(targetObjVO, routeObj.getVo()) && !workflowInboxTaskVO.getInboxTaskType().equals(WorkflowConstants.INBOXTASK_TYPE_WBSACTIVITY)) return;
        WorkflowInboxTask workflowInboxTask = DomUtil.toDom(workflowInboxTaskVO);
        EPApprovalVO epApprovalVO = new EPApprovalVO();
        epApprovalVO.setCommand("AAI");//결재자가 결재을 했을 때 결재상태를 넘겨주는 기능
        epApprovalVO.setSystemPk(workflowInboxTaskVO.getObid());
        epApprovalVO.setC1("02");
        epApprovalVO.setC2(approvalStatus);
        epApprovalVO.setSabun1(workflowInboxTask.getVo().getTaskOwner());
        //epApprovalVO.setUrl1(propertiesService.getString("was.homeUrl") + "/epApprove.do?obid=" + businessObjectRoot.getVo().getObid());
        epApprovalVO.setTaskId(routeObj.getVo().getObid());
        SchemaDaoUtil.insert("WORKFLOW.insertAAIEPApprovalInfo", epApprovalVO);

        epApprovalVO = new EPApprovalVO();
        epApprovalVO.setCommand("AAF"); //apr_status가 03 즉 최종 완료되었을 때 호출하는기능
        epApprovalVO.setSystemPk(workflowInboxTask.getVo().getObid());
        epApprovalVO.setSabun1(targetObjVO.getCreator());
        epApprovalVO.setTaskId(routeObj.getVo().getObid());
        //epApprovalVO.setUrl1(propertiesService.getString("was.homeUrl") + "/epApprove.do?obid=" + businessObjectRoot.getVo().getObid());
        SchemaDaoUtil.insert("WORKFLOW.insertAAFEPApprovalInfo", epApprovalVO);
    }
    public static void createApprovalInfoToEP(BusinessObjectRootVO targetObjVO, WorkflowRouteVO  routeVO, WorkflowInboxTaskVO inboxTaskVO) {
        if(!validateApprovalInfoToEP(targetObjVO, routeVO) && !inboxTaskVO.getInboxTaskType().equals(WorkflowConstants.INBOXTASK_TYPE_WBSACTIVITY)) return;
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(targetObjVO.getClassName());

        //Build ARD Info
        EPApprovalVO epApprovalVO = new EPApprovalVO();
        epApprovalVO.setCommand("ARD"); //system_id,system_pk에 해당하는 결재 정보를 모두 지운다.
        epApprovalVO.setSystemPk(inboxTaskVO.getObid());
        epApprovalVO.setTaskId(routeVO.getObid());
//        commonDao.insert("WORKFLOW.deleteEPApprovalInfoBySystemPk", epApprovalVO, WorkflowConstants.ITF_DATA_SOURCE);
        //commonDao.insert("WORKFLOW.deleteEPApprovalInfoBySystemPk", epApprovalVO);
        SchemaDaoUtil.insert("WORKFLOW.insertARDEPApprovalInfo", epApprovalVO);

        //Build ARI Info
        epApprovalVO = new EPApprovalVO();
        epApprovalVO.setCommand("ARI"); //기안자가 결재를 요청했을 때 필요한 값
        epApprovalVO.setSystemPk(inboxTaskVO.getObid());
        epApprovalVO.setC1("01");
        epApprovalVO.setC2(classInfo.getDisplayedName());
//        int businessObjectRootNameLength = businessObjectRoot.getVo().getNames().getBytes().length;
//        epApprovalVO.setC3(businessObjectRoot.getVo().getNames()+" ("+ WorkflowUtil.getMaxByteString(businessObjectRoot.getVo().getTitles(), 48 - businessObjectRootNameLength) +")");
        epApprovalVO.setC3(WorkflowUtil.getMaxByteString(targetObjVO.getTitles(), 100));
        epApprovalVO.setC4(mobileApproveCheck(targetObjVO,classInfo,  inboxTaskVO));
        epApprovalVO.setC5(classInfo.getDisplayedName());
        epApprovalVO.setSabun1(targetObjVO.getCreator());
        //epApprovalVO.setUrl1(propertiesService.getString("was.homeUrl") + "/epApprove.do?obid=" + businessObjectRoot.getVo().getObid());
        epApprovalVO.setTaskId(routeVO.getObid());
        SchemaDaoUtil.insert("WORKFLOW.insertARIEPApprovalInfo", epApprovalVO);

        //Build ABY Info
        epApprovalVO =  new EPApprovalVO();
        epApprovalVO.setCommand("ABY"); //결재요청 또는 결재 처리후 다음 차수에 결재할 결재자 정보를 넣는다.
        epApprovalVO.setSystemPk(inboxTaskVO.getObid());
        epApprovalVO.setC1("01");
        epApprovalVO.setC2(WorkflowConstants.APPROVAL_STATUS_APPROVE);
        epApprovalVO.setSabun1(inboxTaskVO.getTaskOwner());
        //epApprovalVO.setUrl1(propertiesService.getString("was.homeUrl") + "/epApprove.do?obid=" + businessObjectRoot.getVo().getObid());
        epApprovalVO.setTaskId(routeVO.getObid());
        SchemaDaoUtil.insert("WORKFLOW.insertABYEPApprovalInfo", epApprovalVO);
    }
    private static String mobileApproveCheck(BusinessObjectRootVO targetObjVO, ClassInfo classInfo, WorkflowInboxTaskVO inboxTaskVO){
        String mobileUseFlag = "01";

//        if(workflowInboxTask.getVo().getInboxTaskType().equals(WorkflowConstants.INBOXTASK_TYPE_WBSACTIVITY)) {
//            mobileUseFlag = null;
//        }else{
//            if(classInfo.getClassName().equals("ChangeProcess")) {
//                ChangeProcess changeProcess = (ChangeProcess)businessObjectRoot;
//                if(!changeProcess.isMobileApproval()) mobileUseFlag = null;
//            }
//        }

        return mobileUseFlag;
    }
    private static boolean validateApprovalInfoToEP(BusinessObjectRootVO targetObjVO, WorkflowRouteVO routeVO) {
        boolean bResult = true;
        if(WorkflowConstants.ROUTE_PURPOSE_END_WORKING.equals(routeVO.getRouteBasePurpose())) {
            bResult = false;
        }
        if(WorkflowConstants.ROUTE_PURPOSE_DISTRIBUTION.equals(routeVO.getRouteBasePurpose())) {
            bResult = false;
        }
        return bResult;
    }
    public static void notifyMail(BusinessObjectRootVO targetVO, WorkflowRouteVO routeVO, BusinessObjectRootVO usersVO) {
        if( usersVO != null ){
            MailSendVO mailSendVO = new MailSendVO();
            if(routeVO.getRouteBasePurpose().equals(WorkflowConstants.ROUTE_PURPOSE_DISTRIBUTION)) {
                mailSendVO.setSendType(WorkflowConstants.MAIL_TYPE_DISTRIBUTION);
            }else{
                mailSendVO.setSendType(WorkflowConstants.MAIL_TYPE_APPROVAL);
            }
            mailSendVO.setObid(targetVO.getObid());
            mailSendVO.setClassName(targetVO.getClassName());
            mailSendVO.setNames(targetVO.getNames());
            mailSendVO.setCurrentStatus(targetVO.getStates());
            mailSendVO.setFromUserId(ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID));
            List<String> toUserIdList = new ArrayList<String>();
            toUserIdList.add(usersVO.getNames());
            mailSendVO.setToUserIdList(toUserIdList);
            txnCreateMailSendInfo(mailSendVO);
        }
    }
    public static Map<String, List<ApprovalVO>> classifyApprovalVOListByRouteState(List<ApprovalVO> approvalVOList)  {
        Map<String, List<ApprovalVO>> approvalVOListMap = new HashMap<String, List<ApprovalVO>>();
        for(ApprovalVO approvalVO: approvalVOList) {
            if(!approvalVOListMap.containsKey(approvalVO.getRouteState())) approvalVOListMap.put(approvalVO.getRouteState(), new ArrayList<ApprovalVO>());
            approvalVOListMap.get(approvalVO.getRouteState()).add(approvalVO);
        }
        return approvalVOListMap;
    }
    public static Map<String, Object> splitApprovalVOByRecodeMode(List<ApprovalVO> approvalVOList) {

        Map<String, Object> approvalVOMapByRecodeMode = new HashMap<String, Object>();
        if(NullUtil.isNone(approvalVOList)) return approvalVOMapByRecodeMode;

        List<ApprovalVO> approvalVOListForCreate = new ArrayList<ApprovalVO>();
        List<ApprovalVO> approvalVOListForUpdate = new ArrayList<ApprovalVO>();
        List<ApprovalVO> approvalVOListForDelete = new ArrayList<ApprovalVO>();

        for(ApprovalVO approvalVO: approvalVOList) {
            if(GlobalConstants.CREATE_RECORD_MODE.equals(approvalVO.getRecordMode())) {
                approvalVOListForCreate.add(approvalVO);
            }else if(GlobalConstants.UPDATE_RECORD_MODE.equals(approvalVO.getRecordMode())) {
                approvalVOListForUpdate.add(approvalVO);
            }else if(GlobalConstants.DELETE_RECORD_MODE.equals(approvalVO.getRecordMode())) {
                if(!StringUtils.isEmpty(approvalVO.getStepNodeUserObid()))
                    approvalVOListForDelete.add(approvalVO);
            }
        }
        approvalVOMapByRecodeMode.put(GlobalConstants.CREATE_RECORD_MODE, approvalVOListForCreate);
        approvalVOMapByRecodeMode.put(GlobalConstants.UPDATE_RECORD_MODE, approvalVOListForUpdate);
        approvalVOMapByRecodeMode.put(GlobalConstants.DELETE_RECORD_MODE, approvalVOListForDelete);
        return approvalVOMapByRecodeMode;
    }
    public static void createDeleteApprovalInfoToEP(WorkflowHeaderVO targetVO, WorkflowRouteVO wfRouteVO,
                                              WorkflowInboxTaskVO wfInboxTaskVO) {
        EPApprovalVO epApprovalVO = new EPApprovalVO();
        epApprovalVO.setCommand("ARD");//system_id,system_pk에 해당하는 결재 정보를 모두 지운다.
        epApprovalVO.setSystemPk(wfInboxTaskVO.getObid());
        epApprovalVO.setTaskId(wfRouteVO.getObid());
        SchemaDaoUtil.insert("WORKFLOW.insertARDEPApprovalInfo", epApprovalVO);
    }
    public static void txnCreateMailSendInfo(MailSendVO mailSendVO) {
//        IfPlmDataByTriggerVO dataVO = new IfPlmDataByTriggerVO();
//
//        // Default Value Setting
//        dataVO.setObjectRevision( "-" );
//        dataVO.setTargetSystem( WorkflowConstants.INF_TARGET_SYSTEM_MAIL_SEND );
//        dataVO.setInterfaceId( WorkflowConstants.INF_TARGET_SYSTEM_MAIL_SEND_MAIL001 );

        // Target Value Setting
//        dataVO.setObjectId( mailSendVO.getObid() );
//        dataVO.setObjectType( mailSendVO.getClassName() );
//        dataVO.setObjectName( mailSendVO.getNames() );
//        dataVO.setUserId( mailSendVO.getFromUserId() );
//        dataVO.setCurrentStatus( mailSendVO.getCurrentStatus() );
//
//        StringBuffer sendTypeUserInfo = new StringBuffer();
//        sendTypeUserInfo.append( mailSendVO.getSendType() + ":" );
//        List<String> toUserIdList = mailSendVO.getToUserIdList();
//        if( toUserIdList != null && toUserIdList.size() > 0 ){
//            for( int inx = 0; inx < toUserIdList.size(); inx++ ){
//                sendTypeUserInfo.append( toUserIdList.get(inx) );
//                if( inx < toUserIdList.size() - 1 ){
//                    sendTypeUserInfo.append( "," );
//                }
//            }
//        }
//        dataVO.setAttribute1( sendTypeUserInfo.toString() );
//        CommonDaoUtil.insert("Integration.insertDataByTrigger", dataVO);
    }
    public static void createReassignApprovalInfoToEP(BusinessObjectRootVO targetObjVO, WorkflowRouteVO routeVO,
                                               WorkflowInboxTaskVO fromInboxTaskVO, WorkflowInboxTaskVO toInboxTaskVO) {
        if(!validateApprovalInfoToEP(targetObjVO, routeVO) && !toInboxTaskVO.getInboxTaskType().equals(WorkflowConstants.INBOXTASK_TYPE_WBSACTIVITY)) return;

        EPApprovalVO epApprovalVO = new EPApprovalVO();
        epApprovalVO.setCommand("ARD"); //system_id,system_pk에 해당하는 결재 정보를 모두 지운다.
        epApprovalVO.setSystemPk(fromInboxTaskVO.getObid());
        epApprovalVO.setTaskId(routeVO.getObid());
        SchemaDaoUtil.insert("WORKFLOW.insertARDEPApprovalInfo", epApprovalVO);

        createApprovalInfoToEP(targetObjVO, routeVO, toInboxTaskVO);
    }
    public static void createReassignApprovalInfoToEP(BusinessObjectRootVO targetObjVO, WorkflowRouteVO routeVO,
                                                WorkflowInboxTaskVO fromWorkflowInboxTaskVO, WorkflowStepNodeUserVO toWorkflowStepNodeUserVO) {
        if(!validateApprovalInfoToEP(targetObjVO, routeVO) && !fromWorkflowInboxTaskVO.getInboxTaskType().equals(WorkflowConstants.INBOXTASK_TYPE_WBSACTIVITY)) return;

        EPApprovalVO epApprovalVO = new EPApprovalVO();
        epApprovalVO.setCommand("ARD"); //system_id,system_pk에 해당하는 결재 정보를 모두 지운다.
        epApprovalVO.setSystemPk(fromWorkflowInboxTaskVO.getObid());
        epApprovalVO.setTaskId(routeVO.getObid());
        SchemaDaoUtil.insert("WORKFLOW.insertARDEPApprovalInfo", epApprovalVO);

        WorkflowRoute routeObj = DomUtil.toDom(routeVO);
        WorkflowInboxTaskVO toWorkflowInboxTaskVO = routeObj.getInboxTask(toWorkflowStepNodeUserVO);
        createApprovalInfoToEP(targetObjVO, routeVO, toWorkflowInboxTaskVO);
    }
    public static void copyAttribute(WorkflowHeaderVO headerVO, WorkflowRouteVO routeVO, WorkflowStepVO stepVO, WorkflowStepNodeUserVO stepNodeUserVO, WorkflowInboxTaskVO inboxTaskVO){
        inboxTaskVO.setStepSequences(stepNodeUserVO.getStepSequences());
        inboxTaskVO.setStepNodeUserSequences(stepNodeUserVO.getStepNodeUserSequences());
        inboxTaskVO.setRouteNodeObid(stepNodeUserVO.getRouteNodeObid());
        inboxTaskVO.setStepNodeUserObid(stepNodeUserVO.getStepNodeUserObid());
        inboxTaskVO.setStepNodeObid(stepNodeUserVO.getStepNodeObid());

        inboxTaskVO.setRouteAction(stepNodeUserVO.getRouteAction());
        inboxTaskVO.setRouteInstructions(stepNodeUserVO.getRouteInstructions());
        inboxTaskVO.setResponsibility(stepNodeUserVO.getResponsibility());
        inboxTaskVO.setTaskRequirement(stepNodeUserVO.getTaskRequirement());
        inboxTaskVO.setReviewTask(stepNodeUserVO.getReviewTask());
        inboxTaskVO.setReviewersComments(stepNodeUserVO.getReviewersComments());
        inboxTaskVO.setReviewCommentsNeeded(stepNodeUserVO.getReviewCommentsNeeded());
        inboxTaskVO.setDueDateOffset(stepNodeUserVO.getDueDateOffset());
        inboxTaskVO.setDateOffsetFrom(stepNodeUserVO.getDateOffsetFrom());
        inboxTaskVO.setAssigneeSetDueDate(stepNodeUserVO.getAssigneeSetDueDate());
        inboxTaskVO.setAllowDelegation(stepNodeUserVO.getAllowDelegation());
        inboxTaskVO.setIsEssential(stepNodeUserVO.getIsEssential());
        inboxTaskVO.setParallelNodeProcessionRule(stepNodeUserVO.getParallelNodeProcessionRule());
        inboxTaskVO.setActionComments(stepNodeUserVO.getActionComments());
        inboxTaskVO.setNotifyEmail(stepNodeUserVO.getNotifyEmail());

        inboxTaskVO.setApprovalStatus(WorkflowConstants.APPROVAL_STATUS_NONE);
        inboxTaskVO.setStates(WorkflowConstants.STATES_TYPE_ASSIGNED);//Assigned,Review,Complete
        inboxTaskVO.setRevision("1");
        inboxTaskVO.setNames(NameGeneratorUtil.generateUniqueName(IdGeneratorConstants.ID_GENERATOR_WORKFLOW_IN_BOX_NAME));

        inboxTaskVO.setProcessTimestamp(routeVO.getProcessTimestamp());
        inboxTaskVO.setTitles(headerVO.getTitles());
        inboxTaskVO.setDescriptions(routeVO.getDescriptions()+"_"+stepVO.getTitles());


        if(WorkflowConstants.WBS_DATE_OFFSET_FROM.equals(stepNodeUserVO.getDateOffsetFrom())
                && stepNodeUserVO.getDueDateOffset() > 0) {
            Calendar c = Calendar.getInstance();
            c.setTime(TimeServiceUtil.getDBLocalTime());
            c.add(Calendar.DATE, stepNodeUserVO.getDueDateOffset());
            inboxTaskVO.setScheduledCompletionDate(c.getTime());
        }
    }
}