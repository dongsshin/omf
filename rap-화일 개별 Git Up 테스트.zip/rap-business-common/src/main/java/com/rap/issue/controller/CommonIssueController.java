package com.rap.issue.controller;

import com.rap.api.object.issues.model.IssuesVO;
import com.rap.issue.model.CParmInitIssueVO;
import com.rap.issue.model.CParmIssueVO;
import com.rap.issue.service.IssueService;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import javax.annotation.Resource;

@RestController
public class CommonIssueController extends RestBaseController {
    private static final Logger log = LoggerFactory.getLogger(CommonIssueController.class);
    @Autowired
    private UserSession userSession;

    @Resource(name = "issueService")
    private IssueService issueService;

    @RequestMapping( value= "/common/issue/header",method= {RequestMethod.POST},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> createIssue(@RequestBody CParmInitIssueVO cParmIssueVO) {
        try{
            IssuesVO issuesVO = issueService.txnCreateIssues(cParmIssueVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,issuesVO),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value= "/common/issue/header",method= {RequestMethod.PUT},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> modifyIssue(@RequestBody IssuesVO issuesVO) {
        try{
            issuesVO = issueService.txnModifyIssues(issuesVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,issuesVO),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value= "/common/issue/header",method= {RequestMethod.DELETE},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> deleteIssue(@RequestBody IssuesVO issuesVO) {
        try{
            issueService.txnDeleteIssue(issuesVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,issuesVO),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value= "/common/issue/header/items",method= {RequestMethod.POST},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> addIssueItems(@RequestBody CParmInitIssueVO cParmIssueVO) {
        try{
            issueService.txnAddIssueItems(cParmIssueVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,true),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
    @RequestMapping( value= "/common/issue/header/items",method= {RequestMethod.DELETE},produces = "application/json; charset=utf-8" )
    public ResponseEntity<?> removeIssueItems(@RequestBody CParmIssueVO cParmIssueVO) {
        try{
            issueService.txnRemoveIssueItems(cParmIssueVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,true),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in initiating Workflow!",e);
        }
    }
}
