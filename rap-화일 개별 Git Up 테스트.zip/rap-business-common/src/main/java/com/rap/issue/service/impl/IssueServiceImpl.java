/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : WorkflowServiceImpl.java1
 * ===========================================
 * Modify Date    Modifier    Description
 * -------------------------------------------
 * 2015. 2. 12.  kwanghyui.choi   Initial
 * */
package com.rap.issue.service.impl;

import com.rap.api.object.issues.dom.IssueItems;
import com.rap.api.object.issues.dom.Issues;
import com.rap.api.object.issues.model.IssueItemsVO;
import com.rap.api.object.issues.model.IssuesVO;
import com.rap.common.code.service.CodeService;
import com.rap.issue.model.CParmInitIssueVO;
import com.rap.issue.model.CParmIssueVO;
import com.rap.issue.service.IssueService;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.foundation.classes.service.TimeService;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.util.NullUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;


@Service("issueService")
public class IssueServiceImpl implements IssueService {

    @Resource(name = "timeService")
    private TimeService timeService;

    @Resource(name = "codeService")
    private CodeService codeService;

    @Autowired
    UserSession userSession;

    /*****************************************************************************************************************************************************/
    /*                             txnCreateIssues                                                                                                       */
    /*****************************************************************************************************************************************************/
    @Override
    public IssuesVO txnCreateIssues(CParmInitIssueVO cParmIssueVO) {
        IssuesVO issuesVO = cParmIssueVO.getIssuesVO();
        cParmIssueVO.getIssueItems();
        Issues issuesObj = DomUtil.toDom(issuesVO);
        if(!NullUtil.isNone(cParmIssueVO.getIssueItems())) issuesObj.attacheIssueItem(cParmIssueVO.getIssueItems());
        return issuesObj.getVo();
    }
    /*****************************************************************************************************************************************************/
    /*                             txnModifyIssues                                                                                                       */
    /*****************************************************************************************************************************************************/
    @Override
    public IssuesVO txnModifyIssues(IssuesVO issuesVO) {
        Issues issuesObj = DomUtil.toDom(issuesVO);
        issuesObj.modifyObject();
        return issuesObj.getVo();
    }
    /*****************************************************************************************************************************************************/
    /*                             txnDeleteIssue                                                                                                        */
    /*****************************************************************************************************************************************************/
    @Override
    public void txnDeleteIssue(IssuesVO issuesVO) {
        Issues issuesObj = DomUtil.toDom(issuesVO);
        issuesObj.deleteObject();
    }
    @Override
    public void txnAddIssueItems(CParmInitIssueVO cParmIssueVO) {
        Issues issuesObj = DomUtil.toDom(cParmIssueVO.getIssuesVO());
        if(!NullUtil.isNone(cParmIssueVO.getIssueItems())) issuesObj.attacheIssueItem(cParmIssueVO.getIssueItems());
    }
    @Override
    public void txnRemoveIssueItems(CParmIssueVO cParmIssueVO) {
        if(!NullUtil.isNone(cParmIssueVO.getIssueItemsVOList())) {
            for(IssueItemsVO vo : cParmIssueVO.getIssueItemsVOList()){
                IssueItems itemsObj = DomUtil.toDom(vo);
                itemsObj.deleteObject();
            }
        }
    }
}
    
