package com.rap.issue.model;

import com.rap.api.object.foundation.model.BusinessObjectRootVO;
import com.rap.api.object.foundation.model.CPamBaseModel;
import com.rap.api.object.issues.model.IssuesVO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class CParmInitIssueVO extends CPamBaseModel {
    private IssuesVO issuesVO;
    List<BusinessObjectRootVO> issueItems;
}
