package com.rap.issue.model;

import com.rap.api.object.foundation.model.CPamBaseModel;
import com.rap.api.object.issues.model.IssueItemsVO;
import com.rap.api.object.issues.model.IssuesVO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class CParmIssueVO extends CPamBaseModel {
    private IssuesVO issuesVO;
    List<IssueItemsVO> issueItemsVOList;
}
