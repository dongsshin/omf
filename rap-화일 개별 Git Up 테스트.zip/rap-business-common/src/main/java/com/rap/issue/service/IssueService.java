package com.rap.issue.service;

import com.rap.api.object.issues.model.IssuesVO;
import com.rap.issue.model.CParmInitIssueVO;
import com.rap.issue.model.CParmIssueVO;

public interface IssueService {
    IssuesVO txnCreateIssues(CParmInitIssueVO cParmInitIssueVO);
    IssuesVO txnModifyIssues(IssuesVO issuesVO);
    void txnDeleteIssue(IssuesVO issuesVO);
    void txnAddIssueItems(CParmInitIssueVO cParmInitIssueVO);
    void txnRemoveIssueItems(CParmIssueVO cParmIssueVO);
}
