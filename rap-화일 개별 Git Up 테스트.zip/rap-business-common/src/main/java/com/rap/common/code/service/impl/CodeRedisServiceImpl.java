package com.rap.common.code.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.rap.api.object.common.code.dom.CodeMaster;
import com.rap.api.object.common.code.model.CodeDetailVO;
import com.rap.api.object.common.code.model.CodeMasterVO;
import com.rap.api.object.common.organization.model.AbstractOrganizationsVO;
import com.rap.api.object.common.organization.model.BusinessUnitVO;
import com.rap.api.object.common.organization.model.CompanyVO;
import com.rap.api.object.common.organization.model.DivisionUnitVO;
import com.rap.common.code.service.CodeRedisService;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.organization.service.OrganizationService;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.foundation.model.RedisCodeDetailVO;
import com.rap.omc.foundation.model.RedisCodeMasterVO;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.RedisUtil;
import com.rap.omc.util.biz.BizCommonUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("codeRedisService")

public class CodeRedisServiceImpl implements CodeRedisService {
    @Autowired
    private OrganizationService organizationService;

    @Override
    public void load2RedisCodeMasterAll() {
        List<RedisCodeMasterVO> loadList = getCodeMasterAll();
        String key = "";
        for(RedisCodeMasterVO vo : loadList){
            key = BizCommonUtil.getCodeMasterEachKey(vo.getNames());
            RedisUtil.set(key,vo);
        }
        RedisUtil.set(BizCommonUtil.getMasterAllKey(),loadList);
    }
    private List<RedisCodeMasterVO> getCodeMasterAll() {
        List<CodeMasterVO> list = BusinessObjectMaster.findObjects(AppSchemaCommonConstants.BIZCLASS_CODEMASTER,"");
        List<RedisCodeMasterVO> loadList = new ArrayList<RedisCodeMasterVO>();
        for(CodeMasterVO vo : list){
            RedisCodeMasterVO redisVO = new RedisCodeMasterVO();
            redisVO.setTitles(vo.getTitles());
            redisVO.setUseCache(vo.getUseCache());
            redisVO.setNames(vo.getNames());
            loadList.add(redisVO);
        }
        return loadList;
    }
    @Override
    public void load2RedisCodeDetailsAll() {
        List<RedisCodeMasterVO> loadList = getCodeMasterAll();
        for(RedisCodeMasterVO vo : loadList){
            load2RedisCodeDetails(vo.getNames());
        }
    }
    @Override
    public void load2RedisCodeDetails(String codeMasterNames) {
        List<CodeDetailVO> list = CodeMaster.getCodeDetailList(codeMasterNames);
        List<RedisCodeDetailVO> loadList = new ArrayList<RedisCodeDetailVO>();
        String key = BizCommonUtil.getCodeListKey(codeMasterNames);
        for(CodeDetailVO vo : list){
            RedisCodeDetailVO redisVO = new RedisCodeDetailVO();
            redisVO.setMasterCode(codeMasterNames);
            redisVO.setCode(vo.getRevision());
            redisVO.setDisplayName(vo.getTitles());
            redisVO.setDisplayNameKr(vo.getDisplayNameKr());
            redisVO.setIsDefault(vo.getIsDefault());
            redisVO.setSequences(vo.getSequences());
            redisVO.setStates(vo.getStates());
            redisVO.setSubCodeMaster(vo.getSubCodeMaster());
            redisVO.setUsingOrganizationList(vo.getUsingOrganizationList());
            redisVO.setAttribute01(vo.getAttribute01());
            redisVO.setAttribute02(vo.getAttribute02());
            redisVO.setAttribute03(vo.getAttribute03());
            redisVO.setAttribute04(vo.getAttribute04());
            redisVO.setAttribute05(vo.getAttribute05());
            loadList.add(redisVO);
            String codeKey = BizCommonUtil.getCodeKey(redisVO.getMasterCode(),redisVO.getCode());
            RedisUtil.set(codeKey,redisVO);
        }
        RedisUtil.set(key,loadList);
    }
    @Override
    public void load2RedisOrganizations() {
        ObjectMapper mapper = new ObjectMapper();
        List<CompanyVO> companyList = organizationService.getOrganizationListAll(AppSchemaCommonConstants.BIZCLASS_COMPANY,false);
        int seq = 1;
        for(CompanyVO vo : companyList){
            load2RedisOrganizationsSub(vo);
            RedisCodeDetailVO redisVO = makeRedisCode(vo,seq++,null,mapper);
            String eachKey = BizCommonUtil.getCodeKey(GlobalConstants.REDIS_KEY_ORG_EACH,vo.getNames());
            RedisUtil.set(eachKey,redisVO);
        }
        List<BusinessUnitVO> businessUnitList = organizationService.getOrganizationListAll(AppSchemaCommonConstants.BIZCLASS_BUSINESSUNIT,false);
        for(BusinessUnitVO vo : businessUnitList){
            load2RedisOrganizationsSub(vo);
        }
        List<DivisionUnitVO> businessDivisionList = organizationService.getOrganizationListAll(AppSchemaCommonConstants.BIZCLASS_DIVISIONUNIT,false);
        for(DivisionUnitVO vo : businessDivisionList){
            load2RedisOrganizationsSub(vo);
        }
    }
    @Override
    public void load2RedisOrganizations(String organizationCode) {
        AbstractOrganizationsVO orgVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_ABSTRACTORGANIZATIONS,organizationCode);
        load2RedisOrganizationsSub(orgVO);
    }
    private void load2RedisOrganizationsSub(AbstractOrganizationsVO vo) {
        ObjectMapper mapper = new ObjectMapper();
        String jsonStr = "";

        String key = BizCommonUtil.getOrgListKey(vo.getClassName(),vo.getNames());
        int seq = 1;
        List<AbstractOrganizationsVO> orgList =  organizationService.getExplodedOrganizationList(vo.getNames(),1,false,false);
        List<RedisCodeDetailVO> loadList = new ArrayList<RedisCodeDetailVO>();
        for(AbstractOrganizationsVO orgVO : orgList){
            RedisCodeDetailVO redisVO = makeRedisCode(orgVO,seq++,vo,mapper);
            loadList.add(redisVO);

            RedisCodeDetailVO copiedVO = (RedisCodeDetailVO)DomUtil.cloneBean(redisVO);
            copiedVO.setMasterCode(vo.getNames());
            String eachKey = BizCommonUtil.getCodeKey(GlobalConstants.REDIS_KEY_ORG_EACH,orgVO.getNames());
            RedisUtil.set(eachKey,copiedVO);
        }
        RedisUtil.set(key,loadList);
    }
    private RedisCodeDetailVO makeRedisCode(AbstractOrganizationsVO orgVO, int seq, AbstractOrganizationsVO upperVO, ObjectMapper mapper){
        RedisCodeDetailVO redisVO = new RedisCodeDetailVO();

        redisVO.setCode(orgVO.getNames());
        redisVO.setDisplayName(orgVO.getTitles());
        redisVO.setDisplayNameKr(orgVO.getDescriptions());
        redisVO.setIsDefault(false);
        redisVO.setSequences(seq);
        redisVO.setStates(orgVO.getStates());
        if(!NullUtil.isNull(upperVO)){
            redisVO.setMasterCode(upperVO.getNames());
            redisVO.setAttribute01(upperVO.getClassName() + "@" + upperVO.getNames());
        }else{
            redisVO.setMasterCode("");
            redisVO.setAttribute01("");
        }
        redisVO.setAttribute02(orgVO.getClassName());
        orgVO.setOutData(null);
        String jsonStr = "";
        try {
            jsonStr = mapper.writeValueAsString(orgVO);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            jsonStr = "";
        }
        redisVO.setAttribute05(jsonStr);
        return redisVO;
    }
    private List<CodeDetailVO> makeCodeDetail(List<? extends AbstractOrganizationsVO> list){
        List<CodeDetailVO> result = new ArrayList<CodeDetailVO>();
        for (AbstractOrganizationsVO orgVO : list){
            CodeDetailVO detailVO = new CodeDetailVO();
            detailVO.setClassName(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL);
            detailVO.setStates(orgVO.getStates());
            DomUtil.copyAttributeAll(orgVO,detailVO);
            detailVO.setClassName(orgVO.getClassName());
            result.add(detailVO);
        }
        return result;
    }

}