package com.rap.common.code.service;

public interface CodeRedisService {
    public void load2RedisCodeMasterAll();
    public void load2RedisCodeDetailsAll();
    public void load2RedisCodeDetails(String codeMasterNames);
    public void load2RedisOrganizations();
    public void load2RedisOrganizations(String organizationCode);
}