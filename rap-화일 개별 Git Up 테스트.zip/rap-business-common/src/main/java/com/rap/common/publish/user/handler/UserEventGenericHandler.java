package com.rap.common.publish.user.handler;


import com.rap.omc.framework.publish.GenericEventHandler;

public class UserEventGenericHandler extends GenericEventHandler {
    public UserEventGenericHandler(String serviceName) {
        super(serviceName, "/mybatis/mapper/foundation/user/eventsynch");
    }
}