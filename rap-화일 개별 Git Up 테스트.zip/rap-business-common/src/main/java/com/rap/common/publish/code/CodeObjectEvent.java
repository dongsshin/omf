package com.rap.common.publish.code;

import com.event.publish.vo.EventCodeVO;
import com.rap.omc.framework.publish.GenericEvent;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpMethod;

@Setter
@Getter
public class CodeObjectEvent extends GenericEvent {
    public CodeObjectEvent(Object source, EventCodeVO eventCodeVO) {
        super(source,eventCodeVO, HttpMethod.POST);
    }
}