package com.rap.common.util;

public class CommonMessageConstants {
    public static final String ERR_MES_CODE_MSTR_CREATE = "common.error.code.master.create.general";
    //Error occurred On Creating {0}.
}
