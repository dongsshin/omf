package com.rap.common.user;

import com.rap.omc.schema.util.OmcUniqueIDGenerator;

public class UsersConstants {
    public static final String MAP_KEY_ROLE = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_GROUP = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_PROPERTY = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_ORGANIZATION = OmcUniqueIDGenerator.getObid();

    public static final String MAP_KEY_company = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_businessUnit = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_divisionUnit = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_plantUnit = OmcUniqueIDGenerator.getObid();
    public static final String MAP_KEY_sessionMap = "session";
}
