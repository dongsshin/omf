package com.rap.common.organization.controller;

import com.rap.api.object.common.organization.dom.Company;
import com.rap.api.object.common.organization.model.*;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.organization.service.OrganizationService;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.responsive.ResponseAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CommonOrganizationController extends RestBaseController {

	@Autowired
	private OrganizationService organizationService ;

    /*********************************************************************************************/
    /************************************** Company***********************************************/
    /*********************************************************************************************/
    //Create
    @RequestMapping(path = "/company", method= RequestMethod.POST, produces = "application/json; charset=utf-8")
    public CompanyVO createCompany(@RequestBody CompanyVO companyVO){
        return organizationService.txnCreateCompany(companyVO);
    }
    //Modify
    @RequestMapping(path = "/company", method= RequestMethod.PUT, produces = "application/json; charset=utf-8")
    public ResponseEntity<?> modifyCompany(@RequestBody CompanyVO companyVO){
        try{
            Company companyDom = new Company(companyVO);
            companyDom.modifyObject();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,companyDom.getVo()), HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on creating Company!",e);
        }
    }
    //Delete
    @RequestMapping(value = "/company",method=RequestMethod.DELETE)

    public ResponseEntity<?> deleteCompany(@RequestBody CompanyVO companyVO){
        try{
            Company companyDom = DomUtil.toDom(companyVO.getObid());
            companyDom.deleteObject();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,companyDom.getVo()), HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on deleting Company!",e);
        }
    }
    //Find
    @RequestMapping(value = "/company/{names}",method=RequestMethod.GET)
    public @ResponseBody ResponseEntity<?> findCompany(@PathVariable("names") String names){
        try{
            CompanyVO companyVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_COMPANY,names);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,companyVO), HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on getting Company!",e);
        }
    }
    //Search
    @RequestMapping(value = "/companies/{names}",method=RequestMethod.GET)
    public ResponseEntity<?> findCompanies(@PathVariable("names") String names){
        try{
            List<CompanyVO> companyVOList = BusinessObjectMaster.findObjects(AppSchemaCommonConstants.BIZCLASS_COMPANY,names);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,companyVOList), HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on finding Company!",e);
        }
    }
    //Search All
    @RequestMapping(value = "/companies",method=RequestMethod.GET)
    public ResponseEntity<?> findCompanyAll(){
        try{
            List<CompanyVO> companyVOList = BusinessObjectMaster.findObjects(AppSchemaCommonConstants.BIZCLASS_COMPANY,"*");
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,companyVOList), HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on getting all Company!",e);
        }
    }
    /*********************************************************************************************/
    /************************************** PlantUnit*********************************************/
    /*********************************************************************************************/
    @RequestMapping(path = "/plantunit", method= RequestMethod.POST, produces = "application/json; charset=utf-8")
    public ResponseEntity<?> plantUnit(@RequestBody PlantUnitVO plantUnitVO){
        try{
            AbstractOrganizationsVO orgVO = organizationService.txnCreatePlantUnit(plantUnitVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,orgVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on create PantUnity!",e);
        }
    }
    @RequestMapping(path = "/businessunit", method= RequestMethod.POST, produces = "application/json; charset=utf-8")
    public ResponseEntity<?> company(@RequestBody BusinessUnitVO businessUnitVO){
        try{
            AbstractOrganizationsVO orgVO = organizationService.txnCreateBusinessUnit(businessUnitVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,orgVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on create BusinessUnit!",e);
        }
    }
    @RequestMapping(path = "/division", method= RequestMethod.POST, produces = "application/json; charset=utf-8")
    public ResponseEntity<?> company(@RequestBody DivisionUnitVO divisionUnitVO){
        try{
            AbstractOrganizationsVO orgVO = organizationService.txnCreateDivisionUnit(divisionUnitVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,orgVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on create BusinessUnit!",e);
        }
    }
    @RequestMapping(path = "/orgstructure/{orgName}", method= RequestMethod.GET, produces = "application/json; charset=utf-8")
    public ResponseEntity<?>  explodeOrganizationExplode(@PathVariable("orgName") String orgName){
        try{
            List<AbstractOrganizationsVO> list = organizationService.getExplodedOrganizationList(orgName,5, false,true);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,list), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred on exploding Organization!",e);
        }
    }
}