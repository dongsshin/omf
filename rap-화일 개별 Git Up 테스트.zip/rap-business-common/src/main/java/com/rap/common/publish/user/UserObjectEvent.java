package com.rap.common.publish.user;

import com.event.publish.vo.EventUserVO;
import com.rap.omc.framework.publish.GenericEvent;
import lombok.Getter;
import lombok.Setter;
import org.springframework.http.HttpMethod;

@Setter
@Getter
public class UserObjectEvent extends GenericEvent {
    public UserObjectEvent(Object source, EventUserVO eventUserVO) {
        super(source,eventUserVO, HttpMethod.POST);
    }
}