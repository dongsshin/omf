package com.rap.common.code.service.impl;

import com.rap.api.object.common.code.dom.CodeDetail;
import com.rap.api.object.common.code.dom.CodeMaster;
import com.rap.api.object.common.code.model.CodeDetailVO;
import com.rap.api.object.common.code.model.CodeMasterVO;
import com.rap.api.object.common.organization.model.*;
import com.rap.api.object.foundation.dom.BusinessObject;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.common.code.service.CodeService;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.constants.BizCommonCodeConstants;
import com.rap.common.organization.service.OrganizationService;
import com.rap.omc.controller.model.CParmSyncCodeSetVO;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.omc.CacheUtil;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.classes.model.ClassInfo;
import com.rap.omc.foundation.classes.model.ClassNameForDisplayVO;
import com.rap.omc.foundation.lifecycle.model.StateInfo;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import com.rap.omc.util.foundation.ClassInfoUtil;
import com.rap.omc.util.foundation.LifeCycleUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;

@Service("codeService")

public class CodeServiceImpl implements CodeService {
    @Autowired
    private UserSession userSession;

    @Autowired
    private OrganizationService organizationService;

    /****************************************Code Master*****************************************/
    @Override
    public CodeMasterVO txnCreateCodeMaster(CodeMasterVO codeMasterVO) {

        codeMasterVO.setClassName(AppSchemaCommonConstants.BIZCLASS_CODEMASTER);
        codeMasterVO.setLifeCycle(AppSchemaCommonConstants.LIFECYCLE_CODE_MASTER);
        codeMasterVO.setStates(AppSchemaCommonConstants.STATE_WITHOUT_STATE_EXISTS);

        CodeMaster inputDom = (CodeMaster)DomUtil.toDom(codeMasterVO);
        inputDom.createObject();
        return inputDom.getVo();
    }
    @Override
    public CodeMasterVO txnDeleteCodeMaster(CodeMasterVO codeMasterVO) {
        CodeMaster objDom = new CodeMaster( codeMasterVO.getObid() );
        objDom.deleteObject();
        return objDom.getVo();
    }
    @Override
    public CodeMasterVO txnModifyCodeMaster(CodeMasterVO codeMasterVO) {
        CodeMaster objDom = new CodeMaster( codeMasterVO.getObid() );
        objDom.modifyObject();
        CacheUtil.evictCache("commonCodeMasterCache", codeMasterVO.getNames());
        return objDom.getVo();
    }
    @Override
    public CodeMasterVO getCodeMaster(String names) {
        return CodeMaster.findCodeMaster(names);
    }
    @Override
    public CodeMasterVO getCodeMasterWithObid(String codeMasterObid) {
        CodeMaster masterObj = new CodeMaster(codeMasterObid);
        return masterObj.getVo();
    }
    @Override
    public List<CodeMasterVO> getCodeMasterList(CodeMasterVO codeMasterVO, PagingEntity pagingEntity) {
        return CodeMaster.getCodeMasterList(codeMasterVO.getNames(),codeMasterVO, pagingEntity);
    }
    /****************************************Code Detail*****************************************/
    @Override
    public CodeDetailVO txnCreateCodeDetail(String masterCode, CodeDetailVO codeDetailVO,List<String> orgList) {

        if(StrUtil.isEmpty(masterCode)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Code Master's name is empty.");
        CodeMasterVO masterVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_CODEMASTER,masterCode);
        if(NullUtil.isNull(masterVO)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Code Master(" + masterCode +") is not found.");
        if(NullUtil.isNone(orgList)) throw new OmfApplicationException(HttpStatus.INTERNAL_SERVER_ERROR,"Applied Organization list is empty.");

        HashMap<String, Object> parmMap = new HashMap<String, Object>();

        parmMap.put(BizCommonCodeConstants.MAP_KEY_CODEMASTER,masterVO);
        parmMap.put(BizCommonCodeConstants.MAP_KEY_ORGLIST_STR,orgList);
        CodeDetail codeDetailDom = (CodeDetail)DomUtil.toDom(codeDetailVO);
        codeDetailDom.createObject(parmMap);
        codeDetailDom = new CodeDetail(codeDetailDom.getObid(),true);
        return codeDetailDom.getVo();
    }
    @Override
    public CodeDetailVO txnDeleteCodeDetail(CodeDetailVO codeDetailVO) {
        CodeDetail objDom = new CodeDetail( codeDetailVO.getObid() );
        objDom.deleteObject();
        return objDom.getVo();
    }
    @Override
    public CodeDetailVO txnModifyCodeDetail(CodeDetailVO codeDetailVO, List<String> orgList) {
        CodeDetail objDom = new CodeDetail( codeDetailVO.getObid() );
        objDom.modifyObject();
        CacheUtil.evictCache("commonCodeMasterCache", codeDetailVO.getNames());
        return objDom.getVo();
    }
    @Override
    public void txnCreateModifyDeleteCodeDetailList(List<CodeDetailVO> codeDetailVOList) {
        for(CodeDetailVO vo : codeDetailVOList){
            List<String> orgList = new ArrayList<String>();
            if(!StrUtil.isEmpty(vo.getRecordMode())){
                orgList = vo.getOutDataAttributeValue("orgList");
                switch (vo.getRecordMode()){
                    case "C":
                        this.txnCreateCodeDetail(vo.getNames(),vo,orgList);
                        break;
                    case "U":
                        this.txnModifyCodeDetail(vo,orgList);
                        break;
                    case "D":
                        this.txnDeleteCodeDetail(vo);
                        break;
                    default:
                        break;
                }
            }
        }
    }
    @Override
    public CodeDetailVO txnActivateCodeDetail(String obid) {
        CodeDetail objDom = DomUtil.toDom(obid);
        objDom.changeStates(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);
        return objDom.getVo();
    }
    @Override
    public CodeDetailVO txnInActivateCodeDetail(String obid) {
        CodeDetail objDom = DomUtil.toDom(obid);
        objDom.changeStates(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_INACTIVE);
        return objDom.getVo();
    }

    @Override
    public CodeDetailVO getCodeDetail(String obid) {
        return (CodeDetailVO)DomUtil.toDom(obid,true).getVo();
    }

    @Override
    public CodeDetailVO getCodeDetail(String codeMasterNames, String code) {
        return BusinessObject.findBusinessObject(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL,codeMasterNames,code);
    }

    @Override
    public List<CodeDetailVO> getCodeDetailListAll(String codeMasterNames){
        return CodeMaster.getCodeDetailList(codeMasterNames);
    }

    @Override
    public List<CodeDetailVO> getCodeDetailListByScope(String masterCode, String codeScope) {
        CodeDetailVO searchVO = new CodeDetailVO();
        searchVO.setNames(masterCode);
        searchVO.setUsingOrganizationList(codeScope);
        return CodeMaster.getCodeListByScope(searchVO,null);
    }

    @Override
    public List<CodeDetailVO> getCodeDetailListByScope(CodeDetailVO searchVO, PagingEntity pagingEntity){
        return CodeMaster.getCodeListByScope(searchVO,pagingEntity);
    }
    @Override
    public List<CodeDetailVO> getCodeDetailListByCodeSet(String masterCode, Set<String> codeSet) {
        return CodeMaster.getCodeDetailListWithCodeSet(masterCode, codeSet);
    }

    /****************************************Attribute Range List *****************************************/
    @Override
    public List<CodeDetailVO> getAttributeRangeList(String classAttribute, boolean sort) {
        String[] strArray = classAttribute.split(Pattern.quote("."));
        List<String> strList = ClassInfoUtil.getRanges(strArray[0], strArray[1], sort);
        List<CodeDetailVO> result = new ArrayList<CodeDetailVO>();
        for(String str : strList){
            CodeDetailVO vo = new CodeDetailVO();
            vo.setNames(classAttribute + "_" + "valueList");
            vo.setRevision(str);
            vo.setDescriptions(str);
            vo.setTitles(str);
            result.add(vo);
        }
        return result;
    }
    /****************************************Class List *****************************************/
    @Override
    public List<CodeDetailVO> getClassNameList(String className, boolean orderByDesc) {
        List<ClassNameForDisplayVO> classList = ClassInfoUtil.getChildClassListForCombo(className);
        List<CodeDetailVO> result = new ArrayList<CodeDetailVO>();
        for(ClassNameForDisplayVO classVO : classList){
            CodeDetailVO vo = new CodeDetailVO();
            vo.setNames(className + "_" + "className");
            vo.setRevision(classVO.getCalssName());
            vo.setDescriptions(classVO.getDisplayedName());
            vo.setTitles(classVO.getDisplayedName());
            result.add(vo);
        }
        return result;
    }
    /****************************************Life Cycle State List *****************************************/
    @Override
    public List<CodeDetailVO> getLifeCycleStatesList(String lifeCycle) {
        List<StateInfo> stateInfoList = LifeCycleUtil.getLifieCycleStateListByName(lifeCycle);
        List<CodeDetailVO> result = new ArrayList<CodeDetailVO>();
        for (StateInfo statInfo : stateInfoList){
            CodeDetailVO vo = new CodeDetailVO();
            vo.setNames(lifeCycle + "_" + "State");
            vo.setRevision(statInfo.getStateName());
            vo.setDescriptions(statInfo.getStateName());
            vo.setTitles(statInfo.getStateName());
            result.add(vo);
        }
        return result;
    }
    /****************************************Life Cycle List *****************************************/
    @Override
    public List<CodeDetailVO> getClassPolicyList(String className) {
        ClassInfo classInfo = ClassInfoUtil.getClassInfo(className);
        List<String> lifeCycleList = classInfo.getAllowedLifeCycleList();
        List<CodeDetailVO> result = new ArrayList<CodeDetailVO>();
        for (String str : lifeCycleList){
            CodeDetailVO vo = new CodeDetailVO();
            vo.setNames(className + "_" + "Policy");
            vo.setRevision(str);
            vo.setDescriptions(str);
            vo.setTitles(str);
            result.add(vo);
        }
        return result;
    }
    /****************************************Organization*****************************************/
    @Override
    public List<CodeDetailVO> getCompanyListAll(boolean activeOnly) {
        List<CompanyVO> orgList = organizationService.getOrganizationListAll(AppSchemaCommonConstants.BIZCLASS_COMPANY,activeOnly);
        return makeCodeDetail(orgList);
    }

    @Override
    public List<CodeDetailVO> getBusinessUnitListAll(boolean activeOnly) {
        List<BusinessUnitVO> orgList =  organizationService.getOrganizationListAll(AppSchemaCommonConstants.BIZCLASS_BUSINESSUNIT,activeOnly);
        return makeCodeDetail(orgList);
    }

    @Override
    public List<CodeDetailVO> getDivisionUnitListAll(boolean activeOnly) {
        List<DivisionUnitVO> orgList =  organizationService.getOrganizationListAll(AppSchemaCommonConstants.BIZCLASS_DIVISIONUNIT,activeOnly);
        return makeCodeDetail(orgList);
    }

    @Override
    public List<CodeDetailVO> getPlantUnitListAll(boolean activeOnly) {
        List<PlantUnitVO> orgList =  organizationService.getOrganizationListAll(AppSchemaCommonConstants.BIZCLASS_PLANTUNIT,activeOnly);
        return makeCodeDetail(orgList);
    }
    @Override
    public List<CodeDetailVO> getBusinessUnitListWithCompany(String companyNames, boolean activeOnly) {
        List<BusinessUnitVO> orgList =  organizationService.getExplodedOrganizationList(companyNames,1,activeOnly,false);
        return makeCodeDetail(orgList);
    }
    @Override
    public List<CodeDetailVO> getDivisionUnitListWithBusinessUnit(String businessUnitNames, boolean activeOnly) {
        List<DivisionUnitVO> orgList =  organizationService.getExplodedOrganizationList(businessUnitNames,1,activeOnly,false);
        return makeCodeDetail(orgList);
    }
    @Override
    public List<CodeDetailVO> getPlantUnitListWithDivisionUnit(String divisionUnitNames, boolean activeOnly) {
        List<PlantUnitVO> orgList =  organizationService.getExplodedOrganizationList(divisionUnitNames,1,activeOnly,false);
        return makeCodeDetail(orgList);
    }
    @Override
    public void txnRefreshSyncInfo(CParmSyncCodeSetVO cParmSyncCodeSetVO) {
        for(String obid : cParmSyncCodeSetVO.getObidSet()){
            CodeDetail codeDetailDom = new CodeDetail(obid);
            if(codeDetailDom.getVo().getSynchronizedList()==null) codeDetailDom.getVo().setSynchronizedList("");
            codeDetailDom.getVo().setSynchronizedList(codeDetailDom.getVo().getSynchronizedList() + "@" + cParmSyncCodeSetVO.getDatabaseBeanName() + "@");
            codeDetailDom.modifyObject();
        }
    }
    private List<CodeDetailVO> makeCodeDetail(List<? extends AbstractOrganizationsVO> list){
        List<CodeDetailVO> result = new ArrayList<CodeDetailVO>();
        for (AbstractOrganizationsVO orgVO : list){
            CodeDetailVO detailVO = new CodeDetailVO();
            detailVO.setClassName(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL);
            DomUtil.copyAttributeAll(orgVO,detailVO);
            detailVO.setClassName(orgVO.getClassName());
            result.add(detailVO);
        }
        return result;
    }
}