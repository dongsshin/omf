package com.rap.common.sample.controller;

import com.rap.omc.foundation.user.service.FoundationUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@RestController
public class CommonTestController {

    @Autowired
    FoundationUserDetailsService foundationUserDetailsService;

	@RequestMapping("/common/autoLogin")
    public String autoLogin(HttpServletRequest request) throws Exception{
    	UserDetails userDetails = foundationUserDetailsService.loadUserByUsername("XP3866");
    	UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails,userDetails.getPassword());
    	SecurityContext securityContext = SecurityContextHolder.getContext();
    	securityContext.setAuthentication(usernamePasswordAuthenticationToken);
    	HttpSession session = request.getSession(true);
    	session.setAttribute("SPRING_SECURITY_CONTEXY", securityContext);
    	return "Auto Login Success";
    }
}