/**
 * ===========================================
	 * System Name : LGE GPDM Project
 * Program ID : UsersServiceImpl.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 1. 15. hyeyoung.park Initial
 * ===========================================
 */
package com.rap.common.user.service.impl;

import com.rap.api.object.common.organization.model.DivisionUnitVO;
import com.rap.api.object.common.user.dom.Users;
import com.rap.api.object.common.user.model.AbstractUsersVO;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.api.relation.common.model.MembersVO;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.constants.BusinessCommonConstants;
import com.rap.common.user.model.CUsersVO;
import com.rap.common.user.model.UsersProfileVO;
import com.rap.common.user.model.UsersSearchVO;
import com.rap.common.user.service.UsersService;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.constants.UserPropertyConstants;
import com.rap.omc.controller.model.CSysUserVO;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.core.util.general.FoundationUserUtil;
import com.rap.omc.core.util.general.NameGeneratorUtil;
import com.rap.omc.core.util.general.RelationShip;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.user.model.SysUserVO;
import com.rap.omc.foundation.user.model.UserInfoVO;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.foundation.user.service.FoundationUserService;
import com.rap.omc.framework.exception.OmfFoundationException;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.StrUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * <pre>
 * Class : UsersServiceImpl
 * Description : TODO
 * </pre>
 *
 * @author hyeyoung.park
 */
@Service("usersService")

public class UsersServiceImpl implements UsersService {
    private static final Logger log = LoggerFactory.getLogger(UsersServiceImpl.class);
    @Autowired
    private UserSession userSession;

    @Autowired
    private FoundationUserService foundationUserService;


//	@Resource(name = "commonDao")
//	private CommonDao commonDao;
//
//    @Resource( name = "organizationsService" )
//    private OrganizationsService organizationsService;
//
//    @Resource( name = "personalDataService" )
//    private PersonalDataService personalDataService;
//
//    @Resource(name="accessService")
//    private AccessService accessService;
//
//    @Resource(name="desktopService")
//    private DesktopService desktopService;
//
//    @Resource(name = "idGenerateService")
//    private IdGenerateService idGenerateService;
//
//    @Resource(name="mailService")
//    MailService mailService;

    @Override
    public UsersVO txnCreateUser(UsersVO usersVO) {
        Users userDom = new Users(usersVO);
        userDom.getVo().setStates(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);
        userDom.createObject();
        userDom = DomUtil.toDom(userDom.getObid(),true);

        CSysUserVO cSysUserVO = new CSysUserVO();
        cSysUserVO.setDescriptions(usersVO.getDescriptions());
        cSysUserVO.setEmailId(usersVO.getEmailAddress());
        cSysUserVO.setPassword(usersVO.getNames());
        cSysUserVO.setSite("LG");
        cSysUserVO.setUserId(usersVO.getNames());
        SysUserVO sysUserVO = new SysUserVO(cSysUserVO);

        CUsersVO cUsersVO = usersVO.getOutDataAttributeValue("cUsersVO");

        SysUserVO dbSysUserVO = foundationUserService.getCommonUserInfo(usersVO.getNames());
        Map<String, String> propertyMap = new HashMap<>();
        propertyMap.put(UserPropertyConstants.USER_PROPERTY_DR,cUsersVO.getDivisionUnit());
        propertyMap.put(UserPropertyConstants.USER_PROPERTY_BUSINESS_UNIT,cUsersVO.getBusinessUnit());
        propertyMap.put(UserPropertyConstants.USER_PROPERTY_MR,cUsersVO.getPlantUnit());
        propertyMap.put(UserPropertyConstants.USER_PROPERTY_COMPANY,cUsersVO.getCompany());
        propertyMap.put(UserPropertyConstants.USER_PROPERTY_LOCALE,GlobalConstants.DEFAULT_LANG);
        propertyMap.put(UserPropertyConstants.USER_PROPERTY_TIME_ZONE, GlobalConstants.DEFAULT_TIME_ZONE);
        sysUserVO.setPropertyList(propertyMap);
        if(NullUtil.isNull(dbSysUserVO)){
            foundationUserService.txnCreateUser(sysUserVO);
        }else{
            foundationUserService.txnSetPropertyValueList(usersVO.getNames(),propertyMap);
        }
        return userDom.getVo();
    }

    @Override
    public UsersVO txnModifyUser(UsersVO usersVO) {
        Users userDom = new Users(usersVO);
        userDom.modifyObject();
        userDom = DomUtil.toDom(userDom.getObid(),true);
        return userDom.getVo();
    }
    @Override
    public UsersVO txnInActivateUser(String userId) {
        UsersVO usersVO = getUserInfo(userId);
        Users userDom = new Users(usersVO);
        userDom.inActivate();
        return userDom.getVo();
    }
    @Override
    public UsersVO txnActivateUser(String userId) {
        UsersVO usersVO = getUserInfo(userId);
        Users userDom = new Users(usersVO);
        userDom.activate();
        return userDom.getVo();
    }
    /**
     * 사용자 상세정보 조회
     * @param userId
     * @return
     * @see com.rap.common.user.service.UsersService#getUserInfo(java.lang.String)
     */
    @Override
    public UsersVO getUserInfo(String userId) {
        return Users.findMe(userId);
    }
    @Override
    public void txnAddRole(String userId, Set<String> roleSet) {
        Users userDom = new Users(getUserInfo(userId));
        userDom.addRole(roleSet);
    }
    @Override
    public void txnRemoveRole(String userId, Set<String> roleSet) {
        Users userDom = new Users(getUserInfo(userId));
        userDom.removeRole(roleSet);
    }

    @Override
    public void txnAddGroup(String userId, Set<String> groupSet) {
        Users userDom = new Users(getUserInfo(userId));
        userDom.addGroup(groupSet);
    }

    @Override
    public void txnRemoveGroup(String userId, Set<String> groupSet) {
        Users userDom = new Users(getUserInfo(userId));
        userDom.removeGroup(groupSet);
    }

    /**
     * 사용자 검색
     * @param searchInfo
     * @return
     * @see com.rap.common.user.service.UsersService#retrieveUserList(UsersSearchVO, PagingEntity)
     */
    
    @Override
    public List<UsersVO> retrieveUserList(UsersSearchVO searchInfo, PagingEntity pagingEntity) {
        StringBuffer selectPattern = new StringBuffer();
        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();
        StringBuffer searchCondition = new StringBuffer();
        
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "IFNULL(NULLIF(@this.[inOffiStatFlag],''),'C')", GlobalConstants.OQL_OPERATOR_NOT_EQUAL, "T");
        
        if( searchInfo != null && !searchInfo.getIsIncludeInactiveUser() ){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[states]", GlobalConstants.OQL_OPERATOR_EQUAL, "Active");
        }
//        
//        if( searchInfo != null && !StrUtil.isEmpty(searchInfo.getDescriptions()) ){
//            if( searchInfo.getDescriptions().contains(PlmConstants.DELIM_2) ){
//                StringUtil.constructWherePattern(wherePattern, paramPattern, "@this.[descriptions]", GlobalConstants.OQL_OPERATOR_IN, searchInfo.getDescriptions());
//                searchCondition.append( "descriptions:" + searchInfo.getDescriptions() );
//            }
//            else{
//                StringUtil.constructWherePattern(wherePattern, paramPattern, "UPPER(@this.[searchingForUser])", GlobalConstants.OQL_OPERATOR_LIKE, GlobalConstants.FLAG_TYPE_ALL + (NullUtil.isNone(searchInfo.getDescriptions()) ? searchInfo.getDescriptions(): searchInfo.getDescriptions().toUpperCase()) + GlobalConstants.FLAG_TYPE_ALL);
//                searchCondition.append( "searchingForUser:" + searchInfo.getDescriptions() );
//            }
//        }
        if( searchInfo != null && !StrUtil.isEmpty(searchInfo.getEmailAddress()) ){
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[emailAddress]", GlobalConstants.OQL_OPERATOR_LIKE, searchInfo.getEmailAddress() + GlobalConstants.FLAG_TYPE_ALL);
            if( searchCondition.length() > 0 ){
                searchCondition.append( "," );
            }
            searchCondition.append( "emailAddress:" + searchInfo.getEmailAddress() );
        }
//        if( searchInfo != null && !StrUtil.isEmpty(searchInfo.getHrDepartmentKor()) ){
//            StringUtil.constructWherePattern(wherePattern, paramPattern, "@this.[hrDepartmentKor]", GlobalConstants.OQL_OPERATOR_LIKE, GlobalConstants.FLAG_TYPE_ALL + searchInfo.getHrDepartmentKor() + GlobalConstants.FLAG_TYPE_ALL);
//            if( searchCondition.length() > 0 ){
//                searchCondition.append( "," );
//            }
//            searchCondition.append( "hrDepartmentKor:" + searchInfo.getHrDepartmentKor() );
//        }
//        if( searchInfo != null && !StrUtil.isEmpty(searchInfo.getHrDepartmentEng()) ){
//            StringUtil.constructWherePattern(wherePattern, paramPattern, "@this.[hrDepartmentEng]", GlobalConstants.OQL_OPERATOR_LIKE, GlobalConstants.FLAG_TYPE_ALL + searchInfo.getHrDepartmentEng() + GlobalConstants.FLAG_TYPE_ALL);
//            if( searchCondition.length() > 0 ){
//                searchCondition.append( "," );
//            }
//            searchCondition.append( "hrDepartmentEng:" + searchInfo.getHrDepartmentEng() );
//        }
//        if( searchInfo != null && !StrUtil.isEmpty(searchInfo.getHrDepartmentCode()) ){
//            StringUtil.constructWherePattern(wherePattern, paramPattern, "@this.[hrDepartmentCode]", GlobalConstants.OQL_OPERATOR_IN, searchInfo.getHrDepartmentCode());
//            if( searchCondition.length() > 0 ){
//                searchCondition.append( "," );
//            }
//            searchCondition.append( "hrDepartmentCode:" + searchInfo.getHrDepartmentCode() );
//        }
//        String leaderYn = searchInfo.getLeaderYn();
//        if( searchInfo != null && !StrUtil.isEmpty(leaderYn) ){
//            if ( "NN".equals(leaderYn) ) {
//                StringUtil.constructWherePattern(wherePattern, paramPattern, "@this.[leaderYn]", GlobalConstants.OQL_OPERATOR_EQUAL, "N");
//            } else if ( "Y".equals(leaderYn) ) {
//                StringUtil.constructWherePattern(wherePattern, paramPattern, "@this.[leaderYn]", GlobalConstants.OQL_OPERATOR_EQUAL, leaderYn);
//            }
//  
//            if( searchCondition.length() > 0 ){
//                searchCondition.append( "," );
//            }
//            searchCondition.append( "leaderYn:" + searchInfo.getLeaderYn() );
//        }
        
        OqlBuilderUtil.constructSelectPattern(selectPattern, "SortBy@this.[titles]");
        List<UsersVO> result = new ArrayList<UsersVO>();
        if ( NullUtil.isNull(pagingEntity)) {
            result = ObjectRoot.findObjects(
                    AppSchemaCommonConstants.BIZCLASS_USERS,
                    GlobalConstants.FLAG_TYPE_ALL,
                    GlobalConstants.FLAG_TYPE_ALL,
                    selectPattern.toString(),
                    wherePattern.toString(),
                    paramPattern.toString(),
                    0);
        } else {
            result = ObjectRoot.findObjectPagingList( AppSchemaCommonConstants.BIZCLASS_USERS, 
                    GlobalConstants.FLAG_TYPE_ALL, 
                    GlobalConstants.FLAG_TYPE_ALL, 
                    selectPattern.toString(), 
                    wherePattern.toString(),
                    paramPattern.toString(),
                    pagingEntity);
        }
        return result;
    }



    /**
     * 사용자 정보 수정
     * @param usersProfileVO
     * @return
     * @see com.rap.common.user.service.UsersService#txnUpdateUserInfo(com.rap.common.user.model.UsersProfileVO)
     */
    @Override
    public Users txnUpdateUserInfo(UsersProfileVO usersProfileVO) {
        FoundationUserUtil.setUserProperty( usersProfileVO.getNames(), BusinessCommonConstants.USER_PROP_DIVISION, usersProfileVO.getDivision() );
        FoundationUserUtil.setUserProperty( usersProfileVO.getNames(), BusinessCommonConstants.USER_PROP_MANAGEMENTGROUP, usersProfileVO.getManagementGroup() );
        FoundationUserUtil.setUserProperty( usersProfileVO.getNames(), BusinessCommonConstants.USER_PROP_DAYLIGHT_SAVINGS, usersProfileVO.getDaylightSavings().toString() );
        FoundationUserUtil.setUserProperty( usersProfileVO.getNames(), BusinessCommonConstants.USER_PROP_AFFILIATE_UNIT, usersProfileVO.getAffiliate() );
        if( usersProfileVO.getTimeZone() != null && !usersProfileVO.getTimeZone().isEmpty()){
            FoundationUserUtil.setUserProperty( usersProfileVO.getNames(), BusinessCommonConstants.USER_PROP_TIME_ZONE, usersProfileVO.getTimeZone() );
        }
        return new Users( usersProfileVO.getObid() );
    }

    /**
     * GPDM 사용자 권한 삭제
     * @param userObid
     * @see com.rap.common.user.service.UsersService#txnDeleteUserAuth(java.lang.String)
     */
    @Override
    public void txnDeleteUserAuth(String userObid) {
//        Users userDom = new Users( userObid );
//        UsersVO userVO = userDom.getVo();
//
//        if( CommonApplicationSchemaConstants.STATE_ACTIVE_INACTIVE_ACTIVE.equals(userVO.getStates()) ){
////            // Inactive 처리 되기 전에 조회
////            String businessUnitCode = UserManagementUtil.getUserProperty( userVO.getNames(), PlmConstants.USER_PROP_BUSINESS_UNIT );
////            String divisionUnitCode = UserManagementUtil.getUserProperty( userVO.getNames(), PlmConstants.USER_PROP_DIVISION );
//
//            // 1. Inactive 처리
//            userDom.changePolicyAndState(userDom.getVo().getLifeCycle(), CommonApplicationSchemaConstants.STATE_PERSON_INACTIVE);
//            UserManagementUtil.inActiviateUser( userVO.getNames() );    // PSYSUSER Inactive 처리
//
//            // 2. Site 삭제
//            List<BusinessRelationObjectVO> plantRelList = userDom.getRelationship(CommonApplicationSchemaConstants.RELCLASS_PLANTUNIT2USERS, CommonApplicationSchemaConstants.BIZCLASS_PLANTUNIT, GlobalConstants.FLAG_TYPE_FROM);
//            if( plantRelList != null && plantRelList.size() > 0 ){
//                for( int jnx = 0; jnx < plantRelList.size(); jnx++ ){
//                    RelationShip.disconnect( plantRelList.get(jnx) );
//                }
//            }
//            List<BusinessRelationObjectVO> memberList = userDom.getRelationship(CommonApplicationSchemaConstants.RELCLASS_MEMBERS, CommonApplicationSchemaConstants.BIZCLASS_PLANTUNIT, GlobalConstants.FLAG_TYPE_FROM);
//            if( memberList != null && memberList.size() > 0 ){
//                for( int jnx = 0; jnx < memberList.size(); jnx++ ){
//                    RelationShip.disconnect( memberList.get(jnx) );
//                }
//            }
//
//            // 5. IAM Role 삭제
//            Set<String> roleList = accessService.getRoleList( userVO.getNames() );
//            if( roleList != null && roleList.size() > 0 ){
//                boolean hasIAMRole = false;
//                for(String role : roleList){
//                    if(StrUtil.in(role,PlmConstants.IAM_ROLE_LIST)){
//                        hasIAMRole = true;break;
//                    }
//                }
//                if( hasIAMRole ){
//                    accessService.txnUpdateIAMRole(userVO.getNames(), null, StrUtil.convertArrayToString(PlmConstants.IAM_ROLE_LIST));
//                }
//            }
//            // 6. Desktop Object 삭제
//            desktopService.txnDeleteDesktopObjectForUser( userDom );
//
//            // 7. GPDM_PERSON USE_FLAG 변경 추가 VC내용
//            commonDao.update("IAM.updateInactivePerson", userVO.getNames());
//        }
//        else{
//            throw new ApplicationException( "Select active user!" );
//        }
    }

    /**
     * 사용자 Portal 화면 초기화
     * 
     * @param userList
     * @param targetModule
     * @see com.rap.common.user.service.UsersService#txnInitializeUserPortal(java.util.List, java.lang.String)
     */
    @Override
    public void txnInitializeUserPortal(List<UsersVO> userList, String targetModule) {
//        if( userList != null && userList.size() > 0 ){
//            for( int inx = 0; inx < userList.size(); inx++ ){
//                txnInitializeUserPortal( userList.get(inx).getObid(), targetModule );
//            }
//        }
    }

    /**
     * 사용자 Portal 화면 초기화
     * 
     * @param userObid
     * @param targetModule
     * @see com.rap.common.user.service.UsersService#txnInitializeUserPortal(java.lang.String, java.lang.String)
     */
    @Override
    public void txnInitializeUserPortal(String userObid, String targetModule) {
//        if( StrUtil.isEmpty(userObid) ){
//            throw new ApplicationException( "UserObid is null." );
//        }
//        else{
//            Users userDom = new Users( userObid );
//            
//            // Active 사용자인 경우만 수행
//            if( userDom.getVo().getStates().equals( CommonApplicationSchemaConstants.STATE_ACTIVE_INACTIVE_ACTIVE ) ){
//                String userId = userDom.getVo().getNames();
//                desktopService.txnDeleteDesktopObjectForUser( userDom, targetModule );
//                desktopService.txnCreateDefaultDesktopWidgetForUser( userId, targetModule );
//            }
//        }
    }

    /**
     *
     * @param dataList
     * @return
     * @see com.rap.common.user.service.UsersService#deleteInactiveUser(java.util.List)
     */
    @Override
    public HashMap<String, Object> deleteInactiveUser(List<UserInfoVO> dataList) {
        HashMap<String, Object> mapResult = new HashMap<String, Object>();
        StringBuffer message = new StringBuffer();
        int successCount = 0;

        for( int inx = 0; inx < dataList.size(); inx++ ){
            try{
                // User 조회
                UsersVO usersVO = ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_USERS, dataList.get(inx).getUserId());
                if( usersVO != null && AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_INACTIVE.equals(usersVO.getStates()) ){
                    Users deleteDom = new Users( usersVO.getObid() );
                    deleteDom.deleteObject();
                    successCount++;
                }
            }
            catch( Exception e ){
                e.printStackTrace();
                continue;
            }
        }
        if (StrUtil.isEmpty(message.toString())) {
            message.append( "Success!" );
        }
        mapResult.put( "message", message.toString() );
        mapResult.put( "successCount", successCount );
        return mapResult;
    }

    /**
     * 사용자 권한 회수 (Excel Import)
     * @param dataList
     * @return
     * @see com.rap.common.user.service.UsersService#deleteUserAuth(java.util.List)
     */
    @Override
    public HashMap<String, Object> deleteUserAuth(List<UsersVO> dataList) {
        HashMap<String, Object> mapResult = new HashMap<String, Object>();
        StringBuffer message = new StringBuffer();
        int successCount = 0;

        for( int inx = 0; inx < dataList.size(); inx++ ){
            try{
                if( !StrUtil.isEmpty( dataList.get(inx).getObid() ) ){
                    this.txnDeleteUserAuth( dataList.get(inx).getObid() );
                    successCount++;
                }
            }
            catch( Exception e ){
                e.printStackTrace();
                continue;
            }
        }

        if (StrUtil.isEmpty(message.toString())) {
            message.append( "Success!" );
        }

        mapResult.put( "message", message.toString() );
        mapResult.put( "successCount", successCount );

        return mapResult;
    }


    /**
     * Session 정보에서 해당 Role있는지 Check함.
     * 
     * @param roleCode
     * @return
     * @see com.rap.common.user.service.UsersService#hasRole(java.lang.String)
     */
    @Override
    public boolean hasRole(String roleCode){
        return userSession.getRoleSet().contains(roleCode);
    }
    
    @Override
    public boolean hasGroup(String group){
        return userSession.getGroupSet().contains(group);
    }
   
    /**
     * 
     * @param authName
     * @return
     * @see com.rap.common.user.service.UsersService#hasAuth(java.lang.String)
     */
    @Override
    public boolean hasAuth(String authName, String divisionCode){
        String authInfo = divisionCode + "." + authName;
        return userSession.getManagementRoleSet().contains(authInfo);
    }
    
    /**
     * 
     * @param authName
     * @return
     * @see com.rap.common.user.service.UsersService#hasAuth(java.lang.String)
     */
    @Override
    public boolean hasAuthExceptDivision(String authName){
        String authInfo = "." + authName;
        boolean result = false;
        
        Iterator<String> it = userSession.getManagementRoleSet().iterator(); 
        while(it.hasNext() && !result) {
            if(it.next().endsWith(authInfo)){
                result = true;
            }
        }        
                
        return result;
    }
    
    /**
     * 
     * @return
     * @see com.rap.common.user.service.UsersService#getRoleSet()
     */
    @Override
    public Set<String> getRoleSet(){
        return userSession.getRoleSet();
    }
    /**
     * 
     * @return
     * @see com.rap.common.user.service.UsersService#getGroupSet()
     */
    @Override
    public Set<String> getGroupSet(){
        return userSession.getGroupSet();
    }
    /**
     * 
     * @return
     * @see com.rap.common.user.service.UsersService#getAccessibleMenuSet()
     */
    @Override
    public Set<String> getAccessibleMenuSet(){
        return userSession.getAccessibleMenuSet();
    }

    /**
     * 
     * @return
     * @see com.rap.common.user.service.UsersService#getManagementRoleSet()
     */
    @Override
    public Set<String> getManagementRoleSet(){
        return userSession.getManagementRoleSet();
    }

    /**
     * 
     * @return
     * @see com.rap.common.user.service.UsersService#getUserId()
     */
    @Override
    public String getUserId(){
        return userSession.getUserId();
    }
    
    /**
     * 
     * @param groupCode
     * @return
     * @see com.rap.common.user.service.UsersService#isAssignedGroup(java.lang.String)
     */
    @Override
    public boolean isAssignedGroup(String groupCode){
        return userSession.getGroupSet().contains(groupCode);
    }
    /**
     * 
     * @return
     * @see com.rap.common.user.service.UsersService#retriveUserDivisionMappingList(com.rap.common.user.model.UsersSearchVO)
     */
//    @Override
//    public List<WBSJobActivityVO> getMyJobActivities(boolean notCompletedOnly){
//        String userId = ThreadLocalUtil.getString(ThreadLocalUtil.KEY.userId, GlobalConstants.NO_USER_ID);
//        return Users.getUsers(userId).getMyJobActivityList(notCompletedOnly);
//    }
    
    public List<UsersVO> retriveUserDivisionMappingList(UsersSearchVO searchInfo) {
        StringBuffer selectPatternBuf = new StringBuffer();
        StringBuffer fromPatternBuf = new StringBuffer();
        StringBuffer wherePatternBuf = new StringBuffer();
        StringBuffer paramPatternBuf = new StringBuffer();
        
        fromPatternBuf.append("<this>ThisConnectedWithTo<[Members]@MB>+");
        fromPatternBuf.append("<[Members]@MB>FromConnectedWithThis<[DivisionUnit]@DV>+");
        
        OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[states]", GlobalConstants.OQL_OPERATOR_EQUAL, AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);

        if ( !StrUtil.isEmpty(searchInfo.getNames()) ) {
            OqlBuilderUtil.constructWherePattern(wherePatternBuf, paramPatternBuf, "@this.[names]", GlobalConstants.OQL_OPERATOR_EQUAL, searchInfo.getNames());
        }
        
        OqlBuilderUtil.constructSelectPattern(selectPatternBuf, "@MB.[obid] relationObid");
        OqlBuilderUtil.constructSelectPattern(selectPatternBuf, "IFNULL(getUserInfo(@MB.[modifier],'T'),@MB.[modifier]) relModifier");
        OqlBuilderUtil.constructSelectPattern(selectPatternBuf, "omcConvertUtcToLocal(@MB.[modified]) relModified");
        OqlBuilderUtil.constructSelectPattern(selectPatternBuf, "@DV.[*]");
        OqlBuilderUtil.constructSelectPattern(selectPatternBuf, "CONCAT(@DV.[titles], '(', @DV.[names], ')') dv_divisionDesc");
        OqlBuilderUtil.addSortByPattern(selectPatternBuf, "@DV.[titles], @this.[titles]");

        List<UsersVO> result = ObjectRoot.searchObjects(
                AppSchemaCommonConstants.BIZCLASS_USERS,
                selectPatternBuf.toString(),
                fromPatternBuf.toString(),
                wherePatternBuf.toString(),
                paramPatternBuf.toString(),
                0);
                
        return result;
    }

    /**
     * 
     * @param createList
     * @param deleteList
     * @see com.rap.common.user.service.UsersService#txnUpdateUserDivisionMappingList(java.util.List,java.util.List)
     */
    @Override
    public void txnUpdateUserDivisionMappingList(List<MembersVO> createList, List<MembersVO> deleteList) {
        if ( createList.size() > 0 ) {
            MembersVO existVO = new MembersVO();
            for ( MembersVO vo : createList ) {
                existVO = checkExistMember(vo.getFromObid(), vo.getToObid());
                if ( existVO == null ) {
                    RelationShip.connect( AppSchemaCommonConstants.RELCLASS_MEMBERS, vo.getFromObid(), vo.getToObid(), null );
                }
            }
        }
        
        if ( deleteList.size() > 0 ) {
            ObjectRoot.deleteObjectSet(deleteList);
        }
    }
    public MembersVO checkExistMember(String divisionObid, String userObid) {
        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();
        
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[fromObid]", GlobalConstants.OQL_OPERATOR_IN, divisionObid);
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[toObid]", GlobalConstants.OQL_OPERATOR_IN, userObid);
        
        MembersVO existVO = new MembersVO();
        existVO = ObjectRoot.findObject(
                AppSchemaCommonConstants.RELCLASS_MEMBERS, 
                GlobalConstants.FLAG_TYPE_ALL, 
                GlobalConstants.FLAG_TYPE_ALL, 
                GlobalConstants.FLAG_TYPE_ALL, 
                wherePattern.toString(), 
                paramPattern.toString());
        return existVO;
    }

    /**
     * 사용자 Migration 수행
     * @param dataList
     * @return
     * @see com.rap.common.user.service.UsersService#excelImportUsers(java.util.List)
     */
    @Override
    public HashMap<String, Object> excelImportUsers(List<UsersVO> dataList){
        HashMap<String, Object> mapResult = new HashMap<String, Object>();
        StringBuffer message = new StringBuffer();
        int successCount = 0;
        int failCount = 0;
//        
//        if( !NullUtil.isNone(dataList) ){
//            Users createDom = null;
//            UsersVO createVo = null;
//            String userId = "";
//            String searchingForUserStr = "";
//            for( int inx = 0; inx < dataList.size(); inx++ ){
//                try{
//                    createVo = dataList.get( inx );
//                    userId = createVo.getNames();
//                    
//                    // 중복체크
//                    UsersVO existVo = ObjectRoot.findObject(CommonApplicationSchemaConstants.BIZCLASS_USERS, userId, false);
//                    if( NullUtil.isNull(existVo) ){
//                        // Create PSYSUSER
//                        HashMap<String, Object> searchInfo = new HashMap<String, Object>();
//                        searchInfo.put("empNo", userId);
//                        HashMap<String,Object> result = commonDao.select("HR.retrieveSysUserCheck", searchInfo);
//                        if(NullUtil.isNull(result)) {
//                            UserManagementUtil.createUser(userId, GlobalConstants.SYSKEY_KIND_NAME_USER, userId, createVo.getTitles(), "LG", "", "");
//                        }
//                        
//                        // Data setting for search
//                        searchingForUserStr = createVo.getDescriptions();
//                        searchingForUserStr += " " + createVo.getGradeName();
//                        searchingForUserStr += " " + createVo.getMailId();
//                        createVo.setSearchingForUser( searchingForUserStr );
//    
//                        // Create PTUSER
//                        createVo.setClassName( CommonApplicationSchemaConstants.BIZCLASS_USERS );
//                        createVo.setLifeCycle( CommonApplicationSchemaConstants.LIFECYCLE_PERSON );
//                        createVo.setStates( CommonApplicationSchemaConstants.STATE_ACTIVE_INACTIVE_ACTIVE );
//                        
//                        createDom = DomUtil.toDom( createVo );
//                        createDom.createObject();
//                        
//                        successCount++;
//                    }
//                    else{
//                        failCount++;
//                    }
//                }
//                catch( Exception e ){
//                    failCount++;
//                    e.printStackTrace();
//                    continue;
//                }
//            }
//        }
//
//        if (StrUtil.isEmpty(message.toString())) {
//            message.append( "Success!" );
//        }

        mapResult.put( "message", message.toString() );
        mapResult.put( "successCount", successCount );
        mapResult.put( "failCount", failCount );
        
        return mapResult;
    }
    
    public List<UsersVO> getUserProperty(UsersSearchVO searchInfo) {
        StringBuffer selectPattern = new StringBuffer();
        StringBuffer wherePattern = new StringBuffer();
        StringBuffer paramPattern = new StringBuffer();
        
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[states]", GlobalConstants.OQL_OPERATOR_EQUAL, AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);
        OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "IFNULL(NULLIF(@this.[inOffiStatFlag],''),'C')", GlobalConstants.OQL_OPERATOR_NOT_EQUAL, "T");
        if ( !StrUtil.isEmpty(searchInfo.getNames()) ) {
            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[names]", GlobalConstants.OQL_OPERATOR_EQUAL, searchInfo.getNames());
        }
//        if ( !StrUtil.isEmpty(searchInfo.getHrDepartmentCode()) ) {
//            StringUtil.constructWherePattern(wherePattern, paramPattern, "@this.[hrDepartmentCode]", GlobalConstants.OQL_OPERATOR_IN, searchInfo.getHrDepartmentCode());
//        }
        
        OqlBuilderUtil.constructSelectPattern(selectPattern, "To[HasAuthorizationGroup].From.titles authGroupTitle");
        List<UsersVO> userList = ObjectRoot.findObjects(AppSchemaCommonConstants.BIZCLASS_USERS, selectPattern.toString(), wherePattern.toString(), paramPattern.toString());
        for ( UsersVO vo : userList ) {
            HashMap<String, Object> outData = new HashMap<String, Object>();
            outData = vo.getOutData();
            outData.put("division", FoundationUserUtil.getUserProperty(vo.getNames(), BusinessCommonConstants.USER_PROP_DIVISION));
            outData.put("businessUnit", FoundationUserUtil.getUserProperty(vo.getNames(), BusinessCommonConstants.USER_PROP_BUSINESS_UNIT));
            outData.put("affiliate", FoundationUserUtil.getUserProperty(vo.getNames(), BusinessCommonConstants.USER_PROP_AFFILIATE_UNIT));
            outData.put("timeZone", FoundationUserUtil.getUserProperty(vo.getNames(), BusinessCommonConstants.USER_PROP_TIME_ZONE));
            Users user = DomUtil.toDom(vo);
            List<DivisionUnitVO> divisionList = user.getRelatedObjects(AppSchemaCommonConstants.RELCLASS_MEMBERS, AppSchemaCommonConstants.BIZCLASS_DIVISIONUNIT, GlobalConstants.FLAG_TYPE_FROM);
            if ( !NullUtil.isNone(divisionList) && divisionList.size() > 0 ) {
                outData.put("divisionName", divisionList.get(0).getNames());
            }
            vo.setOutData(outData);
        }
        
        return userList;
    }
    
    public void modifyUserProperty(UsersVO userVO, HashMap<String, Object> propertyParams) {
        if ( !NullUtil.isNone((String)propertyParams.get("division")) ) {
            FoundationUserUtil.setUserProperty( userVO.getNames(), BusinessCommonConstants.USER_PROP_DIVISION, (String)propertyParams.get("division") );
        }
        if ( !NullUtil.isNone((String)propertyParams.get("businessUnitCode")) ) {
            FoundationUserUtil.setUserProperty( userVO.getNames(), BusinessCommonConstants.USER_PROP_BUSINESS_UNIT, (String)propertyParams.get("businessUnitCode") );
        }
        if ( !NullUtil.isNone((String)propertyParams.get("affiliate")) ) {
            FoundationUserUtil.setUserProperty( userVO.getNames(), BusinessCommonConstants.USER_PROP_AFFILIATE_UNIT, (String)propertyParams.get("affiliate") );
        }
        if ( !NullUtil.isNone((String)propertyParams.get("timeZone")) ) {
            FoundationUserUtil.setUserProperty( userVO.getNames(), BusinessCommonConstants.USER_PROP_TIME_ZONE, (String)propertyParams.get("timeZone") );
        }
    }
    
    /**
     * Admin > 관리자용 엑셀 업로드 > User Property Setting Excel Import
     *
     * @param userVO
     * @param propertyParams
     * @return
     */
    public HashMap<String, Object> excelImportUserProperty(UsersVO userVO, HashMap<String, Object> propertyParams) {
        HashMap<String, Object> mapResult = new HashMap<String, Object>();
        StringBuffer message = new StringBuffer();
        
        if( !NullUtil.isNull(userVO) ){
            try {
                UsersVO existVo = ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_USERS, userVO.getNames());
                if ( !NullUtil.isNull(existVo) ) {
                    modifyUserProperty(userVO, propertyParams);
                }
                else {
                    message.append("Not exists user.");
                }
            }
            catch ( Exception e ) {
                e.printStackTrace();
                if ( !StrUtil.isEmpty(message.toString()) ) {
                    message.append(new StringBuffer(e.getMessage()));
                } else {
                    message = new StringBuffer(e.getMessage());
                }
            }
        }
        mapResult.put( "message", message.toString() );
        return mapResult;
    }

	@Override
	public boolean hasAuth(String authName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void txnUpdateSessionPlant(String userId, String preferredSite) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public UsersVO retrieveUserInfoByMailId(String mailId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public UsersVO retrieveUserInfoByEmpNo(String empNo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AbstractUsersVO> retrieveAbstractUserList(UsersSearchVO searchInfo) {
		// TODO Auto-generated method stub
		return null;
	}

//	@Override
//	public List<WBSActivitiesVO> getMyActivities(Set<String> classFilter, boolean isDelayedOnly) {
//		// TODO Auto-generated method stub
//		return null;
//	}
//
//	@Override
//	public List<WBSActivitiesVO> getMyActivities(Set<String> classFilter, boolean isDelayedOnly,
//			boolean onlyPrevActivityComplete) {
//		// TODO Auto-generated method stub
//		return null;
//	}

	@Override
	public void txnCopyUserDivisionMappingList(String copyType, String fromObid, String toObid) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void txnUserCRUDTest() {
		Users usersDom = null;
		UsersVO usersVO = new UsersVO();
		
		String names = NameGeneratorUtil.generateUniqueName(BusinessCommonConstants.ID_GENERATOR_TEST);
		
		usersVO.setNames(names);
		usersVO.setLifeCycle(AppSchemaCommonConstants.LIFECYCLE_PERSON);
		usersVO.setStates(AppSchemaCommonConstants.STATE_PERSON_ACTIVE);
		usersVO.setTitles("LG CNS User1");
		usersVO.setDescriptions("LG CNS User Desc1");
		usersVO.setWorkPhoneNumber("082-1234-12341");
		usersVO.setEmailAddress("lgcnsuser@lgcns.com1");
		usersVO.setDepartmentCode("LGCNS");
		usersVO.setDepartmentTitles("LG CNS Department");
		
		//생성
		usersDom = new Users(usersVO);
		usersDom.createObject();

		log.info("Created User:" + names);
//		if(true) throw new FoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"ddddddddddddd");
//		
		//수정하기
		usersDom.getVo().setDescriptions("dddddddddddddddddddddddddddddddddd");
		usersDom.modifyObject();
		
//		
//		ObjectRoot.deleteObjectSet(userList);
	//	
		//삭제하기
		usersVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_USERS, names);
		usersDom = new Users(usersVO);
		usersDom.deleteObject();
		
		//일괄조회
		List<UsersVO> userList = ObjectRoot.findObjects(AppSchemaCommonConstants.BIZCLASS_USERS, "START*");
		
		//일괄 수정
		ObjectRoot.modifyObjectSetBatch(userList, "descriptions,titles");
		
		ObjectRoot.deleteObjectSetBatch(userList);
		
		if(true) throw new OmfFoundationException(HttpStatus.INTERNAL_SERVER_ERROR,"All Data Discarded!!!!");
		
	}
}