package com.rap.common.code.service;

import com.rap.api.object.common.code.model.CodeDetailVO;
import com.rap.api.object.common.code.model.CodeMasterVO;
import com.rap.omc.controller.model.CParmSyncCodeSetVO;
import com.rap.omc.dataaccess.paging.model.PagingEntity;

import java.util.List;
import java.util.Set;

public interface CodeService {
    public CodeMasterVO txnCreateCodeMaster(CodeMasterVO codeMasterVO);
    public CodeMasterVO txnModifyCodeMaster(CodeMasterVO codeMasterVO);
    public CodeMasterVO txnDeleteCodeMaster(CodeMasterVO codeMasterVO);

    public CodeMasterVO getCodeMaster(String names);
    public List<CodeMasterVO> getCodeMasterList(CodeMasterVO codeMasterVO, PagingEntity pagingEntity);
    public CodeMasterVO getCodeMasterWithObid(String codeMasterObid);

    public CodeDetailVO txnCreateCodeDetail(String masterCode, CodeDetailVO codeDetailVO,List<String> orgList);
    public CodeDetailVO txnDeleteCodeDetail(CodeDetailVO codeDetailVO);
    public CodeDetailVO txnModifyCodeDetail(CodeDetailVO codeDetailVO, List<String> orgList);
    public CodeDetailVO txnActivateCodeDetail(String obid);
    public CodeDetailVO txnInActivateCodeDetail(String obid);
    public void txnCreateModifyDeleteCodeDetailList(List<CodeDetailVO> codeDetailVOList);

    public CodeDetailVO getCodeDetail(String obid);
    public CodeDetailVO getCodeDetail(String codeMasterNames, String code);

    public List<CodeDetailVO> getCodeDetailListAll(String codeMasterNames);
    public List<CodeDetailVO> getCodeDetailListByScope(String masterCode, String codeScope);
    public List<CodeDetailVO> getCodeDetailListByScope(CodeDetailVO searchVO, PagingEntity pagingEntity);
    public List<CodeDetailVO> getCodeDetailListByCodeSet(String masterCode, Set<String> codeSet);

    public List<CodeDetailVO> getAttributeRangeList(String classAttribute, boolean sort);
    public List<CodeDetailVO> getClassNameList(String className, boolean orderByDesc);
    public List<CodeDetailVO> getLifeCycleStatesList(String lifeCycle);
    public List<CodeDetailVO> getClassPolicyList(String className);

    public List<CodeDetailVO> getCompanyListAll(boolean activeOnly);
    public List<CodeDetailVO> getBusinessUnitListAll(boolean activeOnly);
    public List<CodeDetailVO> getDivisionUnitListAll(boolean activeOnly);
    public List<CodeDetailVO> getPlantUnitListAll(boolean activeOnly);

    public List<CodeDetailVO> getBusinessUnitListWithCompany(String companyNames, boolean activeOnly);
    public List<CodeDetailVO> getDivisionUnitListWithBusinessUnit(String businessUnitNames, boolean activeOnly);
    public List<CodeDetailVO> getPlantUnitListWithDivisionUnit(String divisionUnitNames, boolean activeOnly);

    public void txnRefreshSyncInfo(CParmSyncCodeSetVO cParmSyncCodeSetVO);

/*

    public List<CompanyVO> getCompanyList();
    public List<CompanyVO> getCompanyList(String names, String descriptions);
    public List<CompanyVO> getCompanyList(String names, String descriptions, boolean isOrderByNames);
    
    public List<BusinessUnitVO> getBusinessList(String businessUnitCode, String names, String descriptions);
    public List<BusinessUnitVO> getBusinessList(String businessUnitCode, String names, String descriptions, boolean isOrderByNames);
    
    public List<CodeDetailVO> getCodeDetailList(CodeDetailVO searchInfo, boolean isPaging);
    
    public List<DivisionUnitVO> getDivisionList();
    public List<DivisionUnitVO> getDivisionList(String businessUnitCode);
    public List<DivisionUnitVO> getDivisionList(String businessUnitCode, String names, String descriptions);
    public List<DivisionUnitVO> getDivisionList(String businessUnitCode, String names, String descriptions, boolean isOrderByNames);
    public List<DivisionUnitVO> getDivisionList(String names, String descriptions);
    public List<DivisionUnitVO> getDivisionList(String names, String descriptions, boolean isOrderByNames);
    
    public List<AffiliateUnitVO> getAffiliateList(String divisionCode, boolean isOrderByNames);
    
    public List<PlantUnitVO> getPlantList(String divisionCode);
    public List<PlantUnitVO> getPlantList(String businessUnitCode, String divisionCode, String names, String descriptions);
    public List<PlantUnitVO> getPlantList(String businessUnitCode, String divisionCode, String names, String descriptions, boolean isOrderByNames);
    public List<PlantUnitVO> getPlantList(String divisionCode, String names, String descriptions, boolean isOrderByNames);



    public CodeMasterVO getCodeMaster(String names);
    public String getCodeMasterInfo(String codeMasterName);
    public List<CodeMasterVO> getCodeMasterListForManagement(String userId);
    public List<CodeMasterVO> getCodeMasterByAssignedAuthType(String authName);
    
    public List<CodeDetailVO> getCodeDetailListByScope(String masterCode, String codeScope);
    public List<CodeDetailVO> getCodeDetailList(String codeMasterObid, String codeScope, String states);
    public List<CodeDetailVO> getCodeDetailList(String codeMasterObid, CodeDetailVO searchInfo);
    public List<CodeDetailVO> getCodeDetailList(String codeMasterObid, String codeDetailNames);
    
    public List<CodeDetailVO> getCodeDetailListbyCodeName(String codeMasterName, String codeNames );
    public List<CodeDetailVO> getCodeDetailListForInactive(String masterCode, String codeScope);
    public List<CodeDetailVO> getCodeDetailListForAll(String masterCode, String codeScope);
    
    public CodeDetailVO getCodeDetail(String codeMasterObid, String names);
    

    
    public CodeDetail txnCreateCodeDetail(String codeMasterObid, CodeDetailVO codeDetailVO, List<OrganizationsVO> relatedOrgList);
    public void txnCreateCodeDetail(String codeMasterName, CodeDetailVO codeDetailVO, OrganizationsVO orgVO);
    public CodeDetail txnUpdateCodeDetail(String codeMasterObid, String codeDetailObid, CodeDetailVO codeDetailVO, List<OrganizationsVO> relatedOrgList);
    public void txnUpdateStateCodeDetail(String codeMasterObid, String activeStr, List<CodeDetailVO> codeDetailList);
    public void txnDeleteCodeDetail(String codeMasterObid, List<CodeDetailVO> codeDetailList);
    */






}