package com.rap.common.organization.service.impl;

import com.rap.api.object.common.organization.dom.AbstractOrganizations;
import com.rap.api.object.common.organization.model.*;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.organization.service.OrganizationService;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.omc.core.util.DomUtil;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service("organizationService")
public class OrganizationServiceImpl implements OrganizationService {

	@Override
	public CompanyVO txnCreateCompany(CompanyVO companyVO) {
		return createOrganization(companyVO);
	}

	@Override
	public CompanyVO txnModifyCompany(CompanyVO companyVO) {
		return modifyOrganization(companyVO);
	}

	@Override
	public CompanyVO txnDeleteCompany(CompanyVO companyVO) {
		return deleteOrganization(companyVO);
	}

	@Override
	public CompanyVO txnActiviateCompany(CompanyVO companyVO) {
		return activiateOrganization(companyVO);
	}

	@Override
	public CompanyVO txnInActiviateCompany(CompanyVO companyVO) {
		return inActiviateOrganization(companyVO);
	}

	@Override
	public List<CompanyVO> getCompanyList() {
		return null;
	}

	@Override
	public CompanyVO getMainCompany() {
		return null;
	}

	@Override
	public CompanyVO getCompany(String names) {
		return null;
	}

	@Override
	public List<CompanyVO> getBusinessUnitList(String companyNames, boolean isActivieOnly) {
		return null;
	}

	@Override
	public BusinessUnitVO txnCreateBusinessUnit(BusinessUnitVO businessUnitVO) {
		return createOrganization(businessUnitVO);
	}

	@Override
	public BusinessUnitVO txnModifyBusinessUnit(BusinessUnitVO businessUnitVO) {
		return modifyOrganization(businessUnitVO);
	}

	@Override
	public BusinessUnitVO txnDeleteBusinessUnit(BusinessUnitVO businessUnitVO) {
		return deleteOrganization(businessUnitVO);
	}

	@Override
	public BusinessUnitVO txnActiviateBusinessUnit(BusinessUnitVO businessUnitVO) {
		return activiateOrganization(businessUnitVO);
	}

	@Override
	public BusinessUnitVO txnInActiviateBusinessUnit(BusinessUnitVO businessUnitVO) {
		return inActiviateOrganization(businessUnitVO);
	}

	@Override
	public CompanyVO getCompanyWithBusinessUnit(String businessUnitNames) {
		return null;
	}

	@Override
	public CompanyVO getBusinessUnit(String businessUnitNames) {
		return null;
	}

	@Override
	public List<DivisionUnitVO> getDivisionUnitList(String businessUnitNames, boolean isActivieOnly) {
		return null;
	}

	@Override
	public DivisionUnitVO txnCreateDivisionUnit(DivisionUnitVO divisionUnitVO) {
		return createOrganization(divisionUnitVO);
	}

	@Override
	public DivisionUnitVO txnModifyDivisionUnit(DivisionUnitVO divisionUnitVO) {
		return modifyOrganization(divisionUnitVO);
	}

	@Override
	public DivisionUnitVO txnDeleteDivisionUnit(DivisionUnitVO divisionUnitVO) {
		return deleteOrganization(divisionUnitVO);
	}

	@Override
	public DivisionUnitVO txnActiviateDivisionUnit(DivisionUnitVO divisionUnitVO) {
		return activiateOrganization(divisionUnitVO);
	}

	@Override
	public DivisionUnitVO txnInActiviateDivisionUnit(DivisionUnitVO divisionUnitVO) {
		return inActiviateOrganization(divisionUnitVO);
	}

	@Override
	public BusinessUnitVO getBusinessUnitWithDivisionUnit(String divisionUnitNames) {
		return null;
	}

	@Override
	public CompanyVO getDivisionUnit(String divisionUnitNames) {
		return null;
	}

	@Override
	public List<DivisionUnitVO> getPlantUnitList(String divisionUnitNames, boolean isActivieOnly) {
		return null;
	}

	@Override
	public PlantUnitVO txnCreatePlantUnit(PlantUnitVO plantUnitVO) {
		return createOrganization(plantUnitVO);
	}

	@Override
	public PlantUnitVO txnModifyPlantUnit(PlantUnitVO plantUnitVO) {
		return modifyOrganization(plantUnitVO);
	}

	@Override
	public PlantUnitVO txnDeletePlantUnit(PlantUnitVO plantUnitVO) {
		return deleteOrganization(plantUnitVO);
	}

	@Override
	public PlantUnitVO txnActiviatePlantUnit(PlantUnitVO plantUnitVO) {
		return activiateOrganization(plantUnitVO);
	}

	@Override
	public PlantUnitVO txnInActiviatePlantUnit(PlantUnitVO plantUnitVO) {
		return inActiviateOrganization(plantUnitVO);
	}

	@Override
	public DivisionUnitVO getDivisonUnitWithPlantUnit(String plantUnitNames) {
		return null;
	}

	@Override
	public CompanyVO getPlantUnit(String plantUnitNames) {
		return null;
	}

	@Override
	public <T extends AbstractOrganizationsVO> List<T> getExplodedOrganizationList(String orgName, int depth, boolean activeOnly,boolean selfInclude){
		List<AbstractOrganizationsVO> list = new ArrayList<AbstractOrganizationsVO>();
		AbstractOrganizationsVO orgVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_ABSTRACTORGANIZATIONS,orgName);
		AbstractOrganizations orgObj = DomUtil.toDom(orgVO);
		return orgObj.getExplodedOrganizationList(activeOnly,depth,selfInclude);
	}

	@Override
	public <T extends AbstractOrganizationsVO> List<T> getOrganizationListAll(String className, boolean activeOnly) {
		return AbstractOrganizations.getOrganizationListAll(className,activeOnly);
	}

	private <T extends AbstractOrganizationsVO> T createOrganization(AbstractOrganizationsVO organizationsVO) {
		AbstractOrganizations orgDom = DomUtil.toDom(organizationsVO);
		orgDom.createObject();
		return (T)DomUtil.toDom(orgDom.getObid()).getVo();
	}
	private <T extends AbstractOrganizationsVO> T modifyOrganization(AbstractOrganizationsVO organizationsVO) {
		AbstractOrganizations orgDom = DomUtil.toDom(organizationsVO);
		orgDom.modifyObject();
		return (T)DomUtil.toDom(orgDom.getObid()).getVo();
	}
	private <T extends AbstractOrganizationsVO> T deleteOrganization(AbstractOrganizationsVO organizationsVO) {
		AbstractOrganizations orgDom = DomUtil.toDom(organizationsVO);
		orgDom.deleteObject();
		return (T)orgDom.getVo();
	}
	private <T extends AbstractOrganizationsVO> T activiateOrganization(AbstractOrganizationsVO organizationsVO) {
		AbstractOrganizations orgDom = DomUtil.toDom(organizationsVO.getObid());
		orgDom.changeStates(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);
		orgDom = DomUtil.toDom(organizationsVO.getObid());
		return (T)orgDom.getVo();
	}
	private <T extends AbstractOrganizationsVO> T inActiviateOrganization(AbstractOrganizationsVO organizationsVO) {
		AbstractOrganizations orgDom = DomUtil.toDom(organizationsVO.getObid());
		orgDom.changeStates(AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_INACTIVE);
		orgDom = DomUtil.toDom(organizationsVO.getObid());
		return (T)orgDom.getVo();
	}
}