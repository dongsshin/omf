/**
 * ===========================================
 * System Name : LGE PLM Project
 * Program ID : UserSessionUtil.java
 * ===========================================
 * Modify Date    Modifier    Description 
 * -------------------------------------------
 * 2017. 8. 23.  s_dongsshin   Initial
 * ===========================================
 */
package com.rap.common.util;

import com.rap.common.code.service.CodeRedisService;
import com.rap.omc.core.util.spring.SpringFactoryUtil;

/**
 * <pre>
 * Class : CodeRedisServiceUtil
 * Description : TODO
 * </pre>
 * 
 * @author s_dongsshin
 */
public class CodeRedisServiceUtil {
    private CodeRedisService codeRedisService;
    private static CodeRedisServiceUtil cInstance;
    
    /**
     * Singleton을 구성된 getInstance() method
     */
    private synchronized static CodeRedisServiceUtil getInstance(){
        if (cInstance == null) {
            cInstance = new CodeRedisServiceUtil();
            cInstance.codeRedisService = (CodeRedisService)SpringFactoryUtil.getBean("codeRedisService");
        }
        return cInstance;
    }
    public static void load2RedisCodeMasterAll(){
        getInstance().codeRedisService.load2RedisCodeMasterAll();
    }
    public static void load2RedisCodeDetailsAll(){
        getInstance().codeRedisService.load2RedisCodeDetailsAll();
    }
    public static void load2RedisCodeDetails(String codeMasterNames){
        getInstance().codeRedisService.load2RedisCodeDetails(codeMasterNames);
    }
}