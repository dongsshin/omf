/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : BusinessUnitUtil.java
 * ===========================================
 * Modify Date    Modifier    Description
 * -------------------------------------------
 * 2015. 9. 16.  jongjung.kwon   Initial
 * ===========================================
 */
package com.rap.common.util;

import com.rap.api.object.common.organization.model.BusinessUnitVO;
import com.rap.api.object.common.organization.model.DivisionUnitVO;
import com.rap.api.object.common.organization.model.PlantUnitVO;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.dom.ObjectRoot;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import com.rap.omc.util.OqlBuilderUtil;
import com.rap.omc.util.OqlParameter;
import com.rap.omc.util.StrUtil;
import org.springframework.util.StringUtils;

import java.util.List;




/**
 * <pre>
 * Class : BusinessUnitUtil
 * Description : TODO
 * </pre>
 *
 * @author jongjung.kwon
 */
public class BusinessUnitUtil {

    public static String getBusinessUnit(){
        return ThreadLocalUtil.getString(ThreadLocalUtil.KEY.businessUnit, "");
    }

    /**
     * Site 기준으로 BusinessUnitCode 조회
     * @param site
     * @return
     */
    public static String getBusinessUnit( String site ){
        String businessUnitCode = "";

        if( !StringUtils.isEmpty(site) ){
            PlantUnitVO plantUnitVO = ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_PLANTUNIT, site);
            if( plantUnitVO != null && !StrUtil.isEmpty(plantUnitVO.getDivisionCode())){
            	DivisionUnitVO divisionUnitVO = ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_DIVISIONUNIT, plantUnitVO.getDivisionCode());
                businessUnitCode = divisionUnitVO.getBusinessUnitCode();
            }
        }
        return businessUnitCode;
    }

    /**
     * Site 기준으로 BusinessUnitCode 조회
     * @param site
     * @return
     */
    public static String getDivisionUnit( String site ){
        String businessCode = "";
        if( !StringUtils.isEmpty(site) ){
            PlantUnitVO plantUnitVO = ObjectRoot.findObject(AppSchemaCommonConstants.BIZCLASS_PLANTUNIT, site);
            if( plantUnitVO != null ){
                businessCode = plantUnitVO.getDivisionCode();
            }
        }

        return businessCode;
    }

    /**
     * 사용자 BusinessUnitVO 목록 조회
     * @param
     * @return
     */
    public static List<BusinessUnitVO> getBusinessUnitList(){
        OqlParameter oqlParameter = new OqlParameter();
        OqlBuilderUtil.constructWherePattern(oqlParameter,"states", GlobalConstants.OQL_OPERATOR_EQUAL,AppSchemaCommonConstants.STATE_ACTIVE_INACTIVE_ACTIVE);
        return BusinessObjectMaster.findObjects(AppSchemaCommonConstants.BIZCLASS_BUSINESSUNIT,getBusinessUnit(),"",oqlParameter.getWherePattern(),oqlParameter.getParamPattern(),0);
    }
}
