package com.rap.common.code.controller;

import com.constants.GlobalCommonConstants;
import com.event.publish.vo.EventCodeVO;
import com.rap.api.object.common.code.model.CodeDetailVO;
import com.rap.api.object.common.code.model.CodeMasterVO;
import com.rap.api.object.common.organization.model.AbstractOrganizationsVO;
import com.rap.api.object.common.organization.model.BusinessUnitVO;
import com.rap.api.object.common.organization.model.CompanyVO;
import com.rap.api.object.common.organization.model.DivisionUnitVO;
import com.rap.api.object.foundation.dom.BusinessObjectMaster;
import com.rap.api.object.foundation.model.ObjectRootVO;
import com.rap.common.code.model.CParmCodeDetailVO;
import com.rap.common.code.model.CodeSampleData;
import com.rap.common.code.service.CodeRedisService;
import com.rap.common.code.service.CodeService;
import com.rap.common.constants.AppSchemaCommonConstants;
import com.rap.common.publish.code.CodeObjectEvent;
import com.rap.common.util.CodeRedisServiceUtil;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.controller.model.CParmSyncCodeSetVO;
import com.rap.omc.core.util.DomUtil;
import com.rap.omc.dataaccess.paging.model.OmfPagingList;
import com.rap.omc.dataaccess.paging.model.PagingEntity;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.framework.annotation.OMFCrud;
import com.rap.omc.framework.annotation.OmfAuthority;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.publish.EventPublishUtil;
import com.rap.omc.framework.publish.classes.handler.ClassFileServiceEventHandler;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.Parameters;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
public class CommonCodeController extends RestBaseController {
    private static final Logger log = LoggerFactory.getLogger(CommonCodeController.class);
    private final String ERR_MSG_CODE_GET_LIST = "common.error.code.list.general";
    private final String ERR_MSG_CODE_GET = "common.error.code.general";
    private final String ERR_MSG_CODE_ACTIVATE = "common.error.code.activate.general";
    private final String ERR_MSG_CODE_INACTIVATE = "common.error.code.inactivate.general";
    private final String ERR_MSG_CODE_GET_ALL = "common.error.code.get.all.general";
    private final String ERR_MSG_CODE_GET_BY_SCOPE = "common.error.code.get.scope.general";
    private final String ERR_MSG_CODE_GET_BY_STATE = "common.error.code.get.state.general";
    private final String ERR_MSG_CODE_GET_RANGE_LIST = "common.error.code.get.range.general";
    private final String ERR_MSG_CODE_GET_SUB_CLASS_LIST = "common.error.code.get.class.list.general";
    private final String ERR_MSG_CODE_GET_STATE_LIST = "common.error.code.get.state.list.general";
    private final String ERR_MSG_CODE_GET_POLICY_LIST = "common.error.code.get.policy.list.general";
    private final String ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST = "common.error.code.get.org.structure.general";

    private final String MSG_PARM_CODE_MASTER = "Code Master";
    private final String MSG_PARM_CODE_DETAIL = "Code";

    @Autowired
    private CodeService codeService;

    @Autowired
    private UserSession userSession;
    @Autowired
    private CodeRedisService codeRedisService;

    /**************************************★★★ Code Master Create ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.(Swagger에서 테스트할 수 있도록 Example 에 테스트 데이하도록 함
    @Operation(summary  = "Code Master를 Creation하는 API",
            description  = "■Parameter"
                    +"<br>⊙ codeMasterJsonVO : CodeMasterVO 대한 Json을 Parameter로 넘겨주면 된다.<br> VO의 className의 속성에 반드시 해당 Object의 Class명을 넘겨줘야 한다."
                    +"<br>■Return   : 생성되어진 CodeMasterVO"
                    +"<br>============= Example ============="
                    +"<br>▶codeMasterJsonVO: "
                    +"<br>" + CodeSampleData.CODE_MASTER_JSON_CREATE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    //Operation의 Example외에 추가적인 테스트 데이터를 관리하기 위해 Parameter에 대한 정의 및 Example을 작성하도록 함.
    @Parameters({
            @Parameter(name = "codeMasterJsonVO",
                    description = "생성하고자하는 CodeMasterVO Json",
                    example = "CodeMasterVO codeMasterJsonVO:" + CodeSampleData.CODE_MASTER_JSON_CREATE)})
    //권한 Check와 관련된 정보를 정의함
    //target = true//Check대상인지
    //checkItem = "system.schema.authority"//권한 Check를 관리할 대상 정의, checkItem을 대해서 사용자/Group/Role을 할당할 수 있음
    //crudTypes = {OMFCrud.KEY.Create, OMFCrud.KEY.Modify, OMFCrud.KEY.Delete} 본 기능이 어떠한 작업(CRUD 관점)을 하는 지 정의
    //users = {"XP3866"}//Optional, 초기 정의시 항상 권한을 줄 사용자를 정의할 수 있다.
    //roles = {"System Administration Role"} //Optional, 초기 정의시 항상 권한을 줄 Role을 정의할 수 있다.
    //groups = {"Administration Group"}//Optional, 초기 정의시 항상 권한을 줄 Group을 정의할 수 있다.
    //users,roles,groups은 Online에서 추가 관리할 수 있음. 여기에 정의하는 것은 실제 자동으로 Database에 저장되어짐(Online에서 관리되어지는 것과 동일), 삭제는 관리하지 않고
    //추가만 되어지는 형식임. 삭제가 필요한 경우 Online 프로그램에서 삭제하면 됨.
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Create},
            users = {"XP3866"},
            roles = {"System Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codemaster",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createCodeMaster(@RequestBody CodeMasterVO codeMasterJsonVO) {
        try{
            ObjectRootVO objVO = codeService.txnCreateCodeMaster(codeMasterJsonVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,MSG_PARM_CODE_MASTER);
        }
    }
    /**************************************★★★ Code Master Getting ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.(Swagger에서 테스트할 수 있도록 Example 에 테스트 데이하도록 함
    @Operation(summary  = "Code Master 상세조회하는 API",
            description  = "■Parameter"
                    +"<br>⊙ masterCode : Code Master Name"
                    +"<br>■Return   : 조회되어진 CodeMasterVO"
                    +"<br>============= Example ============="
                    +"<br>▶masterCode: TEST-DSS-01"
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    //Operation의 Example외에 추가적인 테스트 데이터를 관리하기 위해 Parameter에 대한 정의 및 Example을 작성하도록 함.
    @Parameters({
            @Parameter(name = "masterCode",
                    description = "죄회하고자하는 Code Master Name",
                    example = "String masterCode:TEST-DSS-01")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read}
    )
    @RequestMapping(value = "/common/code/codemaster/{masterCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?>  getCodeMaster(@PathVariable(name="masterCode",required = true) String masterCode) {
        try{
            CodeMasterVO objVO = codeService.getCodeMaster(masterCode);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,MSG_PARM_CODE_MASTER);
        }
    }
    /**************************************★★★ Code Master Modify ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Master를 수정하는 API",
            description  = "■Parameter"
                    +"<br>⊙ codeMasterJsonVO : CodeMasterVO 대한 Json을 Parameter로 넘겨주면 된다.<br> VO의 obid 속성을 반드시 넘겨줘야 한다."
                    +"<br>■Return   : 수정되어진 CodeMasterVO"
                    +"<br>============= Example ============="
                    +"<br>▶codeMasterJsonVO: "
                    +"<br>" + CodeSampleData.CODE_MASTER_JSON_MODIFY
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "codeMasterJsonVO",
                    description = "생성하고자하는 CodeMasterVO Json",
                    example = "CodeMasterVO codeMasterJsonVO:" + CodeSampleData.CODE_MASTER_JSON_MODIFY)
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Modify},
            users = {"XP3866"},
            roles = {"System Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codemaster",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyCodeMaster(@RequestBody CodeMasterVO codeMasterJsonVO) {
        try{

            ObjectRootVO objVO = codeService.txnModifyCodeMaster(codeMasterJsonVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_MODIFY,e,MSG_PARM_CODE_MASTER);
        }
    }
    /**************************************★★★ Code Master Delete ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Master를 삭제하는 API",
            description  = "■Parameter"
                    +"<br>⊙ codeMasterJsonVO : CodeMasterVO 대한 Json을 Parameter로 넘겨주면 된다.<br> VO의 obid 속성을 반드시 넘겨줘야 한다."
                    +"<br>■Return   : 삭제되어진 CodeMasterVO"
                    +"<br>============= Example ============="
                    +"<br>▶codeMasterJsonVO: "
                    +"<br>" + CodeSampleData.CODE_MASTER_JSON_DELETE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "codeMasterJsonVO",
                    description = "삭제하고자하는 CodeMasterVO Json",
                    example = "CodeMasterVO codeMasterJsonVO:" + CodeSampleData.CODE_MASTER_JSON_DELETE)
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Delete},
            users = {"XP3866"},
            roles = {"System Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codemaster",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> deleteCodeMaster(@RequestBody CodeMasterVO codeMasterJsonVO) {
        try{
            ObjectRootVO objVO = codeService.txnDeleteCodeMaster(codeMasterJsonVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_MODIFY,e,MSG_PARM_CODE_MASTER);
        }
    }
    /**************************************★★★ Code Master 리스트 조회(No Paging) ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Master 리스트를 조회하는 API",
            description  = "■Parameter"
                    +"<br>============= Example ============="
                    +"<br>▶masterCodePattern: TEST*"
                    +"<br>▶codeMasterScope: Company"
                    +"<br>▶zz4_sortByPattern: @this.[names] asc,@this.[modified] desc"
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "masterCodePattern",
                    description = "죄회하고자하는 Code Master Name Pattern",
                    example = "String masterCodePattern: TEST*"),
            @Parameter(name = "codeMasterScope",
                    description = "죄회하고자하는 Code Master 의 Scope(Organization)",
                    example = "String codeMasterScope: Company"),
            @Parameter(name = "zz4_sortByPattern",
                    description = "Sort By Pattern",
                    example = "String zz4_sortByPattern: @this.[names] asc,@this.[modified] desc")
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read}
    )
    @RequestMapping(value = "/common/code/codemasters",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeMasterList(@RequestParam(name="masterCodePattern"   ,required = false,defaultValue = "Sample)Test*") String masterCodePattern,
                                                             @RequestParam(name="codeMasterScope"     ,required = false,defaultValue = "Company") String codeMasterScope,
                                                             @RequestParam(name="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{
            CodeMasterVO searchVO = new CodeMasterVO();
            searchVO.setNames(masterCodePattern);
            searchVO.setCodeMasterScope(codeMasterScope);
            searchVO.setOutDataAttributeValue(GlobalConstants.MAP_KEY_sortByPattern,sortByPattern);
            List<CodeMasterVO> objVOList = codeService.getCodeMasterList(searchVO,null);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_FIND,e,MSG_PARM_CODE_MASTER);
        }
    }
    /**************************************★★★ Code Master 리스트 조회(Paging) ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Master 리스트를 조회하는 API(Paging)",
            description  = "조회 조건에 맞는 Code Master를 조회한다.(Paging처리)"
            + "<br>■Parameter"
            +"<br>============= Example ============="
            +"<br>▶masterCodePattern:TEST*"
            +"<br>▶codeMasterScope: Company"
            +"<br>▶zz1_targetRow: 1"
            +"<br>▶zz2_rowSize: 30"
            +"<br>▶zz3_currentPage: 1"
            +"<br>▶zz4_sortByPattern: @this.[names] asc,@this.[modified] desc"
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "masterCodePattern",
                    description = "죄회하고자하는 Code Master Name Pattern",
                    example = "String masterCodePattern:TEST*"),
            @Parameter(name = "codeMasterScope",
                    description = "죄회하고자하는 Code Master 의 Scope(Organization)",
                    example = "String codeMasterScope: Company"),
            @Parameter(name = "zz1_targetRow",
                    description = "시작 Row",
                    example = "int zz1_targetRow: 1"),
            @Parameter(name = "zz2_rowSize",
                    description = "Row 크기",
                    example = "int zz2_rowSize: 30"),
            @Parameter(name = "zz3_currentPage",
                    description = "현재 Page",
                    example = "int zz3_currentPage: 1"),
            @Parameter(name = "zz4_sortByPattern",
                    description = "Sort By Pattern",
                    example = "String zz4_sortByPattern:@this.[names] asc,@this.[modified] desc")
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read}
    )
    @RequestMapping(value = "/common/code/codemasters/paging",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeMasterListPaging(@RequestParam(name="masterCodePattern"   ,required = false,defaultValue = "Sample)Test*") String masterCodePattern,
                                                                   @RequestParam(name="codeMasterScope"     ,required = false,defaultValue = "Company") String codeMasterScope,
                                                                   @RequestParam(name="zz1_targetRow"       ,required = true ,defaultValue = "1") int targetRow,
                                                                   @RequestParam(name="zz2_rowSize"         ,required = true ,defaultValue = "30") int rowSize,
                                                                   @RequestParam(name="zz3_currentPage"     ,required = true ,defaultValue = "1") int currentPage,
                                                                   @RequestParam(name="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{
            CodeMasterVO searchVO = new CodeMasterVO();
            searchVO.setNames(masterCodePattern);
            PagingEntity pagingEntity = new PagingEntity(targetRow,rowSize,currentPage,sortByPattern);

            searchVO.setCodeMasterScope(codeMasterScope);
            List<CodeMasterVO> objVOList = codeService.getCodeMasterList(searchVO,pagingEntity);
            OmfPagingList<CodeMasterVO> pagingList = (OmfPagingList<CodeMasterVO>)objVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingList.getPagingEntity());
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,pagingList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_FIND,e,MSG_PARM_CODE_MASTER);
        }
    }

    /**************************************★★★ Code Detail Create ★★★ **********************************************/
    //Create
    //Swagger를 사용하기 위해서는 바로 Value Object(CodeDetailVO codeDetailVO)로 선언하면 비정상적임
    //HashMap<String,Object> codeDetailMap를 사용하면 정상적으로 UI가 Generation 되어짐. 대신 DomUtil.makeVO(codeDetailMap)와 같이 VO를 만들어야 함.
    //Swagger를 사용하지 않을거면 CodeDetailVO codeDetailVO로 Parameter를 정의할 수 있음
    //DomUtil.makeVO를 사용하는 경우 반드시 className에 정의되어진 Class Name의 값이 있어야 함.
/*
    @RequestMapping(value = "/common/codeDetail",method= {RequestMethod.POST,RequestMethod.OPTIONS},produces = "application/json; charset=utf-8")

    public ResponseEntity<?> createCodeDetail(@OMFJsonResolver("codeDetailVO") CodeDetailVO codeDetailVO,
                                              //@OMFJsonResolver("codeDetailVO") HashMap<String,Object> codeDetailMap,
                                              @OMFJsonResolver("orgList") ArrayList<String> orgList) {
        try{
            ObjectRootVO objVO = codeService.txnCreateCodeDetail(codeDetailVO.getNames(), codeDetailVO,orgList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in creating Code Detail!",e);
        }
    }
*/
    /**************************************★★★ Code Detail Create ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail를 생성하는 API",
            description  = "■Parameter"
                    +"<br>⊙ cParmCodeDetailVO : CParmCodeDetailVO 대한 Json을 Parameter로 넘겨주면 된다."
                    +"<br>■Return   : 생성되어진 CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶cParmCodeDetailVO: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_CREATE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "cParmCodeDetailVO",
                    description = "생성하고자 하는 Code Detail Json",
                    example = "CParmCodeDetailVO cParmCodeDetailVO:" + CodeSampleData.CODE_DETAIL_JSON_CREATE)
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Create},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail",method= {RequestMethod.POST},produces = "application/json; charset=utf-8")
    public ResponseEntity<?> createCodeDetail(@RequestBody CParmCodeDetailVO cParmCodeDetailVO) {
        try{
/*
            StringBuffer wherePattern  = new StringBuffer();
            StringBuffer paramPattern  = new StringBuffer();


            OqlBuilderUtil.constructWherePattern(wherePattern, paramPattern, "@this.[names]",GlobalConstants.OQL_OPERATOR_EQUAL,"TEST-DSS-01");
            List<CodeDetailVO> list = BusinessObject.findObjects(AppSchemaCommonConstants.BIZCLASS_CODEDETAIL,wherePattern.toString(),paramPattern.toString());

            List<ObjectRootVO> rel1List1 = ObjectRoot.getRelationshipSet(list,AppSchemaCommonConstants.RELCLASS_CODE2ORGANIZATION,AppSchemaCommonConstants.BIZCLASS_COMPANY,GlobalConstants.FLAG_TYPE_TO);
            ObjectRoot.deleteObjectSetBatch(rel1List1);
            List<ObjectRootVO> rel1List2 = ObjectRoot.getRelationshipSet(list, AppSchemaCommonConstants.RELCLASS_CODEMASTER2CODE,AppSchemaCommonConstants.BIZCLASS_CODEMASTER,GlobalConstants.FLAG_TYPE_FROM);
            ObjectRoot.deleteObjectSetBatch(rel1List2);

            ObjectRoot.deleteObjectSetBatch(list);
*/

            /*
            for(CodeDetailVO vo : list){
                CodeDetail dom = new CodeDetail(vo);
                dom.deleteObject();
            }

             */

            List<String> orgList = cParmCodeDetailVO.getOrgList();
            CodeDetailVO codeDetailVO = DomUtil.copyAttributeAll(cParmCodeDetailVO,new CodeDetailVO());
            CodeDetailVO objVO = codeService.txnCreateCodeDetail(codeDetailVO.getNames(), codeDetailVO,cParmCodeDetailVO.getOrgList());
            CodeRedisServiceUtil.load2RedisCodeDetails(codeDetailVO.getNames());
            EventPublishUtil.publishEvent(new CodeObjectEvent(this,convertEventUserVO(codeDetailVO)));// 이벤트 발생시키기

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CREATE,e,MSG_PARM_CODE_DETAIL);
        }
    }

    /*
    //Modify
    @RequestMapping(value = "/common/codeDetail/",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyCodeDetail(@OMFJsonResolver("codeDetailVO") CodeDetailVO codeDetailVO,
                                                            @OMFJsonResolver("codeDetailVO") List<String> orgList) {
        try{
            CodeDetailVO objVO = codeService.txnModifyCodeDetail(codeDetailVO,orgList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);

        }catch (Exception e){
            throw new ResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in modifying Code Detail!",e);
        }
    }
    */
    /**************************************★★★ Code Detail Modify ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail를 수정하는 API",
            description  = "■Parameter"
                    +"<br>⊙ cParmCodeDetailVO : CParmCodeDetailVO 대한 Json을 Parameter로 넘겨주면 된다."
                    +"<br>■Return   : 숮되어진 CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶cParmCodeDetailVO: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_MODIFY
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "cParmCodeDetailVO",
                    description = "수정하고자 하는 Code Detail Json",
                    example = "CParmCodeDetailVO cParmCodeDetailVO:" + CodeSampleData.CODE_DETAIL_JSON_MODIFY)
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Modify},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyCodeDetail(@RequestBody CodeDetailVO codeDetailVO) {
        try{
            List<String> orgList = codeDetailVO.getOutDataAttributeValue("orgList");
            CodeDetailVO objVO = codeService.txnModifyCodeDetail(codeDetailVO,orgList);
            CodeRedisServiceUtil.load2RedisCodeDetails(codeDetailVO.getNames());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_MODIFY,e,MSG_PARM_CODE_DETAIL);
        }
    }

    /**************************************★★★ Code Detail Delete ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail를 삭제하는 API",
            description  = "■Parameter"
                    +"<br>⊙ codeDetailVO : CodeDetailVO 대한 Json을 Parameter로 넘겨주면 된다."
                    +"<br>■Return   : 삭제되어진 CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶cParmCodeDetailVO: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_DELETE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "codeDetailVO",
                    description = "삭제하고자 하는 Code Detail Json",
                    example = "CodeDetailVO codeDetailVO:" + CodeSampleData.CODE_DETAIL_JSON_DELETE)
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Delete},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> deleteCodeDetail(@RequestBody CodeDetailVO codeDetailVO) {
        try{
            CodeDetailVO objVO = codeService.txnDeleteCodeDetail(codeDetailVO);
            CodeRedisServiceUtil.load2RedisCodeDetails(codeDetailVO.getNames());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_DELETE,e,MSG_PARM_CODE_DETAIL);
        }
    }
    /**************************************★★★ Code Detail Detail(obid) ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail Get Info API",
            description  = "■Parameter"
                    +"<br>⊙ obid : CodeDetailVO의 obid"
                    +"<br>■Return   : CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶cParmCodeDetailVO: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_DELETE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "obid",
                    description = "Code Detail의 Object Id",
                    example = "String obid:" + "obid")
    })
    //권한 Check와 관련된 정보를 정의함
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/{obid}/",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeDetail(@PathVariable("obid") String obid) {
        try{
            CodeDetailVO objVO = codeService.getCodeDetail(obid);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,MSG_PARM_CODE_DETAIL);
        }
    }




    /**************************************★★★ Code Detail Detail(Master Code/Code) ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail Get Info API",
            description  = "■Parameter"
                    +"<br>⊙ masterCode : Master Code"
                    +"<br>⊙ code : Code"
                    +"<br>■Return   : CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶masterCode:TEST-DSS-01 "
                    +"<br>▶code: C1 "
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "masterCode",
                    description = "Master Code",
                    example = "String masterCode:" + "TEST-DSS-01"),
            @Parameter(name = "code",
                    description = "Code",
                    example = "String code:" + "C1")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/{masterCode}/{code}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeDetail(@PathVariable("masterCode") String masterCode,
                                                         @PathVariable("code") String code) {
        try{
            CodeDetailVO objVO = codeService.getCodeDetail(masterCode,code);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET,e,masterCode,code);
        }
    }
    /**************************************★★★ Code Detail Detail Activiate ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail를 Activate API",
            description  = "Activate 되어지면 해당 정보는 Redis에 Refresh반영되어짐."
                    +"<br>■Return   : 수정 CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶codeDetailVO: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_DELETE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "codeDetailVO",
                       description = "Activate하고자 Code Detail Json",
                       example = "CodeDetailVO codeDetailVO:" + CodeSampleData.CODE_DETAIL_JSON_DELETE)
    })
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Modify},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/activiate",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> activateCodeDetail(@RequestBody CodeDetailVO codeDetailVO) {
        try{
            CodeDetailVO objVO = codeService.txnActivateCodeDetail(codeDetailVO.getObid());
            CodeRedisServiceUtil.load2RedisCodeDetails(codeDetailVO.getNames());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_ACTIVATE,e,codeDetailVO.getNames(),codeDetailVO.getRevision());
        }
    }
    /**************************************★★★ Code Detail Detail Inactivate ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail를 Deactivate API",
            description  = "Inactivate 되어지면 해당 정보는 Redis에 Refresh반영되어짐."
                    +"<br>■Return   : 수정 CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶codeDetailVO: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_DELETE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "codeDetailVO",
                    description = "Inactivate 하고자 Code Detail Json",
                    example = "CodeDetailVO codeDetailVO:" + CodeSampleData.CODE_DETAIL_JSON_DELETE)
    })
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Modify},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/inActivate",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> inActivateCodeDetail(@RequestBody CodeDetailVO codeDetailVO) {
        try{
            CodeDetailVO objVO = codeService.txnInActivateCodeDetail(codeDetailVO.getObid());
            CodeRedisServiceUtil.load2RedisCodeDetails(codeDetailVO.getNames());
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVO),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_INACTIVATE,e,codeDetailVO.getNames(),codeDetailVO.getRevision());
        }
    }
    /**************************************★★★ Code Detail Detail Create/Modify/Delete ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Detail를 Create/Modify/Delete API",
            description  = "Inactivate 되어지면 해당 정보는 Redis에 Refresh반영되어짐."
                    +"<br>■Return   : 수정 CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶codeDetailVOList: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_DELETE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "codeDetailVOList",
                    description = "Create/Modify/Delete할 Json List",
                    example = "List<CodeDetailVO> codeDetailVOList:" + CodeSampleData.CODE_DETAIL_JSON_LIST)
    })
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Create,OMFCrud.KEY.Modify,OMFCrud.KEY.Delete},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?>  createModifyDeleteCodeDetailList(@RequestBody List<CodeDetailVO> codeDetailVOList) {
        try{

            codeService.txnCreateModifyDeleteCodeDetailList(codeDetailVOList);
            //TODO Very Important //CodeRedisServiceUtil.load2RedisCodeDetails(codeDetailVO.getNames());반영해야 함
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Successful Completion"),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_CUD,e,MSG_PARM_CODE_DETAIL);
        }
    }
    /**************************************★★★ Code Detail List(Code Master, Paging) ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Master에 대한 Code 리스트 조회(Paging)",
            description  = "Code Master에 대한 Code 리스트 조회(Paging)"
                    +"<br>■Return   : List<CodeDetailVO>, PagingEntity"
                    +"<br>============= Example ============="
                    +"<br>▶masterCode: TEST-DSS-01"
                    +"<br>▶codeScope: LGE"
                    +"<br>▶activeOnlyYN: Y"
                    +"<br>▶targetRow: 1"
                    +"<br>▶rowSize: 30"
                    +"<br>▶currentPage: 1"
                    +"<br>▶sortByPattern: @this.[names] asc,@this.[modified] desc"
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "masterCode",
                    description = "Master Code",
                    example = "String masterCode:" + "TEST-DSS-01"),
            @Parameter(name = "organizationCode",
                    description = "Code Scope",
                    example = "String organizationCode:" + "LGE"),
            @Parameter(name = "activeOnlyYN",
                    description = "active Only 여부",
                    example = "String activeOnlyYN:" + "Y"),
            @Parameter(name = "zz1_targetRow",
                    description = "시작 Row",
                    example = "int zz1_targetRow:" + "1"),
            @Parameter(name = "zz2_rowSize",
                    description = "Row 사이즈",
                    example = "int zz2_rowSize:" + "1"),
            @Parameter(name = "zz3_currentPage",
                    description = "Current Page 사이즈",
                    example = "int zz3_currentPage:" + "30"),
            @Parameter(name = "zz4_sortByPattern",
                    description = "Paging을 위한 Order By",
                    example = "String sortByPattern:" + "@this.[names] asc,@this.[modified] desc")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/paging/{masterCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeDetailListAllPaging(@PathVariable(name="masterCode"          ,required = true)  String masterCode,
                                                                      @RequestParam(name="organizationCode"    ,required = false) String codeScope,
                                                                      @RequestParam(name="activeOnlyYN"        ,required = false, defaultValue = "Y") String activeOnlyYN,
                                                                      @RequestParam(name="zz1_targetRow"       ,required = true ,defaultValue = "1") int targetRow,
                                                                      @RequestParam(name="zz2_rowSize"         ,required = true ,defaultValue = "30") int rowSize,
                                                                      @RequestParam(name="zz3_currentPage"     ,required = true ,defaultValue = "1") int currentPage,
                                                                      @RequestParam(name="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{
            CodeDetailVO searchVO = new CodeDetailVO();
            searchVO.setNames(masterCode);
            searchVO.setUsingOrganizationList(codeScope);
            if(!StrUtil.isEmpty(activeOnlyYN) && activeOnlyYN.equalsIgnoreCase("Y")) searchVO.setStates("Active");

            PagingEntity pagingEntity = new PagingEntity(targetRow,rowSize,currentPage,sortByPattern);
            List<CodeDetailVO> objVOList = codeService.getCodeDetailListByScope(searchVO,pagingEntity);
            OmfPagingList<CodeDetailVO> pagingList = (OmfPagingList<CodeDetailVO>)objVOList;
            Map<String,Object> map = new HashMap<String,Object>();
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_ENTITY,pagingList.getPagingEntity());
            map.put(GlobalCommonConstants.PAGING_MAP_KEY_LIST,pagingList);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,map),HttpStatus.OK);
            //return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_CODE_GET_BY_STATE,e,masterCode,codeScope,activeOnlyYN);
        }
    }
    /**************************************★★★ Code Detail List(Code Master with Organization, No Paging) ★★★ **********************************************/
    //기능명 및 설명을 입력함. Parameter에 대한 Sample 작함.
    @Operation(summary  = "Code Master에 대한 Code 리스트 조회(No Paging)",
            description  = "Code Master에 대한 Code 리스트 조회(No Paging)"
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶masterCode: "
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_DELETE
    )
    //Parameter에 대한 이름/설명/Sample값을 정의, Method의 Parameter 순서에 맞게 정의 필요
    @Parameters({
            @Parameter(name = "masterCode",
                    description = "Master Code",
                    example = "String masterCode:" + "TEST-DSS-01"),
            @Parameter(name = "zz4_sortByPattern",
                    description = "Paging을 위한 Order By",
                    example = "String zz4_sortByPattern:" + "@this.[names] asc,@this.[modified] desc")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/{masterCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeDetailListAll(@PathVariable(name="masterCode"          ,required = true)  String masterCode,
                                                                @RequestParam(name="organizationCode"    ,required = false) String codeScope,
                                                                @RequestParam(name="activeOnlyYN"        ,required = false, defaultValue = "Y") String activeOnlyYN,
                                                                @RequestParam(name="zz4_sortByPattern"   ,required = true ,defaultValue = "@this.[names] asc,@this.[modified] desc") String sortByPattern) {
        try{
            CodeDetailVO searchVO = new CodeDetailVO();
            searchVO.setNames(masterCode);
            searchVO.setUsingOrganizationList(codeScope);
            searchVO.setOutDataAttributeValue(GlobalConstants.MAP_KEY_sortByPattern,sortByPattern);
            if(!StrUtil.isEmpty(activeOnlyYN) && activeOnlyYN.equalsIgnoreCase("Y")) searchVO.setStates("Active");
            List<CodeDetailVO> objVOList = codeService.getCodeDetailListByScope(searchVO,null);

            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_CODE_GET_BY_STATE,e,masterCode,codeScope,activeOnlyYN);
        }
    }
    /**************************************★★★ Code Detail List(Code Master/Code List★★★ **********************************************/
    @Operation(summary  = "Code Master/Code List에 대한 Code 리스트 조회",
            description  = "Code Master/Code List에 대한 Code 리스트 조회"
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶masterCode: TEST-DSS-01"
                    +"<br>▶codeList: " + "[\"C1\",\"C2\",\"C3\"]"
                    +"<br>" + CodeSampleData.CODE_DETAIL_JSON_DELETE
    )
    @Parameters({
            @Parameter(name = "masterCode",
                    description = "Master Code",
                    example = "String masterCode:" + "TEST-DSS-01"),
            @Parameter(name = "codeList",
                    description = "Code List",
                    example = "String codeList:" + "[\"C1\",\"C2\",\"C3\"]")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/{masterCode}",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCodeDetailList(@PathVariable("masterCode") String masterCode,
                                                             @RequestBody List<String> codeList) {
        try{
            Set<String> codeSet = StrUtil.convertListToSet(codeList);
            List<CodeDetailVO> objVOList = codeService.getCodeDetailListByCodeSet(masterCode, codeSet);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_LIST,e,masterCode,codeList);
        }
    }
    /**************************************★★★ Attribute Range ★★★ **********************************************/
    @Operation(summary  = "Attribute value list조회",
            description  = "Schema에 정의되어진 Attribute value list조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶className: CodeMaster"
                    +"<br>▶attribute: " + "codeMasterScope"
                    +"<br>▶sortYN: " + "Y"
    )
    @Parameters({
            @Parameter(name = "className",
                    description = "Class Name",
                    example = "String className: CodeMaster"),
            @Parameter(name = "attribute",
                    description = "Attribute",
                    example = "String attribute:" + "codeMasterScope"),
            @Parameter(name = "sortYN",
                    description = "정열 여부",
                    example = "String sortYN:" + "Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/attribute/{className}/{attribute}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getAttributeRangeList(@PathVariable(name="className",required = true) String className,
                                                                 @PathVariable(name="attribute",required = true) String attribute,
                                                                 @RequestParam(name="sortYN"   ,required = false, defaultValue = "Y") String sortYN) {
        try{
            boolean isSort = false;
            if(!StrUtil.isEmpty(sortYN) && sortYN.equals("Y")) isSort = true;
            List<CodeDetailVO> objVOList = codeService.getAttributeRangeList(className + "." + attribute, isSort);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_CODE_GET_RANGE_LIST,e,className,attribute);
        }
    }
    /**************************************★★★ Class Name ★★★ **********************************************/
    @Operation(summary  = "ClassName하위 Class List조회",
            description  = "ClassName하위 Class List조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶className: CodeMaster"
                    +"<br>▶orderByDescription: " + "Y"
    )
    @Parameters({
            @Parameter(name = "className",
                    description = "Class Name",
                    example = "String className: CodeMaster"),
            @Parameter(name = "orderByDescription",
                    description = "정열 여부",
                    example = "String orderByDescription:" + "Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/class/{className}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getClassNameList(@PathVariable("className") String className,
                                                            @RequestParam(name = "orderByDescription", defaultValue = "Y") String orderByDesc) {
        try{
            boolean isSort = false;
            if(!StrUtil.isEmpty(orderByDesc) && orderByDesc.equals("Y")) isSort = true;
            List<CodeDetailVO> objVOList = codeService.getClassNameList(className, isSort);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_CODE_GET_SUB_CLASS_LIST,e,className);
        }
    }
    /**************************************★★★ Life Cycle State ★★★ **********************************************/
    @Operation(summary  = "Life Cycle에 대한 State를 조회",
            description  = "Life Cycle에 대한 State를 조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶lifeCycle: Inbox Task Policy"
                    +"<br>▶orderByDescription: " + "Y"
    )
    @Parameters({
            @Parameter(name = "lifeCycle",
                    description = "Life Cycle Name",
                    example = "String lifeCycle: Inbox Task Policy"),
            @Parameter(name = "orderByDescription",
                    description = "정열 여부",
                    example = "String orderByDescription:" + "Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/state/{lifeCycle}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getLifeCycleStatesList(@PathVariable("lifeCycle") String lifeCycle,
                                                                  @RequestParam(name = "orderByDescription", defaultValue = "Y") String orderByDesc) {
        try{
            List<CodeDetailVO> objVOList = codeService.getLifeCycleStatesList(lifeCycle);;
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_CODE_GET_STATE_LIST,e,lifeCycle);
        }
    }
    /**************************************★★★ Class Life Cycle★★ **********************************************/
    @Operation(summary  = "Class에 대한 Life Cycle에 대한 조회",
            description  = "Class에 대한 Life Cycle에 대한 조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶className: Users"
                    +"<br>▶orderByDescription: " + "Y"
    )
    @Parameters({
            @Parameter(name = "className",
                    description = "Class Name",
                    example = "String className: Users"),
            @Parameter(name = "orderByDescription",
                    description = "정열 여부",
                    example = "String orderByDescription:" + "Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/lifecycle/{className}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getClassPolicyList(@PathVariable("className") String className,
                                                              @RequestParam(name = "orderByDescription", defaultValue = "Y") String orderByDesc) {
        try{
            List<CodeDetailVO> objVOList = codeService.getClassPolicyList(className);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR, ERR_MSG_CODE_GET_POLICY_LIST,e,className);
        }
    }
    /**************************************★★★ Organization(Company)★★★ **********************************************/
    @Operation(summary  = "Company List 조회",
            description  = "Company List 조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶orderByDescription: " + "Y"
    )
    @Parameters({
            @Parameter(name = "isActiveOnlyYn",
                    description = "Active Only 여부",
                    example = "String isActiveOnlyYn: Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/companys/{isActiveOnlyYn}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCompanyListAll(@PathVariable("isActiveOnlyYn") String isActiveOnlyYn) {
        try{
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getCompanyListAll(isActiveOnly);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code",e);
        }
    }
    /**************************************★★★ Organization(Company/organizationCode)★★★ **********************************************/
    @Operation(summary  = "Company 조회",
            description  = "Company를 조회한다."
                    +"<br>■Return   : CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶organizationCode: " + "LGE"
    )
    @Parameters({
            @Parameter(name = "organizationCode",
                    description = "Organization Code",
                    example = "String organizationCode: LGE")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/company/{organizationCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getCompany(@PathVariable(name="organizationCode",required = true) String organizationCode) {
        try{
            /*
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getCompanyListAll(isActiveOnly);
            */
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVOList"),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code",e);
        }
    }
    /**************************************★★★ Organization(Business Unit)★★★ **********************************************/
    @Operation(summary  = "Business Unit 리스트 조회",
            description  = "Business Unit 리스트 조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶organizationCode: " + "LGE"
    )
    @Parameters({
            @Parameter(name = "isActiveOnlyYn",
                    description = "Active Only 여부",
                    example = "String isActiveOnlyYn: Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/businessunits",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getBusinessUnitListAll(@RequestParam(name = "isActiveOnlyYn",required = false,defaultValue = "Y") String isActiveOnlyYn) {
        try{
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getBusinessUnitListAll(isActiveOnly);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,AppSchemaCommonConstants.BIZCLASS_COMPANY);
        }
    }
    /**************************************★★★ Organization(Business Unit)★★★ **********************************************/
    @Operation(summary  = "Business Unit 조회",
            description  = "Business Unit 조회한다."
                    +"<br>■Return   : CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶organizationCode: " + "VS"
    )
    @Parameters({
            @Parameter(name = "organizationCode",
                    description = "Organization Code",
                    example = "String organizationCode: VS")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/businessunit/{organizationCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getBusinessUnit(@PathVariable(name="organizationCode",required = true) String organizationCode) {
        try{
            /*
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getBusinessUnitListAll(isActiveOnly);
            */
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVOList"),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,AppSchemaCommonConstants.BIZCLASS_COMPANY);
        }
    }
    /**************************************★★★ Organization(Division Unit)★★★ **********************************************/
    @Operation(summary  = "Division Unit 리스트 조회",
            description  = "Division Unit 리스트 조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶isActiveOnlyYn: " + "Y"
    )
    @Parameters({
            @Parameter(name = "isActiveOnlyYn",
                    description = "Active Only 여부",
                    example = "String isActiveOnlyYn: Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/divisionunits/{isActiveOnlyYn}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getDivisionUnitListAll(@RequestParam(name="isActiveOnlyYn",required = false,defaultValue = "Y") String isActiveOnlyYn) {
        try{
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getDivisionUnitListAll(isActiveOnly);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,AppSchemaCommonConstants.BIZCLASS_DIVISIONUNIT);
        }
    }
    /**************************************★★★ Organization(Division Unit)★★★ **********************************************/
    @Operation(summary  = "Division Unit 조회",
            description  = "Division Unit 조회한다."
                    +"<br>■Return   : CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶organizationCode: " + "ZZZ"
    )
    @Parameters({
            @Parameter(name = "organizationCode",
                    description = "Organization Code",
                    example = "String organizationCode: ZZZ")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/divisionunit/{organizationCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getDivisionUnit(@PathVariable(name="organizationCode",required = true) String organizationCode) {
        try{
            /*
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getDivisionUnitListAll(isActiveOnly);
            */
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVOList"),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,AppSchemaCommonConstants.BIZCLASS_DIVISIONUNIT);
        }
    }
    /**************************************★★★ Organization(Plant Unit)★★★ **********************************************/
    @Operation(summary  = "Plant Unit 리스트 조회",
            description  = "Plant Unit 리스트 조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶isActiveOnlyYn: " + "Y"
    )
    @Parameters({
            @Parameter(name = "isActiveOnlyYn",
                    description = "Active Only 여부",
                    example = "String isActiveOnlyYn: Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/plantunits",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getPlantUnitListAll(@RequestParam(name="isActiveOnlyYn",required = false,defaultValue = "Y") String isActiveOnlyYn) {
        try{
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getPlantUnitListAll(isActiveOnly);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,AppSchemaCommonConstants.BIZCLASS_PLANTUNIT);
        }
    }
    /**************************************★★★ Organization(Plant Unit)★★★ **********************************************/
    @Operation(summary  = "Plant Unit 조회",
            description  = "Plant Unit 조회한다."
                    +"<br>■Return   : CodeDetailVO"
                    +"<br>============= Example ============="
                    +"<br>▶organizationCode: " + "ZZZ.EKHQ"
    )
    @Parameters({
            @Parameter(name = "organizationCode",
                    description = "Organization Code",
                    example = "String organizationCode: ZZZ.EKHQ")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetail/plantunit/{organizationCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getPlantUnit(@PathVariable(name="organizationCode",required = true) String organizationCode) {
        try{
            /*
            boolean isActiveOnly = false;
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            List<CodeDetailVO> objVOList = codeService.getPlantUnitListAll(isActiveOnly);
            */
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVOList"),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_GEN_GET,e,AppSchemaCommonConstants.BIZCLASS_PLANTUNIT);
        }
    }
    /**************************************★★★ Organization Structure★★★ **********************************************/
    @Operation(summary  = "Organization Structure 조회",
            description  = "Organization Structure 조회한다."
                    +"<br>■Return   : List<CodeDetailVO>"
                    +"<br>============= Example ============="
                    +"<br>▶upperOrganizationCode: " + "LGE"
                    +"<br>▶isActiveOnlyYn: " + "Y"
    )
    @Parameters({
            @Parameter(name = "upperOrganizationCode",
                    description = "Upper Organization Code",
                    example = "String organizationCode: LGE"),
            @Parameter(name = "isActiveOnlyYn",
                    description = "Active Only",
                    example = "String isActiveOnlyYn: Y")
    })
    @OmfAuthority(
            target = false,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/codedetails/structure/{upperOrganizationCode}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getSubOrganizationList(@PathVariable("upperOrganizationCode") String upperOrganizationCode,
                                                                  @RequestParam(name="isActiveOnlyYn",required = false,defaultValue = "Y") String isActiveOnlyYn) {
        try{
            boolean isActiveOnly = false;
            List<CodeDetailVO> objVOList = new ArrayList<CodeDetailVO>();
            if(!StrUtil.isEmpty(isActiveOnlyYn) && isActiveOnlyYn.equals("Y")) isActiveOnly = true;
            AbstractOrganizationsVO upperOrgVO = BusinessObjectMaster.findBusinessObjectMaster(AppSchemaCommonConstants.BIZCLASS_ABSTRACTORGANIZATIONS,upperOrganizationCode);
            if(!NullUtil.isNull(upperOrgVO)){
                if(upperOrgVO instanceof DivisionUnitVO){
                    objVOList = codeService.getPlantUnitListWithDivisionUnit(upperOrgVO.getNames(),isActiveOnly);
                }else if(upperOrgVO instanceof BusinessUnitVO){
                    objVOList = codeService.getDivisionUnitListWithBusinessUnit(upperOrgVO.getNames(),isActiveOnly);
                }else if(upperOrgVO instanceof CompanyVO){
                    objVOList = codeService.getBusinessUnitListWithCompany(upperOrgVO.getNames(),isActiveOnly);
                }
            }
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,objVOList),HttpStatus.OK);

        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST,e,upperOrganizationCode);
        }
    }
    /**************************************★★★ Redis Load(Code Master) ★★★ **********************************************/
    @Operation(summary  = "Code Master Redis Refresh",
            description  = "Code Master Redis의 Code정보를 Refresh한다."
                    +"<br>■Return   : N/A"
                    +"<br>============= Example ============="
                    +"<br>▶Parameter 없음"
    )
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/redis/codemasters",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> load2RedisCodeMasterAll() {
        try{
            codeRedisService.load2RedisCodeMasterAll();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVOList"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST,e,"upperOrganizationCode");
        }
    }
    /**************************************★★★ Redis Load(Code Detail) ★★★ **********************************************/
    @Operation(summary  = "Code Detail Redis Refresh",
            description  = "Code Detail Redis의 Code정보를 Refresh한다."
                    +"<br>■Return   : N/A"
                    +"<br>============= Example ============="
                    +"<br>▶Parameter 없음"
    )
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/redis/codes",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> load2RedisCodeDetailsAll() {
        try{
            codeRedisService.load2RedisCodeDetailsAll();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"list"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST,e,"upperOrganizationCode");
        }
    }
    /**************************************★★★ Redis Load(Code Master Detail) ★★★ **********************************************/
    @Operation(summary  = "Code Detail Redis Refresh",
            description  = "Code Detail Redis의 Code정보를 Refresh한다."
                    +"<br>■Return   : N/A"
                    +"<br>============= Example ============="
                    +"<br>▶masterCode: TEST-DSS-01"
    )
    @Parameters({
            @Parameter(name = "masterCode",
                    description = "Master Code",
                    example = "String masterCode: TEST-DSS-01")
    })
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/redis/codes/{masterCode}",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> load2RedisCodeDetails(@PathVariable("masterCode") String masterCode) {
        try{
            codeRedisService.load2RedisCodeDetails(masterCode);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"objVOList"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST,e,"upperOrganizationCode");
        }
    }
    /**************************************★★★ Redis Load(Organization) ★★★ **********************************************/
    @Operation(summary  = "Organization정보 Redis Refresh",
            description  = "Organization정보 Redis의 Code정보를 Refresh한다."
                    +"<br>■Return   : N/A"
                    +"<br>============= Example ============="
                    +"<br>▶Parameter 없음"
    )
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/redis/organizations",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> load2RedisOrganizations() {
        try{
            codeRedisService.load2RedisOrganizations();
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"list"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST,e,"upperOrganizationCode");
        }
    }


    /**************************************★★★ Redis Load(Organization) ★★★ **********************************************/
    @Operation(summary  = "Organization Redis Refresh",
            description  = "Organization Redis의 Code정보를 Refresh한다."
                    +"<br>■Return   : N/A"
                    +"<br>============= Example ============="
                    +"<br>▶masterCode: LGE"
    )
    @Parameters({
            @Parameter(name = "organizationCode",
                    description = "Organization Code",
                    example = "String organizationCode: LGE")
    })
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/code/redis/organizations/{organizationCode}",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> load2RedisOrganizations(@PathVariable("organizationCode") String organizationCode) {
        try{
            codeRedisService.load2RedisOrganizations(organizationCode);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"list"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST,e,"upperOrganizationCode");
        }
    }
    /**************************************★★★ Code정보 Synch ★★★ **********************************************/
    @Operation(summary  = "Code정보 Sync",
            description  = "Code정보를 Sync한다."
                    +"<br>■Return   : N/A"
                    +"<br>============= Example ============="
                    +"<br>▶cParmSyncCodeSetVO: LGE"
    )
    @Parameters({
            @Parameter(name = "cParmSyncCodeSetVO",
                    description = "동기화할 Code의 Object Id",
                    example = "CParmSyncCodeSetVO cParmSyncCodeSetVO: LGE")
    })
    @OmfAuthority(
            target = true,
            checkItem = "common.code.management",
            crudTypes = {OMFCrud.KEY.Read},
            users = {"XP3866"},
            roles = {"System Administration Role","Business Administration Role"},
            groups = {"Administration Group"}
    )
    @RequestMapping(value = "/common/codes/sync",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> refreshSyncInfo(@RequestBody CParmSyncCodeSetVO cParmSyncCodeSetVO) {
        try{
            codeService.txnRefreshSyncInfo(cParmSyncCodeSetVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,new HashMap<String,String>()),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,ERR_MSG_CODE_GET_ORG_STRUCTURE_LIST,e,"upperOrganizationCode");
        }
    }
    private EventCodeVO convertEventUserVO(CodeDetailVO codeDetailVO){
        EventCodeVO eventCodeVO = new EventCodeVO();
        eventCodeVO.setCodeMaster(codeDetailVO.getNames());
        eventCodeVO.setObid(codeDetailVO.getObid());
        eventCodeVO.setRevision(codeDetailVO.getRevision());
        eventCodeVO.setTitles(codeDetailVO.getTitles());
        eventCodeVO.setTitlesKr(codeDetailVO.getDisplayNameKr());
        return eventCodeVO;
    }
}