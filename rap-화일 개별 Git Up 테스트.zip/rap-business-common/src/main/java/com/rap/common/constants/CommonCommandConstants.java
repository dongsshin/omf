package com.rap.common.constants;

public class CommonCommandConstants {
	//Auto Generation from Schema Upload. 
	//You cannot modify/add/delete manually
	public static final String cmdCodeMasterCreate                                                   = "cmdCodeMasterCreate";
	public static final String cmdCodeDetailCreate                                                   = "cmdCodeDetailCreate";
	public static final String cmdCodeDetailActive                                                   = "cmdCodeDetailActive";
	
	public static final String cmdCodeDetailDelete                                                   = "cmdCodeDetailDelete";
	public static final String cmdCodeDetailExcelImport                                              = "cmdCodeDetailExcelImport";
	public static final String cmdCodeDetailInactive                                                 = "cmdCodeDetailInactive";
	public static final String cmdCodeDetailUpdate                                                   = "cmdCodeDetailUpdate";
	public static final String cmdCodeManagement                                                     = "cmdCodeManagement";
	public static final String cmdCodeMaster                                                         = "cmdCodeMaster";
	
	public static final String cmdCodeMasterDelete                                                   = "cmdCodeMasterDelete";
	public static final String cmdCodeMasterMain                                                     = "cmdCodeMasterMain";
	public static final String cmdCodeMasterUpdate                                                   = "cmdCodeMasterUpdate";
}
