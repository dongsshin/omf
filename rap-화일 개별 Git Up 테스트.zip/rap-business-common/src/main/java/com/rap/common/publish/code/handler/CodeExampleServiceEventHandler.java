package com.rap.common.publish.code.handler;

import com.constants.ServiceConstants;
import com.rap.common.publish.code.CodeObjectEvent;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

@Component
public class CodeExampleServiceEventHandler extends CodeEventGenericHandler {
    private static final Logger log = LoggerFactory.getLogger(CodeExampleServiceEventHandler.class);
    public CodeExampleServiceEventHandler() {
        super(ServiceConstants.SERVICE_EXAMPLE);
    }
    @EventListener
    @Order(Ordered.HIGHEST_PRECEDENCE)
    @Async("threadPoolTaskExecutor")
    public void onMyEvent(CodeObjectEvent event) {
        if(log.isTraceEnabled()) log.trace("Call User Synchronization For " + this.getServiceName() + " Service Module Started....................");
        if(log.isTraceEnabled()) ThreadLocalUtil.print();
        try {
            super.execute(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}