package com.rap.common.user.controller;

import com.event.publish.vo.EventUserVO;
import com.rap.api.object.common.user.model.UsersVO;
import com.rap.common.publish.user.UserObjectEvent;
import com.rap.common.user.model.CUsersVO;
import com.rap.common.user.service.UsersService;
import com.rap.omc.foundation.user.model.UserSession;
import com.rap.omc.foundation.user.service.FoundationUserDetailsService;
import com.rap.omc.framework.controller.RestBaseController;
import com.rap.omc.framework.exception.OmfApplicationException;
import com.rap.omc.framework.exception.OmfResponseStatusException;
import com.rap.omc.framework.exception.StatusConstants;
import com.rap.omc.framework.publish.EventPublishUtil;
import com.rap.omc.framework.responsive.ResponseAdapter;
import com.rap.omc.util.NullUtil;
import com.rap.omc.util.StrUtil;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CommonUserController extends RestBaseController {
    @Autowired
    private FoundationUserDetailsService foundationUserDetailsService;

    @Autowired
    private UserSession userSession;

    @Autowired
    private UsersService usersService;
    @Operation(summary  = "사용자 생성",
            description  = "사용자 정보를 입력한 후 생성한다.<br>" +
                    "loadExcelOptionJson 작성시 Upload 할 Excel부분만 true로 입력하면 됨.<br>" +
                    "targetModuleSet의 값은 자기가 올리고 싶은 모듈을 입력하면 되고 변경되어진 전체를 Uplaod시에는 \"All\"를 입력하면 됨.<br>" +
                    "■cUsersVO:<br>" +
                    "{<br>" +
                    "\"businessUnit\":\"VS\"" +
                    ",<br>\"company\":\"LGE\"" +
                    ",<br>\"departmentCode\":\"LG CNS\"" +
                    ",<br>\"departmentTitles\":\"LG CNS\"" +
                    ",<br>\"departmentTitlesKor\":\"엘지씨엔스\"" +
                    ",<br>\"divisionUnit\":\"ZZZ\"" +
                    ",<br>\"departmentTitlesKor\":\"엘지씨엔스\"" +
                    ",<br>\"emailAddress\":\"test@lgcns.com\"" +
                    ",<br>\"plantUnit\":\"ZZZ@EKHQ\"" +
                    ",<br>\"userId\":\"XP3866\"" +
                    ",<br>\"userName\":\"LG CNS\"" +
                    ",<br>\"userNameKor\":\"LG CNS\"" +
                    ",<br>\"workPhoneNumber\":\"010\"" +
                    "<br>}"
    )
    @RequestMapping(value = "/common/user",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> createUser(@RequestBody CUsersVO cUsersVO){
        try{
            UsersVO usersVO = cUsersVO.convert2UsersVO();
            usersVO.setOutDataAttributeValue("cUsersVO",cUsersVO);
            usersVO = usersService.txnCreateUser(usersVO);

            //User정보가 생성되어지면 각 모듈로 사용자 정보를 Publishing한다.
            EventPublishUtil.publishEvent(new UserObjectEvent(this,convertEventUserVO(usersVO)));// 이벤트 발생시키기
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,usersVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in creating user",e);
        }
    }
    private EventUserVO convertEventUserVO(UsersVO usersVO){
        EventUserVO eventUserVO = new EventUserVO();
        eventUserVO.setObid(usersVO.getObid());
        eventUserVO.setNames(usersVO.getNames());
        eventUserVO.setDescriptions(usersVO.getDescriptions());
        return eventUserVO;
    }
    @RequestMapping(value = "/common/user",method= RequestMethod.PUT,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> modifyUser(@RequestBody UsersVO usersVO){
        try{
            usersVO = usersService.txnModifyUser(usersVO);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,usersVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code detail",e);
        }
    }
    @RequestMapping(value = "/common/user/{userid}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> getUserInfo(@PathVariable("userid") String userId){
        try{
            UsersVO usersVO = usersService.getUserInfo(userId);
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,usersVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code detail",e);
        }
    }
    @RequestMapping(value = "/common/user/{isactive}",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?>activeInactive(@RequestBody String userId, @PathVariable("isactive") String isActive){
        try{
            if(StrUtil.isEmpty(isActive)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(activeInactive) is empty.");
            isActive = isActive.toUpperCase();
            if(!StrUtil.in(isActive,"Y","N")) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(activeInactive) must be Y or N.");
            UsersVO usersVO = null;
            if(isActive.equals("Y")){
                usersVO = usersService.txnActivateUser(userId);
            }else{
                usersVO = usersService.txnInActivateUser(userId);
            }
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,usersVO), HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code detail",e);
        }
    }

    @RequestMapping(value = "/common/user/role/{userid}",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> addRole(@RequestBody List<String> roleList , @PathVariable(name="userid") String userId){
        try{
            if(StrUtil.isEmpty(userId)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(userId) is empty.");
            if(NullUtil.isNone(roleList)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(Role) is empty.");
            usersService.txnAddRole(userId,StrUtil.convertListToSet(roleList));
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code detail",e);
        }
    }

    @RequestMapping(value = "/common/user/role/{userid}",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> removeRole(@RequestBody List<String> roleList , @PathVariable(name="userid") String userId){
        try{
            if(StrUtil.isEmpty(userId)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(userId) is empty.");
            if(NullUtil.isNone(roleList)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(Role) is empty.");
            usersService.txnRemoveRole(userId,StrUtil.convertListToSet(roleList));
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code detail",e);
        }
    }

    @RequestMapping(value = "/common/user/group/{userid}",method= RequestMethod.POST,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> addGroup(@RequestBody List<String> groupList , @PathVariable(name="userid") String userId){
        try{
            if(StrUtil.isEmpty(userId)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(userId) is empty.");
            if(NullUtil.isNone(groupList)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(Group) is empty.");
            usersService.txnAddGroup(userId,StrUtil.convertListToSet(groupList));
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code detail",e);
        }
    }

    @RequestMapping(value = "/common/user/group/{userid}",method= RequestMethod.DELETE,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> removeGroup(@RequestBody List<String> groupList , @PathVariable(name="userid") String userId){
        try{
            if(StrUtil.isEmpty(userId)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(userId) is empty.");
            if(NullUtil.isNone(groupList)) throw new OmfApplicationException(StatusConstants.BAD_REQUEST,"Input value(Group) is empty.");
            usersService.txnRemoveGroup(userId,StrUtil.convertListToSet(groupList));
            return new ResponseEntity(ResponseAdapter.responseMapper(RETURN_KEY,"Success"),HttpStatus.OK);
        }catch (Exception e){
            throw new OmfResponseStatusException(StatusConstants.INTERNAL_SERVER_ERROR,"Error Occurred in Getting Code detail",e);
        }
    }
    /*
    @RequestMapping(value = "/common/user/autoLogin/{userid}/{pwd}",method= RequestMethod.GET,produces = "application/json; charset=utf-8")
    public @ResponseBody ResponseEntity<?> autoLogin(HttpServletRequest request,
                                                     @PathVariable String userid,
                                                     @PathVariable String pwd) throws Exception{
        UserDetails userDetails = foundationUserDetailsService.loadUserByUsername("XP3866");
        UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(userDetails,userDetails.getPassword());
        SecurityContext securityContext = SecurityContextHolder.getContext();
        securityContext.setAuthentication(usernamePasswordAuthenticationToken);
        HttpSession session = request.getSession(true);
        session.setAttribute("SPRING_SECURITY_CONTEXT", securityContext);
        request.setAttribute("JSESSIONID",session);
        return null;
    }
    */
}
