package com.rap.common.publish.user.handler;

import com.constants.ServiceConstants;
import com.rap.common.publish.user.UserObjectEvent;
import com.rap.omc.core.util.omc.ThreadLocalUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

//@Component
public class UserFileServiceEventHandler extends UserEventGenericHandler {
    private static final Logger log = LoggerFactory.getLogger(UserFileServiceEventHandler.class);
    public UserFileServiceEventHandler() {
        super(ServiceConstants.SERVICE_EXAMPLE);
    }
    //@EventListener
    //@Order(Ordered.HIGHEST_PRECEDENCE+8)
    //@Async("threadPoolTaskExecutor")
    public void onMyEvent(UserObjectEvent event) {
        if(log.isTraceEnabled()) log.trace("Call User Synchronization For " + this.getServiceName() + " Service Module Started....................");
        if(log.isTraceEnabled()) ThreadLocalUtil.print();
        if(true) return;
        try {
            super.execute(event);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}