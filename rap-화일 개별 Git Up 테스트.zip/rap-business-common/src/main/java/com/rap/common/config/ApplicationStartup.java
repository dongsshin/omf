package com.rap.common.config;

import com.rap.common.code.service.CodeRedisService;
import com.rap.config.OmfApplicationStartupBase;
import com.rap.omc.constants.GlobalConstants;
import com.rap.omc.util.CommonCodeSyncUtil;
import com.rap.omc.util.PropertiesUtil;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.stereotype.Component;

@Component
public class ApplicationStartup extends OmfApplicationStartupBase implements InitializingBean {
    @Autowired
    private CodeRedisService codeRedisService;
    @Override
    public void onApplicationEvent(final ApplicationReadyEvent event) {
        //반드시 super를 Call해야 한다.
        super.onApplicationEvent(event);

        /********************************************************************************************/
        /******************* 모듈 Applicaiton인 경우에만 Load하도록 수정 필요 *****************************/
        /********************************************************************************************/

        //Code Master 정보 Load to Redis
        codeRedisService.load2RedisCodeMasterAll();
        //Code 정보 Load to Redis
        codeRedisService.load2RedisCodeDetailsAll();
        //Org 정보 Load to Redis
        codeRedisService.load2RedisOrganizations();
    }
    @Override
    public void afterPropertiesSet() throws Exception {
        this.setDatasourceName(PropertiesUtil.getString(GlobalConstants.RAP_MODULE_PROPERTY_DATASOURCE_NAME));
    }
}