package com.rap.common.publish.code.handler;


import com.rap.omc.framework.publish.GenericEventHandler;

public class CodeEventGenericHandler extends GenericEventHandler {
    public CodeEventGenericHandler(String serviceName) {
        super(serviceName, "/mybatis/mapper/foundation/code/eventsynch");
    }
}