package com.rap.common.user.model;

import com.rap.api.object.common.user.model.UsersVO;
import com.rap.common.user.UsersConstants;
import com.rap.omc.util.StrUtil;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.ArrayList;
import java.util.HashMap;

@Setter
@Getter
@ToString
public class CUsersVO {
    private String userId ;
    private String userName;
    private String userNameKor;
    private String workPhoneNumber ;
    private String emailAddress    ;
    private String departmentCode  ;
    private String departmentTitles;
    private String company;
    private String businessUnit;
    private String divisionUnit;
    private String plantUnit;
    private String departmentTitlesKor;
    private ArrayList<String> roleList = new ArrayList<String>();
    private ArrayList<String> groupList = new ArrayList<String>();
    private HashMap<String,String> properties = new HashMap<String,String>();

    public UsersVO convert2UsersVO(){
        UsersVO usersVO = new UsersVO();
        usersVO.setNames(this.userId);
        usersVO.setDepartmentCode(this.departmentCode);
        usersVO.setDepartmentTitles(this.departmentTitles);
        usersVO.setEmailAddress(this.emailAddress);
        usersVO.setWorkPhoneNumber(this.workPhoneNumber);
        usersVO.setDescriptions(this.userNameKor);
        usersVO.setTitles(this.userName);
        usersVO.setOutDataAttributeValue(UsersConstants.MAP_KEY_ROLE,StrUtil.convertListToSet(this.roleList));
        usersVO.setOutDataAttributeValue(UsersConstants.MAP_KEY_GROUP,StrUtil.convertListToSet(this.groupList));
        usersVO.setOutDataAttributeValue(UsersConstants.MAP_KEY_PROPERTY,properties);

        HashMap<String,String> orgMap = new HashMap<String,String>();
        orgMap.put(UsersConstants.MAP_KEY_company,company);
        orgMap.put(UsersConstants.MAP_KEY_businessUnit,businessUnit);
        orgMap.put(UsersConstants.MAP_KEY_divisionUnit,divisionUnit);
        orgMap.put(UsersConstants.MAP_KEY_plantUnit,plantUnit);
        usersVO.setOutDataAttributeValue(UsersConstants.MAP_KEY_ORGANIZATION,orgMap);
        return usersVO;
    }
}