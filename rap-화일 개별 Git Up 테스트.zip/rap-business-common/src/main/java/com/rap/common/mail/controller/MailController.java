/**
 * ===========================================
 * System Name : LGE GPDM Project
 * Program ID : MailController.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2015. 4. 29. youngmi.won Initial
 * ===========================================
 */
package com.rap.common.mail.controller;

import com.rap.common.mail.service.MailService;
import com.rap.omc.framework.controller.BaseController;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Resource;



/**
 * <pre>
 * Class : MailController
 * Description : 메일발송 관련 기능 구현 Controller
 * </pre>
 * 
 * @author youngmi.won
 */
//@Controller

public class MailController extends BaseController {

    @Resource(name = "mailService")
    private MailService mailService;

    /**
     * Send warning e-mail
     * @param obid
     * @param map
     * @return
     */
    /*
	@RequestMapping( "/common/mail/sendMailToApprover.do" )
    public String sendMailToApprover( String obid, ModelMap map ){
        if( !StringUtils.isEmpty( obid ) ){
            mailService.sendMailForDelayEco( obid );
        }
        
        return GlobalConstants.AJAX_VIEW;
    }
     */
}
