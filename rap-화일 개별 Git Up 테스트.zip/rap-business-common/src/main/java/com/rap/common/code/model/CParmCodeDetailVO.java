package com.rap.common.code.model;

import com.rap.api.object.foundation.model.CPamBaseModel;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Setter
@Getter
public class CParmCodeDetailVO extends CPamBaseModel {
    private String names;
    private String revision;
    private String descriptions;
    private String titles;
    private String displayNameKr;
    private Boolean isDefault;
    private Integer sequences;
    private String subCodeMaster;
    private String attribute01;
    private String attribute02;
    private String attribute03;
    private String attribute04;
    private String attribute05;
    private String attribute06;
    List<String> orgList;
}