/**
 * ===========================================
 * System Name : LGE GPLM Project
 * Program ID : MailService.java
 * ===========================================
 * Modify Date Modifier Description
 * -------------------------------------------
 * 2017. 8. 28. youngmi.won Initial
 * ===========================================
 */
package com.rap.common.organization.service;

import com.rap.api.object.common.organization.model.*;

import java.util.List;

/**
 * 
 * <pre>
 * Class : MailService
 * Description : TODO
 * </pre>
 * 
 * @author youngmi.won
 */

public interface OrganizationService {
    public CompanyVO txnCreateCompany(CompanyVO companyVO);
    public CompanyVO txnModifyCompany(CompanyVO companyVO);
    public CompanyVO txnDeleteCompany(CompanyVO companyVO);
    public CompanyVO txnActiviateCompany(CompanyVO companyVO);
    public CompanyVO txnInActiviateCompany(CompanyVO companyVO);

    public List<CompanyVO> getCompanyList();
    public CompanyVO getMainCompany();
    public CompanyVO getCompany(String names);
    public List<CompanyVO> getBusinessUnitList(String companyNames, boolean isActivieOnly);

    public BusinessUnitVO txnCreateBusinessUnit(BusinessUnitVO businessUnitVO);
    public BusinessUnitVO txnModifyBusinessUnit(BusinessUnitVO businessUnitVO);
    public BusinessUnitVO txnDeleteBusinessUnit(BusinessUnitVO businessUnitVO);
    public BusinessUnitVO txnActiviateBusinessUnit(BusinessUnitVO businessUnitVO);
    public BusinessUnitVO txnInActiviateBusinessUnit(BusinessUnitVO businessUnitVO);

    public CompanyVO getCompanyWithBusinessUnit(String businessUnitNames);
    public CompanyVO getBusinessUnit(String businessUnitNames);
    public List<DivisionUnitVO> getDivisionUnitList(String businessUnitNames, boolean isActivieOnly);

    public DivisionUnitVO txnCreateDivisionUnit(DivisionUnitVO divisionUnitVO);
    public DivisionUnitVO txnModifyDivisionUnit(DivisionUnitVO divisionUnitVO);
    public DivisionUnitVO txnDeleteDivisionUnit(DivisionUnitVO divisionUnitVO);
    public DivisionUnitVO txnActiviateDivisionUnit(DivisionUnitVO divisionUnitVO);
    public DivisionUnitVO txnInActiviateDivisionUnit(DivisionUnitVO divisionUnitVO);

    public BusinessUnitVO getBusinessUnitWithDivisionUnit(String divisionUnitNames);
    public CompanyVO getDivisionUnit(String divisionUnitNames);
    public List<DivisionUnitVO> getPlantUnitList(String divisionUnitNames, boolean isActivieOnly);

    public PlantUnitVO txnCreatePlantUnit(PlantUnitVO plantUnitVO);
    public PlantUnitVO txnModifyPlantUnit(PlantUnitVO plantUnitVO);
    public PlantUnitVO txnDeletePlantUnit(PlantUnitVO plantUnitVO);
    public PlantUnitVO txnActiviatePlantUnit(PlantUnitVO plantUnitVO);
    public PlantUnitVO txnInActiviatePlantUnit(PlantUnitVO plantUnitVO);

    public DivisionUnitVO getDivisonUnitWithPlantUnit(String plantUnitNames);
    public CompanyVO getPlantUnit(String plantUnitNames);

    public <T extends AbstractOrganizationsVO> List<T> getExplodedOrganizationList(String orgName, int depth, boolean activeOnly,boolean selfInclude);
    public <T extends AbstractOrganizationsVO> List<T> getOrganizationListAll(String className, boolean activeOnly);

}
